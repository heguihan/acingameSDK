//
//  PullAnimationView.h
//  BigPlayers
//
//  Created by Jun on 13-5-27.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PullAnimationView : UIView
- (void)loading;
- (void)loadFinish;
- (void)cancelLoad;
@end
