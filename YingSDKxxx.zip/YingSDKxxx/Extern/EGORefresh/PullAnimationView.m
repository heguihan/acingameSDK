//
//  PullAnimationView.m
//  BigPlayers
//
//  Created by Jun on 13-5-27.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "PullAnimationView.h"


#define kAnimationViewTag 10
#define kLoadingRect CGRectMake(20, 75+2, 21, 38)
#define kLoadFinishRect CGRectMake(20, -80+2, 21, 38)
#define kLoadCancelRect CGRectMake(20, 80+2, 21, 38)

@interface PullAnimationView (){
    
    UIImageView * animationView;
}
@property (nonatomic,retain)UIImageView * animationView;

@end

@implementation PullAnimationView
@synthesize animationView;

- (void)dealloc{
    
    [animationView release]; animationView = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        UIImageView * _imageView = [[UIImageView alloc] initWithFrame:kLoadCancelRect];
        _imageView.backgroundColor = [UIColor clearColor];
        _imageView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/pull_animation_0.png"];
        _imageView.tag = kAnimationViewTag;
        self.animationView = _imageView;
        [self addSubview:animationView];
        [_imageView release];
        
        
        NSMutableArray * imageArray = [[NSMutableArray alloc] initWithCapacity:4];
        
        [imageArray addObject:[UIImage imageNamed:@"ShuZhiZhang.bundle/pull_animation_01.png"]];
        [imageArray addObject:[UIImage imageNamed:@"ShuZhiZhang.bundle/pull_animation_02.png"]];
        [imageArray addObject:[UIImage imageNamed:@"ShuZhiZhang.bundle/pull_animation_03.png"]];
        [imageArray addObject:[UIImage imageNamed:@"ShuZhiZhang.bundle/pull_animation_04.png"]];
        
        animationView.animationDuration = 1;

        
        animationView.animationImages = imageArray;
        [animationView stopAnimating];

        
    }
    return self;
}

- (void)loading{
    
    animationView.frame = kLoadingRect;

    [animationView startAnimating];
}

- (void)loadFinish{
    
    [self loading];
    
    animationView.frame = kLoadingRect;

    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.80];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(showImageAnimationStop)];
    
    animationView.frame = kLoadFinishRect;

    [UIView commitAnimations];
    
}


- (void)cancelLoad{
    
    animationView.frame = kLoadCancelRect;
    
    [animationView stopAnimating];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
