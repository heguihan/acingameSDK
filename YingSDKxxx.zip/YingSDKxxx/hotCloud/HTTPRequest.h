//
//  HTTPRequest.h
//  hotCloud
//
//  Created by Lucas on 2019/4/15.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HTTPRequest : NSObject
@property(nonatomic,strong)NSString *appID;
@property(nonatomic,strong)NSString *appKey;
+(instancetype)shareInstance;
+(void)setupReyunKey:(NSString *)key appID:(NSString *)appID;
//第一次安装打开
+(void)requestFirstInstall;
//启动游戏
+(void)requestStartUP;
//注册
+(void)requestRegister:(NSString *)userID;
//登录成功
+(void)requestLogin:(NSString *)userID;
//支付成功
+(void)requestPayMent:(NSString *)userID andOrderId:(NSString *)orderID paytype:(NSString *)paytype currencytype:(NSString *)currencytype currencyamount:(NSString *)currencyamount;
//下单
+(void)requestGetorder:(NSString *)userID andOrderId:(NSString *)orderID currencytype:(NSString *)currencytype currencyamount:(NSString *)currencyamount;
//其他事件
+(void)requestOtherEvent:(NSString *)userID what:(NSString *)event;
//自己服务器的统计
+(void)requestShuUserID:(NSString *)userid channelid:(NSString *)channelID activeType:(NSString *)activeType;

@end

NS_ASSUME_NONNULL_END
