//
//  hotCloudHTTP.h
//  hotCloud
//
//  Created by Lucas on 2019/4/15.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface hotCloudHTTP : NSObject

+(instancetype)shareInstance;
+(void)POST:(NSString*)URL paramString:(NSString*)paramString ifSuccess:(void(^)(id response))success failure:(void(^)(NSError *error))failure;



@end

NS_ASSUME_NONNULL_END
