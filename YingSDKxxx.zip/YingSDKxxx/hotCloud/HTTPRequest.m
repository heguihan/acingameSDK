//
//  HTTPRequest.m
//  hotCloud
//
//  Created by Lucas on 2019/4/15.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import "HTTPRequest.h"
#import "hotCloudHTTP.h"
#import "Tools.h"
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonDigest.h>
#define URL_DOMAIN @"http://log.trackingio.com"

#define URL_FIRSTINSTALL @"/receive/tkio/install"
#define URL_STARTUP @"/receive/tkio/startup"
#define URL_REGISTER @"/receive/tkio/register"
#define URL_LOGIN @"/receive/tkio/loggedin"
#define URL_PAYMENG @"/receive/tkio/payment"
#define URL_ORDER @"/receive/tkio/event"
#define URL_OTHER @"/receive/tkio/event"
#define APPID @"69ab522b9c70f6e3dc671c48d29b61a2"
#define KEY @"b49db386d2bc029b0f03bc27240b3f64"
@implementation HTTPRequest

+(instancetype)shareInstance
{
    static HTTPRequest *httprequext = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        httprequext = [[HTTPRequest alloc]init];
    });
    return httprequext;
}


+(void)setupReyunKey:(NSString *)key appID:(NSString *)appID
{
    [[NSUserDefaults standardUserDefaults] setObject:key forKey:@"reyunkey"];
    [[NSUserDefaults standardUserDefaults] setObject:appID forKey:@"reyunappid"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


+(void)requestFirstInstall
{
    return;
    BOOL isFirstInstall = [Tools getFirstInstall];
    if (isFirstInstall) {
        return;
    }
    
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_FIRSTINSTALL];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    //////NSLog(@"ipv4=%@",ipv4);
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_campaignid":campaignid,
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_manufacturer":manufacturer, //设备品牌
                              @"_ryos":ryos,
                              @"_rydevicetype":rydevicetype,//设备类型
                              @"_network":network,
                              @"_resolution":resolution,  //分辨率
                              @"_op":op,
                              };
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}


+(void)requestStartUP
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_STARTUP];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              };
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}

+(void)requestRegister:(NSString *)userID
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_REGISTER];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_rydevicetype":rydevicetype,//设备类型
                              };
    
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"who":userID,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}


+(void)requestLogin:(NSString *)userID
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_LOGIN];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    //////NSLog(@"deviceID=%@",deviceid);
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    //////NSLog(@"hghxxxxdevice=%@,idfa=%@,ipv4=%@,ipv6=%@,tz=%@,rydevide=%@",deviceid,idfa,ipv4,ipv6,tz,rydevicetype);
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_rydevicetype":rydevicetype,//设备类型
                              };
    //////NSLog(@"context=%@",context);
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"who":userID,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}


+(void)requestPayMent:(NSString *)userID andOrderId:(NSString *)orderID paytype:(NSString *)paytype currencytype:(NSString *)currencytype currencyamount:(NSString *)currencyamount
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_PAYMENG];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_transactionid":orderID,
                              @"_paymenttype":paytype,   //支付类型(方式)
                              @"_currencytype":currencytype,//货币类型
                              @"_currencyamount":currencyamount,//支付金额
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_rydevicetype":rydevicetype,//设备类型
                              };
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"who":userID,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}

+(void)requestGetorder:(NSString *)userID andOrderId:(NSString *)orderID currencytype:(NSString *)currencytype currencyamount:(NSString *)currencyamount
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_ORDER];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_transactionid":orderID,
                              @"_currencytype":currencytype,//货币类型
                              @"_currencyamount":currencyamount,//支付金额
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_rydevicetype":rydevicetype,//设备类型
                              };
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"who":userID,@"what":@"order",@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}


+(void)requestOtherEvent:(NSString *)userID what:(NSString *)event
{
    return;
    NSString *url = [NSString stringWithFormat:@"%@%@",URL_DOMAIN,URL_ORDER];
    //////NSLog(@"url=%@",url);
    NSString *deviceid = [Tools getIDFA];
    NSString *campaignid = @"_default_";
    NSString *idfa = [Tools getIDFA];
    NSString *ipv4 = [Tools getipv4];
    NSString *ipv6 = [Tools getIPAddress:NO];
    NSString *tz = @"+8";
    NSString *manufacturer = [[UIDevice currentDevice] model];
    NSString *ryos = @"ios";
    NSString *rydevicetype = [Tools iphoneName];
    NSString *network = [Tools getNetconnType];
    NSString *resolution = [Tools getWidthAndHeight];
    NSString *op = [Tools getOperator];
    NSString *bundleid = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
    NSDictionary *context = @{@"_deviceid":deviceid,
                              @"_bundleid":bundleid,
                              @"_idfa":idfa,
                              @"_ip":ipv4,
                              @"_ipv6":ipv6,
                              @"_tz":tz,
                              @"_isreyundefaultevent":@"1",
                              @"_rydevicetype":rydevicetype,//设备类型
                              };
    NSString *appID = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunappid"];
    NSDictionary *dict = @{@"appid":appID,@"who":userID,@"what":event,@"context":context};
    NSString *paramstr = [self toJSONString:dict];
    //////NSLog(@"paramstr=%@",paramstr);
    [hotCloudHTTP POST:url paramString:paramstr ifSuccess:^(id  _Nonnull response) {
        //////NSLog(@"reponse=%@",response);
    } failure:^(NSError * _Nonnull error) {
        //////NSLog(@"error=%@",error);
    }];
}

//
+ (NSString *)exchangeStringWithdict:(NSDictionary *)dict
{
    //    NSArray *keysArray = [dict allKeys];
    //////NSLog(@"dict=%@",dict);

    NSString *paramStr = @"";
    for (NSString *key in dict) {
        //////NSLog(@"key=%@ andValue=%@",key,dict[key]);
        if (dict[key]==nil) {
            //////NSLog(@"kong key=%@",key);
            continue;
        }
        paramStr = [NSString stringWithFormat:@"%@%@=%@&",paramStr,key,dict[key]];
    }
    NSString *resutlStr = [paramStr substringWithRange:NSMakeRange(0, [paramStr length]-1)];
    return resutlStr;
}

+(NSString *)toJSONString:(NSDictionary *)dict
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
       NSString *str = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
       str = [NSString stringWithFormat:@"%@",str];
        return str;
}


+(void)requestShuUserID:(NSString *)userid channelid:(NSString *)channelID activeType:(NSString *)activeType
{
    NSString *url = @"http://182.254.149.87:8004/api/validUser";
    NSString *timess = [Tools getNowTimeTimestamp];
    NSString *idfa = [Tools getIDFA];
    

    NSString *signBefore = [NSString stringWithFormat:@"active_at=%@&active_type=%@&channel_id=%@&idfa=%@&uid=%@",timess,activeType,channelID,idfa,userid];
//    //////NSLog(@"signBefore=%@",signBefore);
    NSString *reyunkey = [[NSUserDefaults standardUserDefaults] objectForKey:@"reyunkey"];
    NSString *signss = [NSString stringWithFormat:@"%@&key=%@",signBefore,reyunkey];
    //////NSLog(@"signBefore=%@",signss);
    NSString *sign = [self md5String:signss];
    NSDictionary *dict=@{@"uid":userid,
                         @"idfa":idfa,
                         @"channel_id":channelID,
                         @"active_type":activeType,
                         @"active_at":timess,
                         @"sign":sign
                         };
    NSString *paramStr = [self exchangeStringWithdict:dict];
    [hotCloudHTTP POST:url paramString:paramStr ifSuccess:^(id  _Nonnull response) {
        //
        //////NSLog(@"shuresponse");
    } failure:^(NSError * _Nonnull error) {
        //
        //////NSLog(@"error=%@",error);
    } ];
}


+(NSString *) md5String:(NSString *)str
{
    const char *original_str = [str UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(original_str, strlen(original_str), result);
    NSMutableString *hash = [NSMutableString string];
    for (int i = 0; i < 16; i++)
        [hash appendFormat:@"%02X", result[i]];
    return [hash lowercaseString];
}
@end
