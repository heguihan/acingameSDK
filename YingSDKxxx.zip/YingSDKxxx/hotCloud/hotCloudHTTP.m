//
//  hotCloudHTTP.m
//  hotCloud
//
//  Created by Lucas on 2019/4/15.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import "hotCloudHTTP.h"

@implementation hotCloudHTTP
+(instancetype)shareInstance
{
    static hotCloudHTTP *network = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        network = [[super alloc] init];
    });
    
    return network;
}
+(void)POST:(NSString*)URL paramString:(NSString*)paramString ifSuccess:(void(^)(id response))success failure:(void(^)(NSError *error))failure
{
    
    //////NSLog(@"url=%@",URL);
    //////NSLog(@"param=%@",paramString);
    
    NSMutableURLRequest*request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:URL] cachePolicy:(NSURLRequestUseProtocolCachePolicy) timeoutInterval:15];
    [request setHTTPMethod:@"POST"];
    
    NSData*paraData=[paramString dataUsingEncoding:NSUTF8StringEncoding];
    
    [request setHTTPBody:paraData];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        if (data) {
            
            NSDictionary*dict=[NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingMutableLeaves) error:nil];
            //////NSLog(@"response=%@",response);
            //////NSLog(@"dict=%@",dict);
            success(dict);
            
        }else
        {
            //////NSLog(@"%@",connectionError);
            //            [HTAlertView showAlertViewWithText:bendihua(@"网络连接失败") com:nil];
            //            [HGHAlertview shareInstance]show
//            [HGHAlertview showAlertViewWithMessage:@"网络连接失败"];
//            failure(connectionError);
        }
    }];
}
@end
