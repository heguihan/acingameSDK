//
//  BPInitInfo.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-9-5.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BPAppInformation : NSObject
@property (nonatomic,retain) NSString *appId;       //游戏id
@property (nonatomic,retain) NSString *appSecretKey;
@property (nonatomic,retain) NSString *channelId;   //渠道id
@property (nonatomic,retain) NSString *clientId;    //客户id
@property (nonatomic,assign) int languageId; //语言id, 1--中文， 2----英文, 默认为中文的
@end
