//
//  BPNotificationName.h
//  BigPlayerSDK
//
//

#ifndef BigPlayerSDK_BPNotificationName_h
#define BigPlayerSDK_BPNotificationName_h

extern NSString * const BPLoginResultNotification; //登陆登出结果通知

extern NSString * const BPThirdLoginResultNotification; // 第三方登录


extern NSString * const BPPlatformExitNotification;  //退出sdk通知
extern NSString * const BPPayResultNotification;  //支付结果通知
extern NSString * const BPInitDidFinishedNotification;  //初始化完成通知

extern NSString * const BPShouldPauseSoundNotification; //游戏客户端应该暂停游戏背景音乐的通知
extern NSString * const BPShouldPlaySoundNotification; //游戏客户端可以播放游戏背景音乐的通知

extern NSString * const BPVoicePlayOverNotification;   //音频播放结束

extern NSString * const BPShareNotification; //分享通知

extern NSString * const BPBindPhoneNumberResult;// 手机号绑定结果


extern NSString * const BPChangeAccountNotification;// 账号切换



typedef enum
{
    BPInterfaceOrientationLandscape,        //横屏, 可自动翻转
    BPInterfaceOrientationProtrait,         //竖屏, 可自动翻转
    BPInterfaceOrientationProtraitDown,     //home键在下面
    BPInterfaceOrientationProtraitUp,       //home键在上面
    BPInterfaceOrientationLandscapeLeft,    //home键在左边
    BPInterfaceOrientationLandscapeRight,   //home键在右边
}BPInterfaceOrientationStatus;

#endif
