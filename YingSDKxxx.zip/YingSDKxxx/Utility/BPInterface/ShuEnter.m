//
//  ShuEnter.m
//  BigPlayerSDK
//
//
//#import "ShuEnter.h"

#import "ShuEnter.h"
#import "BigPlayerSDKBase.h"
#import "BigPlayerSDKBase+LoginAndOut.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"
#import "BigPlayerSDKBase+PlayerShare.h"




#import "BPPhoneVerityView.h"
#import "BPRegisterSelectView.h"
#import "BPHttpRequestBase.h"
#import "ShuZhiZhangIAPPurchaseClass.h"
#import "ShuZhiZhangIAPPurchaseClass.h"
#import "ShuZhiZhangOrderInfo.h"
#import "BPButtonBoard.h"
#import <StoreKit/StoreKit.h>
#import "BigPlayerSDKBase.h"
//#import "ProgressHUD.h"
#import "BPMaiweb.h"
#import "HTTPRequest.h"
#import "Tracking.h"
#import "HGHDeviceReport.h"
//hghwwwwww api入口
@interface ShuEnter ()<ASIHTTPRequestDelegate,HttpRequestBaseDelegate>
{
    ShuZhiZhangOrderInfo *orderInfoPlist;

}


@end

@implementation ShuEnter

- (instancetype)init
{
    self = [super init];
    if (self) {
        orderInfoPlist = [[ShuZhiZhangOrderInfo alloc]init];
    }
    return self;
}
+(void)getLoginInfo:(void(^)(NSDictionary*loginInfo))infoBlack
{
    [self SharedYingApplePayPlatform].loginBackBlock = ^(NSDictionary *loginInfo) {
        infoBlack(loginInfo);
    };
}

+(ShuEnter *)SharedYingApplePayPlatform{
    static ShuEnter *PlatformClass = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        PlatformClass = [[ShuEnter alloc]init];;
    });
    
    return PlatformClass;
}

+(void) BPSDKInit
{
    [[BigPlayerSDKBase getSharedBPPlatform] requestForTheSDKConfigSeting];
    [HGHDeviceReport HGHreportDeviceInfo:@{@"id":@""} ename:@"sdk_init"];
}

+(NSString *)getChannelID
{
     NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    return channelId;
}

+(void)reyunAppID:(NSString *)appID key:(NSString *)key
{

    [Tracking setPrintLog:NO];
    [Tracking initWithAppKey:key withChannelId:@"_default_"];
    
    [HTTPRequest setupReyunKey:key appID:appID];
    [HTTPRequest requestFirstInstall];
    [HTTPRequest requestStartUP];
    NSString *channelID = [self getChannelID];
    [HTTPRequest requestShuUserID:@"0" channelid:channelID activeType:@"3"];
}


//登陆
+(void) ShuZhiZhangLogin
{
    [[BigPlayerSDKBase getSharedBPPlatform] autoLoginFromDatabase];
}

+(void)reportUserInfo:(RoleUserInfo *)userInfo
{
    //    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    //  [dict setObject:[dic objectForKey:@"accountType"] forKey:@"type"];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    NSString *reportID = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"reportID"]];
    NSString *deviceID = [ShuZhiZhangUserPreferences getUUID];
    //    NSString *opType = @"2";
    NSString *ts = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    
    if ([userInfo.roleLevel isEqualToString:@""]) {
        userInfo.roleLevel = @"00";
    }
    
    [dict setObject:reportID forKey:@"id"];
    [dict setObject:appid forKey:@"appID"];
    [dict setObject:channelId forKey:@"channelID"];
    [dict setObject:deviceID forKey:@"deviceID"];
    [dict setObject:userInfo.opType forKey:@"opType"];
    [dict setObject:userInfo.roleID forKey:@"roleID"];
    [dict setObject:userInfo.roleLevel forKey:@"roleLevel"];
    [dict setObject:userInfo.roleName forKey:@"roleName"];
    [dict setObject:userInfo.serverID forKey:@"serverID"];
    [dict setObject:userInfo.serverName forKey:@"serverName"];
    [dict setObject:ts forKey:@"ts"];
    NSString *url = @"http://fshuet.acingame.com/api/analytics/userLog/report";
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSLog(@"signStr=%@",signStr);
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@/%@?%@&sign=%@",url,appid,sortStr,sign];
    NSLog(@"用户上报dict = %@,urlStr = %@",dict,urlStr);
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            if ([[data objectForKey:@"ret"] intValue]==0) {
            }else{
            }
        });
    } failure:^(NSError *error) {
        
    }];
}


//苹果支付接口 iap
+(void) ShuZhiZhangApplePayWithProductInfo:(ShuZhiZhangOrderInfo *)orderInfo
{
    ShuZhiZhangIAPPurchaseClass *applePayVC =[ShuZhiZhangIAPPurchaseClass SharedBPApplePayPlatform];
    if (!applePayVC) {
        return ;
    }
    int way = [[[NSUserDefaults standardUserDefaults] objectForKey:@"maiWay"] intValue];
    if (way==0) {
        [applePayVC  ApplePurchaseWithProductInfo:orderInfo];
    }else if (way==1){
        NSString *maidizhi = [[NSUserDefaults standardUserDefaults] objectForKey:@"maiurl"];
        BPMaiweb *maixx = [[BPMaiweb alloc]init];
        [maixx BPMaiurl:maidizhi andparms:orderInfo];
    }else{
        [applePayVC  ApplePurchaseWithProductInfo:orderInfo];
    }
}


// 上传角色信息

+(void)ShuZhiZhangUploadUserOfRoleInfo:(NSDictionary *)roleInfo{

 // typeid 平台号 1 android 2: ios
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
  //  NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    [dict setObject:channelId forKey:@"channelid"];
    [dict setObject:[ShuZhiZhangUserPreferences CurrentYingID] forKey:@"yingid"];
    [dict setObject:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"userid"];
    [dict setObject:[roleInfo objectForKey:@"roleId"] forKey:@"roleid"];
    [dict setObject:[roleInfo objectForKey:@"roleName"] forKey:@"rolename"];
    [dict setObject:appid forKey:@"appid"];
    [dict setObject:[roleInfo objectForKey:@"level"] forKey:@"level"];
    [dict setObject:[roleInfo objectForKey:@"viplevel"] forKey:@"viplevel"];
    [dict setObject:@"2" forKey:@"typeid"];
    [dict setObject:dateStr forKey:@"ts"];
    
    
        NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
      // NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];

        NSString * signStr = [NSString stringWithFormat:@"%@%@",[ShuZhiZhangUserPreferences CurrentYingID],@"EI9HWxH1ogMq8xnu"];
        NSString *sign = [ShuZhiZhangUtility md5String:signStr];
        NSString *urlStr = [NSString stringWithFormat:@"%@%@/?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"roleinfo",sortStr,sign];
        
        [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if (data.count==0) {

                    return ;
                }
                
                ////////NSLog(@"上传 = %@",data);
                if ([[data objectForKey:@"ret"] intValue]==0) {
                    
                    
                    
                }else{
                    
                    
                }
            });
        } failure:^(NSError *error) {
            
        }];
        
        
    }




+(void)ShuZhiZhangShouldShowQQSinaFLag:(BOOL)flag{

    [BigPlayerSDKBase getSharedBPPlatform].BPShouldShowQQSinaFLag = flag;

}



/**
 * 接入第三方平台需调用这个接口
 * 在第三方登录成功之后调用此接口，传入第三方的uid
 */
+ (void)initAccount:(NSString *)uid{
    
//    [[BigPlayerSDKBase getSharedBPPlatform] BPGetWithUid:uid];
    
}

+ (void)ShuZhiZhangCheckGameUpdate{
    
    //检查更新
    [[BigPlayerSDKBase getSharedBPPlatform] checkGameVersionUpdate];
    
}



//是否已经登陆了
+(BOOL) ShuZhiZhangIsLogined
{
    NSTimeInterval currentTime = [[NSDate date] timeIntervalSince1970];
    double expiredTime = currentTime - [[ShuZhiZhangUserPreferences lastLoginTime] doubleValue];
    if([[ShuZhiZhangUserPreferences CurrentUserID] intValue] > 0 && expiredTime < 3*24*3600)
    {
        return YES;
        ////////NSLog(@"已经登陆");
    }
    return NO;
}


//注销
+(void) ShuZhiZhangLogout
{
    [[BigPlayerSDKBase getSharedBPPlatform] BPLogout];
}

//关闭地理位置的获取
+(void) ShuZhiZhangCloseAddressLocation
{
    [BigPlayerSDKBase getSharedBPPlatform].BPCloseAddressLocation = YES;
}

//设置为debug模式
+(void) ShuZhiZhangSetDebugMode
{
    
}

//设置屏幕的方向
+(void) ShuZhiZhangSetScreenOrientation:(BPInterfaceOrientationStatus)orientation
{
    [BigPlayerSDKBase getSharedBPPlatform].bpOrientation = orientation;
    
}



#pragma mark -----------获取用户数据------------

//获得登录用户的uid
+(NSString *) ShuZhiZhangGetUid
{
    return [ShuZhiZhangUserPreferences CurrentUserID];
}

//获得登录用户的昵称
+(NSString *) ShuZhiZhangGetNickName
{
    return [ShuZhiZhangUserPreferences CurrentNickname];
}

//获得登录用户的token
+(NSString *) ShuZhiZhangGetToken
{
    return [ShuZhiZhangUserPreferences getCurrentToken];
    
}

//获得登录用户的详细信息
+(NSMutableDictionary *) ShuZhiZhangGetUserInfoDetail
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    NSMutableDictionary *userInfoDic = [[userInfoTable queryForDataWithSql:[NSString stringWithFormat:@"select birthday,city,image,level,nickname,province,sex,signature,token,uid from BPUserInfo where uid = '%@'",[ShuZhiZhangUserPreferences CurrentUserID]]] objectAtIndex:0];
//    [userInfoTable release];
    return userInfoDic;
    

}


@end
