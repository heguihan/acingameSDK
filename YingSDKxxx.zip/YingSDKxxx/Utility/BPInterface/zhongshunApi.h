//
//  zhongshunApi.h
//  BigPlayerSDK
//
//

#import <Foundation/Foundation.h>
#import "YingOrderInfo.h"
#import "BPGameRoleInfo.h"
#import "BPNotificationName.h"

/*
 *   YingSDK版本号  1
 */

@interface ShuEnter : NSObject

@property(nonatomic,assign)BOOL receiptValid;


/**
 * 登陆 (显示登录框)
 */
+(void) YingLogin;

/**
 * 是否已经登陆 [尚无]
 *
 * 返回值 :  YES 已登陆    NO  未登陆
 */
+(BOOL) YingIsLogined;

/**
 * 注销 [尚无]
 */
+(void) YingLogout;

+(void) YingApplePayWithProductInfo:(YingOrderInfo *)orderInfo;



/**
 * 设置屏幕的方向 [尚无]
 *
 *  BPInterfaceOrientationStatus
 *  BPInterfaceOrientationLandscape        横屏, 可自动翻转
 *  BPInterfaceOrientationProtrait         竖屏, 可自动翻转
 *  BPInterfaceOrientationProtraitDown     home键在下面
 *  BPInterfaceOrientationProtraitUp       home键在上面
 *  BPInterfaceOrientationLandscapeLeft    home键在左边
 *  BPInterfaceOrientationLandscapeRight   home键在右边
 */

+(void) YingSetScreenOrientation:(BPInterfaceOrientationStatus)orientation;


/**
 *  上传玩家角色信息
 * 参数:
 *  roleId    角色ID
 *  roleName  角色名
 *  level     玩家等级 
 *  viplevel  玩家vip等级
 */



+(void)YingUploadUserOfRoleInfo:(NSDictionary *)roleInfo;
















#pragma mark ---get User Info-------
/**
 * 获得登录用户的uid
 *
 * 返回值   :    获取的用户的UID
 */
+(NSString *) YingGetUid;

/**
 * 获得登录用户的token
 *
 * 返回值    :   获取到的用户的token
 */
+(NSString *) YingGetToken;

/**
 * 获得登录用户的详细信息
 *
 * 返回值    :   用户的信息
 */
+(NSMutableDictionary *) YingGetUserInfoDetail;



#pragma -----用户中心功能球体---待扩展-------
/**
 * 显示悬浮球的起始位置 [尚无]
 *
 * X     :   悬浮球起始x坐标
 * Y     :   悬浮球起始y坐标
 */
+(void) YingShowPendant:(int)x Position_Y:(int)y;


/**
 * 隐藏功能球
 */
+(void) YingHidePendant;

/*
 *  接口类的单例子模式 
 */
+(ShuEnter *)SharedYingApplePayPlatform;

@end
