//
//  UserInfo.m
//  chachaSDK
//
//  Created by Lucas on 2019/8/20.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import "RoleUserInfo.h"

@implementation RoleUserInfo
+(instancetype)shareInstance
{
    static RoleUserInfo *user = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        user = [[RoleUserInfo alloc]init];
    });
    return user;
}

@end
