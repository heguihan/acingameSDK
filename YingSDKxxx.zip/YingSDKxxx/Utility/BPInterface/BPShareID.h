//
//  BPShareID.h
//  BigPlayerSDK
//
//  Created by lily on 14-3-11.
//  Copyright (c) 2014年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BPShareID : NSObject

@property (nonatomic,retain) NSString *QQAppId;        //QQ id
@property (nonatomic,retain) NSString *WeChatAppId;    //微信 id
@property (nonatomic,retain) NSString *SinakAppKey;    //新浪 id
@property (nonatomic,retain) NSString *SinakAppSecret; //新浪
@property (nonatomic,retain) NSString *SinakAppURI; //新浪

@end
