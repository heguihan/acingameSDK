//
//  BPShareID.m
//  BigPlayerSDK
//
//  Created by lily on 14-3-11.
//  Copyright (c) 2014年 John Cheng. All rights reserved.
//

#import "BPShareID.h"

@implementation BPShareID
@synthesize QQAppId;
@synthesize WeChatAppId;
@synthesize SinakAppKey;
@synthesize SinakAppSecret;
@synthesize SinakAppURI;

- (void)dealloc
{
    [QQAppId release];          QQAppId = Nil;
    [WeChatAppId release];      WeChatAppId = Nil;
    [SinakAppKey release];      SinakAppKey = Nil;
    [SinakAppSecret release];   SinakAppSecret = nil;
    [SinakAppURI release];      SinakAppURI = Nil;
    
    [super dealloc];
}

@end
