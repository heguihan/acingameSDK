//
//  UserInfo.h
//  chachaSDK
//
//  Created by Lucas on 2019/8/20.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RoleUserInfo : NSObject
+(instancetype)shareInstance;
@property(nonatomic,strong)NSString *roleID;
@property(nonatomic,strong)NSString *roleLevel;
@property(nonatomic,strong)NSString *roleName;
@property(nonatomic,strong)NSString *serverID;
@property(nonatomic,strong)NSString *serverName;
@property(nonatomic,strong)NSString *opType; //类型: 2-创建角色,3-等级提升 5-进入游戏


@end

NS_ASSUME_NONNULL_END
