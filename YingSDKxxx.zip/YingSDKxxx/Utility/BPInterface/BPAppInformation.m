//
//  BPInitInfo.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-9-5.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import "BPAppInformation.h"

@implementation BPAppInformation
@synthesize appId;
@synthesize channelId;
@synthesize clientId;
@synthesize languageId;
@synthesize appSecretKey;

-(void) dealloc
{
    [appId release];        appId = nil;
    [appSecretKey release]; appSecretKey = nil;
    [channelId release];    channelId = nil;
    [clientId release];     clientId = nil;
    [super dealloc];
}
@end
