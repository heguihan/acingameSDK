//
//  ShuEnter.h
//  BigPlayerSDK
//
//

#import <Foundation/Foundation.h>
#import "ShuZhiZhangOrderInfo.h"
#import "BPGameRoleInfo.h"
#import "BPNotificationName.h"
#import "RoleUserInfo.h"
/*
 *   ShuZhiZhangSDK版本号  1
 */

@interface ShuEnter : NSObject
@property (nonatomic,copy)void(^loginBackBlock)(NSDictionary*loginInfo);
@property(nonatomic,assign)BOOL receiptValid;

+(void) BPSDKInit;
/**
 * 登陆 (显示登录框)
 */
+(void)reyunAppID:(NSString *)appID key:(NSString *)key;
+(void) ShuZhiZhangLogin;
+(void)getLoginInfo:(void(^)(NSDictionary*loginInfo))infoBlack;
+(NSString *)getChannelID;
/**
 * 是否已经登陆 [尚无]
 *
 * 返回值 :  YES 已登陆    NO  未登陆
 */
+(BOOL) ShuZhiZhangIsLogined;

/**
 * 注销 [尚无]
 */
//上传角色信息
+(void)reportUserInfo:(RoleUserInfo *)userInfo;
+(void) ShuZhiZhangLogout;

+(void) ShuZhiZhangApplePayWithProductInfo:(ShuZhiZhangOrderInfo *)orderInfo;



/**
 * 设置屏幕的方向 [尚无]
 *
 *  BPInterfaceOrientationStatus
 *  BPInterfaceOrientationLandscape        横屏, 可自动翻转
 *  BPInterfaceOrientationProtrait         竖屏, 可自动翻转
 *  BPInterfaceOrientationProtraitDown     home键在下面
 *  BPInterfaceOrientationProtraitUp       home键在上面
 *  BPInterfaceOrientationLandscapeLeft    home键在左边
 *  BPInterfaceOrientationLandscapeRight   home键在右边
 */

+(void) ShuZhiZhangSetScreenOrientation:(BPInterfaceOrientationStatus)orientation;


///**
// *  上传玩家角色信息
// * 参数:
// *  roleId    角色ID
// *  roleName  角色名
// *  level     玩家等级
// *  viplevel  玩家vip等级
// */
//
//
//
//+(void)ShuZhiZhangUploadUserOfRoleInfo:(NSDictionary *)roleInfo;
















#pragma mark ---get User Info-------
/**
 * 获得登录用户的uid
 *
 * 返回值   :    获取的用户的UID
 */
+(NSString *) ShuZhiZhangGetUid;

/**
 * 获得登录用户的token
 *
 * 返回值    :   获取到的用户的token
 */
+(NSString *) ShuZhiZhangGetToken;

/**
 * 获得登录用户的详细信息
 *
 * 返回值    :   用户的信息
 */
+(NSMutableDictionary *) ShuZhiZhangGetUserInfoDetail;



#pragma -----用户中心功能球体---待扩展-------
/**
 * 显示悬浮球的起始位置 [尚无]
 *
 * X     :   悬浮球起始x坐标
 * Y     :   悬浮球起始y坐标
 */
+(void) ShuZhiZhangShowPendant:(int)x Position_Y:(int)y;


/**
 * 隐藏功能球
 */
+(void) ShuZhiZhangHidePendant;

/*
 *  接口类的单例子模式 
 */
+(ShuEnter *)SharedYingApplePayPlatform;

@end
