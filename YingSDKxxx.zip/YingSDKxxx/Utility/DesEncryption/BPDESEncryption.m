//
//  DESEncryption.m
//  BigPlayers
//
//  Created by Jun on 13-4-9.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPDESEncryption.h"

#import <CommonCrypto/CommonCryptor.h>

#import "GTMBase64hgh.h"

#define GH_DES_KEY @"7fdc4b8e"

@implementation BPDESEncryption

#pragma mark - DES加密

+ (NSData *)DESEncrypt:(NSData *)data WithKey:(NSString *)key
{
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSUInteger dataLength = [data length];
    
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCBlockSizeDES,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        
        return [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
    }
    
    free(buffer);
    return nil;
}




#pragma mark - DES解密
+ (NSData *)DESDecrypt:(NSData *)data WithKey:(NSString *)key
{
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSUInteger dataLength = [data length];
    
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCBlockSizeDES,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesDecrypted);
    
    if (cryptStatus == kCCSuccess) {
        
        return [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
    }
    
    free(buffer);
    return nil;
}




#pragma mark - DES加密封装
+ (NSString *)desEncodeWithText:(NSString *)text{
    if((NSNull *)text == [NSNull null] || text.length<1)
    {
        return nil;
    }
    BOOL isEncode = YES;
    
    if (isEncode){
        
        NSData * data = [text dataUsingEncoding:NSUTF8StringEncoding];
        NSData * encode_DES = [self DESEncrypt:data WithKey:GH_DES_KEY];
        
        NSData * encode_base64 = [GTMBase64hgh encodeData:encode_DES];
        NSString * base64String = [[[NSString alloc] initWithData:encode_base64 encoding:NSUTF8StringEncoding] autorelease];
        
        return base64String;
        
    }else{
        return text;
    }
}




#pragma mark - DES解密封装
+ (NSString *)desDecodeWithText:(NSString *)text{
    
    BOOL isEncode = YES;
    
    if (isEncode){
        
        NSData * base64data = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
        NSData * decode_base64 = [GTMBase64hgh decodeData:base64data];
        
        NSData * decode_DES = [self DESDecrypt:decode_base64 WithKey:GH_DES_KEY];
        NSString * string = [[[NSString alloc] initWithData:decode_DES encoding:NSUTF8StringEncoding] autorelease];
        
        return string;
        
    }else{
        return text;
    }
}


@end
