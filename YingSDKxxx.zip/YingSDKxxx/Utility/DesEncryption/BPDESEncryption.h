//
//  DESEncryption.h
//  BigPlayers
//
//  Created by Jun on 13-4-9.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BPDESEncryption : NSObject

// DES加密
+ (NSString *)desEncodeWithText:(NSString *)text;


// DES解密
+ (NSString *)desDecodeWithText:(NSString *)text;

@end
