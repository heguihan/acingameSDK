//
//  SDKConfig.h
//  ShuZhiZhangSDK
//
//  Created by Lucas on 2019/11/6.
//  Copyright © 2019 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SDKConfig : NSObject
+(NSString *)getSDKVersion;
@end

NS_ASSUME_NONNULL_END
