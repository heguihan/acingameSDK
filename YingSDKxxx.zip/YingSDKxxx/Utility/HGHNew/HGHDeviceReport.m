//
//  HGHDeviceReport.m
//  ShuZhiZhangSDK
//
//  Created by Lucas on 2019/11/5.
//  Copyright © 2019 John Cheng. All rights reserved.
//

#import "HGHDeviceReport.h"
#import "HGHHttpRequest.h"
#import "Tools.h"
#import "HGHUUID.h"
#import "SDKConfig.h"
#import "ShuZhiZhangUserPreferences.h"
#import "HGHExchange.h"
@implementation HGHDeviceReport

+(void)HGHreportDeviceInfo:(NSDictionary *)deviceInfo ename:(NSString *)ename
{
    NSLog(@"deviceInfo=%@",deviceInfo);
    NSString *channelID = [ShuZhiZhangUserPreferences CurrentChannelId];
    NSString *deviceID = [HGHUUID getUUID];
    NSString *deviceDPI = [Tools getWidthAndHeight];
    NSString *deviceType = [Tools iphoneName];
    NSString *imei = [HGHUUID getUUID];
    NSString *deviceOS = @"2";
    NSString *device_osver = [Tools SystemVersion];
    NSString *mac = [Tools macAddress];
    NSString *ipadd = [Tools deviceWANIPAdress];
    NSString *network = [Tools getNetconnType];
    NSString *sdkver = [SDKConfig getSDKVersion];
    NSString *dm_appid = [ShuZhiZhangUserPreferences CurrentDM_AppID];
    NSString *dm_appkey = [ShuZhiZhangUserPreferences CurrentDM_appKey];
    NSString *signBefore = [NSString stringWithFormat:@"%@%@",dm_appid,dm_appkey];
    NSString *sign = [HGHExchange md5:signBefore];
    NSDictionary *dict = [NSDictionary dictionary];
    if ([ename isEqualToString:@"sdk_init"]) {
        dict = @{@"ename":ename,
                 @"app_id":dm_appid,
                 @"channel_id":channelID,
                 @"device_id":deviceID,
                 @"device_dpi":deviceDPI,
                 @"device_type":deviceType,
                 @"device_os":deviceOS,
                 @"device_osver":device_osver,
                 @"mac":mac,
                 @"ip":ipadd,
                 @"newwork":network,
                 @"sdkver":sdkver,
                 @"sign":sign
                 };
    }else{
        dict = @{@"ename":ename,
                 @"app_id":dm_appid,
                 @"channel_id":channelID,
                 @"userid":[NSString stringWithFormat:@"%@",deviceInfo[@"id"]],
                 @"device_id":deviceID,
                 @"device_dpi":deviceDPI,
                 @"device_type":deviceType,
                 @"device_os":deviceOS,
                 @"device_osver":device_osver,
                 @"mac":mac,
                 @"ip":ipadd,
                 @"newwork":network,
                 @"sdkver":sdkver,
                 @"sign":sign
                 };
    }
    NSLog(@"dict=%@",dict);
    [HGHHttpRequest POSTNEW:GLOBAL_DEVCIE_API_URL paramString:dict ifSuccess:^(id  _Nonnull response) {
        NSLog(@"response=%@",response);
    } failure:^(NSError * _Nonnull error) {
        NSLog(@"xxxx");
    }];
}

@end
