//
//  SDKConfig.m
//  ShuZhiZhangSDK
//
//  Created by Lucas on 2019/11/6.
//  Copyright © 2019 John Cheng. All rights reserved.
//

#import "SDKConfig.h"

@implementation SDKConfig

+(NSString *)getSDKVersion
{
    return @"2.1.0";
}
@end
