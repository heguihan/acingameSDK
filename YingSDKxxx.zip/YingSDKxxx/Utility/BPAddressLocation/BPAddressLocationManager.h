//
//  BPAddressLocationManager.h
//  BigPlayers
//
//  Created by John Cheng on 13-9-13.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
 #import <CoreLocation/CoreLocation.h>

@protocol BPAddressLocationDelegate <NSObject>
@optional
-(void)DidGetLocalLatitudeLongitude:(CLLocation *)aLoc;
-(void)GetLocalLatitudeLongitudeFailedWithError:(NSError *)error;

-(void)DidGetLocalProviceCity:(CLPlacemark *)placemark;

@end

@interface BPAddressLocationManager : NSObject <CLLocationManagerDelegate>
{
    id<BPAddressLocationDelegate> delegate;
    CLLocationManager *locationManager;
    
    BOOL getCityFlag;
}
@property (nonatomic,assign) id<BPAddressLocationDelegate> delegate;

-(id) initWithDelegate:(id)delegate_t getCityFlag:(BOOL) getCity;
@end
