//
//  BPAddressLocationManager.m
//  BigPlayers
//
//  Created by John Cheng on 13-9-13.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPAddressLocationManager.h"

@implementation BPAddressLocationManager
@synthesize delegate;

-(void) dealloc
{
    [locationManager release];      locationManager = nil;
    [super dealloc];
}

-(id) initWithDelegate:(id)delegate_t getCityFlag:(BOOL) getCity
{
    if(self = [super init])
    {
//        if (![CLLocationManager locationServicesEnabled]) 
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.distanceFilter = kCLDistanceFilterNone;
        [locationManager startUpdatingLocation];
        self.delegate = delegate_t;
        getCityFlag = getCity;
    }
    return self;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [locationManager stopUpdatingLocation];
    NSString *latitudeString=[NSString stringWithFormat:@"%g",newLocation.coordinate.latitude];
    NSString *longitudeString=[NSString stringWithFormat:@"%g",newLocation.coordinate.longitude];
//    BPLog(@"%@---%@",latitudeString,longitudeString);
    [[NSUserDefaults standardUserDefaults] setObject:latitudeString forKey:@"BPLatitude"];
    [[NSUserDefaults standardUserDefaults] setObject:longitudeString forKey:@"BPLongitude"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    if(getCityFlag)
    {
        // 获取当前所在的城市名
        CLGeocoder *geocoder = [[[CLGeocoder alloc] init] autorelease];
        [geocoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *array, NSError *error)
         {
             if (array.count > 0)
             {
                 CLPlacemark *placemark = [array objectAtIndex:0];
                 if(delegate)
                 {
                     [delegate DidGetLocalProviceCity:placemark];
                 }
                 [[NSUserDefaults standardUserDefaults] setObject:placemark.locality forKey:@"BPCity"];
                 [[NSUserDefaults standardUserDefaults] setObject:placemark.administrativeArea forKey:@"BPPrivice"];
                 [[NSUserDefaults standardUserDefaults] setObject:placemark.subLocality forKey:@"BPDistrict"];
                 NSString *address = [NSString stringWithFormat:@"%@ %@",[[NSUserDefaults standardUserDefaults] objectForKey:@"BPCity"],[[NSUserDefaults standardUserDefaults] objectForKey:@"BPDistrict"]];
                 [[NSUserDefaults standardUserDefaults] setObject:address forKey:@"BPAddressDetail"];
                 [[NSUserDefaults standardUserDefaults] synchronize];
             }
             else if (error == nil && [array count] == 0)
             {
                 BPLog(@"No results were returned.");
             }
             else if (error != nil)
             {
//                 BPLog(@"An error occurred = %@", error);
             }
         }];
    }

}


@end
