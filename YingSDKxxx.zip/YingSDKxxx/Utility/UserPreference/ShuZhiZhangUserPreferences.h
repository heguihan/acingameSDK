//
//  UserPreferences.h
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BPGameRoleInfo.h"
#import "BPAppInformation.h"

@interface ShuZhiZhangUserPreferences : NSObject

//设置用户的信息
+(void) setUserInfoWithDic:(NSMutableDictionary *)dic;

//更新用户的信息，比如修改信息之后
+(void) updateUserInfoWithDic:(NSMutableDictionary *)dic;

//清除用户信息－－注销的时候
+(void) clearUserInfo;

//当前ShuZhiZhangID
+(NSString *) CurrentYingID;

//当前用户ID
+(NSString *) CurrentUserID;
+(void) setCurrentUserID:(NSString *)_userID;

//当前帐号
+(NSString *) CurrentAccount;
+(void) setCurrentAccount:(NSString *)_Account;

//获取玩家头像
+(NSString *) currentUserHeadURLStr;

//当前昵称
+(NSString *) CurrentNickname;
+(void) setCurrentNickname:(NSString *)_nickname;


//当前帐号类型
+(NSString *) CurrentAccountType;
+(void) setCurrentAccountType:(NSString *)_AccountType;


//当前token
+(NSString *) getCurrentToken;

//当前新浪
+(NSString *) CurrentSinaWeibo;
+(void) setCurrentSinaWeibo:(NSString *)sinaWeibo;

//当前qq
+(NSString *) CurrentQQAccount;
+(void) setCurrentQQAccount:(NSString *)qqAccount;

//当前腾迅
+(NSString *) CurrentTencentWeibo;
+(void) setCurrentTencentWeibo:(NSString *)tencentWeibo;


//当前游戏Id
+(NSString *) CurrentGameId;
+(void) setCurrentGameId:(NSString *)gameId;


//当前第三方UID
+(NSString *) CurrentThirdUid;
+(void) setCurrentThirdUid:(NSString *)uid;

#pragma mark ----game info
//当前客户Id
+(NSString *) CurrentClientId;

//初始化后，保存游戏信息
+(void) setCurrentGameInfoWhenInit:(BPAppInformation *)appInfo;

// 注销
+ (void)logoutCurrentUser;


//获取上次登陆时间
+(NSString *) lastLoginTime;

#pragma mark ----role info
//设置角色信息
+(void) setGameRoleInfo:(BPGameRoleInfo *)roleInfo;

//获取当前服务器id
+(NSString *) currentServerId;

//获取当前角色id
+(NSString *) currentRoleId;

//获取当前角色名称
+(NSString *) currentRoleName;

#pragma ------mark servicePhone and other info------
//设置客服电话等信息
+(void) setServicePhoneAndOtherInfo:(NSMutableDictionary *)dic;

//获取当前客服电话
+(NSString *) currentAccountServicePhone;

//获取客服的聊天id
+(NSString *) currentChatId;






//当前渠道Id
+(void) setCurrentChannelId:(NSString *)channelId;
//当前渠道Id
+(NSString *) CurrentChannelId;

//DM后台上报的appid和appkey
+(NSString *)CurrentDM_AppID;
+(NSString *)CurrentDM_appKey;


//当前网络环境
+(void)setCurrentEnvironment:(NSString *)environment;  //当前网络环境
+(NSString *) CurrentEnvironment;

// app id
+(void) setCurrentAppID:(NSString *)appId;
//当前appidId
+(NSString *) CurrentAppId;

// 当前appsecret
+(void) setCurrentAppSeceretKey:(NSString *)appSecret;

+(NSString *) CurrentAppSecret;

+(NSString *)getUUID;


@end
