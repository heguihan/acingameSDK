

#import "ShuZhiZhangUserPreferences.h"

#define UP_USER_ID_KEY @"BPUserID"
#define UP_ACCOUNT_KEY @"BPAccount"
#define UP_NICKNAME_KEY @"BPNickname"
#define UP_USERHEADURL_KEY @"BPUserHeadUrl"
#define UP_ACCOUNT_TYPE_KEY @"BPAccountType"
#define UP_SINA_KEY @"BPSinaKey"
#define UP_TENCENT_KEY @"BPTencent"
#define UP_QQ_ACCOUNT_KEY @"BPQQAcount"
#define UP_GAME_ID_KEY @"BPGameId"
#define UP_THIRD_UID_KEY @"BPThirdUid"
#define UP_Client_ID_KEY @"BPClientId"
#define UP_TOKEN_KEY @"BPToken"
#define UP_LastLoginTime_key @"BPLastLoginTime"
#define UP_ChatId_Key @"BPChatId"
#define UP_ServerId_Key @"BPServerId"
#define UP_RoleId_Key @"BPRoleId"
#define UP_RoleName_Key @"BPRoleName"
#define UP_PhoneNumber_key @"phoneNumber"


#define UP_CHANNEL_ID_KEY @"BPChannelId"
#define UP_App_ID_KEY @"BPAppId"
#define UP_appSecret_KEY @"BPAppSecret"
#define UP_Environment_KEY @"BPEnvironment"
#define UP_YingID_KEY @"BPYingID"
#define  KEYCHAIN @"hghgonghuisdk"


@implementation ShuZhiZhangUserPreferences

//设置用户的信息
+(void) setUserInfoWithDic:(NSMutableDictionary *)dic
{
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"userID"] forKey:UP_USER_ID_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"username"] forKey:UP_ACCOUNT_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"password"] forKey:@"BPUserPasswor_now"];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nickname"] forKey:UP_NICKNAME_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"accountType"] forKey:UP_ACCOUNT_TYPE_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"token"] forKey:UP_TOKEN_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"yingID"] forKey:UP_YingID_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"qqweibo"] forKey:UP_TENCENT_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"qqAccount"] forKey:UP_QQ_ACCOUNT_KEY];
//    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"phoneNumber"] forKey:UP_PhoneNumber_key];

    
    [[NSUserDefaults standardUserDefaults ] setObject:[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]] forKey:UP_LastLoginTime_key]; //[dic objectForKey:@"time"]
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"image"] forKey:UP_USERHEADURL_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//更新用户的信息，比如修改信息之后
+(void) updateUserInfoWithDic:(NSMutableDictionary *)dic
{
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nickname"] forKey:UP_NICKNAME_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"image"] forKey:UP_USERHEADURL_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


//清除用户信息－－注销的时候
+(void) clearUserInfo
{
    [[NSUserDefaults standardUserDefaults ] setObject:@"-1" forKey:UP_USER_ID_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:@"-1" forKey:UP_ACCOUNT_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:@"-1" forKey:UP_NICKNAME_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:@"-1" forKey:UP_ACCOUNT_TYPE_KEY];
    [[NSUserDefaults standardUserDefaults ] setObject:@"-1" forKey:UP_TOKEN_KEY];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//当前ShuZhiZhangID
+(NSString *) CurrentYingID
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_YingID_KEY];
    if(!str)
    {
        return @"";
    }
    return str;
}


//当前用户ID
+(NSString *) CurrentUserID
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_USER_ID_KEY];
    if(!str)
    {
        return @"";
    }
    return str;
}

+(void) setCurrentUserID:(NSString *)_userID
{
    [[NSUserDefaults standardUserDefaults ] setObject:_userID forKey:UP_USER_ID_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//获取玩家头像
+(NSString *) currentUserHeadURLStr
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_USERHEADURL_KEY];
    if(!str)
    {
        return @"";
    }
    return str;
}

//当前帐号
+(NSString *) CurrentAccount
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_ACCOUNT_KEY];
}

+(void) setCurrentAccount:(NSString *)_Account
{
    [[NSUserDefaults standardUserDefaults ] setObject:_Account forKey:UP_ACCOUNT_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



//当前昵称
+(NSString *) CurrentNickname
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_NICKNAME_KEY];
    if(!str)
    {
        return @"";
    }
    return str;
}

+(void) setCurrentNickname:(NSString *)_nickname
{
    [[NSUserDefaults standardUserDefaults ] setObject:_nickname forKey:UP_NICKNAME_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


//当前帐号类型
+(NSString *) CurrentAccountType
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_ACCOUNT_TYPE_KEY];
}

+(void) setCurrentAccountType:(NSString *)_AccountType
{
    [[NSUserDefaults standardUserDefaults ] setObject:_AccountType forKey:UP_ACCOUNT_TYPE_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


//当前新浪
+(NSString *) CurrentSinaWeibo
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_SINA_KEY];
}

+(void) setCurrentSinaWeibo:(NSString *)sinaWeibo
{
    [[NSUserDefaults standardUserDefaults ] setObject:sinaWeibo forKey:UP_SINA_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


//当前腾迅
+(NSString *) CurrentTencentWeibo
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_TENCENT_KEY];
}

+(void) setCurrentTencentWeibo:(NSString *)tencentWeibo
{
    [[NSUserDefaults standardUserDefaults ] setObject:tencentWeibo forKey:UP_TENCENT_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//当前qq
+(NSString *) CurrentQQAccount
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_QQ_ACCOUNT_KEY];
}

+(void) setCurrentQQAccount:(NSString *)qqAccount
{
    [[NSUserDefaults standardUserDefaults ] setObject:qqAccount forKey:UP_QQ_ACCOUNT_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark -----game info-------
//当前游戏Id
+(NSString *) CurrentGameId
{
    //////////NSLog(@"当前游戏ID ========= %@",[[NSUserDefaults standardUserDefaults] objectForKey:UP_GAME_ID_KEY]);
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_GAME_ID_KEY];
}

+(void) setCurrentGameId:(NSString *)gameId
{
    [[NSUserDefaults standardUserDefaults ] setObject:gameId forKey:UP_GAME_ID_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(NSString *) CurrentClientId
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_Environment_KEY];
}




/******************************************************88*************************************************/


//当前渠道Id
+(void) setCurrentChannelId:(NSString *)channelId
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *channelIDhgh = [dic objectForKey:@"cahnnelID"];
    [[NSUserDefaults standardUserDefaults ] setObject:channelIDhgh forKey:UP_CHANNEL_ID_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//当前渠道Id
+(NSString *) CurrentChannelId
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *channelIDhgh = [dic objectForKey:@"cahnnelID"];
    return channelIDhgh;
}



//当前网络环境
+(void)setCurrentEnvironment:(NSString *)environment{

    [[NSUserDefaults standardUserDefaults ] setObject:environment forKey:UP_Environment_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
//当前网络环境
+(NSString *) CurrentEnvironment
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_Environment_KEY];
}
// 应用ID
+(void) setCurrentAppID:(NSString *)appId
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *appidhgh = [dic objectForKey:@"appID"];
    [[NSUserDefaults standardUserDefaults ] setObject:appidhgh forKey:UP_App_ID_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//当前应用Id
+(NSString *) CurrentAppId
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *appidhgh = [dic objectForKey:@"appID"];
    return appidhgh;
}

// 当前appsecret
+(void) setCurrentAppSeceretKey:(NSString *)appSecret
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *appSecrethgh = [dic objectForKey:@"appSecretKey"];
    [[NSUserDefaults standardUserDefaults ] setObject:appSecrethgh forKey:UP_appSecret_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(NSString *) CurrentAppSecret
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *appSecrethgh = [dic objectForKey:@"appSecretKey"];
    return appSecrethgh;
}


//dm_app_id
+(NSString *)CurrentDM_AppID
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *dm_appID = [dic objectForKey:@"dm_app_id"];
    return dm_appID;
}
//dm_appkey
+(NSString *)CurrentDM_appKey
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    NSString *dm_appkey = [dic objectForKey:@"dm_appkey"];
    return dm_appkey;
}




/******************************************************88*************************************************/






//初始化后，保存游戏信息
+(void) setCurrentGameInfoWhenInit:(BPAppInformation *)appInfo
{
    if(appInfo.appId && appInfo.appId.length>3)
    [[NSUserDefaults standardUserDefaults ] setObject:appInfo.appId forKey:UP_App_ID_KEY];
    
    if(appInfo.channelId && appInfo.channelId.length>3)
    [[NSUserDefaults standardUserDefaults ] setObject:appInfo.channelId forKey:UP_CHANNEL_ID_KEY];
    
    if(appInfo.appSecretKey && appInfo.appSecretKey.length>3)
    [[NSUserDefaults standardUserDefaults ] setObject:appInfo.clientId forKey:UP_appSecret_KEY];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//当前token
+(NSString *) getCurrentToken
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_TOKEN_KEY];
}

+(void) setCurrentToken:(NSString *)token
{
    [[NSUserDefaults standardUserDefaults ] setObject:token forKey:UP_TOKEN_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//获取上次登陆时间
+(NSString *) lastLoginTime
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_LastLoginTime_key];
}

#pragma mark ----role info-------
//设置角色信息
+(void) setGameRoleInfo:(BPGameRoleInfo *)roleInfo
{
//    [[NSUserDefaults standardUserDefaults ] setObject:[NSNumber numberWithInt:roleInfo.serverId] forKey:UP_ServerId_Key];
//    [[NSUserDefaults standardUserDefaults ] setObject:roleInfo.roleId forKey:UP_RoleId_Key];
//    [[NSUserDefaults standardUserDefaults ] setObject:roleInfo.roleName forKey:UP_RoleName_Key];
//    [[NSUserDefaults standardUserDefaults] synchronize];
}

//获取当前服务器id
+(NSString *) currentServerId
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_ServerId_Key];
    if(!str)
    {
        return @"";
    }
    return str;
}

//获取当前角色id
+(NSString *) currentRoleId
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_RoleId_Key];
    if(!str)
    {
        return @"";
    }
    return str;
}

//获取当前角色名称
+(NSString *) currentRoleName
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_RoleName_Key];
    if(!str)
    {
        return @"";
    }
    return str;
}


#pragma ------mark servicePhone and other info------
//设置客服电话等信息
+(void) setServicePhoneAndOtherInfo:(NSMutableDictionary *)dic
{
    
    NSString *str = [dic objectForKey:@"csPhone"];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString *docDir = [paths objectAtIndex:0];
    
//    ////////NSLog(@"docDir = %@",docDir);
    if(str && str.length>1)
    {
       [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"csPhone"] forKey:@"csPhoneNumberOnLine"];
    }
//    str = [dic objectForKey:@"customer_service_id"];
//    if(str && str.length>1)
//    {
//        [[NSUserDefaults standardUserDefaults ] setObject:str forKey:UP_ChatId_Key];
//    }
////
//
//    if([[dic allKeys] containsObject:@"nav_raiders"])
//    {
//        //功能球的显示配置
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nav_me"] forKey:@"BP_ButtonBoard_nav_me"];
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nav_customer_service"] forKey:@"BP_ButtonBoard_nav_customer_service"];
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nav_msg"] forKey:@"BP_ButtonBoard_nav_msg"];
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nav_bbs"] forKey:@"BP_ButtonBoard_nav_bbs"];
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"nav_raiders"] forKey:@"BP_ButtonBoard_nav_raiders"];
//        
//        //账号异常修改链接
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"changeAccountUrl"] forKey:@"BP_AccountException_ModifyURL"];
//    }
//    
//    //游戏信息
//    str = [dic objectForKey:@"gameIcon"];
//    if(str && str.length>1)
//    {
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"gameIcon"] forKey:@"BPGameIconURL"];;
//    }
//    str = [dic objectForKey:@"gameName"];
//    if(str && str.length>1)
//    {
//        [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"gameName"] forKey:@"BPGameName"];
//    }
//    
//    BPAppInformation *appInfo = [[BPAppInformation alloc] init];
//    appInfo.appId = [dic objectForKey:@"gameId"];
//    appInfo.clientId = [dic objectForKey:@"cmsmid"];
//    [ShuZhiZhangUserPreferences setCurrentGameInfoWhenInit:appInfo];
//    [appInfo release];
//    
//    [[NSUserDefaults standardUserDefaults] synchronize];
}

//获取当前客服电话
+(NSString *) currentAccountServicePhone
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"csPhoneNumberOnLine"];
    if(!str)
    {
        return @"";
    }
    return str;

}

//获取客服的聊天id
+(NSString *) currentChatId
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_ChatId_Key];
    if (str) {
        return str;
    }
    str = [[NSUserDefaults standardUserDefaults] objectForKey:UP_GAME_ID_KEY];
    if(str)
    {
        return str;
    }
    return @"";
}

//第三方uid
+(NSString *) CurrentThirdUid{
    
    return [[NSUserDefaults standardUserDefaults] objectForKey:UP_THIRD_UID_KEY];
}

+(void) setCurrentThirdUid:(NSString *)uid{
    
    [[NSUserDefaults standardUserDefaults ] setObject:uid forKey:UP_THIRD_UID_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


// 注销
+ (void)logoutCurrentUser{
    
    [self setCurrentUserID:@"-1"];
    [self setCurrentAccount:@"-1"];
    [self setCurrentNickname:@""];
    [self setCurrentAccountType:@"-1"];
    [self setCurrentSinaWeibo:@"-1"];
    [self setCurrentQQAccount:@"-1"];
    [self setCurrentTencentWeibo:@"-1"];
    [self setCurrentGameId:@"-1"];
    [self setCurrentThirdUid:@"-1"];
}

+(NSString *)getUUID
{
    NSString * strUUID = (NSString *)[self load:@"hghsdksbapple"];
    NSLog(@"wocaoxxx=%@",strUUID);
    //首次执行该方法时，uuid为空
    if ([strUUID isEqualToString:@""] || !strUUID)
    {
        //生成一个uuid的方法
        CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
        
        strUUID = (NSString *)CFBridgingRelease(CFUUIDCreateString (kCFAllocatorDefault,uuidRef));
        
        //将该uuid保存到keychain
        [self save:KEYCHAIN data:strUUID];
        
    }
    return strUUID;
}

+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service {
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            (id)kSecClassGenericPassword,(id)kSecClass,
            service, (id)kSecAttrService,
            service, (id)kSecAttrAccount,
            (id)kSecAttrAccessibleAfterFirstUnlock,(id)kSecAttrAccessible,
            nil];
}

+ (void)save:(NSString *)service data:(id)data {
    //Get search dictionary
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Delete old item before add new item
    SecItemDelete((CFDictionaryRef)keychainQuery);
    //Add new object to search dictionary(Attention:the data format)
    [keychainQuery setObject:[NSKeyedArchiver archivedDataWithRootObject:data] forKey:(id)kSecValueData];
    //Add item to keychain with the search dictionary
    SecItemAdd((CFDictionaryRef)keychainQuery, NULL);
}

+ (id)load:(NSString *)service {
    id ret = nil;
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    
    [keychainQuery setObject:(id)kCFBooleanTrue forKey:(id)kSecReturnData];
    [keychainQuery setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];
    CFDataRef keyData = NULL;
    if (SecItemCopyMatching((CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {
        @try {
            ret = [NSKeyedUnarchiver unarchiveObjectWithData:(__bridge NSData *)keyData];
        } @catch (NSException *e) {
            NSLog(@"Unarchive of %@ failed: %@", service, e);
        } @finally {
        }
    }
    if (keyData)
        CFRelease(keyData);
    return ret;
}

+ (void)deleteKeyData:(NSString *)service {
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    SecItemDelete((CFDictionaryRef)keychainQuery);
}


@end
