//
//  ShuZhiZhangUtility.h
//  BigPlayers
//
//  Created by Jun on 13-4-25.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShuZhiZhangUtility : NSObject

// 转换到base64
+ (NSString * )encodeBase64:(NSString * )text;

// 转换到普通
+ (NSString * )decodeBase64:(NSString * )text;

//url编码
+(NSString *)encodeToPercentEscapeString: (NSString *) input;

//md5加密
+(NSString *) md5String:(NSString *)str;

NSString * sha1(const char *string);

// Url decode
+(NSString*)URLEncodeString:(NSString*)unencodedString;

+(NSString *)URLDecodedString:(NSString *)str;





#pragma mark ------显示-----------
//自定义title
+(void) customNavigationTitle:(NSString *)title ViewController:(UIViewController *)currentController;

//自定义导航栏的左右按钮
+(void) customNavigationButton:(UIViewController *)currentController isleftButton:(BOOL)leftFlag NormalImage:(NSString *)nor_img HighLightedImage:(NSString *)hl_img;

//自定义导航栏的左右按钮, --文字型
+(void) customNavigationButtonWithTitle:(UIViewController *)currentController isleftButton:(BOOL)leftFlag Title:(NSString *)title;

//显示进入应用的提示
+(void) showEnterBigPlayerAppPrompt;

//缩放图片
+ (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size;

//当没有数据时，显示提示
+(void) showNoListTishi:(UIView *)superView tishiConment:(NSString *)str;

//在邮箱绑定等，键盘不消失的界面，设置显示位置
+(void) setPromptPosition;

#pragma mark ------UIText delegate----
//视图上移
+(void) ViewScrollUp:(UIView *) textField WillScrollView:(UIView *)scrollView;

//视图下移
+(void) ViewScrollDown:(UIView *)willScrollView;


//获取mac地址
+(NSString *) macaddress;

//获取idfa
+ (NSString *)getIDFA;


//对数组的某个key进行排序
+(void) sortArrayWithKey:(NSString *)key SortArray:(NSMutableArray *)array isAscending:(BOOL) ascending;

//数组去重
+(NSMutableArray *) removeSameObject:(NSMutableArray *)array InOriginalArray:(NSMutableArray *)originalArray withKey:(NSString *)key;

//获取星座
+(NSString *)getAstroWithMonth:(NSDate *)date;

//计算年龄
+(int) getAge:(NSString *)stringTime;

//获取时间字符串，昨天，今天。。。。
//ctime:要算的时间
//currentTime：当前时间，最好拿服务器的上面的
+(NSString *) getTimeString:(double) ctime nowTime:(double) currentTime;

// 正则判断手机号码地址格式
+(BOOL) isMobileNumber:(NSString *)mobileNum;

//判断邮箱是否有效
+(BOOL) isValidateEmail:(NSString *)email;

// Ascall 码排序
+ (NSString *)sortHttpString:(NSMutableDictionary *)dic;

//获取当前的viewController
+(UIViewController *) getCurrentViewController;



//发送退出平台的消息
+(void) postPlatformExitNotification;


//获取敏感词汇名
+(NSArray*)getWordLibrary;

//过滤敏感词汇
+(NSString*)filterSomeWord:(NSMutableArray*)wordArray theContent:(NSString*)content;

+(void) saveAccountAndPasswordToKeyChain:(NSString *)account AndPassword:(NSString *)password;
+(NSDictionary *) getAccountAndPasswordFromKeyChain;

+ (NSString *)getFileNameWithURLStr:(NSString *)urlStr;


//获取屏幕大小
+ (CGRect)myScreenBounds;

//设备类型
+(NSString *) platformString;
@end
