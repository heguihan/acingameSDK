//
//  BPBaseViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-25.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import "BPBaseViewController.h"
#import "BigPlayerSDKBase.h"

@interface BPBaseViewController ()

@end

@implementation BPBaseViewController
@synthesize bpTableView;

-(void) dealloc
{
    [bpTableView release];        bpTableView = nil;
    [super dealloc];
}

-(void) showLeftButton
{
    [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_nav_back.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_nav_back_sel.png"];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
        
    [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_nav_back.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_nav_back_sel.png"];

//#ifndef BPLessThanXcode5
        if(BP_Show_IOS7)
        {
            self.edgesForExtendedLayout= UIRectEdgeNone;
        }
//#endif
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
//     self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    UIImageView * back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    back.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
    back.userInteractionEnabled = YES;
    [self.view addSubview:back];
    [back release];
    
}

//显示tableView
-(void) showTableViewWithFrame:(CGRect)frame
{
    bpTableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStyleGrouped];
    bpTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    bpTableView.separatorColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1];
    bpTableView.delegate = self;
    bpTableView.dataSource = self;
    bpTableView.bounces = NO;
    [bpTableView setBackgroundView:nil];
    [bpTableView setBackgroundView:[[[UIView alloc] init] autorelease]];
    [bpTableView setBackgroundColor:UIColor.clearColor];
    [self.view addSubview:bpTableView];
    
//    if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0))
//    {
//        bpTableView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
//    }
    //if(CGRectIsNull(frame))
    if(CGRectIsEmpty(frame))
    {
        if(SCREEN_IS_LANDSCAPE)
        {
            bpTableView.frame = CGRectMake((SCREEN_WIDTH-320)/2, 10, 320, SCREEN_HEIGHT_NAV);
        }
        else
        {
            bpTableView.frame = CGRectMake((SCREEN_WIDTH-300)/2, 10, 300, SCREEN_HEIGHT_NAV);
        }
    }
}

-(void) viewWillAppear:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}
- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) leftButtonItemAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"detailCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    return cell;
}


#pragma mark ----textfield delegate----
-(void) hideAllKeyBoard
{

}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollUp:textField WillScrollView:self.view];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollDown: self.view];
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{

}

#pragma mark --------orientation------

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
//    if([BigPlayerSDKBase getSharedBPPlatform].bpShouldLockOrientation)
//    {
//        return NO;
//    }
    
    switch ([BigPlayerSDKBase getSharedBPPlatform].bpOrientation) {
        case BPInterfaceOrientationProtraitDown:
            return interfaceOrientation == UIInterfaceOrientationPortrait;
        case BPInterfaceOrientationProtraitUp:
            return interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown;
        case BPInterfaceOrientationLandscapeLeft:
            return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
        case BPInterfaceOrientationLandscapeRight:
            return interfaceOrientation == UIInterfaceOrientationLandscapeRight;
        case BPInterfaceOrientationProtrait:
            return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
        case BPInterfaceOrientationLandscape:
            return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
        default:
            break;
    }
}

-(NSUInteger)supportedInterfaceOrientations
{
//    if([BigPlayerSDKBase getSharedBPPlatform].bpShouldLockOrientation)
//    {
//        return [[UIApplication sharedApplication] statusBarOrientation];
//    }
    switch ([BigPlayerSDKBase getSharedBPPlatform].bpOrientation) {
        case BPInterfaceOrientationProtraitDown:
            return UIInterfaceOrientationMaskPortrait;
        case BPInterfaceOrientationProtraitUp:
            return UIInterfaceOrientationMaskPortraitUpsideDown;
        case BPInterfaceOrientationLandscapeLeft:
            return UIInterfaceOrientationMaskLandscapeLeft;
        case BPInterfaceOrientationLandscapeRight:
            return UIInterfaceOrientationMaskLandscapeRight;
        case BPInterfaceOrientationProtrait:
            return (UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskPortraitUpsideDown);
        case BPInterfaceOrientationLandscape:
            return UIInterfaceOrientationMaskLandscape;
        default:
            break;
    }
}

- (BOOL)shouldAutorotate
{
//    if([BigPlayerSDKBase getSharedBPPlatform].bpShouldLockOrientation)
//    {
//        return NO;
//    }
    if([BigPlayerSDKBase getSharedBPPlatform].bpOrientation<2)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
@end
