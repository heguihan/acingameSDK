//
//  BPBaseViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-25.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPNotificationName.h"

@interface BPBaseViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property (nonatomic,retain) UITableView *bpTableView;

//显示tableView
-(void) showTableViewWithFrame:(CGRect)frame;

-(void) leftButtonItemAction;




@end
