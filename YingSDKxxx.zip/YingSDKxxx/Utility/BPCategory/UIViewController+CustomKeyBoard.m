//
//  UIViewController+CustomKeyBoard.m
//  BigPlayerSDK
//

//

#import "UIViewController+CustomKeyBoard.h"

@implementation UIViewController (CustomKeyBoard)
-(BOOL)disablesAutomaticKeyboardDismissal
{
    return NO;
}
@end
