//
//  UINavigationController+BPRotation.h
//  BigPlayerSDK
//

#import <UIKit/UIKit.h>

@interface UINavigationController (BPRotation)

@end
