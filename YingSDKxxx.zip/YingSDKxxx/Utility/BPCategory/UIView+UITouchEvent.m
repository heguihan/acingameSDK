//
//  UIView+UITouchEvent.m
//  BigPlayerSDK
//
//

#import "UIView+UITouchEvent.h"

@implementation UIView (UITouchEvent)
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesBegan:touches withEvent:event];
    
    UITouch *touch = [touches anyObject];
    if([NSStringFromClass([touch.view class]) isEqualToString:@"PUAlbumListCellContentView"]
       || [NSStringFromClass([touch.view class]) isEqualToString:@"PUPhotoView"])
    {
        [super touchesBegan:touches withEvent:event];
    }
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesMoved:touches withEvent:event];
    
    UITouch *touch = [touches anyObject];
    if([NSStringFromClass([touch.view class]) isEqualToString:@"PUAlbumListCellContentView"]
       || [NSStringFromClass([touch.view class]) isEqualToString:@"PUPhotoView"])
    {
        [super touchesMoved:touches withEvent:event];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesEnded:touches withEvent:event];
    
    UITouch *touch = [touches anyObject];
    if([NSStringFromClass([touch.view class]) isEqualToString:@"PUAlbumListCellContentView"]
       || [NSStringFromClass([touch.view class]) isEqualToString:@"PUPhotoView"])
    {
        [super touchesEnded:touches withEvent:event];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self nextResponder] touchesCancelled:touches withEvent:event];
    
    UITouch *touch = [touches anyObject];
    if([NSStringFromClass([touch.view class]) isEqualToString:@"PUAlbumListCellContentView"]
       || [NSStringFromClass([touch.view class]) isEqualToString:@"PUPhotoView"])
    {
        [super touchesCancelled:touches withEvent:event];
    }
}
@end
