//
//  UIScrollView+UITouchEvent.h
//  BigPlayers
//
//  Created by John Cheng on 13-5-9.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (UITouchEvent)

@end
