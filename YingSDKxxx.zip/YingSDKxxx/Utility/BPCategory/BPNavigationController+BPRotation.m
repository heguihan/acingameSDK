//
//  BPNavigationController+BPRotation.m
//  ShuZhiZhangSDKSDK_Mini
//

//

#import "BPNavigationController+BPRotation.h"
#import "BPRervicerOnlineViewController.h"
#import "BPWebViewBaseViewController.h"

@implementation BPNavigationController (BPRotation)
-(BOOL)shouldAutorotate
{
    return [[self.viewControllers lastObject] shouldAutorotate];
}

-(NSUInteger)supportedInterfaceOrientations
{
    return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
//    if([[self.viewControllers lastObject] isKindOfClass:[BPRervicerOnlineViewController class]] || [[self.viewControllers lastObject] isKindOfClass:[BPWebViewBaseViewController class]])
//        {
//          return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
//        }
//        return UIInterfaceOrientationPortrait;
    return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
    
//    return UIInterfaceOrientationLandscapeRight;
}
@end
