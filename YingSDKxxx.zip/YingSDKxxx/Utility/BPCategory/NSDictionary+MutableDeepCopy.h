//
//  NSDictionary+MutableDeepCopy.h
//  GameHubSDK
//
//  Created by John Cheng on 13-4-9.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (MutableDeepCopy)
//深拷贝
-(NSMutableDictionary *)mutableDeepCopy;
@end
