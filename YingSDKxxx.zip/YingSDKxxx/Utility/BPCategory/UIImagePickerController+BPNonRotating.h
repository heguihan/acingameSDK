//
//  UIImagePickerController+BPNonRotating.h
//  BigPlayerSDK
//

#import <UIKit/UIKit.h>

@interface UIImagePickerController (BPNonRotating)

@end
