//
//  UIImagePickerController+BPNonRotating.m
//  BigPlayerSDK
//
//

#import "UIImagePickerController+BPNonRotating.h"

@implementation UIImagePickerController (BPNonRotating)
- (BOOL)shouldAutorotate {
    return NO;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}
@end
