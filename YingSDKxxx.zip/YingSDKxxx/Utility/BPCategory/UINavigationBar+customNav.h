//
//  UINavigationBar+customNav.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (customNav)

- (void)customNavigationBar;

@end
