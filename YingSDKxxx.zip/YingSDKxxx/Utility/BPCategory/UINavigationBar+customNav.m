//
//  UINavigationBar+customNav.m
//  BigPlayerSDK
//
//

#import "UINavigationBar+customNav.h"

@implementation UINavigationBar (customNav)

//- (void)drawRect:(CGRect)rect
//{
//    UIImage *image = [UIImage imageNamed: @"nav_head.png"];
//    [image drawInRect:CGRectMake(0, 0, self.frame.size.width, 64)];
//}

//- (CGSize)sizeThatFits:(CGSize)size
//{
//    int height = 44;
//    if(SCREEN_IS_LANDSCAPE)
//    {
//        height = 32;
//    }
////    UIViewController *con = [ShuZhiZhangUtility getCurrentViewController];
////    if([con isKindOfClass:[UINavigationController class]])
////    {
////        con = [[(UINavigationController *)con viewControllers] lastObject];
////    }
////    if([con isKindOfClass:[BPPurchaseViewController class]])
////    {
////        height = 20;
////    }
//    
////    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"BPHideNavBar"] intValue] == 1)
////    {
////        height = 20;
////    }
//     ////////NSLog(@"-----90909-----%@",self.topItem.title);
//    NSString *str = self.topItem.title;
//    ////////NSLog(@"-----90909-----%@",str);
//    if(str && ![str isEqualToString:@"Photos"])
//    {
//        self.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
//                                    [UIColor colorWithRed:48/255.0f green:48/255.0f blue:48/255.0f alpha:1],
//                                    UITextAttributeTextColor,
//                                    [UIColor clearColor],
//                                    UITextAttributeTextShadowColor,
//                                    //                                [NSValue valueWithUIOffset:UIOffsetMake(0, -1)],
//                                    //                                UITextAttributeTextShadowOffset,
//                                    [UIFont boldSystemFontOfSize:20],
//                                    UITextAttributeFont,
//                                    nil];
//        CGSize newSize = CGSizeMake(self.frame.size.width,height);
//        return newSize;
//    }
//    else
//    {
//        CGSize newSize = CGSizeMake(self.frame.size.width,self.frame.size.height);
//        return newSize;
//    }
//}

- (void)customNavigationBar
{
//    UIImage *image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_status_bar.png"];
//    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(0,100,0,0)];
//    UIImageView *imageview = [[UIImageView alloc] initWithImage:image];
//    imageview.frame = CGRectMake(0, 0, SCREEN_WIDTH, 20);
//    [self addSubview:imageview];
//    imageview.userInteractionEnabled = YES;
//    [imageview release];
//    
//    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    closeButton.frame = CGRectMake(SCREEN_WIDTH-50, 0, 50, 20);
//    [closeButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_close.png"] forState:UIControlStateNormal];
//    [closeButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_close.png"] forState:UIControlStateHighlighted];
//    [closeButton addTarget:self action:@selector(closeBPPlatform) forControlEvents:UIControlEventTouchUpInside];
//    [imageview addSubview:closeButton];
    self.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor colorWithRed:48/255.0f green:48/255.0f blue:48/255.0f alpha:1],
                                UITextAttributeTextColor,
                                [UIColor clearColor],
                                UITextAttributeTextShadowColor,
                                //                                [NSValue valueWithUIOffset:UIOffsetMake(0, -1)],
                                //                                UITextAttributeTextShadowOffset,
                                [UIFont boldSystemFontOfSize:20],
                                UITextAttributeFont,
                                nil];
    
    CGMutablePathRef path = CGPathCreateMutable();
    if(SCREEN_IS_LANDSCAPE)
    {
        CGRect frame = self.bounds;
        frame.size.width = [UIScreen mainScreen].bounds.size.width;
//        frame.size.height = self.bounds.size.width;
        CGPathAddRect(path, NULL, frame);
    }
    else
    {
        CGPathAddRect(path, NULL, self.bounds);
    }
    self.layer.shadowPath = path;
    CGPathCloseSubpath(path);
    CGPathRelease(path);
    
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOffset = CGSizeMake(0, 1);
    self.layer.shadowOpacity = 0.5;
    self.layer.shadowRadius = 2;
//    self.layer.shadowOpacity = 1;
//
//    // Default clipsToBounds is YES, will clip off the shadow, so we disable it.
    self.clipsToBounds = NO;

}



@end
