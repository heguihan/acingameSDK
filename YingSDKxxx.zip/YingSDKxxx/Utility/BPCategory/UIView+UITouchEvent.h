//
//  UIView+UITouchEvent.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>

@interface UIView (UITouchEvent)

@end
