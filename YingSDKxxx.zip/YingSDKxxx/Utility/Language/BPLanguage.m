//
//  GHLanguage.m
//  GHLanguage
//
//

#import "BPLanguage.h"

static NSString *language;
@implementation BPLanguage
//设置语言，字符
+(void) setLanguange:(NSString *)lan
{
    if(language != nil)
    {
        [language release];
    }
    language = [[NSString alloc] initWithString:lan];
}
//获取当前语言id
+(int) getCurrentLanguageId
{
    if([language isEqualToString:@"en"])
    {
        return 2;
    }
    else
    {
        return 1;
    }
}
//设置语言，id
+(void) setLanguangeWithId:(int)lanId
{
    if(language != nil && lanId>0)
    {
        [language release];
    }
    if(lanId==2)
    {
        language = [[NSString alloc] initWithString:@"en"];
    }
    else
    {
        language = [[NSString alloc] initWithString:@"zh-Hans"];
    }
}

+(NSString*) getStringForKey:(NSString*) key InTable:(NSString *)table
{
//    return NSLocalizedStringFromTable(@"BPLogin",@"BPMultiLanguage", nil);
    
    if(!language)
    {
        language = @"zh-Hans";
//        //获取设备语言
//        NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];    //语言
//        NSArray *languages_all =[defaults objectForKey:@"AppleLanguages"];
//        language=[[NSString alloc] initWithString:[languages_all objectAtIndex:0]];
    }
    
	NSString *path;
    path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.lproj",language]];
	NSBundle* languageBundle = [NSBundle bundleWithPath:path];
    NSString* str=[languageBundle localizedStringForKey:key value:nil table:table];
    if(!languageBundle || [str isEqualToString:key])
    {
        //info里设置的默认语言
        NSBundle* bundle =[NSBundle mainBundle];
        NSDictionary* info =[bundle infoDictionary];
        language =[info objectForKey:@"CFBundleDevelopmentRegion"];
        path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
        path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.lproj",language]];
        
        languageBundle = [NSBundle bundleWithPath:path];
        str=[languageBundle localizedStringForKey:key value:@"" table:table];
        
        //还没有此本地化，则用中文
        if(!languageBundle || [str isEqualToString:key])
        {
            language = @"zh-Hans";
            path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
            path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.lproj",language]];
            
            languageBundle = [NSBundle bundleWithPath:path];
            str=[languageBundle localizedStringForKey:key value:@"" table:table];
        }
    }
	return str;
}


@end
