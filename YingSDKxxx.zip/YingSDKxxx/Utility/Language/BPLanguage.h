//
//  GHLanguage.h
//  GHLanguage
//

//

#import <Foundation/Foundation.h>

@interface BPLanguage : NSObject

//设置语言，字符
+(void) setLanguange:(NSString *)lan;
//获取当前语言id
+(int) getCurrentLanguageId;

//设置语言，id
+(void) setLanguangeWithId:(int)lanId;

+(NSString*) getStringForKey:(NSString*) key InTable:(NSString *)table;
@end
