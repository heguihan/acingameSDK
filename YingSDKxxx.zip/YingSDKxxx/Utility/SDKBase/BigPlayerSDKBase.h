//
//  BigPlayerSDKBase.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-18.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BPRegisterAndLoginRequest.h"
//#import "BPGameAnnouncements.h"
#import "BPAddressLocationManager.h"
#import "ShuEnter.h"


@protocol WxGetAuthoDelegate <NSObject>


-(void)loginSuccessByCode:(NSString *)code;

@end


@interface BigPlayerSDKBase : NSObject <UIApplicationDelegate>

@property (nonatomic,retain) BPRegisterAndLoginRequest *BPBaseRequest;
@property (nonatomic,assign) BPInterfaceOrientationStatus bpOrientation;
@property (nonatomic,assign) BOOL BPCloseAddressLocation; //是否关闭地理位置获取接口
@property (nonatomic,assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic,assign) BOOL BPHasInitFinish; //初始化完成

@property (nonatomic,assign) BOOL BPShouldShowADFLag;//是否显示idfa广告和qq、新浪登陆的开关
@property (nonatomic,assign) BOOL BPHasShowedADForIDFA; //已显示过广告了，该广告是为了苹果审核的，以免因为idfa而被拒。

@property (nonatomic,assign) BOOL BPShouldShowQQSinaFLag;//是否显示idfa广告和qq、新浪登陆的开关

@property(nonatomic,strong) id<WxGetAuthoDelegate> wxDelegate;


+(BigPlayerSDKBase *) getSharedBPPlatform;


//-(void)sourceApplicationWithurl:(NSURL *)url;

-(BOOL)sourceApplicationWithurl:(NSURL *)url;

-(BOOL)handelopenurl:(NSURL *)url;


@end
