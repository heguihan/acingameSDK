//
//  BigPlayerSDKBase+PlayerShare.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-9-4.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase.h"

@interface BigPlayerSDKBase (PlayerShare)
//IOS屏幕截图---Opengl截屏
-(NSString *) getScreenShotWithOpenGL;

//IOS屏幕截图---普通截图
-(NSString *) getScreenShotWithContext;

//当图片大于Maximum，进行图片压缩，再保存到imagePath
-(void) compressionImageInPath:(NSString *)imagePath WhenMoreThan:(int) Maximum;

@end
