//
//  BigPlayerSDKBase.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-18.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase.h"
#import "BigPlayerSDKBase+LoginAndOut.h"
#import "BPPublicHandle.h"


#import "MBProgressHUD.h"




@implementation BigPlayerSDKBase
@synthesize BPBaseRequest;
//@synthesize addressManage;
@synthesize bpOrientation;
@synthesize BPCloseAddressLocation;
@synthesize currentOrientation;
@synthesize BPHasInitFinish;
@synthesize BPHasShowedADForIDFA;//已显示过广告了，该广告是为了苹果审核的，以免因为idfa而被拒。
@synthesize BPShouldShowQQSinaFLag;
@synthesize BPShouldShowADFLag;

static BigPlayerSDKBase *BPPlatformShared;

+(BigPlayerSDKBase *) getSharedBPPlatform
{
    @synchronized(BPPlatformShared)
    {
        if(BPPlatformShared == nil)
        {
            BPPlatformShared =[[BigPlayerSDKBase alloc] init];
        }
        
        return BPPlatformShared;
    }
}

-(void) dealloc
{
//    [BPBaseRequest release];        BPBaseRequest = nil;
//    [super dealloc];
}

-(id) init
{
    self = [super init];
    if(self)
    {
        [self didFinishLaunchingWithOptions];
        
    }
    return self;
}



- (void)didFinishLaunchingWithOptions
{

}


//按home键出去
- (void)applicationDidEnterBackground{

    
  
}

-(void) applicationDidResignActive
{
    
}

@end
