//
//  BigPlayerSDKBase+PlayerShare.m
//  BigPlayerSDK
//
//

#import "BigPlayerSDKBase+PlayerShare.h"
#import <OpenGLES/ES1/glext.h>
#import <OpenGLES/ES2/glext.h>
//#import "BPIWYShareViewController.h"

@implementation BigPlayerSDKBase (PlayerShare)
//IOS屏幕截图---Opengl截屏
- (NSString *) getScreenShotWithOpenGL
{
    // Get the size of the backing CAEAGLLayer
    GLint backingWidth, backingHeight;
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
    
    NSInteger x = 0, y = 0, width = backingWidth, height = backingHeight;
    NSInteger dataLength = width * height * 4;
    GLubyte *data = (GLubyte*)malloc(dataLength * sizeof(GLubyte));
    
    // Read pixel data from the framebuffer
    glPixelStorei(GL_PACK_ALIGNMENT, 4);
    glReadPixels(x, y, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
    
    // Create a CGImage with the pixel data
    // If your OpenGL ES content is opaque, use kCGImageAlphaNoneSkipLast to ignore the alpha channel
    // otherwise, use kCGImageAlphaPremultipliedLast
    CGDataProviderRef ref = CGDataProviderCreateWithData(NULL, data, dataLength, NULL);
    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
    CGImageRef iref = CGImageCreate(width, height, 8, 32, width * 4, colorspace, kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast,
                                    ref, NULL, true, kCGRenderingIntentDefault);
    
    // OpenGL ES measures data in PIXELS
    // Create a graphics context with the target size measured in POINTS
    NSInteger widthInPoints, heightInPoints;
    
    widthInPoints = width;
    heightInPoints = height;
    UIGraphicsBeginImageContext(CGSizeMake(widthInPoints, heightInPoints));
    //}
    
    CGContextRef cgcontext = UIGraphicsGetCurrentContext();
    
    // UIKit coordinate system is upside down to GL/Quartz coordinate system
    // Flip the CGImage by rendering it to the flipped bitmap context
    // The size of the destination area is measured in POINTS
    CGContextSetBlendMode(cgcontext, kCGBlendModeCopy);
    CGContextDrawImage(cgcontext, CGRectMake(0.0, 0.0, widthInPoints, heightInPoints), iref);

    // Retrieve the UIImage from the current context
    UIImage *ScreenImage = UIGraphicsGetImageFromCurrentImageContext();
    //[GetScreen_ImageView retain];
    //    [imageView setImage: GetScreen_ImageView];
    
    //////////NSLog(@"ccy3333---%d",[GetScreen_ImageView retainCount]);
    UIGraphicsEndImageContext();
    
    // Clean up
    free(data);
    CFRelease(ref);
    CFRelease(colorspace);
    CGImageRelease(iref);
    
     NSData *imageData = UIImageJPEGRepresentation(ScreenImage, 1.0);
    
    NSString *timeSp = [NSString stringWithFormat:@"%0f.jpg",[[NSDate date] timeIntervalSince1970]];
    
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"/user/user_%@/sharefile/",[ShuZhiZhangUserPreferences CurrentUserID]]];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString *imagePath  =  [path stringByAppendingPathComponent:timeSp];
    [imageData writeToFile:imagePath atomically:YES];
    
    return imagePath;
}

//IOS屏幕截图---普通截图
- (NSString *) getScreenShotWithContext
{
    UIWindow *screenWindow = [[UIApplication sharedApplication] keyWindow];
    UIGraphicsBeginImageContext(screenWindow.frame.size);//全屏截图，包括window
    [screenWindow.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
//    UIImageWriteToSavedPhotosAlbum(viewImage, nil, nil, nil);
//    viewImage = [self rotateImage:viewImage byOrientationFlag:viewImage.imageOrientation];
    
    NSData *imageData = UIImageJPEGRepresentation(viewImage, 1.0);
    
    NSString *timeSp = [NSString stringWithFormat:@"%0f.jpg",[[NSDate date] timeIntervalSince1970]];
    
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"/user/user_%@/sharefile/",[ShuZhiZhangUserPreferences CurrentUserID]]];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString *imagePath  =  [path stringByAppendingPathComponent:timeSp];
    [imageData writeToFile:imagePath atomically:YES];
    
    return imagePath;
}

- (NSString *)getCachePathWithFileName:(NSString *)fileName AndURLStr:(NSString *)urlStr
{
    if(!urlStr || (NSNull *)urlStr == [NSNull null] || urlStr.length<1)
    {
        return @"null";
        //return nil;
    }
    NSString *str = sha1([urlStr UTF8String]);
    fileName = [NSString stringWithFormat:@"%@",fileName];
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:fileName];
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [path stringByAppendingPathComponent:str];
}


- (UIImage*)rotateImage:(UIImage*)img byOrientationFlag:(UIImageOrientation)orient
{
    CGImageRef          imgRef = img.CGImage;
    CGFloat             width = CGImageGetWidth(imgRef);
    CGFloat             height = CGImageGetHeight(imgRef);
    CGAffineTransform   transform = CGAffineTransformIdentity;
    CGRect              bounds = CGRectMake(0, 0, width, height);
    CGSize              imageSize = bounds.size;
    CGFloat             boundHeight;

    switch(orient) {
        case UIImageOrientationUp: //EXIF = 1
           transform = CGAffineTransformIdentity;
           break;

        case UIImageOrientationDown: //EXIF = 3
           transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
             break;

        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3 * M_PI / 2.0);
           break;

        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
           //transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
          break;

       default:
           // image is not auto-rotated by the photo picker, so whatever the user
          // sees is what they expect to get. No modification necessary
            transform = CGAffineTransformIdentity;
           break;
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // if ((orient == UIImageOrientationDown) || (orient == UIImageOrientationRight) || (orient == UIImageOrientationUp))
    {
        // flip the coordinate space upside down
        CGContextScaleCTM(context, 1, -1);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}


//当图片大于Maximum，进行图片压缩，再保存到imagePath
-(void) compressionImageInPath:(NSString *)imagePath WhenMoreThan:(int) Maximum
{
    if(!imagePath || imagePath.length<1)
    {
        return;
    }
    UIImage *imageReadyPost = [UIImage imageWithContentsOfFile:imagePath];
    NSData *dataImage = UIImageJPEGRepresentation(imageReadyPost, 1.0);
    NSUInteger sizeOrigin = [dataImage length];
    NSUInteger sizesizeOriginKB = sizeOrigin / 1024;
    
    // 图片大于500k要先进行压缩
    if (sizesizeOriginKB > Maximum) {
        float a = Maximum;//500.00000;
        float  b = (float)sizesizeOriginKB;
        float q = sqrt(a/b);
        CGSize sizeImage = [imageReadyPost size];
        CGFloat iwidthSmall = sizeImage.width * q;
        CGFloat iheightSmall = sizeImage.height * q;
        CGSize itemSizeSmall = CGSizeMake(iwidthSmall, iheightSmall);
        UIGraphicsBeginImageContext(itemSizeSmall);
        CGRect imageRectSmall = CGRectMake(0.0f, 0.0f, itemSizeSmall.width, itemSizeSmall.height);
        [imageReadyPost drawInRect:imageRectSmall];
        UIImage *SmallImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        NSData *dataImageSend = UIImageJPEGRepresentation(SmallImage, 1.0);
        dataImage = dataImageSend;
        [dataImage writeToFile:imagePath atomically:YES];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSDictionary *userInfo = request.userInfo;
//    ////////NSLog(@"%@----%@",request.userInfo,request.responseString);
    NSDictionary *postInfo = [NSDictionary dictionaryWithObjectsAndKeys:[userInfo objectForKey:@"RequestTag"],@"ShareTag",
                              request.responseString , @"ShareResult", nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:BPShareNotification object:postInfo];
    
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"shareToApp"])
    {
        int response = [request.responseString intValue];

        if (response == 1) {
           
        }
        else{
            
            if (response == 0){
               
            }
            
            else if (response == -10){
//                BPLog(@"参数为空，文字、图片不能同时为空");
            }
            
            else if (response == -20){
//                BPLog(@"图片上传失败");
            }
        }
    }
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"enterBackground_role"])
    {
        ////////NSLog(@"enterBackground_role ----back");
    }
}
@end
