//
//  HGHUserTypeSave.m
//  ShuZhiZhangSDK
//
//  Created by Lucas on 2019/7/23.
//  Copyright © 2019 John Cheng. All rights reserved.
//

#import "HGHUserTypeSave.h"

@implementation HGHUserTypeSave
+(void)saveUserTypeWithUsername:(NSString *)username password:(NSString *)pwd field:(NSString *)field
{
    NSDictionary *dict = @{@"userNamehgh":username,@"pwdhgh":pwd};
    NSArray * arr = [[NSUserDefaults standardUserDefaults] objectForKey:field];
    ////////NSLog(@"arr=%@",arr);
    NSMutableArray *mutableArr = [[NSMutableArray alloc]initWithArray:arr];
    for (NSDictionary *dic in mutableArr) {
        if ([username isEqualToString:dic[@"userNamehgh"]]) {
            [mutableArr removeObject:dic];
            break;
        }
    }
    ////////NSLog(@"mutableArr=%@",mutableArr);
    [mutableArr addObject:dict];
    while (mutableArr.count>=6) {
        [mutableArr removeObjectAtIndex:0];
    }
    NSArray *newArr = [mutableArr copy];
    [[NSUserDefaults standardUserDefaults] setObject:newArr forKey:field];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
@end
