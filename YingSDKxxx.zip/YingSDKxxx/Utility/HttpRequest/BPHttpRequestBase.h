//
//  BPHttpRequestBase.h
//  BigPlayers
//
//  Created by John Cheng on 13-4-26.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIFormDataRequest.h"
#import "ASINetworkQueue.h"
#import "ASIDownloadCache.h"

@protocol HttpRequestBaseDelegate <NSObject>
@optional
-(void) requestDidFinished:(ASIHTTPRequest *)request;
-(void) requestDidFailed:(ASIHTTPRequest *)request;

-(void) downloadImageSuccessWithRequest:(ASIHTTPRequest *)request;
-(void) downloadImageFailed:(ASIHTTPRequest *)request;

@end

@interface BPHttpRequestBase : NSObject

{
    ASINetworkQueue *RequestQueue;
    id<HttpRequestBaseDelegate> delegate;
}

@property (nonatomic,retain) ASINetworkQueue *RequestQueue;
@property (nonatomic,assign) id<HttpRequestBaseDelegate> delegate;


-(id) initWithDelegate:(id)delegate_t;
-(ASIFormDataRequest *)CreateRequestWithUrl:(NSString *)urlStr SetInfoTag:(NSString *)InfoTag;
-(ASIFormDataRequest *)CreateRequestWithUserInfo:(NSString *)urlStr UserInfo:(NSMutableDictionary *)userInfo;

//取消所有的下载请求
-(void) cancelAllRequest;
-(void) waitUntilOperationsFinished;
//下载文件／图片
-(void) downloadFileWithUrl:(NSString *)urlStr UserInfo:(NSMutableDictionary *)userInfo ProgressView:(UIProgressView *)progressView;

@end
