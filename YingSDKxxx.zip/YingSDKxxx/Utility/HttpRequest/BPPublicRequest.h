//
//  BPPublicRequest.h
//  BigPlayerSDK
//
//

#import "BPHttpRequestBase.h"
#import "BPAddressLocationManager.h"

@interface BPPublicRequest : BPHttpRequestBase <HttpRequestBaseDelegate>


@property (nonatomic,retain) BPAddressLocationManager *addressManage;
/*************************
 //第一次用第三方sdk登陆成功后，上传用户信息，并下载头像上传
 //dic: 第三方sdk返回的信息
 **********************/
+(void) updateUserInfoWithOtherSdk:(NSMutableDictionary *)dic  TypeFlag:(int)type;

//上传设备信息
+(void) updateDeviceInfo;

//获取客服电话和聊天id等
+(void) getServicePhoneAndOtherInfo;

//更新敏感词文件
+(void) requestDownloadSensitiveWordsFile;

//打开大包，上传信息
-(void) postGameAndDeviceInfoWhenStart;

////下载应用
//-(void) downloadYingSDKAppAndInstall;

#pragma mark -----获取审核开关
-(void) getReviewSwitch;

+ (BPPublicRequest *)getSharedBPPublicRequest;
@end
