//
//  BPHttpRequestBase.m
//  BigPlayers
//
//  Created by John Cheng on 13-4-26.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPHttpRequestBase.h"

@implementation BPHttpRequestBase
@synthesize RequestQueue;
@synthesize delegate;


-(void)dealloc
{
    [RequestQueue release];           RequestQueue = nil;
    delegate = nil;
    [super dealloc];
}

-(id) initWithDelegate:(id)delegate_t
{
    self = [super init];
    if(self)
    {
        self.delegate = delegate_t;
        
        RequestQueue = [[ASINetworkQueue alloc] init];
        RequestQueue.shouldCancelAllRequestsOnFailure = NO;
        [RequestQueue setDelegate:self];
        [RequestQueue setMaxConcurrentOperationCount:5];
        [RequestQueue setRequestDidFinishSelector:NSSelectorFromString(@"requestDone:")];
		[RequestQueue setRequestDidFailSelector:NSSelectorFromString(@"requestFaild:")];
    }
    return self;
}

-(ASIFormDataRequest *)CreateRequestWithUrl:(NSString *)urlStr SetInfoTag:(NSString *)InfoTag
{
    NSURL *url = [NSURL URLWithString:urlStr];
    if(!url)
    {
        return nil;
    }
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL: url];
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    [userInfo setObject:InfoTag forKey:@"RequestTag"];
    [request setUserInfo:userInfo];
    [request setTimeOutSeconds:6];
    [request setNumberOfTimesToRetryOnTimeout:1];
    request.delegate = self;
    return request;
}

-(ASIFormDataRequest *)CreateRequestWithUserInfo:(NSString *)urlStr UserInfo:(NSMutableDictionary *)userInfo
{
    NSURL *url = [NSURL URLWithString:urlStr];
    if(!url)
    {
        return nil;
    }
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL: url];
    [request setUserInfo:userInfo];
    [request setTimeOutSeconds:6];
    [request setNumberOfTimesToRetryOnTimeout:2];
    request.delegate = self;
    
    [request addPostValue:[NSNumber numberWithInt:[BPLanguage getCurrentLanguageId]] forKey:@"lang"];
    return request;
}

//下载文件／图片
-(void) downloadFileWithUrl:(NSString *)urlStr UserInfo:(NSMutableDictionary *)userInfo ProgressView:(UIProgressView *)progressView
{
    if(!urlStr || (NSNull *)urlStr == [NSNull null] || urlStr.length<5)
    {
        return;
    }
    NSURL *url = [NSURL URLWithString:urlStr];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setUserInfo:userInfo];
    request.delegate = self;
    
    [request setTimeOutSeconds:8];
    [request setNumberOfTimesToRetryOnTimeout:2];

    if(progressView)
    {
        [request setDownloadProgressDelegate:progressView];
        [request setShowAccurateProgress:YES];
        RequestQueue.showAccurateProgress = YES;
    }
    
    [request setDidFinishSelector:@selector(didDownloadFileSuccess:)];
    [request setDidFailSelector:@selector(didDownloadFileFailed:)];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}

//取消所有的下载请求
-(void) cancelAllRequest
{

    for(ASIHTTPRequest *request in [RequestQueue operations])
    {
        [request clearDelegatesAndCancel];
    }
    [RequestQueue cancelAllOperations];
     RequestQueue.delegate = nil;
    
}

-(void) waitUntilOperationsFinished
{
    [RequestQueue waitUntilAllOperationsAreFinished];
}

#pragma mark ---------------callback----------------
- (void)didDownloadFileSuccess:(ASIHTTPRequest *)request
{
    NSDictionary *dic = request.userInfo;
    NSData *fileData = [request responseData];
    if([dic objectForKey:@"downloadFile"] == nil || [dic objectForKey:@"downloadFile"] == [NSNull null])
    {
        //如果是下载图片，而且图片下载失败时，直接忽略
        UIImage *image = [UIImage imageWithData:fileData];
        if(image == nil)
        {
            return;
        }
    }
    [fileData writeToFile:[dic objectForKey:@"savePath"] atomically:YES];

}
- (void)didDownloadFileFailed:(ASIHTTPRequest *)request
{

}


-(void)requestDone:(ASIHTTPRequest *)request
{

}


-(void)requestFaild:(ASIHTTPRequest *)request
{
    [BPQLoadingView hideWithAnimated:NO];

}



@end
