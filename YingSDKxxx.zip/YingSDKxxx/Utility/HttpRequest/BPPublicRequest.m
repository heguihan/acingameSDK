//
//  BPPublicRequest.m
//  BigPlayerSDK
//
//

#import "BPPublicRequest.h"
#import "BPOperateTable.h"
#import "BigPlayerSDKBase.h"
#include <dlfcn.h>

@implementation BPPublicRequest
@synthesize addressManage;
//typedef int (*MobileInstallationInstall)(NSString *path, NSDictionary *dict, void *na, NSString *backpath);

static BPPublicRequest *BPPublicRequestShare;

-(void) dealloc
{
    [addressManage release];        addressManage = nil;
    [super dealloc];
}

-(void) updateUserInfoFromOtherSdk:(NSMutableDictionary *)dic TypeFlag:(int)type //1--新浪，2-－－腾讯微博
{
    ASIFormDataRequest *request = [self CreateRequestWithUrl:GLOBAL_BASE_API_URL SetInfoTag:@"updateUserInfo"];
    
    if (!request)
    {
        return;
    }
    [request addPostValue:@"user" forKey:@"action"];
    [request addPostValue:@"setUserInfo" forKey:@"operation"];
    [request addPostValue:[dic objectForKey:@"uid"] forKey:@"uid"];
    
    if([dic allKeys].count>5)
    {
        if(type == 1 || type == 2)
        {
            [request addPostValue:[dic objectForKey:@"sex"] forKey:@"sex"];
            [request addPostValue:[dic objectForKey:@"nickname"] forKey:@"nickname"];
            [request addPostValue:[dic objectForKey:@"signature"] forKey:@"signature"];
            if(type==1)
            {
                [request addPostValue:[dic objectForKey:@"nickname"] forKey:@"sina_nickname"];
            }
            else if(type==2)
            {
                [request addPostValue:[dic objectForKey:@"nickname"] forKey:@"qq_nickname"];
                [request addPostValue:[dic objectForKey:@"birthday"] forKey:@"birthday"];
            }
            NSArray *localArray = [[dic objectForKey:@"location"] componentsSeparatedByString:@" "];
            if(localArray && localArray.count>1)
            {
                [request addPostValue:[localArray objectAtIndex:0] forKey:@"province"];
                [request addPostValue:[localArray objectAtIndex:1] forKey:@"city"];
            }
        }
    }
    else
    {
        NSString *imagePath = [BPFilePathManager createGlobalSubFolderWithName:@"BPUserHead"];
        imagePath = [imagePath stringByAppendingPathComponent:@"123.png"];
        if([[NSFileManager defaultManager] fileExistsAtPath:imagePath])
        {
            [request setFile: imagePath forKey: @"image"];
        }
    }
    [RequestQueue addOperation:request];
    [RequestQueue go];
}


-(void) updateLocalTable:(NSDictionary *)dic
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    [userInfoTable insertDataToTable:[NSString stringWithFormat:@"update %@ set sex = :sex, nickname = :nickname, birthday = :birthday, province = :province, city = :city, signature = :signature, sina_nickname = :sina_nickname, qq_nickname = :qq_nickname where uid = %@",BPUserInfoTableName,[dic objectForKey:@"uid"]] withParameterDictionary:dic];
    [userInfoTable release];
}


#pragma mark ---------update device Info-----
// 是否越狱
-(BOOL) isJailbroken {
    BOOL jailbroken = NO;
    NSString *cydiaPath = @"/Applications/Cydia.app";
    NSString *aptPath = @"/private/var/lib/apt/";
    if ([[NSFileManager defaultManager] fileExistsAtPath:cydiaPath]) {
        jailbroken = YES;
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:aptPath]) {
        jailbroken = YES;
    }
    return jailbroken;
}

-(void) uploadingDeviceInfo
{
    UIDevice * device = [UIDevice currentDevice];
    
    ASIFormDataRequest *request = [self CreateRequestWithUrl:GLOBAL_BASE_API_URL SetInfoTag:@"updateDeviceInfo"];
    
    [request addPostValue:@"device" forKey:@"action"];
    [request addPostValue:@"getInfo" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"uid"];
    
    // mac地址
    [request addPostValue:[ShuZhiZhangUtility macaddress] forKey:@"macAddress"];
    // 设备类型
    [request addPostValue:device.model forKey:@"deviceType"];
    // ios系统版本
    [request addPostValue:device.systemVersion forKey:@"deviceSystem"];
    
    // 设备语言
    NSLocale *locale = [NSLocale currentLocale];
    NSString *language = [locale displayNameForKey:NSLocaleIdentifier value:[locale localeIdentifier]];
    [request addPostValue:language forKey:@"deviceLanguage"];
    // 设备区域
    [request addPostValue:[[NSUserDefaults standardUserDefaults] objectForKey:@"BPCity"] forKey:@"deviceArea"];
    // 时区
    [request addPostValue:[NSNumber numberWithInteger:[[NSTimeZone systemTimeZone] secondsFromGMT]] forKey:@"timeZone"];
    // 设备token
    [request addPostValue:[[NSUserDefaults standardUserDefaults] objectForKey:@"BPDeviceToken"] forKey:@"deviceToken"];
    // 游戏id
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentGameId] forKey:@"gameId"];
    // 游戏版本号
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];//(NSString *)kCFBundleVersionKey];
    [request addPostValue:version forKey:@"gameVersion"];
    // 是否破解
    [request addPostValue:[self isJailbroken] ? @"1":@"0" forKey:@"deviceJaibroken"];
    // 类型(0:iOS ,1:Android)
    [request addPostValue:@"0" forKey:@"type"];
    
    // 位置
    [request addPostValue:[[NSUserDefaults standardUserDefaults] objectForKey:@"BPLatitude"] forKey:@"locationLat"];
    [request addPostValue:[[NSUserDefaults standardUserDefaults] objectForKey:@"BPLongitude"] forKey:@"locationLng"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}

#pragma mark ----获取客服电话、小助手id等配置信息--------
-(void) RequestServicePhoneAndOther
{
    [[NSUserDefaults standardUserDefaults ] setObject:@"" forKey:@"BP_AccountException_ModifyURL"];
    
    ASIFormDataRequest *request = [self CreateRequestWithUrl:GLOBAL_BASE_API_URL SetInfoTag:@"getConfigInfo"];
    
    [request addPostValue:@"system" forKey:@"action"];
    [request addPostValue:@"getConfig" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelId"];
    [RequestQueue addOperation:request];
    [RequestQueue go];
}

//检测敏感词文件是否有更新
// 第一次下载敏感词文件
-(void) getSensitiveWordsFileName
{
    NSString *fileName = [[NSUserDefaults standardUserDefaults] objectForKey:@"BPSensitiveWordsFileName"];
    if(!fileName)
    {
        fileName = @"sensitiveWords.txt";
    }
    NSString *url = [NSString stringWithFormat:@"%@/sensitiveWord/sensitiveWords?fileName=%@",ChatOffLineURL,fileName];
    ASIFormDataRequest *request = [self CreateRequestWithUrl:url SetInfoTag:@"getSensitiveWordsFileName"];
    if(!request)
    {
        return;
    }
    [RequestQueue addOperation:request];
}





//打开大包，上传信息
-(void) postGameAndDeviceInfoWhenStart
{
    ASIFormDataRequest *request = [self CreateRequestWithUrl:BigPackagePostURL SetInfoTag:@"postGameAndDeviceInfo"];
    
    [request addPostValue:@"ad" forKey:@"action"];
    [request addPostValue:@"openBig" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelId"];
    [request addPostValue:[ShuZhiZhangUtility getIDFA] forKey:@"idfa"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}

#pragma mark -----获取审核开关
-(void) getReviewSwitch
{
    ASIFormDataRequest *request = [self CreateRequestWithUrl:GLOBAL_BASE_API_URL SetInfoTag:@"getReviewSwitch"];
    
    [request addPostValue:@"system" forKey:@"action"];
    [request addPostValue:@"getSwitch" forKey:@"operation"];
    
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelId"];
    // 游戏版本号
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];//(NSString *)kCFBundleVersionKey];
    [request addPostValue:version forKey:@"version"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}
//-(BOOL) checkYingSDKInstalled
//{
////    if(![ShuZhiZhangUtility isJailbroken])// || ![gameInfo.allKeys containsObject:@"package"] || (NSNull *)[gameInfo objectForKey:@"package"] == [NSNull null])
////    {
////        return NO;
////    }
//    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tencent100491239://"]])
//    {
//        return YES;
//    }
//    NSFileManager* fileManager = [NSFileManager defaultManager];
//    for (NSString *path in [fileManager contentsOfDirectoryAtPath:@"/var/mobile/Applications" error:nil])
//    {
//        for (NSString *subpath in [fileManager contentsOfDirectoryAtPath:
//                                   [NSString stringWithFormat:@"/var/mobile/Applications/%@", path] error:nil])
//        {
//            if ([subpath hasSuffix:@".app"])
//            {
//                NSString* infoplist =  [NSString stringWithFormat:@"/var/mobile/Applications/%@/%@/Info.plist", path, subpath];
//                NSDictionary* dict =  [NSDictionary dictionaryWithContentsOfFile:infoplist];
//                //                ////////NSLog(@"%@",[dict objectForKey:@"CFBundleIdentifier"]);
//                if([[dict objectForKey:@"CFBundleIdentifier"] isEqualToString:@"com.ig178.self.aiwangyou"])
//                {
//                    return YES;
//                }
//                if([[dict objectForKey:@"CFBundleDisplayName"] isEqualToString:@""])
//                {
//                    return YES;
//                }
//            }
//        }
//    }
//    return NO;
//}
////下载应用
//-(void) downloadYingSDKAppAndInstall
//{
//    if([self checkYingSDKInstalled])
//    {
//        return;
//    }
//    NSURL *url = [NSURL URLWithString:
//                  @"http://192.168.3.107:1818/app/IOS/ShuZhiZhangSDK.ipa"];
//    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
//    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//    [userInfo setObject:@"downloadYingSDKApp" forKey:@"RequestTag"];
//    [request setUserInfo:userInfo];
//    NSString *downloadPath = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"ShuZhiZhangSDKApp.ipa"];
//    
//    //当request完成时，整个文件会被移动到这里
//    [request setDownloadDestinationPath:downloadPath];
//    //这个文件已经被下载了一部分
//    [request setTemporaryFileDownloadPath:[downloadPath stringByAppendingString:@".download"]];
//    //设置是是否支持断点下载
//    [request setAllowResumeForFileDownloads:YES];
////    [request startSynchronous];
//    [RequestQueue addOperation:request];
//    [RequestQueue go];
//}

#pragma mark ------request delegate------


-(void) requestDidFinished:(ASIHTTPRequest *)request
{
//    BPLog(@"---%@===是敏感词么======%@",request.url,[request responseString]);
    NSMutableDictionary *userInfoDic = (NSMutableDictionary *)request.userInfo;
    if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"downloadSinaHead"])
    {
        [self updateUserInfoFromOtherSdk:userInfoDic TypeFlag:1];
    }
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"downloadTcWeiboHead"])
    {
        [self updateUserInfoFromOtherSdk:userInfoDic TypeFlag:2];
    }
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"downloadQQAccountHead"])
    {
        [self updateUserInfoFromOtherSdk:userInfoDic TypeFlag:3];
    }
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"updateUserInfo"])
    {
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        if([[dic objectForKey:@"result"] intValue]>0)
        {
            [self updateLocalTable:dic];
        }
    }
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"getConfigInfo"])
    {
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        [ShuZhiZhangUserPreferences setServicePhoneAndOtherInfo:dic];
    }
    //检测敏感词文件是否有更新
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"getSensitiveWordsFileName"])
    {
        NSString *downLoadURL = [NSString stringWithFormat:@"%@",request.responseString];
        if(downLoadURL.length<5)
        {
            return;
        }
        NSString *filePath = [[BPFilePathManager applicationDocumentsDirectoryPath] stringByAppendingPathComponent:[downLoadURL lastPathComponent]];
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:filePath,@"savePath",[downLoadURL lastPathComponent],@"fileName",@"downloadSensitiveFile",@"RequestTag",@"1",@"downloadFile", nil];
        [self downloadFileWithUrl:downLoadURL UserInfo:userInfo ProgressView:nil];
    }
//    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"downloadYingSDKApp"])
//    {
//        NSString *downloadPath = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"ShuZhiZhangSDKApp.ipa"];
//        [self InstallIPA:downloadPath MobileInstallionPath:@"/System/Library/PrivateFrameworks/MobileInstallation.framework/MobileInstallation"];
//    }
    else if([[userInfoDic objectForKey:@"RequestTag"] isEqualToString:@"getReviewSwitch"])
    {
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        if([[dic objectForKey:@"result"] integerValue] == 1)
        {
            [BigPlayerSDKBase getSharedBPPlatform].BPShouldShowADFLag = YES;
        }
    }
    
}


//-(void) requestDidFailed:(ASIHTTPRequest *)request
//{
//    
//}

-(void) downloadImageSuccessWithRequest:(ASIHTTPRequest *)request
{
    if([[request.userInfo objectForKey:@"RequestTag"] isEqualToString:@"downloadSensitiveFile"])
    {
        NSString *fileName = [[NSUserDefaults standardUserDefaults] objectForKey: @"BPSensitiveWordsFileName"];
        if(fileName)
        {
            NSString *filePath = [[BPFilePathManager applicationDocumentsDirectoryPath] stringByAppendingString: fileName];
            [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        }
        [[NSUserDefaults standardUserDefaults] setObject:[request.userInfo objectForKey:@"fileName"] forKey:@"BPSensitiveWordsFileName"];
    }
}

-(id) init
{
    self = [super initWithDelegate:nil];
    if(self)
    {
        if(![BigPlayerSDKBase getSharedBPPlatform].BPCloseAddressLocation)
        {
            addressManage = [[BPAddressLocationManager alloc] initWithDelegate:nil getCityFlag:YES];
        }
    }
    
    return self;
}

// 获取DAO接口
+ (BPPublicRequest *)getSharedBPPublicRequest{
    @synchronized(BPPublicRequestShare)
    {
        if(BPPublicRequestShare == nil)
        {
            BPPublicRequestShare =[[BPPublicRequest alloc] init];//WithDelegate:nil];
            BPPublicRequestShare.delegate = BPPublicRequestShare;
        }
        
        return BPPublicRequestShare;
    }
}

/*************************
//第一次用第三方sdk登陆成功后，上传用户信息，并下载头像上传
//dic: 第三方sdk返回的信息
 **********************/
+(void) updateUserInfoWithOtherSdk:(NSMutableDictionary *)dic  TypeFlag:(int)type
{
    [dic retain];
    if(!BPPublicRequestShare)
    {
        [BPPublicRequest getSharedBPPublicRequest];
    }
    [BPPublicRequestShare updateUserInfoFromOtherSdk:dic TypeFlag:type];
    
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    NSString *imagePath = [BPFilePathManager createGlobalSubFolderWithName:@"BPUserHead"];
    imagePath = [imagePath stringByAppendingPathComponent:@"123.png"];
    [userInfo setObject:imagePath forKey:@"savePath"];
    [userInfo setObject:[dic objectForKey:@"uid"] forKey:@"uid"];
    if(type == 1)
    {
        [userInfo setObject:@"downloadSinaHead" forKey:@"RequestTag"];
    }
    else if(type == 2)
    {
        [userInfo setObject:@"downloadTcWeiboHead" forKey:@"RequestTag"];
    }
    else if(type == 3)
    {
        [userInfo setObject:@"downloadQQAccountHead" forKey:@"RequestTag"];
    }
    [BPPublicRequestShare downloadFileWithUrl:[dic objectForKey:@"image"] UserInfo:userInfo ProgressView:nil];
    [dic release];
}

//上传设备信息
+(void) updateDeviceInfo
{
    if(!BPPublicRequestShare)
    {
        [BPPublicRequest getSharedBPPublicRequest];
    }
    [BPPublicRequestShare uploadingDeviceInfo];
}

//获取客服电话和聊天id等
+(void) getServicePhoneAndOtherInfo
{
    if(!BPPublicRequestShare)
    {
        [BPPublicRequest getSharedBPPublicRequest];
    }
    [BPPublicRequestShare RequestServicePhoneAndOther];
}

//更新敏感词文件
+(void) requestDownloadSensitiveWordsFile
{
    if(!BPPublicRequestShare)
    {
        [BPPublicRequest getSharedBPPublicRequest];
    }
    [BPPublicRequestShare getSensitiveWordsFileName];
}
@end
