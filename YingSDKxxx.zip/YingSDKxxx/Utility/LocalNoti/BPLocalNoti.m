//
//  BPLocalNotification.m
//  ShuZhiZhangSDKSDK_Mini
//
//  Created by lily on 14-1-2.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPLocalNoti.h"

@implementation BPLocalNoti


//距离当前多少时间推送一条消息
+ (void)sendOneLocalNoti:(NSString *)content Date:(NSDate *)time Uid:(NSString *)uid
{
    UILocalNotification *newNotification = [[UILocalNotification alloc] init];
    if (newNotification) {
        //时区
        newNotification.timeZone=[NSTimeZone defaultTimeZone];
        //推送事件---10秒后
        newNotification.fireDate= time;
        //推送内容
        newNotification.alertBody = content;
        //应用右上角红色图标数字
        newNotification.applicationIconBadgeNumber = 1;
        //设置按钮
        newNotification.alertAction = @"查看";
        //判断重复与否
        newNotification.repeatInterval = kCFCalendarUnitEra;
        
        NSDictionary *infoDict = [NSDictionary dictionaryWithObjectsAndKeys:uid,@"notificationsId", nil];
        newNotification.userInfo = infoDict;
        
       [[UIApplication sharedApplication] scheduleLocalNotification:newNotification];
    }
    [newNotification release];
}

+ (int)checkLocalIsExist:(NSString *)uid
{
    NSArray *notifications = [[UIApplication sharedApplication] scheduledLocalNotifications];
    for (UILocalNotification *notification in notifications ) {
        if([[notification.userInfo objectForKey:@"notificationsId"] isEqualToString:uid] ) {
            [[UIApplication sharedApplication] cancelLocalNotification:notification];
            return 0;
        }
    }
    return 1;
}
//距离当前多少时间推送一条消息
+ (void)sendLocalNotiFromNow:(NSString *)content Time:(int)time Flag:(int)flag Uid:(NSString *)uid
{
    if ([self checkLocalIsExist:uid] == 0) {
        return;
    }
    NSDate *nowDate = [[NSDate date] dateByAddingTimeInterval:time];
    
    if (flag == 1) {
        for (int i = 0 ; i < 7; i ++) {
            NSDate *notiDate = [nowDate dateByAddingTimeInterval:i * 3600 * 24];
            [self sendOneLocalNoti:content Date:notiDate Uid:uid];
        }
    }
    else
    {
        //////////NSLog(@"推送时间 : %@" , nowDate);
        [self sendOneLocalNoti:content Date:nowDate Uid:uid];
    }
}

+ (NSDate *)timeSum:(LocalNotiTime)time
{
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    NSDate *nowTime = [NSDate date];
    NSDateComponents *dateComponents = [calendar components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit )
												   fromDate:nowTime];
    NSDateComponents *Components = [calendar components:( NSHourCalendarUnit | NSMinuteCalendarUnit |  NSSecondCalendarUnit )
                                               fromDate:nowTime];
    NSDateComponents *dateComps = [[NSDateComponents alloc] init];
    
    [dateComps setYear:[dateComponents year]];
    [dateComps setMonth:[dateComponents month]];
    
    //连续多天发送本地通知
    [dateComps setDay:[dateComponents day]];
    
    int hour = [Components hour];
    int minute = [Components minute];
    int second = [Components second];
    
    [dateComps setHour:time.notiHour];
    [dateComps setMinute:time.notiMinute];
    [dateComps setSecond:time.notiSecond];
    NSDate *itemDate = [calendar dateFromComponents:dateComps];
    
    
    NSDate *notiDate;
    if (time.notiHour > hour) {
        notiDate = itemDate;
    }
    else
    {
        if (time.notiMinute > minute) {
            notiDate = itemDate;
        }
        else
        {
            if (time.notiSecond > second) {
                notiDate = itemDate;
                
            }
            else
            {
                notiDate = [itemDate dateByAddingTimeInterval:3600 * 24];
            }
        }
    }
    
//    ////////NSLog(@"tuisongshijian  : %@" , notiDate);
    [dateComps release];
    
    return notiDate;
}

//固定某个时间推送
+ (void)sendLocalNotiFixedTime:(LocalNotiTime)time Content:(NSString *)content Flag:(int)flag Uid:(NSString *)uid
{
    if ([self checkLocalIsExist:uid] == 0) {
        return;
    }
    NSDate *nowDate = [self timeSum:time];
    BPLog(@"通知开始时间 : %@" , nowDate);
    
    if (flag == 1) {
        for (int i = 0 ; i < 7; i ++) {
            NSDate *notiDate = [nowDate dateByAddingTimeInterval:i * 3600 * 24];
            [self sendOneLocalNoti:content Date:notiDate Uid:uid];
        }
    }
    else
    {
        [self sendOneLocalNoti:content Date:nowDate Uid:uid];
    }
}


+ (void)cancelLocalNoti
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}


static BPLocalNoti *localNoti;

+ (BPLocalNoti *) getLocalNoti
{
    @synchronized(localNoti)
    {
        if(localNoti == nil)
        {
            localNoti =[[BPLocalNoti alloc] init];
        }
        
        return localNoti;
    }
}

@end
