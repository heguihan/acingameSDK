//
//  BPLocalNotification.h
//  ShuZhiZhangSDKSDK_Mini
//
//  Created by lily on 14-1-2.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef struct
{
    int notiHour;    //小时
    int notiMinute;  //分钟
    int notiSecond;  //秒
}LocalNotiTime;


@interface BPLocalNoti : NSObject


+ (BPLocalNoti *) getLocalNoti;

//距离当前多少时间推送一条消息
//Flag:(int)flag  0 不重复  1重复
//距离当前多少时间推送一条消息
+ (void)sendLocalNotiFromNow:(NSString *)content Time:(int)time Flag:(int)flag Uid:(NSString *)uid;

//固定某个时间推送
//Flag:(int)flag  0 不重复  1重复
+ (void)sendLocalNotiFixedTime:(LocalNotiTime)time Content:(NSString *)content Flag:(int)flag Uid:(NSString *)uid;

+ (void)cancelLocalNoti;

@end
