//
//  BPDatabase.m
//  BigPlayers
//
//  Created by John Cheng on 13-4-12.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPDatabase.h"

@implementation BPDatabase
@synthesize dbQueue;

- (void)dealloc{
    
    [dbQueue release];
    dbQueue = nil;
    [super dealloc];
}
@end
