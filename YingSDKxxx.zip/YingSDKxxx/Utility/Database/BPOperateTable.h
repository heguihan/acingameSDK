//
//  OperateTable_GlobalDataBase.h
//  GameHub
//
//  Created by John Cheng on 13-3-21.
//  Copyright (c) 2016年 Jun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
#import "BPDatabase.h"

@interface BPOperateTable : NSObject
{
//    BOOL isGlobalDatabase;
    BPDatabase *dataBase;
}

- (id)initWithDatabaseTypeIsGlobal:(BOOL)isGlobal;

-(BOOL) CreateTableToDataBase:(NSString *)tableName SQLString:(NSString *)sqlStr;
//插入数据
-(void) insertDataToTable:(NSString *)sqlStr  withParameterDictionary:(NSDictionary *) insertDic;
-(void) insertDataToTable:(NSString *)sqlStr  withDictionaryInArray:(NSArray *) insertArray;
//插入数据， 监测是否存在该条纪录，删除并存入
-(void) insertDataToTable:(NSString *)sqlStr withDictionaryInArray:(NSArray *)insertArray withDeleteStr:(NSArray *)strArray;

//查询数据
-(NSMutableArray *)queryForDataWithSql:(NSString *)sqlStr;
-(BOOL) TableExists:(NSString *)tableName;
//清楚表数据
-(void) EraseTable:(NSString *)tableName;
//更新表数据
-(void) UpdateDataToTable:(NSString *)sqlStr;

//插入数据
-(void) insertDataWithTableName:(NSString *)tableName withParameterDictionary:(NSDictionary *)insertDic;


//删除
-(void)deleteWithDeleteSql:(NSString *)deleteSql;



@end

