//
//  BPGlobalDatabaseDAO.m
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPGlobalDatabaseDAO.h"
#import "BPFilePathManager.h"


@implementation BPGlobalDatabaseDAO
//@synthesize dbQueue;

static BPGlobalDatabaseDAO * dataBaseDao = nil;


- (void)dealloc{
    
//    [dbQueue release];
//    dbQueue = nil;
    [super dealloc];
}

- (id)init{
    
    self = [super init];
    if(self){
        NSString * dbName = [NSString stringWithFormat:@"GlobalDatabase.db"];
        NSString * dbPath = [BPFilePathManager globalDocumentPath];
        ////////NSLog(@"dbpath = %@",dbPath);
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL fileExists = [fileManager fileExistsAtPath:[dbPath stringByAppendingPathComponent:dbName]];
        if(fileExists){
            self.dbQueue =[FMDatabaseQueue databaseQueueWithPath:[dbPath stringByAppendingPathComponent:dbName]];
            
            
        }else{
            
            self.dbQueue =[FMDatabaseQueue databaseQueueWithPath:[dbPath stringByAppendingPathComponent:dbName]];
            
        }
    }
    
    return self;
}



// 改变DAO接口
+ (void)changeBPGlobalDatabaseDAO{
    
    @synchronized(dataBaseDao)
    {
        if(dataBaseDao)
        {
            [dataBaseDao release];
            dataBaseDao = nil;
            
            
//            if(![UserPreferences CurrentUserID]){
//                return;
//            }
            
            dataBaseDao =[[BPGlobalDatabaseDAO alloc] init];
        }
    }
}


// 获取DAO接口
+ (BPGlobalDatabaseDAO *)getSharedBPGlobalDatabaseDAO{
    @synchronized(dataBaseDao)
    {
        if(dataBaseDao == nil)
        {
//            if(![UserPreferences CurrentUserID]){
//                return nil;
//            }
            dataBaseDao =[[BPGlobalDatabaseDAO alloc] init];
        }
        
        return dataBaseDao;
    }
}


/*+ (DatabaseDAO *) getSharedDatabaseDAO{
 
 static dispatch_once_t dataBase_once;
 
 dispatch_once(&dataBase_once, ^{
 ////////NSLog(@"一次");
 dataBaseDao = [[self alloc] init];
 });
 
 
 return dataBaseDao;
 }*/


@end

