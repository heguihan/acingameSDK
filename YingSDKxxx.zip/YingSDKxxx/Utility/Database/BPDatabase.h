//
//  BPDatabase.h
//  BigPlayers
//
//  Created by John Cheng on 13-4-12.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabaseQueue.h"

@interface BPDatabase : NSObject
@property(nonatomic,retain) FMDatabaseQueue * dbQueue;
@end
