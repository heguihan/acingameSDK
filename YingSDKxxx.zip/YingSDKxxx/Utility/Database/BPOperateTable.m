//
//  OperateTable_GlobalDataBase.m
//  GameHub
//
//  Created by John Cheng on 13-3-21.
//  Copyright (c) 2016年 Jun. All rights reserved.
//

#import "BPOperateTable.h"
#import "BPGlobalDatabaseDAO.h"
#import "DatabaseDAO.h"

@implementation BPOperateTable

- (id)initWithDatabaseTypeIsGlobal:(BOOL)isGlobal
{
    self = [super init];
    if(self)
    {
        if(isGlobal)
        {
            dataBase = (BPGlobalDatabaseDAO *)[BPGlobalDatabaseDAO getSharedBPGlobalDatabaseDAO];
        }
        else
        {
           //  dataBase = (DatabaseDAO *)[DatabaseDAO getSharedDatabaseDAO];
        }
    }
    return  self;
}


- (void)dealloc
{
    [super dealloc];
}

//创建表格
-(BOOL) CreateTableToDataBase:(NSString *)tableName SQLString:(NSString *)sqlStr
{
    __block BOOL createSuccess = YES;
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        if(![db open])
        {
            [db close];
            return;
        }
        
        if(![db tableExists:tableName])
        {
            NSString *str = [NSString stringWithFormat:@"create table if not exists %@(%@)",tableName,sqlStr];
            
            
            [db beginTransaction];
            createSuccess = [db executeUpdate:str];
            [db commit];
        }
        [db close];
    }];

    return createSuccess;
}

//清除表数据
-(void) EraseTable:(NSString *)tableName
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        if(![db open])
        {
            [db close];
            return;
        }
        if(![db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", tableName]])
        {
            ////////NSLog(@"Erase table error!");
        }
        [db close];
    }];
}

//删除
-(void)deleteWithDeleteSql:(NSString *)deleteSql
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
    if(![db open])
    {
        [db close];
        return;
    }
    BOOL res = [db executeUpdate:deleteSql];
    
    if (!res) {
        ////////NSLog(@"删除失败");
    } else {
        ////////NSLog(@"删除成功");
    }
    [db close];
          
 }];
}


//判断表格是否存在
-(BOOL) TableExists:(NSString *)tableName
{
    __block BOOL exist = NO;
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        if(![db open])
        {
            [db close];
            return;
        }
        exist = [db tableExists:tableName];
        [db close];
    }];
    
    return exist;
}

//插入数据
-(void) insertDataToTable:(NSString *)sqlStr  withParameterDictionary:(NSDictionary *) insertDic
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        
        [db beginTransaction];
      BOOL result =   [db executeUpdate:sqlStr withParameterDictionary:insertDic];
        if (result) {
            ////////NSLog(@"插入成功");
        }else{
          ////////NSLog(@"插入失败");
    }
        
        [db commit];
        [db close];
    }];
}
//-(void) insertDataToTable:(NSString *)sqlStr  withParameterDictionary:(NSDictionary *) insertDic deleteWithSql:(NSString *)deleteStr
//{
//    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
//        
//        if(![db open])
//        {
//            [db close];
//            return;
//        }
//        //先删除表中存在的纪录，再删除
//        if(deleteStr && deleteStr.length>1)
//        {
//            [db executeUpdate:deleteStr];
//        }
//        
//        [db beginTransaction];
//        [db executeUpdate:sqlStr withParameterDictionary:insertDic];
//
//        [db commit];
//        [db close];
//    }];
//}

//插入数据
-(void) insertDataToTable:(NSString *)sqlStr withDictionaryInArray:(NSArray *) insertArray
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        [db beginTransaction];
        for(int i=0; i< [insertArray count]; i++)
        {
            [db executeUpdate:sqlStr withParameterDictionary:[insertArray objectAtIndex:i]];
        }
        
        [db commit];
        [db close];
    }];
}

//插入数据， 监测是否存在该条纪录，删除并存入
-(void) insertDataToTable:(NSString *)sqlStr withDictionaryInArray:(NSArray *)insertArray withDeleteStr:(NSArray *)strArray
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        [db beginTransaction];
        for(int i=0; i< [insertArray count]; i++)
        {
            NSDictionary *dic = [insertArray objectAtIndex:i];
            if(strArray&&[strArray count] >=2)
            {
                NSString *str_t = [strArray objectAtIndex:1];
                NSString *str = [NSString stringWithFormat:@"delete from %@ where %@ = %@",[strArray objectAtIndex:0],str_t,[dic objectForKey:str_t]];
                if([strArray count]>2)
                {
                    for (int i=2; i<[strArray count]; i++)
                    {
                        str_t = [strArray objectAtIndex:i];
                        str = [str stringByAppendingFormat:@" And %@ = %@ ",str_t,[dic objectForKey:str_t]];
                    }
                }
                [db executeUpdate:str];
            }
            [db executeUpdate:sqlStr withParameterDictionary:dic];
        }
        
        [db commit];
        [db close];
    }];
}


//查询数据
-(NSMutableArray *)queryForDataWithSql:(NSString *)sqlStr
{
    __block NSMutableArray * array = [[[NSMutableArray alloc] initWithCapacity:0] autorelease];
    
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        
        FMResultSet * rs = [db executeQuery: sqlStr];
        
        while ([rs next])
        {
            [array addObject:[NSMutableDictionary dictionaryWithDictionary:[rs resultDictionary]]];
        }
        [rs close];
        [db close];
        
    }];
    if([array count] <= 0)
    {
        return nil;
    }
    return array;
}


//更新表数据
-(void) UpdateDataToTable:(NSString *)sqlStr
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        
        [db beginTransaction];
       BOOL result= [db executeUpdate:sqlStr];
        if (result) {
            ////////NSLog(@"更新成功");
        }else{
            
        ////////NSLog(@"更新失败");
            
        }
        [db commit];
        [db close];
    }];
}


//获取sql语句，并创建表格
-(NSString *) getSqlStrFromDic:(NSDictionary *)insertDic CreateTableName:(NSString *)tableName DataBase:(FMDatabase *)db
{
    NSString *sqlStr_b = [insertDic.allKeys componentsJoinedByString:@","];
    if(![db tableExists:tableName])
    {
        NSString* createTable = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@(%@)",tableName,sqlStr_b];
        [db executeUpdate:createTable];
    }
    //    NSMutableArray *ary = [NSMutableArray arrayWithCapacity:50];
    //    for(int i=0;i<insertDic.allKeys.count;i++)
    //    {
    //        [ary addObject:@"?"];
    //    }
    NSString *sqlStr_a = [insertDic.allKeys componentsJoinedByString:@",:"];
    sqlStr_a = [NSString stringWithFormat:@":%@",sqlStr_a];
    NSString *sqlStr = [NSString stringWithFormat:@"INSERT INTO %@ (%@) VALUES (%@)",tableName,sqlStr_b,sqlStr_a];
    return sqlStr;
}

//插入数据
-(void) insertDataWithTableName:(NSString *)tableName withParameterDictionary:(NSDictionary *)insertDic// deleteWithSql:(NSString *)deleteStr
{
    [dataBase.dbQueue inDatabase:^(FMDatabase *db) {
        
        if(![db open])
        {
            [db close];
            return;
        }
        [db beginTransaction];
        NSString *sqlStr = [self getSqlStrFromDic:insertDic CreateTableName:tableName DataBase:db];
        [db executeUpdate:sqlStr withParameterDictionary:insertDic];
        
        [db commit];
        [db close];
    }];
}




@end
