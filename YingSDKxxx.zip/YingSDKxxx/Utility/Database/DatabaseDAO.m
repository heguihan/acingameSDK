//
//  DatabaseDAO.m
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "DatabaseDAO.h"
#import "ShuZhiZhangUserPreferences.h"
#import "BPFilePathManager.h"
#import "LKDAOBase.h"

#define USER_ID_FILE_NAME @"user_%@/dataBase"   // 数据库.db根目录

@implementation DatabaseDAO
//@synthesize dbQueue;

static DatabaseDAO * dataBaseDao = nil;


- (void)dealloc{
    
//    [dbQueue release];
//    dbQueue = nil;
//    [super dealloc];
}

- (id)init{
    
    self = [super init];
    if(self){
        NSString * dbName = [NSString stringWithFormat:@"user_%@.db",[ShuZhiZhangUserPreferences CurrentUserID]];
        NSString * dbPath = [BPFilePathManager createUserFolderWithName:[NSString stringWithFormat:USER_ID_FILE_NAME,[ShuZhiZhangUserPreferences CurrentUserID]]];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL fileExists = [fileManager fileExistsAtPath:[dbPath stringByAppendingPathComponent:dbName]];
       // ////////NSLog(@"数据库路径:%@",[dbPath stringByAppendingPathComponent:dbName]);
        
        if(fileExists){
            self.dbQueue =[FMDatabaseQueue databaseQueueWithPath:[dbPath stringByAppendingPathComponent:dbName]];
            
            
        }else{
            
            self.dbQueue =[FMDatabaseQueue databaseQueueWithPath:[dbPath stringByAppendingPathComponent:dbName]];
            
        }
    }
    
    return self;
}



// 改变DAO接口
+ (void)changeDatabaseDAO{
    
    @synchronized(dataBaseDao)
    {
        if(dataBaseDao)
        {
//            [dataBaseDao release];
            dataBaseDao = nil;
            
            
            if(![ShuZhiZhangUserPreferences CurrentUserID]){
                return;
            }
            
            dataBaseDao =[[DatabaseDAO alloc] init];
            [LKDAOBase clearCreateHistory];
        }
    }
}


// 获取DAO接口
+ (DatabaseDAO *)getSharedDatabaseDAO{
    
    @synchronized(dataBaseDao)
    {
        if(dataBaseDao == nil)
        {
            if(![ShuZhiZhangUserPreferences CurrentUserID]){
                return nil;
            }
            dataBaseDao =[[DatabaseDAO alloc] init];
        }
        
        return dataBaseDao;
    }
}


/*+ (DatabaseDAO *) getSharedDatabaseDAO{
 
 static dispatch_once_t dataBase_once;
 
 dispatch_once(&dataBase_once, ^{
 ////////NSLog(@"一次");
 dataBaseDao = [[self alloc] init];
 });
 
 
 return dataBaseDao;
 }*/


@end
