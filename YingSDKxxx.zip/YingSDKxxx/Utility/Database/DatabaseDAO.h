//
//  DatabaseDAO.h
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabaseQueue.h"
#import "BPDatabase.h"

@interface DatabaseDAO : BPDatabase//NSObject

//@property(nonatomic,retain) FMDatabaseQueue * dbQueue;

// 改变DAO接口 （用于注销更改用户）
+ (void)changeDatabaseDAO;

// 获取DAO接口
+ (DatabaseDAO *)getSharedDatabaseDAO;

@end
