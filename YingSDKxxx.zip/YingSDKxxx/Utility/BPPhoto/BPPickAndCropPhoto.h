//
//  pickAndCropPhoto.h
//  GameHubSDK
//
//  Created by John Cheng on 13-4-2.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ELCImagePickerController.h"
#import "ELCAlbumPickerController.h"
#import "ELCAssetTablePicker.h"
#import "SSPhotoCropperViewController.h"

@protocol PickAndCropPhotoDelegate <NSObject>

-(void) PickAndCropPhotoDidFinishWithImage:(UIImage *)image;

@end


@interface BPPickAndCropPhoto : NSObject <ELCImagePickerControllerDelegate,SSPhotoCropperDelegate,UIImagePickerControllerDelegate>
{
    id<PickAndCropPhotoDelegate> delegate;
    ELCAlbumPickerController *albumController;
    ELCImagePickerController *elcPicker;
}

@property (nonatomic,retain) ELCAlbumPickerController *albumController;
@property (nonatomic,retain) ELCImagePickerController *elcPicker;
@property (nonatomic,assign) id<PickAndCropPhotoDelegate> delegate;

-(void)displayPhotoWithType:(UIImagePickerControllerSourceType)sourceType;
@end
