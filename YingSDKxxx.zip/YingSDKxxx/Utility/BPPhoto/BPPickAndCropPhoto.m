//
//  pickAndCropPhoto.m
//  GameHubSDK
//
//  Created by John Cheng on 13-4-2.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import "BPPickAndCropPhoto.h"
#import "BPUtility.h"

@implementation BPPickAndCropPhoto
@synthesize delegate;
@synthesize albumController;
@synthesize elcPicker;

-(void) dealloc
{
    [albumController release]; albumController = nil;
    [elcPicker release];   elcPicker = nil;
    [super dealloc];
}

//设置图片的方向
- (UIImage*)rotateImage:(UIImage*)img byOrientationFlag:(UIImageOrientation)orient
{
    CGImageRef          imgRef = img.CGImage;
    CGFloat             width = CGImageGetWidth(imgRef);
    CGFloat             height = CGImageGetHeight(imgRef);
    CGAffineTransform   transform = CGAffineTransformIdentity;
    CGRect              bounds = CGRectMake(0, 0, width, height);
    
    
    UIGraphicsBeginImageContext(bounds.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
   // if ((orient == UIImageOrientationDown) || (orient == UIImageOrientationRight) || (orient == UIImageOrientationUp))
    {
        // flip the coordinate space upside down
        CGContextScaleCTM(context, 1, -1);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

//显示相册或照相
-(void)displayPhotoWithType:(UIImagePickerControllerSourceType)sourceType   //:(UIViewController *)viewController_t
{
//    UIWindow* window = [UIApplication sharedApplication].keyWindow;
//    if (!window)
//    {
//        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
//    }
    //相册
    if(sourceType == UIImagePickerControllerSourceTypePhotoLibrary)
    {
        albumController = [[ELCAlbumPickerController alloc] initWithNibName:@"ELCAlbumPickerController" bundle:[NSBundle mainBundle]];
        elcPicker = [[ELCImagePickerController alloc] initWithRootViewController:albumController];
        [albumController setParent:elcPicker];
        [elcPicker setDelegate:self];
        [[BPUtility getCurrentViewController] presentModalViewController:elcPicker animated:YES];
    }
    //照相
    else if(sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        imagePicker.editing=YES;
        imagePicker.allowsEditing=YES;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.showsCameraControls = YES;

        [[BPUtility getCurrentViewController] presentModalViewController:imagePicker animated:YES];
        
    }
}


//显示裁减界面
-(void) showAndCutPhoto:(UIImage *)img withViewControler: (UIViewController *)picker
{
    SSPhotoCropperViewController *photoCropper =
    [[SSPhotoCropperViewController alloc] initWithPhoto:img
                                               delegate:self
                                                 uiMode:SSPCUIModePresentedAsModalViewController
                                        showsInfoButton:YES
                                            IsLandscape:SCREEN_IS_LANDSCAPE
                                                 IsIpad:NO];
    
    [photoCropper setMinZoomScale:0.75f];
    [photoCropper setMaxZoomScale:5.50f];
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:photoCropper];
    
    [picker presentModalViewController:nc animated:NO];

    [photoCropper release];
    [nc release];
}

#pragma mark -----delegate-----
//------------------------------------------------------------------------
//选择了相册里的一张照片，即将进行裁减
- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info
{
    NSDictionary *dic = [info objectAtIndex:0];
    UIImage *image = [dic objectForKey:UIImagePickerControllerOriginalImage];
    [self showAndCutPhoto:[self rotateImage:image byOrientationFlag:image.imageOrientation] withViewControler:picker];
}

- (void)elcImagePickerControllerDidCancel:(ELCImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

//图片裁减完成
- (void) photoCropper:(SSPhotoCropperViewController *)photoCropper
         didCropPhoto:(UIImage *)photo
{
    [photoCropper dismissModalViewControllerAnimated:NO];
    [elcPicker dismissModalViewControllerAnimated:NO];
    
    if([delegate respondsToSelector:@selector(PickAndCropPhotoDidFinishWithImage:)])
    {
        [delegate PickAndCropPhotoDidFinishWithImage:photo];
    }
}

- (void) photoCropperDidCancel:(SSPhotoCropperViewController *)photoCropper
{
    [photoCropper dismissModalViewControllerAnimated:NO];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    if([delegate respondsToSelector:@selector(PickAndCropPhotoDidFinishWithImage:)])
    {
        [delegate PickAndCropPhotoDidFinishWithImage:[info valueForKey:UIImagePickerControllerEditedImage]];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
@end
