
/*
 Copyright 2011 Ahmet Ardal
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

//
//  SSPhotoCropperViewController.m
//  SSPhotoCropperDemo
//
//  Created by Ahmet Ardal on 10/17/11.
//  Copyright 2011 SpinningSphere Labs. All rights reserved.
//

#import "SSPhotoCropperViewController.h"

bool GEIsLandscape();

@interface SSPhotoCropperViewController(Private)
- (void) loadPhoto;
- (void) setScrollViewBackground;
- (IBAction) saveAndClose:(id)sender;
- (IBAction) cancelAndClose:(id)sender;
- (BOOL) isRectanglePositionValid:(CGPoint)pos;
- (IBAction) imageMoved:(id)sender withEvent:(UIEvent *)event;
- (IBAction) imageTouch:(id)sender withEvent:(UIEvent *)event;
@end

@implementation SSPhotoCropperViewController

@synthesize scrollView, photo, imageView, cropRectangleButton, infoButton, delegate,
            minZoomScale, maxZoomScale, infoMessageTitle, infoMessageBody, photoCropperTitle,iv_test;

- (id) initWithPhoto:(UIImage *)aPhoto
            delegate:(id<SSPhotoCropperDelegate>)aDelegate
{
    return [self initWithPhoto:aPhoto
                      delegate:aDelegate
                        uiMode:SSPCUIModePresentedAsModalViewController
               showsInfoButton:YES
                   IsLandscape:NO
                        IsIpad:NO];
}

- (id) initWithPhoto:(UIImage *)aPhoto
            delegate:(id<SSPhotoCropperDelegate>)aDelegate
              uiMode:(SSPhotoCropperUIMode)uiMode
     showsInfoButton:(BOOL)showsInfoButton
     IsLandscape:(BOOL)m_IsLandscape
     IsIpad:(BOOL)m_isIpad
{
    self.photo = aPhoto;
    self.delegate = aDelegate;
    _uiMode = uiMode;
    _showsInfoButton = showsInfoButton;

    self.minZoomScale = 0.5f;
    self.maxZoomScale = 3.0f;

    self.infoMessageTitle = @"In order to crop the photo";
    self.infoMessageBody = @"Use two of your fingers to zoom in and out the photo and drag the"
                           @" green window to crop any part of the photo you would like to use.";
    self.photoCropperTitle = @"Crop Photo";
    isLandscape = m_IsLandscape;
    return self;
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.photo = nil;
        self.delegate = nil;
    }
    return self;
}

- (void) dealloc
{
    [self.scrollView release];
    [self.photo release];
    [self.imageView release];
    [self.cropRectangleButton release];
    [self.infoButton release];
    [self.infoMessageTitle release];
    [self.infoMessageBody release];
    [self.photoCropperTitle release];
    [self.iv_test release];
    [super dealloc];
}

- (void) didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction) infoButtonTapped:(id)sender
{
    UIAlertView *av = [[UIAlertView alloc] initWithTitle:self.infoMessageTitle
                                                 message:self.infoMessageBody
                                                delegate:nil
                                       cancelButtonTitle:@"OK"
                                       otherButtonTitles:nil];
    [av show];
    [av release];
}


#pragma -
#pragma mark - View lifecycle

- (void) viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    //
    // setup view ui
    //
    UIBarButtonItem *bi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                        target:self
                                                                        action:@selector(saveAndClose:)];
    self.navigationItem.rightBarButtonItem = bi;
    [bi release];

    if (_uiMode == SSPCUIModePresentedAsModalViewController) {
        bi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel
                                                           target:self
                                                           action:@selector(cancelAndClose:)];
        self.navigationItem.leftBarButtonItem = bi;
        [bi release];
    }

    self.title = self.photoCropperTitle;
    int x,y,w,h;
    //int titleHeight = [UIScreen mainScreen].bounds.size.height - self.view.bounds.size.height;
    if(SCREEN_IS_LANDSCAPE)
    {
        w = [UIScreen mainScreen].bounds.size.height;
        h = [UIScreen mainScreen].bounds.size.width-22;
    }
    else
    {
        w = [UIScreen mainScreen].bounds.size.width;
        h = [UIScreen mainScreen].bounds.size.height-22;
    }
    x = (w - 180)/2;
    y = (h - 180)/2;
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    scrollView.scrollEnabled = YES;
    scrollView.userInteractionEnabled = YES;
    scrollView.delegate = self;
    [self.view addSubview:scrollView];
    
    
    //
    // photo cropper ui stuff
    //
    [self setScrollViewBackground];
    [self.scrollView setMinimumZoomScale:self.minZoomScale];
    [self.scrollView setMaximumZoomScale:self.maxZoomScale];
    
    iv_test= [[UIImageView alloc] init];
    iv_test.image = self.photo;
    iv_test.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:iv_test];
    
    
    cropRectangleButton = [[UIButton alloc] initWithFrame:CGRectMake(x, y, 180, 180)];
    [cropRectangleButton setBackgroundImage:[UIImage imageNamed:@"photo_cropper_rect.png"] forState:UIControlStateNormal];
    [cropRectangleButton setBackgroundImage:[UIImage imageNamed:@"photo_cropper_rect.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:cropRectangleButton];
    
    [self.cropRectangleButton addTarget:self
                                 action:@selector(imageTouch:withEvent:)
                       forControlEvents:UIControlEventTouchDown];
    [self.cropRectangleButton addTarget:self
                                 action:@selector(imageMoved:withEvent:)
                       forControlEvents:UIControlEventTouchDragInside];

    self.infoButton = [UIButton buttonWithType:UIButtonTypeInfoDark];
    infoButton.frame = CGRectMake(w-30, h-60, 20, 20);
    [infoButton addTarget:self action:@selector(infoButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:infoButton];
    if (!_showsInfoButton) {
        [self.infoButton setHidden:YES];
    }
    
    if (self.photo != nil) {
        [self loadPhoto];
    }
}

- (void) viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if(isLandscape) 
    {
        return UIInterfaceOrientationIsLandscape(interfaceOrientation);
    }
    else 
    {
        return UIInterfaceOrientationIsPortrait(interfaceOrientation);
    }

   
    //
}


#pragma -
#pragma UIScrollViewDelegate Methods

- (UIView *) viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}


#pragma -
#pragma Private Methods

- (UIImage*)rotateImage:(UIImage*)img byOrientationFlag:(UIImageOrientation)orient
{
    CGImageRef          imgRef = img.CGImage;
    CGFloat             width = CGImageGetWidth(imgRef);
    CGFloat             height = CGImageGetHeight(imgRef);
    CGAffineTransform   transform = CGAffineTransformIdentity;
    CGRect              bounds = CGRectMake(0, 0, width, height);
    CGSize              imageSize = bounds.size;
    CGFloat             boundHeight;
    
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        default:
            // image is not auto-rotated by the photo picker, so whatever the user
            // sees is what they expect to get. No modification necessary
            transform = CGAffineTransformIdentity;
            break;
            
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if ((orient == UIImageOrientationDown) || (orient == UIImageOrientationRight) || (orient == UIImageOrientationUp)){
        // flip the coordinate space upside down
        CGContextScaleCTM(context, 1, -1);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

- (void) loadPhoto
{
    if (self.photo == nil) {
        return;
    }
    
    //self.photo=[self rotateImage:self.photo byOrientationFlag:self.photo.imageOrientation];
    CGFloat w = self.photo.size.width;
    CGFloat h = self.photo.size.height;
    
    int x;
    int y;
    CGFloat ScreenH = 960;
    CGFloat ScreenW = 640;
    if(SCREEN_IS_LANDSCAPE)
    {
        x = (ScreenH - w)/4;
        y = (ScreenW - h)/4;
//        [scrollView setContentOffset:CGPointMake(0, -(640 - h)/4.0f)];
    }
    else
    {
        x = (ScreenW - w)/4;
        y = (ScreenH-h)/4-22;
//        [scrollView setContentOffset:CGPointMake(-(640 - h)/4.0f, 0)];
    }
    if(x<0)
    {
        [scrollView setContentOffset:CGPointMake(-x, 0)];
        x = 0;
    }
    if(y<0)
    {
        [scrollView setContentOffset:CGPointMake(0, -y)];
        y = 0;
    }
    CGRect imageViewFrame = CGRectMake(x, y, roundf(w / 2.0f), roundf(h / 2.0f));
   // CGRect imageViewFrame = CGRectMake(0.0f, 0.0f, w, h);
    self.scrollView.contentSize = imageViewFrame.size;
    

    //UIImageView *iv 
//    iv_test= [[UIImageView alloc] initWithFrame:imageViewFrame];
    iv_test.image = self.photo;
    iv_test.frame = imageViewFrame;
    iv_test.contentMode = UIViewContentModeScaleAspectFit;
//    [self.scrollView addSubview:iv_test];
    self.imageView = iv_test;
}

- (void) setScrollViewBackground
{
    self.scrollView.backgroundColor = [UIColor grayColor];
   // self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"photo_cropper_bg"]];
}


double radians (double degrees) {return degrees * M_PI/180;}
- (UIImage *) croppedPhoto
{
    int x;
    int y;
//    CGFloat w = self.photo.size.width;
//    CGFloat h = self.photo.size.height;
//    CGFloat ScreenH = 960;
//    CGFloat ScreenW = 640;
//    if([PublicFunction DeviceisLandscape])
//    {
//        x = (ScreenH - w)/4;
//        y = (ScreenW - h)/4;
//    }
//    else
//    {
//        x = (ScreenW - w)/4;
//        y = (ScreenH-h)/4-22;
//    }
    x = self.imageView.frame.origin.x;
    y = self.imageView.frame.origin.y;
    CGFloat ox = self.scrollView.contentOffset.x;
    CGFloat oy = self.scrollView.contentOffset.y;
    CGFloat zoomScale = self.scrollView.zoomScale;
    
    CGFloat cx = (ox + self.cropRectangleButton.frame.origin.x+15-x) * 2.0f / zoomScale;
    CGFloat cy = (oy + self.cropRectangleButton.frame.origin.y + 15-y) * 2.0f / zoomScale;
    CGFloat cw = 300.0f / zoomScale;
    CGFloat ch = 300.0f / zoomScale;
    CGRect cropRect = CGRectMake(cx, cy, cw, ch);
    
//    NSLog(@"---------- cropRect: %@", NSStringFromCGRect(cropRect));
//    NSLog(@"--- self.photo.size: %@", NSStringFromCGSize(self.photo.size));
//    
    CGImageRef imageRef = CGImageCreateWithImageInRect([self.photo CGImage], cropRect);
    
    UIImage *result = [UIImage imageWithCGImage:imageRef];
    
    //NSLog(@"------- result.size: %@", NSStringFromCGSize(result.size));
    
    return result;
}

- (IBAction) saveAndClose:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(photoCropper:didCropPhoto:)]) {
        [self.delegate photoCropper:self didCropPhoto:[self croppedPhoto]];
    }
}

- (IBAction) cancelAndClose:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(photoCropperDidCancel:)]) {
        [self.delegate photoCropperDidCancel:self];
    }
}

- (BOOL) isRectanglePositionValid:(CGPoint)pos
{
    CGRect innerRect = CGRectMake((pos.x + 15), (pos.y + 15), 150, 150);
    return CGRectContainsRect(self.scrollView.frame, innerRect);
}

- (IBAction) imageMoved:(id)sender withEvent:(UIEvent *)event
{
    CGPoint point = [[[event allTouches] anyObject] locationInView:self.view];

    CGPoint prev = _lastTouchDownPoint;
    _lastTouchDownPoint = point;
    CGFloat diffX = point.x - prev.x;
    CGFloat diffY = point.y - prev.y;

    UIControl *button = sender;
    CGRect newFrame = button.frame;
    newFrame.origin.x += diffX;
    newFrame.origin.y += diffY;
    if ([self isRectanglePositionValid:newFrame.origin]) {
        button.frame = newFrame;
    }
}

- (IBAction) imageTouch:(id)sender withEvent:(UIEvent *)event
{
    CGPoint point = [[[event allTouches] anyObject] locationInView:self.view];
    _lastTouchDownPoint = point;
    NSLog(@"imageTouch. point: %@", NSStringFromCGPoint(point));
}
@end
