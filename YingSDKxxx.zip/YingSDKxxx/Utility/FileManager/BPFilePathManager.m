//
//  FilePathManager.m
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPFilePathManager.h"

#define USER_ROOT @"user"
#define GLOBAL_ROOT @"global"

@implementation BPFilePathManager


// 获取Document路径
+ (NSString *)applicationDocumentsDirectoryPath{
    
    NSArray * DocumentDirectory = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return [DocumentDirectory objectAtIndex:0];
}


//获取Cache路径
+(NSString *)applicationCacheDirectoryPath
{
    return [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
}

// 判断路径存在
+ (BOOL)fileExistsAtPath:(NSString *)path{
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        return YES;
    }else{
        return NO;
    }
}


// 按路径删除文件
+ (void)deleteFileAtPath:(NSString *)path{
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        
        [fileManager removeItemAtPath:path error:nil];
    }else{
        
        
    }
}



// 获取global根目录
+ (NSString *)globalDocumentPath{
    
    NSString * path = [[self applicationDocumentsDirectoryPath]stringByAppendingPathComponent:GLOBAL_ROOT];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        
        //////////NSLog(@"存在");
        
    }else{
        //-创建
        [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    
    return path;
}

// 创建global文件 global+folder
+ (NSString *)createGlobalSubFolderWithName:(NSString *)folderName{
    
    NSString * path = [[self globalDocumentPath]stringByAppendingPathComponent:folderName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        
    }else{
        [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    
    return path;
}



// 获取user根目录
+ (NSString *)userDocumentPath{
    
    NSString * path = [[self applicationDocumentsDirectoryPath]stringByAppendingPathComponent:USER_ROOT];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        
    }else{
        //-创建
        [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    
    return path;
}



// 创建user文件 user+folder
+ (NSString *)createUserFolderWithName:(NSString *)folderName{
    
    NSString * path = [[self userDocumentPath]stringByAppendingPathComponent:folderName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:path];
    
    if(fileExists){
        
    }else{
        [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    
    return path;
}

//// 获取用户头像
//+ (NSString *)UserHeadImagePathWithUserId:(int )userId{
//    
//    NSString * userPath = [[self userDocumentPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"user_%d",userId]];
//    if(![[NSFileManager defaultManager] fileExistsAtPath:userPath])
//    {
//        [[NSFileManager defaultManager] createDirectoryAtPath:userPath withIntermediateDirectories:YES attributes:nil error:nil];
//    }
//    NSString * headPath = [userPath stringByAppendingPathComponent:@"userHead.png"];
//    return headPath;
//}

//通过url获取路径
+(NSString *) getCachePathWithFileName:(NSString *)fileName AndURLStr:(NSString *)urlStr
{
    if(!urlStr || (NSNull *)urlStr == [NSNull null] || urlStr.length<1)
    {
        return nil;
    }
    NSString *str = sha1([urlStr UTF8String]);
    NSString *path = [[self applicationCacheDirectoryPath] stringByAppendingPathComponent:fileName];
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [path stringByAppendingPathComponent:str];
}

@end
