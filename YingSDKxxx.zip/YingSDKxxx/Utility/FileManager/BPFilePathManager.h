//
//  FilePathManager.h
//  BigPlayers
//
//  Created by Jun on 13-4-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BPFilePathManager : NSObject

// 获取Document路径
+ (NSString *)applicationDocumentsDirectoryPath;


//获取Cache路径
+(NSString *)applicationCacheDirectoryPath;


// 判断路径存在
+ (BOOL)fileExistsAtPath:(NSString *)path;



// 按路径删除文件
+ (void)deleteFileAtPath:(NSString *)path;


// 获取global根目录
+ (NSString *)globalDocumentPath;

// 创建global文件 global+folder
+ (NSString *)createGlobalSubFolderWithName:(NSString *)folderName;




// 获取user根目录
+ (NSString *)userDocumentPath;


// 创建user文件 user+folder
+ (NSString *)createUserFolderWithName:(NSString *)folderName;




//// 获取用户头像
//+ (NSString *)UserHeadImagePathWithUserId:(int )userId;


//通过url获取路径
+(NSString *) getCachePathWithFileName:(NSString *)fileName AndURLStr:(NSString *)urlStr;

@end
