//
//  CommonHeader.h
//  BigPlayers
//
//  Created by Jun on 13-4-9.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "TPCommonUrlModel.h"




/***********************************************************网络API***************************************************/

#define GLOBAL_LOGIN_API_URL [[TPCommonUrlModel ChooseSDKEnvironment] objectForKey:@"TYLogin"] // ****登录测试地址*****//
#define GLOBAL_Pay_API_URL [[TPCommonUrlModel ChooseSDKEnvironment] objectForKey:@"TYPay"]    // *****支付下单地址*****//
#define GLOBAL_Pay_callback_URL   [[TPCommonUrlModel ChooseSDKEnvironment] objectForKey:@"TYPayCallback"]   // *****支付回调地址*****//
#define GLOBAL_Config_API_URL    [[TPCommonUrlModel ChooseSDKEnvironment] objectForKey:@"TYConfig"]  // ****配置config表***正式环境**//
#define GLOBAL_DEVCIE_API_URL [[TPCommonUrlModel ChooseSDKEnvironment] objectForKey:@"DMdevice"]
















#define GLOBAL_BASE_API_URL  @""

// 新的支付宝支付地址
#define PurchaseManagerDomainUrl  @""  // ************//


#define PurchaseCallBackDomainUrl @""

//发送消息
#define ChatMessageDomainURL  @""

//客服MQTT
#define MQTT_URL @""
//论坛
#define ForumDomainURL @""


//离线信息
#define ChatOffLineURL @""

#define BigPackagePostURL @""

#define GLOBAL_DOMAIN_URL @""









/******************************************************************************************************************/

#define BPLog ////////NSLog
// 用户文件夹
#define USER_FILE_WITH_USERID @"user_%@"

#define BPUserInfoTableName @"BPUserInfo"
#define BPGameInfoTableName @"BPGameInfo"
#define BPPaymentInfoTableName @"BPPaymentInfoTable"


#ifdef DEBUG
#   define TPLog(fmt, ...) ////////NSLog((@"^ %s line %d " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#   define TPLog(...)
#endif


#ifdef DEBUG
#define LRString [NSString stringWithFormat:@"%s", __FILE__].lastPathComponent
#define LRLog(...) printf("%s: %s 第%d行: %s\n\n",[[NSString lr_stringDate] UTF8String], [LRString UTF8String] ,__LINE__, [[NSString stringWithFormat:__VA_ARGS__] UTF8String]);

#else
#define LRLog(...)
#endif



//ios7
#define BPDeviceSystemVersion_IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue] < 7.0f ? NO : YES)
////用于显示判断，单为xcode5以下时，不需要这个区分
//#ifdef BPLessThanXcode5
//#define BP_Show_IOS7 NO
//#else
//#define BP_Show_IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue] < 7.0f ? NO : YES)
//#endif


#define BP_Show_IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue] < 7.0f ? NO : YES)



#ifdef BPLessThanXcode6
#define BP_IS_OS_8_OR_LATER NO
#else

#define BP_IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

#endif

// IPHONE5
#define BPDevice_is_iphone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)


// 是横屏
// #define SCREEN_IS_LANDSCAPE  UIDeviceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])

#define SCREEN_IS_LANDSCAPE   UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])



//是否为ipad的
#define BPDevice_is_ipad  [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad

// 屏宽
#define SCREEN_WIDTH_IPHONE  ((SCREEN_IS_LANDSCAPE && !BP_IS_OS_8_OR_LATER) ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width )//(! SCREEN_IS_LANDSCAPE ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)
// 屏高
#define SCREEN_HEIGHT_IPHONE ((SCREEN_IS_LANDSCAPE && !BP_IS_OS_8_OR_LATER) ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)//(! SCREEN_IS_LANDSCAPE ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)

// 屏宽
#define SCREEN_WIDTH_IPAD  540//(! SCREEN_IS_LANDSCAPE ? 540 : 620)
// 屏高
#define SCREEN_HEIGHT_IPAD 620//(! SCREEN_IS_LANDSCAPE ? 620 : 540)


#define BPBackImageWidth 300   //320
#define BPBackImageHeight 300 //278


// 屏宽
#define SCREEN_WIDTH (BPDevice_is_ipad ? SCREEN_WIDTH_IPAD : SCREEN_WIDTH_IPHONE)
// 屏高
#define SCREEN_HEIGHT (BPDevice_is_ipad ? SCREEN_HEIGHT_IPAD : SCREEN_HEIGHT_IPHONE)

//真实的屏幕高宽，主要是ipad用的
#define REAL_SCREEN_WIDTH ((SCREEN_IS_LANDSCAPE && !BP_IS_OS_8_OR_LATER) ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)

#define REAL_SCREEN_HEIGHT ((SCREEN_IS_LANDSCAPE && !BP_IS_OS_8_OR_LATER) ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)



// 屏高 - 导航栏
#define SCREEN_HEIGHT_NAV ((SCREEN_IS_LANDSCAPE && ! BPDevice_is_ipad) ? (SCREEN_HEIGHT -32) : (SCREEN_HEIGHT -44) )


//收到消息，显示消息提示的红点
#define BPHasGotMessageNotification @"BPHasGotMessage"
//消息读取完成，隐藏消息提示的红点
#define BPNoMessageHidePromptNotification @"BPNoMessageHidePrompt"

////分享监听事件
//
//#define BPShareNotification @"BPShareCallback"
//
//

#define BPUITableViewCellSelectedColor [UIColor colorWithRed:245/255.0f green:239/255.0f blue:220/255.0f alpha:1]


#define SDKVersion  2.7.0


// 用户类型
typedef enum {
    
    CommonType = 0,     //普通
    SinaType,           //新浪
    TcWeiboType,        //腾讯
    TcQQType,           //QQ
    
}BPUserType;

// 注册类型
typedef enum
{
    PhoneRegist = 0,
    NameAccount,
    EmailRegister,
    
} registerTypes;


