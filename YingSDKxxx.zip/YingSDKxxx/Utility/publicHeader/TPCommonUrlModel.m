//
//  TPCommonUrlClass.m
//  BigPlayerSDK
//
//  Created by SkyGame on 16/5/23.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import "TPCommonUrlModel.h"

@implementation TPCommonUrlModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
        
    }
    return self;
}

+(NSDictionary *)ChooseSDKEnvironment{
    
    int index = [[ShuZhiZhangUserPreferences CurrentEnvironment] intValue];

    NSDictionary *URLDic =nil ;
 
    switch (index) {
        case 0:    // 上线环境
            URLDic = @{
                       @"TYLogin":@"http://fshuet.acingame.com/",
                       @"TYPay":  @"http://fshuet.acingame.com/requestPay/",
                       @"TYPayCallback":@"http://fshuet.acingame.com/paycallback/" ,
                       @"TYConfig": @"http://fshuet.acingame.com/config/getConfig",
                       @"DMdevice": @"http://dm.acing.com/api/reports"
                       };
//            URLDic = @{
//                       @"TYLogin":@"http:192.168.1.89:8080/",
//                       @"TYPay":  @"http:192.168.1.89:8080/requestPay/",
//                       @"TYPayCallback":@"http:192.168.1.89:8080/paycallback/" ,
//                       @"TYConfig": @"http://fshuet.acingame.com/config/getConfig"
//                       };
//            URLDic = @{
//                       @"TYLogin":@"http://zhijie.test.acingame.com/",
//                       @"TYPay":  @"http://zhijie.test.acingame.com/requestPay/",
//                       @"TYPayCallback":@"http://zhijie.test.acingame.com/paycallback/" ,
//                       @"TYConfig": @"http://u8svr.acingame.com/config/getConfig"
//                       };
           ////////NSLog(@"上线环境URL === 0%d",index);
            break;
            
        case 1: // 外网测试环境
            URLDic = @{
                       @"TYLogin":@"https://182.254.225.137/",
                       @"TYPay":  @"https://182.254.225.137/requestPay/",
                       @"TYPayCallback":@"https://182.254.225.137/paycallback/" ,
//                     @"TYConfig":@"http://182.254.225.137:8080/u8server/config/getConfig"
                       @"TYConfig": @"https://u8svr.acingame.com/config/getConfig",
                       @"DMdevice": @"http://192.168.254.210:8001/api/reports"
                       };
          ////////NSLog(@"外网测试环境URL ===0%d",index);
            
            break;
        default: // 上线环境
            URLDic = @{
                       @"TYLogin":@"https://zhijie.acingame.com/",
                       @"TYPay":  @"https://zhijie.acingame.com/requestPay/",
                       @"TYPayCallback":@"https://zhijie.acingame.com/paycallback/" ,
                       @"TYConfig": @"https://u8svr.acingame.com/config/getConfig"                       };
          ////////NSLog(@"默认上线环境URL === 0%d",index);
            break;
    }
    
    
    return  URLDic;
    
}




@end
