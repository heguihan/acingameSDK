//
//  TPCommonUrlClass.h
//  BigPlayerSDK
//
//  Created by SkyGame on 16/5/23.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TPCommonUrlModel : NSObject

+(NSDictionary *)ChooseSDKEnvironment;
@end
