//
//  BPWebViewBaseViewController.h
//  BigPlayerSDK
//

//

#import "BPBaseViewController.h"

@interface BPWebViewBaseViewController : BPBaseViewController <UIWebViewDelegate>
@property (nonatomic,assign) BOOL fromGameFlag;

- (id)initWithUrl:(NSString *)url AndTitle:(NSString *)title;

-(void) leftButtonItemAction;

-(void) showWebViewActionButtons;



@end
