//
//  BPWebViewBaseViewController.m
//  BigPlayerSDK
//

//

#import "BPWebViewBaseViewController.h"

@interface BPWebViewBaseViewController ()
@property (nonatomic,retain) UIWebView *webView;
@property (nonatomic,retain) UIActivityIndicatorView *activityView;
@property (nonatomic,retain) NSString *webTitle;
@end

@implementation BPWebViewBaseViewController
@synthesize webView;
@synthesize activityView;
@synthesize fromGameFlag;
@synthesize webTitle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void) showTitleAfterDelay:(NSString *)str
{
    [ShuZhiZhangUtility customNavigationTitle:str ViewController:self];
}


- (id)initWithUrl:(NSString *)url AndTitle:(NSString *)title
{
    self = [super init];
    if (self) {
        // Custom initialization
//        self.title = title;
//        [ShuZhiZhangUtility customNavigationTitle:title ViewController:self];
//        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"BP_nav_back.png" HighLightedImage:@"BP_nav_back_sel.png"];
        
        if(!url || (NSNull *)url==[NSNull null] ||url.length<1)
        {
            return self;
        }
//        self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
        webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV)];
        [webView setBackgroundColor:[UIColor whiteColor]];
        [webView setOpaque:NO];
        [webView  setUserInteractionEnabled: YES];  //是否支持交互
        

        webView.delegate = self;
        webView.scalesPageToFit = YES;
        webView.tag = 1010;
//        webView.contentMode = UIViewContentModeScaleToFill;
//        self.modalPresentationStyle=UIModalPresentationFormSheet;
//        webView.autoresizingMask = UIViewAutoresizingFlexibleWidth;// | UIViewAutoresizingFlexibleHeight;
//        [[NSURLCache sharedURLCache] removeAllCachedResponses];
        NSMutableURLRequest *requestObj = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
        [requestObj setCachePolicy:NSURLRequestUseProtocolCachePolicy];
        [webView loadRequest:requestObj];

        activityView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
        activityView.center = webView.center;
        [activityView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
        [activityView setHidden:YES];
        self.webTitle = title;
    }
    return self;
}

//-(void) viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:animated];
//    
//    //resize modal view
//    self.view.superview.bounds = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
//}
//
//-(void) viewDidAppear:(BOOL)animated
//{
//    CGPoint centerPoint = CGPointMake([[UIScreen mainScreen] bounds].size.width/2, [[UIScreen mainScreen] bounds].size.height/2);
//    self.view.superview.center = centerPoint;
//}

-(void) showWebViewActionButtons
{
    self.webView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-32);
//    self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-44);
    UIImageView *backView = [[UIImageView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT_NAV-32, SCREEN_WIDTH, 32)];
    backView.tag = 61200;
//    backView.backgroundColor = [UIColor colorWithRed:239/255.0f green:239/255.0f blue:239/255.0f alpha:1];
    //    backView.alpha = 0.5;
    backView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_barBG.png"];
    [self.view addSubview:backView];
    [backView release];
    
    //返回
    UIButton *goBack =[UIButton buttonWithType:UIButtonTypeCustom];
    goBack.frame = CGRectMake(10, SCREEN_HEIGHT_NAV-32, 50, 32);
    goBack.tag = 61201;
    [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateNormal];
    [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateHighlighted];
    [goBack addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:goBack];
    //前进
    UIButton *goForward =[UIButton buttonWithType:UIButtonTypeCustom];
    goForward.frame = CGRectMake(80, SCREEN_HEIGHT_NAV-32, 50, 32);
    goForward.tag = 61202;
    [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateNormal];
    [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateHighlighted];
    [goForward addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:goForward];
    
    //刷新
    UIButton *refresh =[UIButton buttonWithType:UIButtonTypeCustom];
    refresh.frame = CGRectMake(SCREEN_WIDTH - 50, SCREEN_HEIGHT_NAV-32, 50, 32);
    refresh.tag = 61203;
    [refresh setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_refresh.png"] forState:UIControlStateNormal];
    [refresh setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_refresh_sel.png"] forState:UIControlStateHighlighted];
    [refresh addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:refresh];
}

-(void) refreshButtonStatus
{
    UIButton *goBack = (UIButton *)[self.view viewWithTag:61201];
    UIButton *goForward = (UIButton *)[self.view viewWithTag:61202];
    if(!goBack || !goForward)
    {
        return;
    }
    if (self.webView.canGoBack)
    {
        [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back.png"] forState:UIControlStateNormal];
        [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back_sel.png"] forState:UIControlStateHighlighted];
    }
    else
    {
        [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateNormal];
        [goBack setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateHighlighted];
    }
    if (self.webView.canGoForward)
    {
        [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward.png"] forState:UIControlStateNormal];
        [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward_sel.png"] forState:UIControlStateHighlighted];
    }
    else
    {
        [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateNormal];
        [goForward setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateHighlighted];
    }
}

-(void) clickButtons:(UIButton *)sender
{
    int index = sender.tag - 61201;
    switch (index) {
        case 0:
            if (self.webView.canGoBack)
            {
                [self.webView goBack];
            }
            break;
        case 1:
            if (self.webView.canGoForward)
            {
                [self.webView goForward];
            }
            break;
        case 2:
            [self.webView reload];
            break;
        default:
            break;
    }
    
}

-(void) leftButtonItemAction
{
    if([webTitle isEqualToString:[BPLanguage getStringForKey:@"BPServiceClause" InTable:@"BPMultiLanguage"]])
    {
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
        return;
    }
    if(!fromGameFlag)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
        
        [ShuZhiZhangUtility postPlatformExitNotification];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    if(fromGameFlag)
    {
        
        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 0.2*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self showTitleAfterDelay:webTitle];
        });
        
        
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:[BPLanguage getStringForKey:@"BPBackToGame" InTable:@"BPMultiLanguage"]];
    }
    else
    {
        [ShuZhiZhangUtility customNavigationTitle:webTitle ViewController:self];
    }
    [self.view addSubview:webView];
    [self.view addSubview:activityView];
}


- (void )webViewDidFinishLoad:(UIWebView *)webView
{
    [activityView stopAnimating];
    activityView.hidden  = YES ;
    [self refreshButtonStatus];
    if(BPDevice_is_ipad)
    {
        NSString* js =
        @"var meta = document.createElement('meta'); "
        @"meta.setAttribute( 'name', 'viewport' ); "
        @"meta.setAttribute( 'content', 'width = 540px, initial-scale = 1.0, user-scalable = yes' ); "
        @"document.getElementsByTagName('head')[0].appendChild(meta)";
        
        [[self webView] stringByEvaluatingJavaScriptFromString: js];
    }
}

- (void )webViewDidStartLoad:(UIWebView *)webView
{
    [activityView startAnimating];
    activityView.hidden  = NO ;
}

- (void)webView:(UIWebView *)webview didFailLoadWithError:(NSError *)error
{
    [activityView stopAnimating];
    activityView.hidden  = YES ;
}


- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
//    NSURL *requestURL =[ [ request URL ] retain ];
//    if ( ( [ [ requestURL scheme ] isEqualToString: @"http" ] || [ [ requestURL scheme ] isEqualToString: @"https" ] || [ [ requestURL scheme ] isEqualToString: @"mailto" ])
//        && ( navigationType == UIWebViewNavigationTypeLinkClicked ) ) {
//        // click_inside_click_flag=1;
//        return ![ [ UIApplication sharedApplication ] openURL: [ requestURL autorelease ] ];
//    }
//    else
//    {
//        
//    }
//    [ requestURL release ]; 
    return YES;
}

-(void)dealloc
{
    [webView release];          webView = nil;
    [activityView release];     activityView = nil;
    [webTitle release];         webTitle = nil;
    [super dealloc];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
