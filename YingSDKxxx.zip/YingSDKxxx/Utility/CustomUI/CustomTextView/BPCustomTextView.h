//
//  UICustomTextView.h
//  BigPlayerSDK
//

//

#import <UIKit/UIKit.h>

@interface BPCustomTextView : UITextView
@property (nonatomic, retain) NSString *placeholder;
@property (nonatomic, retain) UIColor *placeholderColor;

-(void)textChanged:(NSNotification*)notification;

@end
