//
//  BPCustomTextField.m
//  BigPlayers
//
//  Created by John Cheng on 13-6-5.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPCustomTextField.h"
#import "BPCommonHeader.h"

@implementation BPCustomTextField
@synthesize PlaceholderOffset_x;
@synthesize PlaceholderOffset_y;
@synthesize PlaceholderColor;
@synthesize PlaceholderFont;
@synthesize TextOffset_x;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

//- (id)initWithPlaceHoder:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//        // Initialization code
//    }
//    return self;
//}


//控制placeHolder的位置，左右缩20
-(CGRect)placeholderRectForBounds:(CGRect)bounds
{
    int offset_y = 0;
    if(BP_Show_IOS7)
    {
        offset_y = 11;
    }
    //return CGRectInset(bounds, 20, 0);
    CGRect inset = CGRectMake(bounds.origin.x+PlaceholderOffset_x, bounds.origin.y+offset_y, bounds.size.width, bounds.size.height);//更好理解些
    return inset;
}
//控制显示文本的位置
-(CGRect)textRectForBounds:(CGRect)bounds
{
    if(TextOffset_x==0)
    {
        TextOffset_x = PlaceholderOffset_x;
    }
    //return CGRectInset(bounds, 50, 0);
    CGRect inset = CGRectMake(bounds.origin.x + TextOffset_x, bounds.origin.y, bounds.size.width -TextOffset_x-10, bounds.size.height);//更好理解些
    
    return inset;
    
}
//控制编辑文本的位置
-(CGRect)editingRectForBounds:(CGRect)bounds
{
    //return CGRectInset( bounds, 10 , 0 );
    if(TextOffset_x==0)
    {
        TextOffset_x = PlaceholderOffset_x;
    }
    CGRect inset = CGRectMake(bounds.origin.x + TextOffset_x, bounds.origin.y, bounds.size.width -TextOffset_x-10, bounds.size.height);
    return inset;
}
////控制左视图位置
//- (CGRect)leftViewRectForBounds:(CGRect)bounds
//{
//    CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width-250, bounds.size.height);
//    return inset;
//    //return CGRectInset(bounds,50,0);
//}

//控制placeHolder的颜色、字体
- (void)drawPlaceholderInRect:(CGRect)rect
{
    //CGContextRef context = UIGraphicsGetCurrentContext();
    //CGContextSetFillColorWithColor(context, [UIColor yellowColor].CGColor);
    [[UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1] setFill];

    [[self placeholder] drawInRect:rect withFont:[UIFont systemFontOfSize:14]];
    
//    if(PlaceholderColor)
//    {
//        [PlaceholderColor setFill];
//    }
//    if(PlaceholderFont)
//    {
//        [[self placeholder] drawInRect:rect withFont:PlaceholderFont];
//    }

}

@end
