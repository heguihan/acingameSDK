//
//  CustomTextField.h
//  BigPlayers
//
//  Created by John Cheng on 13-6-5.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPCustomTextField : UITextField
{
//    CGRect PlaceholderFrame;
    int PlaceholderOffset_x;
    int PlaceholderOffset_Y;
    UIColor *PlaceholderColor;
    UIFont *PlaceholderFont;
    
    int TextOffset_x;
}

@property (nonatomic,assign) int PlaceholderOffset_x;
@property (nonatomic,assign) int PlaceholderOffset_y;
@property (nonatomic,assign) UIColor *PlaceholderColor;
@property (nonatomic,assign) UIFont *PlaceholderFont;
@property (nonatomic,assign) int TextOffset_x;

@end
