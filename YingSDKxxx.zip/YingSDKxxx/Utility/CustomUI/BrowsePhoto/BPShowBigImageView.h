//
//  BPShowBigImageView.h
//  BigPlayers
//
//  Created by John Cheng on 13-8-5.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPShowBigImageView : UIView <UIActionSheetDelegate,UIScrollViewDelegate>
{
    UIInterfaceOrientation currentOrientation;
    BOOL canRotation;
//    int showType;
//    int gifWidth;
//    int gifHeight;
    
    int photoNum;
}

@property (nonatomic,retain) NSMutableArray *picArray;
@property (nonatomic,retain) UIScrollView *scrollView;


- (id)initWithArray:(NSMutableArray *)array AndIndex:(int)index;
@end
