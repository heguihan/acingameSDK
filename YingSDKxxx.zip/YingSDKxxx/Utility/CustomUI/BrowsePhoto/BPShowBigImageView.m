//
//  BPShowBigImageView.m
//  BigPlayers
//
//  Created by John Cheng on 13-8-5.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import "BPShowBigImageView.h"
#import "BPPhoteShareActionSheet.h"
#import "BigPlayerSDKBase.h"


@implementation BPShowBigImageView
@synthesize picArray;
@synthesize scrollView;

-(void) dealloc
{
    [picArray release];         picArray = nil;
    [scrollView release];       scrollView = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

//- (id)initfilePath:(NSString *)imagePath BigImageUrl:(NSString *)url showType:(int)type
- (id)initWithArray:(NSMutableArray *)array AndIndex:(int)index
{
    self = [super init];
    if (self) {
        int PhotoPageWidth = SCREEN_WIDTH+40;
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
        self.picArray = array;
        
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        self.backgroundColor = [UIColor blackColor];
        self.alpha = 0.0;
        
        scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(-(PhotoPageWidth - SCREEN_WIDTH)/2, 0, PhotoPageWidth, self.bounds.size.height)];
        scrollView.delegate = self;
        scrollView.pagingEnabled = YES;
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.showsVerticalScrollIndicator = NO;
        [self addSubview:scrollView];
        
        photoNum = 0;
        for(int i=0;i<[array count];i++)
        {
//            NSDictionary *dic = [array objectAtIndex:i];
            NSString *imagePath = [BPFilePathManager getCachePathWithFileName:@"bugImage" AndURLStr:[array objectAtIndex:i]];
            
            UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:imagePath]];
            imageView.tag = 11110+photoNum;
            imageView.userInteractionEnabled = YES;
            [scrollView addSubview:imageView];
//            if([[NSFileManager defaultManager] fileExistsAtPath:imagePath])
//            {
//                imageView.image = [UIImage imageWithContentsOfFile:imagePath];
//            }
            imageView.contentMode = UIViewContentModeScaleAspectFit;
            imageView.frame = CGRectMake(PhotoPageWidth*photoNum+(PhotoPageWidth - SCREEN_WIDTH)/2, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
            [imageView release];
            photoNum ++;
            
            if(i == index)
            {
                [scrollView setContentOffset:CGPointMake(PhotoPageWidth*(photoNum-1), 0) animated:NO];
                UIView *imageView = [self viewWithTag:(11110+(photoNum-1))];
                imageView.frame = CGRectMake(PhotoPageWidth*(photoNum-1)+PhotoPageWidth/2, SCREEN_HEIGHT/2, 0, 0);
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:.3];

                imageView.frame = CGRectMake(PhotoPageWidth*(photoNum-1)+(PhotoPageWidth - SCREEN_WIDTH)/2, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
                self.alpha = 1.0;
                [UIView commitAnimations];
            }
        }
        
        scrollView.contentSize = CGSizeMake(PhotoPageWidth*photoNum, scrollView.frame.size.height);
//        if([BigPlayerSDKBase getSharedBPPlatform].bpOrientation == BPInterfaceOrientationLandscape || [BigPlayerSDKBase getSharedBPPlatform].bpOrientation >=BPInterfaceOrientationLandscapeLeft)
//        {}
//        else
//        {
//            currentOrientation = UIInterfaceOrientationPortrait;
//            [[NSNotificationCenter defaultCenter] addObserver:self
//                                                     selector:@selector(changeFrames:)
//                                                         name:UIDeviceOrientationDidChangeNotification
//                                                       object:nil];
//            
//            
//    //        [self showButtonsView];
//            
//            canRotation = YES;
//            if([[UIApplication sharedApplication] statusBarOrientation] != currentOrientation)
//            {
//    //            [self changeBrowerToOrientation:[[UIApplication sharedApplication] statusBarOrientation]];
//            }
//        }
    }
    return self;
}


//显示那些操作按钮
-(void) showButtonsView
{
    //顶上
    UIView *upButtonsView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
    upButtonsView.backgroundColor = [UIColor clearColor];
    upButtonsView.tag = 1200;
    [self addSubview:upButtonsView];
    [upButtonsView release];
    
    UIView *upView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
    upView.tag = 12000;
    upView.backgroundColor = [UIColor blackColor];
    upView.alpha = 0.5;
    [upButtonsView addSubview:upView];
    [upView release];
    //返回
    UIButton *back =[UIButton buttonWithType:UIButtonTypeCustom];
    back.frame = CGRectMake(10, 0, 50, 44);
    back.tag = 12001;
    [back setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [back setImage:[UIImage imageNamed:@"back_sel.png"] forState:UIControlStateHighlighted];
    [back addTarget:self action:@selector(clickBackButton) forControlEvents:UIControlEventTouchUpInside];
    [upButtonsView addSubview:back];
    //分享
    UIButton *share =[UIButton buttonWithType:UIButtonTypeCustom];
    share.frame = CGRectMake(SCREEN_WIDTH - 50, 0, 50, 44);
    share.tag = 12002;
    [share setImage:[UIImage imageNamed:@"share.png"] forState:UIControlStateNormal];
    [share setImage:[UIImage imageNamed:@"share_sel.png"] forState:UIControlStateHighlighted];
    [share addTarget:self action:@selector(clickShareButton) forControlEvents:UIControlEventTouchUpInside];
    [upButtonsView addSubview:share];
    
    //分享状态提示
    UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    activity.frame = CGRectMake(125, 20, 10, 10);
    [activity setHidesWhenStopped:YES];
    activity.tag = 12003;
    [activity stopAnimating];
    [upButtonsView addSubview:activity];
    [activity release];
    
    UILabel *postStatus = [[UILabel alloc] initWithFrame:CGRectMake(150, 12, 60, 30)];
    postStatus.backgroundColor = [UIColor clearColor];
    postStatus.font = [UIFont systemFontOfSize:12];
    postStatus.textColor = [UIColor whiteColor];
    postStatus.tag = 12004;
    [upButtonsView addSubview:postStatus];
    [postStatus release];
 
    
    //底下
    UIView *downButtonsView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 44, SCREEN_WIDTH, 44)];
    downButtonsView.backgroundColor = [UIColor clearColor];
    downButtonsView.tag = 1201;
    [self addSubview:downButtonsView];
    [downButtonsView release];
    
    UIView *downView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
    downView.backgroundColor = [UIColor blackColor];
    downView.tag = 12010;
    downView.alpha = 0.5;
    [downButtonsView addSubview:downView];
    [downView release];
    
    UIButton *save =[UIButton buttonWithType:UIButtonTypeCustom];
    save.frame = CGRectMake(10, 0, 50, 44);
    save.tag = 12011;
    [save setImage:[UIImage imageNamed:@"save.png"] forState:UIControlStateNormal];
    [save setImage:[UIImage imageNamed:@"save_sel.png"] forState:UIControlStateHighlighted];
    [save addTarget:self action:@selector(clickSaveButton) forControlEvents:UIControlEventTouchUpInside];
    [downButtonsView addSubview:save];
    
    [self hideAndShowButtonsView];
}

-(void) hideAndShowButtonsView
{
    UIView *upButtonsView = [self viewWithTag:1200];
    UIView *downButtonsView = [self viewWithTag:1201];
    float alpha = upButtonsView.alpha;
    if(alpha<0.2)
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.4];
        upButtonsView.alpha = 1.0;
        downButtonsView.alpha = 1.0;
        [UIView commitAnimations];
    }
    else
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.4];
        upButtonsView.alpha = 0.0;
        downButtonsView.alpha = 0.0;
        [UIView commitAnimations];
    }
}

#pragma mark ------------change frame
//屏幕翻转操作
-(void) changeBrowerToOrientation:(UIInterfaceOrientation) orientation
{
    if(currentOrientation == orientation || !canRotation)
    {
        return;
    }
    int PhotoPageWidth = SCREEN_WIDTH+40;
    int page = floor((scrollView.contentOffset.x) / PhotoPageWidth); // - PhotoPageWidth / 2
    int w = SCREEN_WIDTH;
    int h = SCREEN_HEIGHT;
    CGAffineTransform rotation;
    
   
    switch (orientation)
    {
        case UIInterfaceOrientationPortrait:
        case UIInterfaceOrientationPortraitUpsideDown:
            rotation = CGAffineTransformIdentity;
            break;
//        case UIInterfaceOrientationPortraitUpsideDown:
//            rotation = CGAffineTransformMakeRotation(M_PI);
//            break;
            
        case UIInterfaceOrientationLandscapeRight:
            rotation = CGAffineTransformMakeRotation(M_PI_2);
            break;
        case UIInterfaceOrientationLandscapeLeft:
            rotation = CGAffineTransformMakeRotation(-M_PI_2);
            break;
        default:
            return;
            break;
    }
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [scrollView setTransform:rotation];
    [UIView commitAnimations];
    
    
//    if(showType ==1)
//    {
////        switch (orientation)
////        {
////            case UIInterfaceOrientationPortrait:
////            case UIInterfaceOrientationPortraitUpsideDown:
////                imageView.layer.position = CGPointMake((SCREEN_HEIGHT - gifWidth)/2, (SCREEN_WIDTH - gifHeight)/2);
//////                imageView.layer.contentsCenter = CGRectMake((SCREEN_HEIGHT - gifWidth)/2, (SCREEN_WIDTH - gifHeight)/2, gifWidth, gifHeight);
//////                imageView.frame = CGRectMake((SCREEN_HEIGHT - gifWidth)/2, (SCREEN_WIDTH - gifHeight)/2, gifWidth, gifHeight);
////                break;
////            case UIInterfaceOrientationLandscapeRight:
////            case UIInterfaceOrientationLandscapeLeft:
////                
////                imageView.layer.contentsCenter = CGRectMake((SCREEN_WIDTH -gifHeight)/2,(SCREEN_WIDTH -gifWidth)/2, gifWidth, gifHeight);
//////                imageView.frame = CGRectMake((SCREEN_WIDTH -gifHeight)/2,(SCREEN_WIDTH -gifWidth)/2, gifWidth, gifHeight);
////                break;
////        }
//        return;
//    }
    
//    int page = floor((scrollView.contentOffset.x - PhotoPageWidth / 2) / PhotoPageWidth);
//    if(UIDeviceOrientationIsLandscape(orientation) && !UIDeviceOrientationIsLandscape(currentOrientation))
//    {
//        page++;
//    }
    
    currentOrientation = orientation;
    switch (orientation)
    {
        case UIInterfaceOrientationPortrait:
        case UIInterfaceOrientationPortraitUpsideDown:
            w = SCREEN_WIDTH;
            h = SCREEN_HEIGHT;
            PhotoPageWidth = w + 40;
            scrollView.frame = CGRectMake(-20, 0,PhotoPageWidth, h);
            break;
        case UIInterfaceOrientationLandscapeRight:
        case UIInterfaceOrientationLandscapeLeft:
            w = SCREEN_HEIGHT;
            h = SCREEN_WIDTH;
            PhotoPageWidth = w + 40;
            scrollView.frame = CGRectMake(0, -20, h,PhotoPageWidth);
            break;
        default:
            w = SCREEN_WIDTH;
            h = SCREEN_HEIGHT;
            break;
    }
//    int page = floor((scrollView.contentOffset.x - PhotoPageWidth / 2) / PhotoPageWidth)+1;
    scrollView.contentSize = CGSizeMake(PhotoPageWidth*photoNum, h);
//    CGPoint offset = scrollView.contentOffset;
    
    scrollView.contentOffset = CGPointMake(PhotoPageWidth*page, 0);
    for(int i=0;i<photoNum;i++)
    {
        UIImageView *imageview = (UIImageView *)[scrollView viewWithTag:(11110+i)];
        imageview.frame = CGRectMake(PhotoPageWidth*i+(PhotoPageWidth - w)/2, 0, w, h);
    }
    
//    switch (orientation)
//    {
//        case UIInterfaceOrientationPortrait:
//        case UIInterfaceOrientationPortraitUpsideDown:
//            w = SCREEN_WIDTH;
//            h = SCREEN_HEIGHT;
//            break;
//        case UIInterfaceOrientationLandscapeRight:
//        case UIInterfaceOrientationLandscapeLeft:
//            w = SCREEN_HEIGHT;
//            h = SCREEN_WIDTH;
//            break;
//        default:
//            w = SCREEN_WIDTH;
//            h = SCREEN_HEIGHT;
//            break;
//    }
    
//    imageView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
//    currentOrientation = orientation;
    return;
    //----------------------------------------------------
    //修改操作按钮的显示
    UIView *upButtonsView = [self viewWithTag:1200];
    UIView *downButtonsView = [self viewWithTag:1201];
    [upButtonsView setTransform:rotation];
    [downButtonsView setTransform:rotation];
    
    [upButtonsView setHidden:YES];
    [downButtonsView setHidden:YES];
    switch (orientation)
    {
        case UIInterfaceOrientationPortrait:
            upButtonsView.frame = CGRectMake(0, 0, w, 50);
            downButtonsView.frame = CGRectMake(0, h-50, w, 50);
            break;
        case UIInterfaceOrientationPortraitUpsideDown:
            upButtonsView.frame = CGRectMake(0, h-50, w, 50);
            downButtonsView.frame = CGRectMake(0, 0, w, 50);
            break;
        case UIInterfaceOrientationLandscapeRight:
            downButtonsView.frame = CGRectMake(0, 0, 50, w);
            upButtonsView.frame = CGRectMake(h-50, 0, 50, w);
            break;
        case UIInterfaceOrientationLandscapeLeft:
            upButtonsView.frame = CGRectMake(0, 0, 50, w);
            downButtonsView.frame = CGRectMake(h-50, 0, 50, w);
            break;
        default:
            return;
            break;
    }
    
    
    UIView *background = [upButtonsView viewWithTag:12000];
    background.frame = CGRectMake(0, 0, w, 50);
    UIButton *share = (UIButton *)[upButtonsView viewWithTag:12002];
    share.frame = CGRectMake(w-50, 5, 50, 44);
    
    UIView *background2 = [downButtonsView viewWithTag:12010];
    background2.frame = CGRectMake(0, 0, w, 50);
    [self performSelector:@selector(showButtonsAfterAnimation:) withObject:[NSNumber numberWithInteger:orientation] afterDelay:0.4];
}
-(void) changeFrames:(NSNotification *)notification
{
    [self changeBrowerToOrientation:(UIInterfaceOrientation)[[UIDevice currentDevice] orientation]];
}


//翻转时隐藏按钮，翻转后显示按钮
-(void) showButtonsAfterAnimation:(NSNumber *)orientation
{
    UIView *downButtonsView = [self viewWithTag:1201];
    UIView *upButtonsView = [self viewWithTag:1200];
//    UIButton *save = (UIButton *)[downButtonsView viewWithTag:12011];
    [downButtonsView setHidden:NO];
    [upButtonsView setHidden:NO];
    if(UIDeviceOrientationIsLandscape([orientation intValue]))
    {
        [downButtonsView setHidden:YES];
        [upButtonsView setHidden:YES];
    }
    else
    {
        [downButtonsView setHidden:NO];
        [upButtonsView setHidden:NO];
    }
    
}

#pragma mark --------action-------
-(void) removeView
{
//    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    [self removeFromSuperview];
}

//点击关闭按钮
-(void) clickBackButton
{
//    [imageRequest cancelAllRequest];
    UIResponder *responder = [self.superview nextResponder];
    UIViewController *viewController_t = (UIViewController *)responder;
    viewController_t.navigationController.navigationBarHidden = NO;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIDeviceOrientationDidChangeNotification
                                                  object:nil];
    [self removeView];
//    [self performSelector:@selector(removeView) withObject:nil afterDelay:.5];
    //    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:NO];
//    [self performSelector:@selector(closePhotoBrowser) withObject:nil afterDelay:0.2];
}

//--------------------------------------

//点击分享按钮
-(void) clickShareButton
{
    //    UIActionSheet *shareSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"分享至新浪微博",@"分享至腾讯微博", nil];
    //    [shareSheet showInView:self];
    //    [shareSheet release];
    canRotation = NO;
    BPPhoteShareActionSheet *shareSheet = [[BPPhoteShareActionSheet alloc] init];
    shareSheet.delegate = self;
    [shareSheet showInView:self];
    [shareSheet release];
}


//- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    canRotation = YES;
//
//    NSString *str = [NSString stringWithFormat:@"我在中国最极致的手机网游世界-爱网游（url）中，发现了一款名为《永生门》手机网游，我刚刚查看了它的精彩图片，发现了这张very beautiful的图片，分享给大家欣赏一下。"];
//    NSString *filePath = [PublicFunction getCachePathWithFileName:@"global/game/gameWorld" AndURLStr:imageURL];
//    UIImage *img = [UIImage imageWithContentsOfFile:filePath];
//    
//    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
//    BPShare *share = delegate.share;
//    switch (buttonIndex) {
//        case 0:
//        {
//            [share tcQQShareTitle:@"测试标题" content:str imageUrl:imageURL gotoUrl:@"www.baidu.com"];
//            break;
//        }
//        case 1:
//        {
//            
//            [share sinaWeiboShare:str image:img];
//            break;
//        }
//        case 2:
//        {
//            UIResponder *responder = [self.superview.superview nextResponder];
//            UIViewController *viewController = (UIViewController *)responder;
//            [share tcWeiboShare:str image:img imageUrl:nil target:viewController];
//            break;
//        }
//            
//        default:
//            break;
//    }
//}

//----------------------------------------------
//点击照片保存到本地
-(void) clickSaveButton
{
    UIImageView *imageView = (UIImageView *)[self viewWithTag:11110];
    UIImage *img = imageView.image;
    UIImageWriteToSavedPhotosAlbum(img, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error
  contextInfo:(void *)contextInfo
{
    if (error != NULL)
    {
        //////NSLog(@"%@",error);
    }
    else  // No errors
    {
        // Show message image successfully saved
        //        [self ShowTishiWithMessage:[BPLanguage getStringForKey:@"photoSavedLocal" InTable:@"BPGameCenter"]];
        [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"photoSavedLocal" InTable:@"BPGameCenter"] AndDisappearSecond:2];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
//    if(showType ==0)
//    [self hideAndShowButtonsView];
//    else if(showType ==1)
        [self clickBackButton];
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
