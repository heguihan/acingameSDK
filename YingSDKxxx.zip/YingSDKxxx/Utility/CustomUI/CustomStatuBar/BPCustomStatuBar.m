//
//  BPCustomStatuBar.m
//  BigPlayers
//
//  Created by John Cheng on 13-5-22.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import "BPCustomStatuBar.h"

@implementation BPCustomStatuBar

static BPCustomStatuBar *statuBarShare;

-(CGRect) statusBarHideFrame
{
    CGRect animationDestinationFrame = [UIApplication sharedApplication].statusBarFrame;
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (UIDeviceOrientationPortrait == orientation)
    {
        animationDestinationFrame.origin.x = SCREEN_WIDTH;
    }
    else if (UIDeviceOrientationPortraitUpsideDown == orientation)
    {
        animationDestinationFrame.origin.x = -SCREEN_WIDTH;
    }
    else if (UIDeviceOrientationLandscapeRight == orientation)
    {
        animationDestinationFrame.origin.y = -SCREEN_WIDTH;
    }
    else
    {
        animationDestinationFrame.origin.y = SCREEN_WIDTH;
    }
    return animationDestinationFrame;
}

-(void) setStatusBarTransform
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (UIDeviceOrientationPortrait == orientation)
    {
        self.transform = CGAffineTransformIdentity;
    }
    else if (UIDeviceOrientationPortraitUpsideDown == orientation)
    {
        self.transform = CGAffineTransformMakeRotation(M_PI);
    }
    else if (UIDeviceOrientationLandscapeRight == orientation)
    {
        self.transform = CGAffineTransformMakeRotation(M_PI * (-90.0f) / 180.0f);
    }
    else
    {
        self.transform = CGAffineTransformMakeRotation(M_PI * 90.0f / 180.0f);
    }
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.windowLevel = UIWindowLevelStatusBar + 1.0f;
        orientation_before = [UIApplication sharedApplication].statusBarOrientation;
        StatusBarIsHidden = [UIApplication sharedApplication].isStatusBarHidden;
        if(StatusBarIsHidden)
        {
            [UIApplication sharedApplication].statusBarHidden = NO;
        }
        [self setStatusBarTransform];
        self.frame = [self statusBarHideFrame];//CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, 20);
        self.backgroundColor = [UIColor clearColor];
        
        UIImage *image = [UIImage imageNamed:@"BPSDKResource.bundle/BP_status_bar.png"];
        image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(0,100,0,0)];
        UIImageView *imageview = [[UIImageView alloc] initWithImage:image];
        imageview.frame = CGRectMake(0, 0, SCREEN_WIDTH, 20);
        [self addSubview:imageview];
        [imageview release];
        
        tishiLabel = [[UILabel alloc] initWithFrame:CGRectMake(220, 0, 50, self.frame.size.height)];
        tishiLabel.text = @"分享中...";
        tishiLabel.backgroundColor = [UIColor clearColor];
        tishiLabel.textColor = [UIColor whiteColor];
        tishiLabel.font = [UIFont systemFontOfSize:10.0f];
        tishiLabel.textAlignment = UITextAlignmentCenter;
        [self addSubview:tishiLabel];
        
        activityView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(280, 0, 20, 20)];
        [self addSubview:activityView];
        activityView.hidesWhenStopped = YES;
        [activityView startAnimating];
        
//        self.hidden = NO;
//        self.alpha = 1.0f;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(changeFrames:)
                                                     name:UIDeviceOrientationDidChangeNotification
                                                   object:nil];
    }
    return self;
}


-(void) changeFrames:(NSNotification *)notification
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if(orientation_before == orientation)
    {
        return;
    }
    orientation_before = orientation;
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    [self setStatusBarTransform];
    [UIView commitAnimations];
    
    if(self.isHidden == NO)
    {
        self.frame = [UIApplication sharedApplication].statusBarFrame;
    }
    else
    {
        self.frame = [self statusBarHideFrame];
    }
}

-(void) showStatusBarWithAnimation
{
    self.hidden = NO;
    if(StatusBarIsHidden)
    {
        [UIApplication sharedApplication].statusBarHidden = NO;
    }
    
    CGRect animationDestinationFrame = [UIApplication sharedApplication].statusBarFrame;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.35];
    self.frame = animationDestinationFrame;
    [UIView commitAnimations];
    
}

-(void) animationStopAndHideStatusBar
{
    self.hidden = YES;
    if(StatusBarIsHidden)
    {
        [UIApplication sharedApplication].statusBarHidden = YES;
    }
}

-(void) hideStatusBarWithAnimation
{
    if(StatusBarIsHidden)
    {
        [UIApplication sharedApplication].statusBarHidden = YES;
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.35];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationStopAndHideStatusBar)];
    self.frame = [self statusBarHideFrame];
    [UIView commitAnimations];
}


#pragma mark -------------
-(void) setStatusBarMessage:(NSString *)message ActivityStop:(BOOL)stop
{
    if([UIApplication sharedApplication].isStatusBarHidden == YES)
    {
        return;
    }
    if(!message || message.length<1)
    {
        tishiLabel.hidden = YES;
        [activityView stopAnimating];
//        self.hidden = YES;
        return;
    }
    tishiLabel.text = message;
    if(stop)
    {
        [activityView stopAnimating];
    }
    else
    {
        [activityView startAnimating];
    }
//    self.hidden = NO;
    tishiLabel.hidden = NO;
}

-(void) tishiStatusBarHide
{
    tishiLabel.hidden = YES;
    [activityView stopAnimating];
}

-(void) hideAfterDelay:(float)delaySecond
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(tishiStatusBarHide) object:nil];
    [self performSelector:@selector(tishiStatusBarHide) withObject:nil afterDelay:delaySecond];
}

-(void) dealloc
{
    [tishiLabel release];       tishiLabel = nil;
    [activityView release];     activityView = nil;
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark -------
+(BPCustomStatuBar *) getSharedStatusBar
{
    @synchronized(statuBarShare)
    {
        if(!statuBarShare)
        {
            statuBarShare = [[BPCustomStatuBar alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 20)];
        }
        return statuBarShare;
    }
}


+(void) showBigPlayerStatusBar
{
    [self getSharedStatusBar];
    [statuBarShare showStatusBarWithAnimation];
}

+(void) hideBigPlayerStatusBar
{
    [statuBarShare hideStatusBarWithAnimation];
}

@end
