//
//  BPCustomStatuBar.h
//  BigPlayers
//
//  Created by John Cheng on 13-5-22.
//  Copyright (c) 2013年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPCustomStatuBar : UIWindow
{
    UILabel *tishiLabel;
    UIActivityIndicatorView *activityView;
    
    UIInterfaceOrientation orientation_before;
    
    BOOL StatusBarIsHidden;
}

-(void) setStatusBarMessage:(NSString *)message ActivityStop:(BOOL)stop;
-(void) hideAfterDelay:(float)delaySecond;

+(BPCustomStatuBar *) getSharedStatusBar;


+(void) showBigPlayerStatusBar;

+(void) hideBigPlayerStatusBar;
@end
