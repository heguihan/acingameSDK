//
//  BPCustomPromptBox.h
//  BigPlayers
//
//  Created by John Cheng on 13-6-7.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPCustomPromptBox : UIView
{
    UIInterfaceOrientation currentOrientation;
}
+ (BPCustomPromptBox *)getSharedPromptBox;

+(void) BPHidePromptBox;

+ (void)showWithTitle:(NSString *)title AndDisappearSecond:(float) second;

+(void) setPromptBoxPosition_Y:(int)y;


@end
