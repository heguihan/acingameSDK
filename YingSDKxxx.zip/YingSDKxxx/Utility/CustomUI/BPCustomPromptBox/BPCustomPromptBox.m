//
//  BPCustomPromptBox.m
//  BigPlayers
//
//  Created by John Cheng on 13-6-7.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPCustomPromptBox.h"
#import <QuartzCore/CALayer.h>

@implementation BPCustomPromptBox

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.frame = CGRectMake(0, 0, 50, 50);
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5;
        UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
        backgroundView.alpha = 0.8;
        backgroundView.backgroundColor = [UIColor blackColor];
        backgroundView.tag = 12345;
        [self addSubview:backgroundView];
        [backgroundView release];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.tag = 123456;
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.font = [UIFont systemFontOfSize:14];
        titleLabel.numberOfLines = 0;
        [self addSubview:titleLabel];
        [titleLabel release];
    }
    return self;
}

-(void) performHideAferDelay3:(int)second
{

        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self hidePromptBox];
            });
        });
 
}
-(void) performHideAferDelay4:(int)second
{
    
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 5*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hidePromptBox];
        });
    });
    
}
-(void) performHideAferDelay5:(int)second
{
    
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 5*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hidePromptBox];
        });
    });
    
}

-(void) hidePromptBox
{
//    promptBoxShare.hidden = YES;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(removeFromSuperview)];
    self.alpha = 0.0f;
    [UIView commitAnimations];
}


static BPCustomPromptBox *promptBoxShare;
+ (BPCustomPromptBox *)getSharedPromptBox
{
    
    @synchronized(promptBoxShare)
    {
        if(promptBoxShare == nil)
        {
            promptBoxShare =[[BPCustomPromptBox alloc] init];
        }
        
        return promptBoxShare;
    }
}

+(void) BPHidePromptBox
{
    [[BPCustomPromptBox getSharedPromptBox] hidePromptBox];
}

+ (void)showWithTitle:(NSString *)title AndDisappearSecond:(float) second
{
    UIWindow* window = nil;//[UIApplication sharedApplication].keyWindow; //nil;//
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    
    BPCustomPromptBox *tmp = [BPCustomPromptBox getSharedPromptBox];
    [promptBoxShare removeFromSuperview];
    // CGSize size = CGSizeMake(260,2000);
    UIFont *font = [UIFont systemFontOfSize:14];
    
   // CGSize conmentSize = [title sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByWordWrapping];
    
    NSDictionary * dict=[NSDictionary dictionaryWithObject: font forKey:NSFontAttributeName];
    CGRect rect=[title boundingRectWithSize:CGSizeMake(250,CGFLOAT_MAX) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil];
    
    
    int width = rect.size.width+30;
    if(width < 120)
        width = 120;
    int height = rect.size.height+50;

    if(BPDevice_is_ipad)
    {
        [[UIApplication sharedApplication].keyWindow addSubview:promptBoxShare];
        CGAffineTransform rotation;
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
        switch (orientation)
        {
            case UIInterfaceOrientationPortrait:
                rotation = CGAffineTransformIdentity;
                break;
            case UIInterfaceOrientationPortraitUpsideDown:

                rotation = CGAffineTransformMakeRotation(M_PI);
                break;
                
            case UIInterfaceOrientationLandscapeRight:
                rotation = CGAffineTransformMakeRotation(M_PI_2);
                break;
            case UIInterfaceOrientationLandscapeLeft:
                rotation = CGAffineTransformMakeRotation(-M_PI_2);
                break;
            default:
                return;
                break;
        }
        if(!BP_IS_OS_8_OR_LATER)
        {
            promptBoxShare.transform = rotation;
            switch (orientation)
            {
                case UIInterfaceOrientationPortrait:
                case UIInterfaceOrientationPortraitUpsideDown:
                    promptBoxShare.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width-width)/2, ([UIScreen mainScreen].bounds.size.height-height)/2, width, height);
                    break;
                    
                case UIInterfaceOrientationLandscapeRight:
                case UIInterfaceOrientationLandscapeLeft:
                    promptBoxShare.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width-height)/2, ([UIScreen mainScreen].bounds.size.height-width)/2, height, width);
                    break;
            }

        }
        else
        {
            promptBoxShare.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width-width)/2, ([UIScreen mainScreen].bounds.size.height-height)/2, width, height);
        }
    }
//    else
//    {
//        [[window.subviews objectAtIndex:0] addSubview:promptBoxShare];
//        promptBoxShare.frame = CGRectMake((SCREEN_WIDTH-width)/2, (SCREEN_HEIGHT-height)/2, width, conmentSize.height+30);
//    }

    UIView *backview = [promptBoxShare viewWithTag:12345];
    backview.frame = CGRectMake(0, 0, width,height);
    UILabel *titleLabel = (UILabel *)[promptBoxShare viewWithTag:123456];
    titleLabel.frame = CGRectMake(8, 0, width-10, height);
    titleLabel.text = title;
    promptBoxShare.alpha = 0.0f;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    promptBoxShare.alpha = 1.0f;
    [UIView commitAnimations];
    
    [tmp performHideAferDelay4:second];
    
    
}






+(void) setPromptBoxPosition_Y:(int)y
{
    CGRect frame = promptBoxShare.frame;
    if(SCREEN_IS_LANDSCAPE&&!BP_IS_OS_8_OR_LATER)
        frame.origin.x = y;
    else
    frame.origin.y = y;
    promptBoxShare.frame = frame;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
