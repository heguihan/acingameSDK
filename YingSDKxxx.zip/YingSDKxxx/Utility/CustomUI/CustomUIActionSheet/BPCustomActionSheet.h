//
//  BPCustomActionSheet.h
//  BigPlayers
//
//  Created by John Cheng on 13-6-6.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPCustomActionSheet : UIActionSheet
{
    int titleNum;
}
- (id) initWithtitles:(NSString *) titles,...;
@end
