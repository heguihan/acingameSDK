//
//  BPCustomActionSheet.m
//  BigPlayers
//
//  Created by John Cheng on 13-6-6.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPCustomActionSheet.h"

@implementation BPCustomActionSheet

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


//- (id)init
- (id) initWithtitles:(NSString *) titles,...
{
    double version = [[UIDevice currentDevice].systemVersion doubleValue];//判定系统版本。
    if(version>=7.0f)
    {
//        va_list args;
//        va_start(args, titles);
//        id obj = titles;
//        NSMutableArray *titleArray = [NSMutableArray array];
//        while (obj)
//        {
//            [titleArray addObject:obj];
//            obj = va_arg(args, id);
//            titleNum ++;
//        }
//        va_end(args);
//        if(titleArray.count == 2)
//        {
//            self = [super initWithTitle:nil delegate:nil cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:titleArray[0],titleArray[1], nil];
//        }
//        else if(titleArray.count == 3)
//        {
//            self = [super initWithTitle:nil delegate:nil cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:titleArray[0],titleArray[1],titleArray[2], nil];
//        }
//        else if(titleArray.count == 4)
//        {
//            self = [super initWithTitle:nil delegate:nil cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:titleArray[0],titleArray[1],titleArray[2],titleArray[3], nil];
//        }
//        else if(titleArray.count == 5)
//        {
//            self = [super initWithTitle:nil delegate:nil cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:titleArray[0],titleArray[1],titleArray[2],titleArray[3],titleArray[4], nil];
//        }

        self = [super initWithTitle:nil delegate:nil cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:titles, nil];
        if(self)
        {
            va_list args;
            va_start(args, titles);
            id obj = titles;
            obj = va_arg(args, id);
            while (obj)
            {
                [self addButtonWithTitle:obj];
                
                obj = va_arg(args, id);
                titleNum ++;
            }
            va_end(args);
        }
        return self;
    }
    
    self = [super init];
    if (self) {
        // Initialization code
        va_list args;
        va_start(args, titles);
        id obj = titles;//va_arg(args, id);
        
        self.title = @"\n\n\n\n\n\n\n";
        
        self.backgroundColor =[UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1];
        titleNum = 0;
        int w = SCREEN_WIDTH;
        if(BPDevice_is_ipad)
        {
            w = 270;
        }
        while (obj)
        {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(0, 2+50*titleNum, w, 50);
            button.tag = 100+titleNum;
//            [button setTitle:obj forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/shareSheet_sel.png"] forState:UIControlStateHighlighted];
//            button.titleLabel.font = [UIFont boldSystemFontOfSize:16];
            [button addTarget:self action:@selector(clickActionSheetButton:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:button];
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, w, 50)];
            label.text = obj;
            label.font = [UIFont boldSystemFontOfSize:16];
            label.backgroundColor = [UIColor clearColor];
            label.textColor = [UIColor whiteColor];
            label.textAlignment = NSTextAlignmentCenter;
            [button addSubview:label];
            [label release];
            
            obj = va_arg(args, id);
            titleNum ++;
        } 
        va_end(args);
        NSString *enterStr = @"\n";
        if(BPDevice_is_ipad)
            enterStr = @"\n\n";
        for(int i = 1;i<titleNum;i++)
        {
            if(BPDevice_is_ipad)
                enterStr = [enterStr stringByAppendingString:@"\n\n\n\n"];
            else
                enterStr = [enterStr stringByAppendingString:@"\n\n\n"];
        }
        self.title = enterStr;//[enterStr objectAtIndex:titleNum];
        
//        self.title = @"\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    }
    return self;
}

//点击按钮
- (void) clickActionSheetButton:(id)sender
{
    [self dismissWithClickedButtonIndex:0 animated:YES];
    UIButton *button = (UIButton *)sender;
    int index = button.tag - 100;

}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.

- (void)drawRect:(CGRect)rect
{
    // Drawing code
//    UIImage *lineImage = [UIImage imageNamed:@"line_01.png"];
//    [lineImage drawInRect:CGRectMake(0, 0, SCREEN_WIDTH, 2)];
//    
//    lineImage = [UIImage imageNamed:@"line_02.png"];
//    [lineImage drawInRect:CGRectMake(0, 52, SCREEN_WIDTH, 2)];
//    [lineImage drawInRect:CGRectMake(0, 102, SCREEN_WIDTH, 2)];
    double version = [[UIDevice currentDevice].systemVersion doubleValue];//判定系统版本。
    if(version<7.0f)
    {
        UIImage *lineImage = [UIImage imageNamed:@"ShuZhiZhang.bundle/line_01.png"];
        [lineImage drawInRect:CGRectMake(0, 0, SCREEN_WIDTH, 2)];
        for(int i=1;i<titleNum;i++)
        {
            lineImage = [UIImage imageNamed:@"ShuZhiZhang.bundle/line_02.png"];
            [lineImage drawInRect:CGRectMake(0, 2+50*i, SCREEN_WIDTH, 2)];
        }
    }
}





@end
