//
//  PhoteShareActionSheet.m
//  BigPlayers
//
//  Created by John Cheng on 13-5-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPPhoteShareActionSheet.h"

@implementation BPPhoteShareActionSheet
//@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code
//        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, 152);
        self.title = @"\n\n\n\n\n\n\n";
        
        self.backgroundColor =[UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1];
        
        //新浪
        UIButton *sinaButton = [UIButton buttonWithType:UIButtonTypeCustom];
        sinaButton.frame = CGRectMake(0, 2, SCREEN_WIDTH, 50);
        sinaButton.tag = 100;
//        [sinaButton setTitle:@"      新浪微博" forState:UIControlStateNormal];
        [sinaButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/shareSheet_sel.png"] forState:UIControlStateHighlighted];
//        sinaButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [sinaButton addTarget:self action:@selector(clickActionSheetButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:sinaButton];
        
        UILabel *sinaLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, SCREEN_WIDTH, 50)];
        sinaLabel.text = @"      新浪微博" ;
        sinaLabel.font = [UIFont boldSystemFontOfSize:16];
        sinaLabel.backgroundColor = [UIColor clearColor];
        sinaLabel.textColor = [UIColor whiteColor];
        sinaLabel.textAlignment = NSTextAlignmentCenter;
        [sinaButton addSubview:sinaLabel];
        [sinaLabel release];
        
        UIImageView *sinaImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/login_sina.png"] ];
        sinaImage.frame = CGRectMake(100, 7, 35, 35);
        [sinaLabel addSubview:sinaImage];
        [sinaImage release];
        
        //腾讯
        UIButton *TCButton = [UIButton buttonWithType:UIButtonTypeCustom];
        TCButton.frame = CGRectMake(0, 52, SCREEN_WIDTH, 50);
        TCButton.tag = 101;
        [TCButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/shareSheet_sel.png"] forState:UIControlStateHighlighted];
        [TCButton addTarget:self action:@selector(clickActionSheetButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:TCButton];
        
        UILabel *tcLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, SCREEN_WIDTH, 50)];
        tcLabel.text = @"      腾讯微博";
        tcLabel.font = [UIFont boldSystemFontOfSize:16];
        tcLabel.backgroundColor = [UIColor clearColor];
        tcLabel.textColor = [UIColor whiteColor];
        tcLabel.textAlignment = NSTextAlignmentCenter;
        [TCButton addSubview:tcLabel];
        [tcLabel release];
        
        UIImageView *tcImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/login_txwb.png"] ];
        tcImage.frame = CGRectMake(100, 7, 35, 35);
        [TCButton addSubview:tcImage];
        [tcImage release];
        
        
        //取消
        UIButton *cancel = [UIButton buttonWithType:UIButtonTypeCustom];
        cancel.frame = CGRectMake(0, 102, SCREEN_WIDTH, 50);

        cancel.tag = 102;
        [cancel setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/shareSheet_sel.png"] forState:UIControlStateHighlighted];
        [cancel addTarget:self action:@selector(clickActionSheetButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cancel];
        
        UILabel *cancelLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, SCREEN_WIDTH, 50)];
        cancelLabel.text = @"取消";
        cancelLabel.font = [UIFont boldSystemFontOfSize:16];
        cancelLabel.backgroundColor = [UIColor clearColor];
        cancelLabel.textColor = [UIColor whiteColor];
        cancelLabel.textAlignment = NSTextAlignmentCenter;
        [cancel addSubview:cancelLabel];
        [cancelLabel release];
    }
    return self;
}

//点击按钮
- (void) clickActionSheetButton:(id)sender
{
    [self dismissWithClickedButtonIndex:0 animated:YES];
    UIButton *button = (UIButton *)sender;
    int index = button.tag - 100;

}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    UIImage *lineImage = [UIImage imageNamed:@"ShuZhiZhang.bundle/line_01.png"];
    [lineImage drawInRect:CGRectMake(0, 0, SCREEN_WIDTH, 2)];
    
    lineImage = [UIImage imageNamed:@"ShuZhiZhang.bundle/line_02.png"];
    [lineImage drawInRect:CGRectMake(0, 52, SCREEN_WIDTH, 2)];
    [lineImage drawInRect:CGRectMake(0, 102, SCREEN_WIDTH, 2)];
    
}


@end
