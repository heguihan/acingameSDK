//
//  PhoteShareActionSheet.h
//  BigPlayers
//
//  Created by John Cheng on 13-5-10.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BPPhotoShareActonSheetDelegate <UIActionSheetDelegate>
@end


@interface BPPhoteShareActionSheet : UIActionSheet
{
//    id<PhotoShareActonSheetDelegate> delegate;
}

//@property (nonatomic,assign) id<PhotoShareActonSheetDelegate> delegate;

@end
