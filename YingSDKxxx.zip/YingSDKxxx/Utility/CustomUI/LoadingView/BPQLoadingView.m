//
//  QLoadingView.m
//  QWeiboSDK4iOSDemo
//
//  Created   on 11-1-18.
//   
//

#import "BPQLoadingView.h"


#define LOADINGVIEW_SHOW_DURATION 0.5
#define LOADINGVIEW_ANIMATE_DURATION 0.5

@protocol BPQLoadingView
- (void)hideWithAnimate;
@end

static BPQLoadingView *sShareLoadingView;

@implementation BPQLoadingView

- (id)initWithFrame:(CGRect)frame {
	
	if (self = [super initWithFrame:frame]) {
//		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.backgroundColor = [UIColor clearColor];
		
		backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];//CGRectMake((SCREEN_WIDTH-frame.size.width)/2, (SCREEN_HEIGHT -frame.size.height)/2,frame.size.width, frame.size.height)];//self.bounds];
		backgroundView.backgroundColor = [UIColor blackColor];
		backgroundView.alpha = 0.8;
        backgroundView.layer.masksToBounds = YES;
        backgroundView.layer.cornerRadius = 6;
//		backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:backgroundView];
		
//		UIViewAutoresizing viewAutoResizing = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin |
//		UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
		
		boardView = [[UIImageView alloc] init];//]WithImage:[UIImage imageNamed:@"info_bkg.png"]];
		boardView.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
//		boardView.autoresizingMask = viewAutoResizing;
		[self addSubview:boardView];
		
		activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        
        
//		activityView.center = CGPointMake(boardView.bounds.size.width/2, 0);
        
        
        activityView.center = boardView.center;
        
		activityView.hidesWhenStopped = YES;
		[boardView addSubview:activityView];
		
		labelInfo = [[UILabel alloc] initWithFrame:CGRectMake(boardView.bounds.size.width/2 - 70,
															  5, 140, 60)];
		labelInfo.numberOfLines = 2;
		labelInfo.backgroundColor = [UIColor clearColor];
		labelInfo.textAlignment = NSTextAlignmentCenter;
		labelInfo.textColor = [UIColor whiteColor];
		labelInfo.font = [UIFont systemFontOfSize:16];
		labelInfo.shadowColor = [UIColor blackColor]; 
		labelInfo.shadowOffset = CGSizeMake(0, 1.0);
		[boardView addSubview:labelInfo];
		
		imageView = [[UIImageView alloc] initWithFrame:CGRectMake(boardView.bounds.size.width/2 - 51, 
																  105, 102, 102)];
		[boardView addSubview:imageView];
		imageView.hidden = YES;
//        self.frame = frame;
//        [self setClipsToBounds:YES];
	}
	
	return self;
}

- (void)dealloc
{
	[backgroundView release];
	[boardView release];
	[imageView release];
	[labelInfo release];
	[activityView release];
	[super dealloc];
}

- (void)autoHide
{

    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, LOADINGVIEW_SHOW_DURATION*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self hideWithAnimate];
    });
}

- (void)hideWithAnimate
{
	if(self.superview !=nil)
	{
		self.alpha = 1.0f;
		
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:LOADINGVIEW_ANIMATE_DURATION];
		[UIView setAnimationCurve:UIViewAnimationCurveLinear];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(removeFromSuperview)];
		self.alpha = 0.0f;
		[UIView commitAnimations];
		
	}
}

- (void)setImage:(UIImage *)image
{
	if(image)
	{
		imageView.image = image;
		imageView.hidden = NO;
		[activityView stopAnimating];
	}else
	{
		imageView.hidden = YES;
		activityView.hidden = NO;
		[activityView startAnimating];
	}
}

- (void)setModelInView:(BOOL)value
{
	backgroundView.hidden = !value;
    return;
	if(value)
	{
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	}else
	{
		self.bounds = boardView.bounds;
		self.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin
		| UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
	}	
}


- (void)setInfo:(NSString *)info
{
	labelInfo.text = info;
    if(info && info.length>0)
    {
        sShareLoadingView.frame = CGRectMake((SCREEN_WIDTH-100)/2, (SCREEN_HEIGHT_NAV -100)/2, 100, 100);
        boardView.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
        activityView.center = CGPointMake(boardView.bounds.size.width/2, -8);
        labelInfo.frame = CGRectMake(boardView.bounds.size.width/2 - 70,
															  0, 140, 60);
    }
    else
    {
        sShareLoadingView.frame = CGRectMake((SCREEN_WIDTH-80)/2, (SCREEN_HEIGHT_NAV -80)/2, 80, 80);
        boardView.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
        activityView.center = CGPointMake(boardView.bounds.size.width/2, 0);
    }
    backgroundView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
}

#pragma mark -
#pragma mark class methods

+ (void)showInView:(UIView *)view image:(UIImage *)image info:(NSString *)info 
		  animated:(BOOL)animated modeled:(BOOL)modeled autoHide:(BOOL)autoHide
{
	sShareLoadingView = [BPQLoadingView shareInstance];
	[sShareLoadingView removeFromSuperview];
//	sShareLoadingView.frame = view.bounds;
	sShareLoadingView.frame = CGRectMake((SCREEN_WIDTH-80)/2, (SCREEN_HEIGHT -80)/2, 80, 80);

      
	// setImage
	[sShareLoadingView setImage:image];
	
	//setInfo
	[sShareLoadingView setInfo:info];
	//setModelInView
	[sShareLoadingView setModelInView:modeled];
	
	
	//setAnimated
	if(animated)
	{
		sShareLoadingView.alpha = 0.0f;
		
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:LOADINGVIEW_ANIMATE_DURATION];
		[UIView setAnimationCurve:UIViewAnimationCurveLinear];
		sShareLoadingView.alpha = 1.0f;
		[UIView commitAnimations];
		
	}else
	{
		sShareLoadingView.alpha = 1.0f;
	}
	
	if(autoHide)
	{
		[sShareLoadingView autoHide];
	}
	
	[view addSubview:sShareLoadingView];
    
    
    
    
}

+ (void)hideWithAnimated:(BOOL)animated
{
    dispatch_async(dispatch_get_main_queue(), ^{
        sShareLoadingView = [BPQLoadingView shareInstance];
        if(animated)
        {
            [sShareLoadingView hideWithAnimate];
        }else
        {
            [sShareLoadingView removeFromSuperview];
        }
    });

}



+ (void)showImage:(UIImage *)image info:(NSString *)info autoHide:(BOOL)autoHide
{
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    sShareLoadingView = [BPQLoadingView shareInstance];
	[BPQLoadingView showInView:window.rootViewController.view image:image
					  info:info animated:YES modeled:YES autoHide:autoHide];
}

+(void) setLoadingViewPosition:(int)x Position_Y:(int)y
{
    CGRect frame = sShareLoadingView.frame;
    if(x>=0)
    frame.origin.x = x;
    if(y>=0)
        frame.origin.y = y;
    sShareLoadingView.frame = frame;
}


+ (void)showDefaultLoadingView
{
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
	[BPQLoadingView showInView:window
					 image:nil 
					  info:@""//@"Loading..."
				  animated:NO modeled:YES autoHide:NO];
}





+ (void)showDefaultLoadingViewWithView:(UIView *)view
{
	[BPQLoadingView showInView:view
                       image:nil
                        info:@""//@"Loading..."
                    animated:NO modeled:YES autoHide:NO];
    
    
}

+ (id)shareInstance
{
	if(sShareLoadingView == nil)
	{
		sShareLoadingView = [[self alloc] initWithFrame:CGRectMake((SCREEN_WIDTH-80)/2, (SCREEN_HEIGHT_NAV -80)/2, 80, 80)];
	}
	return sShareLoadingView;
}

@end
