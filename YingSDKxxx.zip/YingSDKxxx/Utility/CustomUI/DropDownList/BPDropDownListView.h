//
//  DropDownListView.h
//  BigPlayers
//
//  Created by John Cheng on 13-5-8.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DropDownListDelegate <NSObject>
@optional
-(void) didClickAtIndex:(NSIndexPath *)indexPath withTableView:(UITableView *)tableView;

-(void) customDropDownListView:(UITableViewCell *)cell cellForRowAtIndexPath:(NSIndexPath *)indexPath;

-(void) DidDeleteCell:(NSArray *)currentArray;
@end

@interface BPDropDownListView : UIView <UITableViewDataSource, UITableViewDelegate>
{
    id<DropDownListDelegate> delegate;
    UITableView *listTableView;
    NSMutableArray *dataArray;
    
    int lastSelectIndex;
}

@property(nonatomic, assign) id<DropDownListDelegate> delegate;
@property(nonatomic, retain) UITableView *listTableView;
@property(nonatomic, retain) NSMutableArray *dataArray;

- (id)initWithFrame:(CGRect)frame AndArray:(NSArray *)array;
-(int) getViewHeiht:(NSArray *)array;
-(void) setArrayAndReload:(NSMutableArray *)array;
-(void) showOrHideDropDownList;
//隐藏列表
-(void) hideDropDownList;

//设置选中的行
-(void) setSelectedRowAtRow:(int)row AndSection:(int)section;
@end
