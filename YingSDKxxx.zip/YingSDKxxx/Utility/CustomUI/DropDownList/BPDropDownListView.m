//
//  DropDownListView.m
//  BigPlayers
//
//  Created by John Cheng on 13-5-8.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPDropDownListView.h"
#define TableViewHeight 40

@implementation BPDropDownListView
@synthesize delegate;
@synthesize listTableView;
@synthesize dataArray;

-(void) dealloc
{
    [listTableView release];        listTableView = nil;
    [dataArray release];            dataArray = nil;
    [super dealloc];
}

-(int) getViewHeiht:(NSArray *)array
{
    int height = (int)[array count]*TableViewHeight + 3;
    if(height > TableViewHeight * 3)
    {
        height = TableViewHeight * 3 + 3;
    }
    return height;
}

- (id)initWithFrame:(CGRect)frame AndArray:(NSArray *)array
{
    self.dataArray = (NSMutableArray *)array;
    for (NSDictionary *dic in self.dataArray) {
        if ([[dic objectForKey:@"accountType"] intValue] == 1) {
            
            [dataArray removeObject:dic];
        }
    }
    frame.size.height = [self getViewHeiht:self.dataArray];
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        frame.size.height = 0;
        self.frame = frame;
        self.backgroundColor = [UIColor clearColor];
       
        [self initDropDownList];
        lastSelectIndex = -1;
    }
    return self;
}

-(void) initDropDownList
{
    UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, [self getViewHeiht:dataArray]-3)];
    backgroundView.alpha = 0.9;
    backgroundView.backgroundColor = [UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1];
    backgroundView.layer.cornerRadius = 8;
    backgroundView.tag = 4100;
    [self addSubview:backgroundView];
    [backgroundView release];
    
    listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -5, self.frame.size.width, [self getViewHeiht:dataArray]-3)];
    listTableView.dataSource = self;
    listTableView.delegate = self;
    
    listTableView.layer.cornerRadius = 8;
//    listTableView.backgroundColor = [UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1];
    listTableView.backgroundColor = [UIColor clearColor];
    listTableView.separatorColor = [UIColor clearColor];
//    listTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
//    listTableView.separatorColor = [UIColor grayColor];
    
    [self addSubview:listTableView];
    [self setClipsToBounds:YES];
    
    UIImageView *arrowImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_list_arrow.png"]];
    arrowImage.tag = 4101;
    arrowImage.frame = CGRectMake(80, 0, 16, 3);
    arrowImage.alpha = 0.9;
    [self addSubview:arrowImage];
    [arrowImage release];
}

//设置选中的行
-(void) setSelectedRowAtRow:(int)row AndSection:(int)section
{
    NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:row inSection:section];
    [listTableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    
    //选中时隐藏线条
    UITableViewCell *cell = [listTableView cellForRowAtIndexPath:selectedIndexPath];
    UIImageView *lineImage = (UIImageView *)[cell.contentView viewWithTag:10000];
    [lineImage setHidden:YES];
    
    if(lastSelectIndex >=0)
    {
        cell = [listTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:lastSelectIndex inSection:0]];
        lineImage = (UIImageView *)[cell.contentView viewWithTag:10000];
        [lineImage setHidden:NO];
    }
    lastSelectIndex = row;
}


//更新数组并重载
-(void) setArrayAndReload:(NSMutableArray *)array
{
    self.dataArray = array;
    [listTableView reloadData];
    NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [listTableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    
    UITableViewCell *cell = [listTableView cellForRowAtIndexPath:selectedIndexPath];
    UIImageView *lineImage = (UIImageView *)[cell.contentView viewWithTag:10000];
    [lineImage setHidden:YES];
    
}

//点击显示或隐藏列表
-(void) showOrHideDropDownList
{
    int h = self.frame.size.height;
    if(h<10)
    {
        [self setHidden:NO];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
//        listTableView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
        CGRect frame = self.frame;
        frame.size.height = [self getViewHeiht:dataArray];
        self.frame = frame;
        [UIView commitAnimations];
    }
    else
    {
//        [UIView beginAnimations:nil context:nil];
//        [UIView setAnimationDuration:0.3];
//        CGRect frame = self.frame;
//        frame.size.height = 0;
//        self.frame = frame;
//        [UIView commitAnimations];
        [self hideDropDownList];
    }
    
}

//隐藏列表
-(void) hideDropDownList
{
    int h = self.frame.size.height;
    if(h>=10)
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
        CGRect frame = self.frame;
        frame.size.height = 0;
        self.frame = frame;
        [UIView commitAnimations];
    }
}

#pragma mark ---------tabelView delegate-----------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return TableViewHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [dataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        
        UIImageView *lineImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_listLine.png"]];
        lineImage.frame = CGRectMake(5, TableViewHeight-1, 120, 2);
        [cell.contentView addSubview:lineImage];
        lineImage.tag = 10000;
        [lineImage release];
//        cell.backgroundColor = [UIColor clearColor];
//        cell.textLabel.backgroundColor = [UIColor clearColor];
        
        //设置点击高亮
        cell.textLabel.highlightedTextColor = [UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1];
        
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        UIImageView *imgview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_serverSelect.png"]];
        imgview.frame = CGRectMake(0, 5, 3, 30);
        [cell.selectedBackgroundView addSubview:imgview];
        [imgview release];
        cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:25/255.0f green:25/255.0f blue:25/255.0f alpha:1];
    }

        NSDictionary *dic = [dataArray objectAtIndex:indexPath.row];
        cell.textLabel.text =[dic objectForKey:@"userID"];
        cell.textLabel.textColor = [UIColor blackColor];
//    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self hideDropDownList];

    
    //选中时隐藏线条
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIImageView *lineImage = (UIImageView *)[cell.contentView viewWithTag:10000];
    [lineImage setHidden:YES];
    
    if(lastSelectIndex >=0)
    {
        cell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:lastSelectIndex inSection:0]];
        lineImage = (UIImageView *)[cell.contentView viewWithTag:10000];
        [lineImage setHidden:NO];
    }
    lastSelectIndex = indexPath.row;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
