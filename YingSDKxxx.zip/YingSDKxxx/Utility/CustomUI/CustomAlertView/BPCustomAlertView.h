//
//  BPCustomAlertView.h
//  textAlertView
//
//  Created by lv xingtao on 12-10-13.
//  Copyright (c) 2012年 lv xingtao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPCustomAlertView : UIAlertView
{
    //在ios5.0时，会重复调用layout函数，如果不设定这个变量，显示会有问题
    int button_y;
}
@end
