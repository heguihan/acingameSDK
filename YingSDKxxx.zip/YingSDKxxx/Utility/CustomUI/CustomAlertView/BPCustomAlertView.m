//
//  BPCustomAlertView.m
//  textAlertView
//
//  Created by lv xingtao on 12-10-13.
//  Copyright (c) 2012年 lv xingtao. All rights reserved.
//
#import "BPCustomAlertView.h"
#import <QuartzCore/CALayer.h>

@implementation BPCustomAlertView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)layoutSubviews{
    
    int buttonNum=0;
    for (UIView *v in self.subviews)
    {
        if ([v isKindOfClass:NSClassFromString(@"UIAlertButton")])
        {
            buttonNum++;
        }
    }
    
    for (UIView *v in self.subviews)
    {
        if ([v isKindOfClass:[UIImageView class]]) {
            UIImageView *imageV = (UIImageView *)v;
            imageV.image = nil;
            imageV.backgroundColor = [UIColor whiteColor];
            
            imageV.layer.masksToBounds = YES;
            imageV.layer.cornerRadius = 8;
        }
        if ([v isKindOfClass:[UILabel class]]) {
            UILabel *label = (UILabel *)v;
            if ([label.text isEqualToString:self.title]) {
                label.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/title.png"]];
                CGRect frame = label.frame;
                frame.origin.x = 0;
                frame.origin.y = 0;
                frame.size.width = 284;
                frame.size.height = 36;
                label.frame = frame;
                
                label.textColor = [UIColor whiteColor];
                label.font = [UIFont boldSystemFontOfSize:18];
                label.numberOfLines = 0;

                label.textAlignment = UITextAlignmentCenter;
                label.shadowColor = [UIColor clearColor];
                
            }else{
                label.shadowColor = [UIColor clearColor];
                label.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
                label.font = [UIFont systemFontOfSize:16];
                
                CGRect frame = label.frame;
//                if(!layoutFlag)
//                frame.origin.y += 13;
                frame.origin.y = 58;
                label.frame = frame;
                button_y = 58+22+label.frame.size.height;
            }
        }
        if ([v isKindOfClass:NSClassFromString(@"UIAlertButton")]) {
            UIButton *button = (UIButton *)v;
            UIImage *image = nil;
            UIImage *image_sel = nil;
            
            if(buttonNum==1)
            {
                image = [UIImage imageNamed:@"ShuZhiZhang.bundle/button.png"];
                image_sel = [UIImage imageNamed:@"ShuZhiZhang.bundle/button_sel.png"];
                
                CGRect frame = button.frame;
                frame.origin.x = 0;
//                if(!layoutFlag)
//                frame.origin.y += 17;
                frame.origin.y = button_y;
                frame.size.width = 284;
                button.frame = frame;
            }
            else
            {
                if (button.tag == 1) {
                    image = [UIImage imageNamed:@"ShuZhiZhang.bundle/button_left.png"];
                    image_sel = [UIImage imageNamed:@"ShuZhiZhang.bundle/button_left_sel.png"];
                }else{
                    image = [UIImage imageNamed:@"ShuZhiZhang.bundle/button_right.png"];
                    image_sel = [UIImage imageNamed:@"ShuZhiZhang.bundle/button_right_sel.png"];
                }
    //            image = [image stretchableImageWithLeftCapWidth:(int)(image.size.width+1)>>1 topCapHeight:0];
                CGRect frame = button.frame;
                frame.origin.x = (button.tag-1)*142;
//                if(!layoutFlag)
                frame.origin.y = button_y;//+= 17;
                frame.size.width = 142;
                button.frame = frame;
            }
            button.titleLabel.font = [UIFont systemFontOfSize:16];
            button.titleLabel.textAlignment = UITextAlignmentCenter;
            button.backgroundColor = [UIColor clearColor];
            [button setBackgroundImage:image forState:UIControlStateNormal];
            [button setBackgroundImage:image_sel forState:UIControlStateHighlighted];
            [button setTitleColor:[UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1] forState:UIControlStateHighlighted];
            [button setTitleShadowColor:[UIColor clearColor] forState:UIControlStateHighlighted];
            [button setTitleShadowColor:[UIColor clearColor] forState:UIControlStateNormal];
        }
    }
//    layoutFlag = YES;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
