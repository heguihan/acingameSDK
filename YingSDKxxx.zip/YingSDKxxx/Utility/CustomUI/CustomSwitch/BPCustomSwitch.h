//
//  BPCustomSwitch.h
//  BigPlayers
//
//  Created by Jun on 13-4-27.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BPCustomSwitch;
@protocol BPCustomSwitchDelegate <NSObject>

//state (0 = 左, 1 = 右)
- (void)BPCustomSwitchDidEnd:(BPCustomSwitch *)CustomSwitch selectState:(int)state;

@end

@interface BPCustomSwitch : UIView{
    
    id <BPCustomSwitchDelegate> delegate;
    int switchState;
}
@property (nonatomic,assign) id <BPCustomSwitchDelegate> delegate;
@property (nonatomic,readonly) int switchState;

//设置初始位置
-(void) setScrollButtonLocation:(int) flag; //0--左边， 1-－－右边
@end
