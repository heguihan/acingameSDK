//
//  BPCustomSwitch.m
//  BigPlayers
//
//  Created by Jun on 13-4-27.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPCustomSwitch.h"

#define SWITCH_W 53
#define SWITCH_H 23.0

@interface BPCustomSwitch()<UIScrollViewDelegate>{
    
    UIScrollView * CustomSwitch;
}
@property (nonatomic,retain) UIScrollView * CustomSwitch;

@end

@implementation BPCustomSwitch
@synthesize delegate;
@synthesize CustomSwitch;
@synthesize switchState;


- (void)dealloc{
    
    [CustomSwitch release]; CustomSwitch = nil;
    
    [super dealloc];
}


- (id)initWithFrame:(CGRect)frame
{
    frame.size.height = SWITCH_H;
    frame.size.width = SWITCH_W;
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code

        self.frame = frame;
        
        switchState = 0;

        UIImageView * switch_back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_customSwitch_back.png"]];
            
        switch_back.frame = CGRectMake(0 , 0, SWITCH_W, SWITCH_H);
        [self addSubview:switch_back];
        [switch_back release];
        
        // 主体
        UIScrollView * _CustomSwitch = [[UIScrollView alloc] initWithFrame:CGRectMake(0 , 0 ,SWITCH_W, SWITCH_H)];
        _CustomSwitch.backgroundColor = [UIColor clearColor];
        _CustomSwitch.bounces = NO;
        _CustomSwitch.delegate = self;
        _CustomSwitch.showsHorizontalScrollIndicator = NO;
        _CustomSwitch.contentSize = CGSizeMake(SWITCH_W*1.5, SWITCH_H);
        [_CustomSwitch setContentOffset:CGPointMake(0, 0) animated:NO];
        self.CustomSwitch = _CustomSwitch;
        [_CustomSwitch release];
        
        // 左
        UIButton * but_left = [UIButton buttonWithType:UIButtonTypeCustom];
        but_left.frame = CGRectMake(0, 0, SWITCH_W/2.0, SWITCH_H);
        [but_left addTarget:self action:@selector(ButtonActionLeft) forControlEvents:UIControlEventTouchUpInside];
        but_left.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        but_left.backgroundColor = [UIColor clearColor];
        [CustomSwitch addSubview:but_left];
        
        
        // sub
        UIButton * scroll_but = [UIButton buttonWithType:UIButtonTypeCustom];
        scroll_but.tag = 777;
        scroll_but.frame = CGRectMake(SWITCH_W/2.0, 0, SWITCH_W/2.0, SWITCH_H);
        [scroll_but addTarget:self action:@selector(ButtonAction) forControlEvents:UIControlEventTouchUpInside];
        scroll_but.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        [scroll_but setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_customSwitch_sub_right.png"] forState:UIControlStateNormal];
        [scroll_but setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_customSwitch_sub_right.png"] forState:UIControlStateHighlighted];

        
        [CustomSwitch addSubview:scroll_but];
        
        
        // 右
        UIButton * but_right = [UIButton buttonWithType:UIButtonTypeCustom];
        but_right.frame = CGRectMake(SWITCH_W, 0, SWITCH_W/2.0, SWITCH_H);
        [but_right addTarget:self action:@selector(ButtonActionRight) forControlEvents:UIControlEventTouchUpInside];
        but_right.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        but_right.backgroundColor = [UIColor clearColor];
        [_CustomSwitch addSubview:but_right];
        
        
        
        
        [self addSubview:CustomSwitch];
        
    }
    return self;
}

//设置初始位置
-(void) setScrollButtonLocation:(int) flag //0--左边， 1-－－右边
{
    switchState = flag;
    if(flag == 0)
    {
        [CustomSwitch setContentOffset:CGPointMake(0, 0) animated:NO];
    }
    else
    {
        [CustomSwitch setContentOffset:CGPointMake(SWITCH_W/2.0+3, 0) animated:NO];
    }
        
}


//左边按钮
-(void)ButtonActionLeft{
    
    [CustomSwitch setContentOffset:CGPointMake(SWITCH_W/2.0, 0) animated:YES];
}


//右边按钮
-(void)ButtonActionRight{
    
    [CustomSwitch setContentOffset:CGPointMake(0, 0) animated:YES];
    
}

//中间按钮
-(void)ButtonAction{
    if(switchState == 0){
        [CustomSwitch setContentOffset:CGPointMake(SWITCH_W/2.0, 0) animated:YES];
    }else{
        [CustomSwitch setContentOffset:CGPointMake(0, 0) animated:YES];
    }
}




//-滑动时
-(void)scrollViewDidScroll:(UIScrollView *)scrollView1{
    
    int page_x =(scrollView1.contentOffset.x);
    if(page_x%(SWITCH_W/2) ==0){
        int page = page_x/(SWITCH_W/2);
        
        UIButton * subView = (UIButton *)[CustomSwitch viewWithTag:777];
        
        if(page == 0){
            
            [subView setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_customSwitch_sub_right.png"] forState:UIControlStateNormal];
            switchState = 0;
            [self leftCilck];
            
        }else if(page ==1){
            
            [subView setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_customSwitch_sub_left.png"] forState:UIControlStateNormal];
            switchState = 1;
            [self rightCilck];
            
        }

    }
    
}



- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
    
    if(scrollView == CustomSwitch){
        if(decelerate){
            return;
        }
        
        float page_x =(scrollView.contentOffset.x);
        
        if(page_x >= SWITCH_W/4){
            
            
            [CustomSwitch setContentOffset:CGPointMake(SWITCH_W/2.0, 0) animated:YES];
            
            
        }else if(page_x < SWITCH_W/4 ){
            
            
            [CustomSwitch setContentOffset:CGPointMake(0, 0) animated:YES];
        }
    }
}


- (void)leftCilck{
    
    [delegate BPCustomSwitchDidEnd:self selectState:switchState];
}

- (void)rightCilck{
    [delegate BPCustomSwitchDidEnd:self selectState:switchState];
}


@end
