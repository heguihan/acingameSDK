//
//  ShuZhiZhangUtility.m
//  BigPlayers
//
//  Created by Jun on 13-4-25.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "ShuZhiZhangUtility.h"
#import "GTMBase64hgh.h"
#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#import <CommonCrypto/CommonDigest.h>
#import <AdSupport/ASIdentifierManager.h>
#import "BPButtonBoard.h"
#import "BPCustomAlertView.h"
//#import "BPCustomStatuBar.h"
#import "BPKeychainItemWrapper.h"

@implementation ShuZhiZhangUtility


NSString * const BPLoginResultNotification = @"BPLoginResult";

NSString * const BPThirdLoginResultNotification = @"BPThirdLoginResult";

NSString * const BPPlatformExitNotification = @"BPPlatformExit";
NSString * const BPPayResultNotification = @"BPPayResult";
NSString * const BPInitDidFinishedNotification = @"BPInitDidFinished";

NSString * const BPShouldPauseSoundNotification = @"BPShouldPauseSound";
NSString * const BPShouldPlaySoundNotification = @"BPShouldPlaySound";

NSString * const BPVoicePlayOverNotification = @"BPVoicePlayOver";
NSString * const BPShareNotification = @"BPShareCallback";

NSString * const BPBindPhoneNumberResult = @"BPBindPhoneNumberResult";

NSString * const BPChangeAccountNotification = @"BPChangeAccountNotification";


#pragma mark --------编码--------------
+ (NSString * )encodeBase64:(NSString * )text
{
    NSData * data = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    // 转换到base64
    data = [GTMBase64hgh encodeData:data];
    NSString * base64String = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    
    return base64String;
}
+ (NSString * )decodeBase64:(NSString * )text
{
    
    NSData * data = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    // 转换到普通
    data = [GTMBase64hgh decodeData:data];
    NSString * string = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    
    return string;
}


//url编码
+(NSString *)encodeToPercentEscapeString: (NSString *) input
{
    NSString *outputStr = (NSString *)
    CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                            (CFStringRef)input,
                                            NULL,
                                            (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                            kCFStringEncodingUTF8);
    
    if(!outputStr || (NSNull *)outputStr == [NSNull null] || outputStr.length<1)
    {
        return @"";
    }
    return outputStr;
}
//md5加密
+(NSString *) md5String:(NSString *)str
{
    const char *original_str = [str UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(original_str, strlen(original_str), result);
    NSMutableString *hash = [NSMutableString string];
    for (int i = 0; i < 16; i++)
        [hash appendFormat:@"%02X", result[i]];
    return [hash lowercaseString];
}
static inline char hexChar(unsigned char c) {
    return c < 10 ? '0' + c : 'a' + c - 10;
}

static inline void hexString(unsigned char *from, char *to, NSUInteger length) {
    for (NSUInteger i = 0; i < length; ++i) {
        unsigned char c = from[i];
        unsigned char cHigh = c >> 4;
        unsigned char cLow = c & 0xf;
        to[2 * i] = hexChar(cHigh);
        to[2 * i + 1] = hexChar(cLow);
    }
    to[2 * length] = '\0';
}

NSString * sha1(const char *string)
{
    if(!string)
    {
        return nil;
    }
    static const NSUInteger LENGTH = 20;
    unsigned char result[LENGTH];
    CC_SHA1(string, (CC_LONG)strlen(string), result);
    
    char hexResult[2 * LENGTH + 1];
    hexString(result, hexResult, LENGTH);
    
    return [NSString stringWithUTF8String:hexResult];
}

#pragma mark ------显示-----------
//自定义title
+(void) customNavigationTitle:(NSString *)title ViewController:(UIViewController *)currentController
{
//    if(SCREEN_IS_LANDSCAPE || BPDevice_is_ipad)
//    {
//        UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH-100, 32)];
//
//        UILabel *titleText = [[UILabel alloc] initWithFrame: CGRectMake(-10, 5, SCREEN_WIDTH-100, 32)];
//        titleText.backgroundColor = [UIColor clearColor];
//        titleText.textColor = [UIColor colorWithRed:48/255.0f green:48/255.0f blue:48/255.0f alpha:1];//[UIColor whiteColor];
//        titleText.textAlignment = NSTextAlignmentCenter;
//        [titleText setFont:[UIFont boldSystemFontOfSize:20.0]];
//        [titleText setText:title];
//        [titleView addSubview:titleText];
//        currentController.navigationItem.titleView=titleView;
//        [titleText release];
//        [titleView release];
//    }
//    else
    {
        currentController.title = title;
    }
    
}


//自定义导航栏的左右按钮
+(void) customNavigationButton:(UIViewController *)currentController isleftButton:(BOOL)leftFlag NormalImage:(NSString *)nor_img HighLightedImage:(NSString *)hl_img
{
    int h = 44;
    int w = 50;
    int y=0;
    if(SCREEN_IS_LANDSCAPE && !BPDevice_is_ipad)
    {
        h=32;
        y=0;
        nor_img = [[nor_img substringToIndex:nor_img.length-4] stringByAppendingString:@"_2.png"];
        hl_img = [[hl_img substringToIndex:hl_img.length-4] stringByAppendingString:@"_2.png"];
    }
    if(leftFlag == YES)
    {
        int offset_x = -7;
        if(BP_Show_IOS7)
        {
            offset_x = -17;
        }
        //返回
        UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        leftButton.frame = CGRectMake(offset_x, y, w, h);
        [leftButton setImage:[UIImage imageNamed:nor_img] forState:UIControlStateNormal];
        [leftButton setImage:[UIImage imageNamed:hl_img] forState:UIControlStateHighlighted];
        [leftButton addTarget:currentController action:@selector(leftButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIView * leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
        [leftView addSubview:leftButton];
        
        UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:leftView];
        currentController.navigationItem.leftBarButtonItem = leftBarButtonItem;
        [leftBarButtonItem release];
        [leftView release];
    }
    else
    {
        int offset_x = 7;
        if(BP_Show_IOS7)
        {
            offset_x = 17;
        }
        UIButton * rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        rightButton.frame = CGRectMake(offset_x, y, w, h);
        [rightButton setImage:[UIImage imageNamed:nor_img] forState:UIControlStateNormal];
        [rightButton setImage:[UIImage imageNamed:hl_img] forState:UIControlStateHighlighted];
        [rightButton addTarget:currentController action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIView * rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
        [rightView addSubview:rightButton];
        
        UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
        currentController.navigationItem.rightBarButtonItem = rightBarButtonItem;
        [rightBarButtonItem release];
        [rightView release];
    }
}

//自定义导航栏的左右按钮
+(void) customNavigationButtonWithTitle:(UIViewController *)currentController isleftButton:(BOOL)leftFlag Title:(NSString *)title
{
    int h = 44;
    int w = 60;
    int y=0;
    if(SCREEN_IS_LANDSCAPE)
    {
        h=32;
        y=0;
    }
    if(leftFlag == YES)
    {
        int offset_x = -5;
        if(BP_Show_IOS7)
        {
            offset_x = -15;
        }
        //返回
        UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        leftButton.frame = CGRectMake(offset_x, y, w, h);
        [leftButton setTitle:title forState:UIControlStateNormal];
        [leftButton setTitleColor:[UIColor colorWithRed:54/255.0f green:95/255.0f blue:178/255.0f alpha:1] forState:UIControlStateNormal];
        [leftButton setTitleColor:[UIColor colorWithRed:143/255.0f green:163/255.0f blue:204/255.0f alpha:1] forState:UIControlStateHighlighted];
        leftButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [leftButton addTarget:currentController action:@selector(leftButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIView * leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
        [leftView addSubview:leftButton];
        
        UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:leftView];
        currentController.navigationItem.leftBarButtonItem = leftBarButtonItem;
        [leftBarButtonItem release];
        [leftView release];
    }
    else
    {
        int offset_x = 5;
        if(BP_Show_IOS7)
        {
            offset_x = 15;
        }
        UIButton * rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        rightButton.frame = CGRectMake(offset_x, y, w, h);
        [rightButton setTitle:title forState:UIControlStateNormal];
        [rightButton setTitleColor:[UIColor colorWithRed:54/255.0f green:95/255.0f blue:178/255.0f alpha:1] forState:UIControlStateNormal];
        rightButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [rightButton setTitleColor:[UIColor colorWithRed:143/255.0f green:163/255.0f blue:204/255.0f alpha:1] forState:UIControlStateHighlighted];
        [rightButton addTarget:currentController action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIView * rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
        [rightView addSubview:rightButton];
        
        UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
        currentController.navigationItem.rightBarButtonItem = rightBarButtonItem;
        [rightBarButtonItem release];
        [rightView release];
    }
}

//显示进入应用的提示
+(void) showEnterBigPlayerAppPrompt
{
    BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:[BPLanguage getStringForKey:@"BPPrompt" InTable:@"BPMultiLanguage"] message:[BPLanguage getStringForKey:@"BPGotoAPPPrompt" InTable:@"BPMultiLanguage"] delegate:nil cancelButtonTitle:[BPLanguage getStringForKey:@"BPNo" InTable:@"BPMultiLanguage"] otherButtonTitles:[BPLanguage getStringForKey:@"BPYes" InTable:@"BPMultiLanguage"],nil, nil];
    alert.delegate = self;
    [alert show];
    [alert release];
}

//缩放图片
+ (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size
{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    // 返回新的改变大小后的图片
    return scaledImage;
}

//当没有数据时，显示提示
+(void) showNoListTishi:(UIView *)superView tishiConment:(NSString *)str
{
    UILabel *label = (UILabel *)[superView viewWithTag:28001];
    if(label==nil)
    {
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, SCREEN_WIDTH, 14)];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:14];
        label.text = str;
        label.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        label.backgroundColor = [UIColor clearColor];
        label.tag = 28001;
        [superView addSubview:label];
        [label release];
    }
    label.hidden = NO;
}

//在邮箱绑定等，键盘不消失的界面，设置显示位置
+(void) setPromptPosition
{
    if(!BPDevice_is_ipad&&!BP_IS_OS_8_OR_LATER)
    {
        if(SCREEN_IS_LANDSCAPE)
        {
            if([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft)
                [BPCustomPromptBox setPromptBoxPosition_Y:80];
            else
                [BPCustomPromptBox setPromptBoxPosition_Y:200];
//            [BPCustomPromptBox setPromptBoxPosition_Y:80];
        }
        else
        {
            if([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationPortrait)
                [BPCustomPromptBox setPromptBoxPosition_Y:170];
            else
                [BPCustomPromptBox setPromptBoxPosition_Y:250];
        }
    }
    else if(!BPDevice_is_ipad&&BP_IS_OS_8_OR_LATER)
    {
        if(SCREEN_IS_LANDSCAPE)
        {
            [BPCustomPromptBox setPromptBoxPosition_Y:80];
        }
        else
        {
            [BPCustomPromptBox setPromptBoxPosition_Y:200];
        }
    }
}

#pragma mark ------UIText delegate----
//视图上移
+(void) ViewScrollUp:(UIView *) textField WillScrollView:(UIView *)scrollView
{
    if(BPDevice_is_ipad)
    {
        return;
    }
    int keyboardHeight;
    int screenHeight;
    CGPoint point = [textField convertPoint:CGPointMake(0, 0) toView:scrollView];
    int viewHeight = textField.frame.size.height;
//    if(viewHeight>50)
//    {
//        viewHeight=50;
//    }
    
    if(SCREEN_IS_LANDSCAPE)
    {
        keyboardHeight=180.0f; //220.0f; //
        screenHeight = [[UIScreen mainScreen] bounds].size.width - 52;
        if (screenHeight - keyboardHeight <= point.y + viewHeight)
        {
            if(viewHeight>80)
            {
                viewHeight = 80;
            }
            //CGFloat y = point.y - (self.view.frame.size.height - keyboardHeight - textField.frame.size.height);
            CGFloat y = keyboardHeight - (screenHeight-point.y) + viewHeight;
            [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
            [UIView setAnimationDuration:0.30f];
            CGPoint point = scrollView.center;
            point = scrollView.center;
            if(y<0)
            {
                y=0;
            }
            point.y -= y;
            scrollView.center = point;
            [UIView commitAnimations];
        }
    }
    else
    {
        keyboardHeight= 250.0f;
        screenHeight = [[UIScreen mainScreen] bounds].size.height;
        if (screenHeight - keyboardHeight <= point.y + viewHeight)
        {
            //CGFloat y = point.y - (self.view.frame.size.height - keyboardHeight - textField.frame.size.height);
            CGFloat y = keyboardHeight - (screenHeight-point.y)+ viewHeight;
            [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
            [UIView setAnimationDuration:0.30f];
            CGPoint point = scrollView.center;
            point.y -= y;
            scrollView.center = point;
            [UIView commitAnimations];
        }
    }
}

// Ascall 码排序
+(NSString *)sortHttpString:(NSMutableDictionary *)dic
{
    
    NSString *str = nil;
    NSMutableArray *parameters_array = [NSMutableArray arrayWithArray:[dic allKeys]];
    [parameters_array sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2];
        return [obj2 compare:obj1];//降序
    } ];
    
    for (int i = 0; i<parameters_array.count; i++) {
        
        
        NSString *key = [parameters_array objectAtIndex: i];
        NSString * value = [dic objectForKey:key];
        value = [self URLEncodeString:value];
        if (i==0) {
            str = [NSString stringWithFormat:@"%@=%@",key,value] ;
        }else{
            str = [NSString stringWithFormat:@"%@&%@=%@",str,key,value];
        }
        
    }
    
    return str;
}



- (NSString*)URLEncodeString:(NSString*)unencodedString{
    
    NSString *encodedString=nil;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0f) {
        
        
        encodedString = (NSString *)
        CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                  (CFStringRef)unencodedString,
                                                                  NULL,
                                                                  (CFStringRef)@"!*'(); :@&=+$,/?%#[]",
                                                                  kCFStringEncodingUTF8));
    }
    
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"%20" withString:@"+"];
    
    return encodedString;
}

//视图下移
+(void) ViewScrollDown:(UIView *)willScrollView
{
    if(BPDevice_is_ipad)
    {
        return;
    }
    [UIView beginAnimations:@"srcollView" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.1f];
    //self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    //self.view.frame.size.height/2+22);
    if(![UIApplication sharedApplication].statusBarHidden)
    {
        willScrollView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT_NAV/2-10);
        if (BP_Show_IOS7)
        {
            willScrollView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2-10);
        }
    }
    else
    {
        if (BP_Show_IOS7)
        {
            willScrollView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2+16);
        }
        else
        {
             willScrollView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT_NAV/2);
        }
    }
    [UIView commitAnimations];
}

#pragma mark------
//获取mac地址
+(NSString *) macaddress
{

    if (NSClassFromString(@"ASIdentifierManager")) {
        
        NSString *str = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
        str = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
        if(str == nil || str.length<2)
        {
            NSString *str = [[UIDevice currentDevice] identifierForVendor].UUIDString;
            str = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
        }
        BPLog(@"--------%@",str);
        return str;
    }
    int                    mib[6];
    size_t                len;
    char                *buf;
    unsigned char        *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl    *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error/n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1/n");
        return NULL;
    }
    
    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!/n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02x%02x%02x%02x%02x%02x", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    return [outstring uppercaseString];
}

+ (NSString *)getIDFA{
    
    return [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
}


//对数组的某个key进行排序
+(void) sortArrayWithKey:(NSString *)key SortArray:(NSMutableArray *)array isAscending:(BOOL) ascending
{
    NSSortDescriptor *sortDescriptor;
    //升序
    if(ascending)
    {
        sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:key ascending:YES comparator:^(id obj1, id obj2) {
            if ([obj1 doubleValue] < [obj2 doubleValue]) {
                return (NSComparisonResult)NSOrderedAscending;//NSOrderedDescending;
            }
            if ([obj1 doubleValue] > [obj2 doubleValue]) {
                return (NSComparisonResult)NSOrderedDescending;//NSOrderedAscending;
            }
            return (NSComparisonResult)NSOrderedSame;
        }];
    }
    else
    {
        sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:key ascending:NO comparator:^(id obj1, id obj2) {
            if ([obj1 doubleValue] > [obj2 doubleValue]) {
                return (NSComparisonResult)NSOrderedDescending;
            }
            if ([obj1 doubleValue] < [obj2 doubleValue]) {
                return (NSComparisonResult)NSOrderedAscending;
            }
            return (NSComparisonResult)NSOrderedSame;
        }];
    }
    [array sortUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
}

//数组去重
+(NSMutableArray *) removeSameObject:(NSMutableArray *)array InOriginalArray:(NSMutableArray *)originalArray withKey:(NSString *)key
{
    if(!originalArray || [originalArray count]<1)
    {
        return array;
    }
    if([array count] > 0)
    {
        for (int i=0; i<[array count]; i++)
        {
            NSDictionary *dic = [array objectAtIndex:i];
            int Id = [[dic objectForKey:key] intValue];
            for(int j=0; j<[originalArray count];j++)
            {
                NSDictionary *orginalDic = [originalArray objectAtIndex:j];
                int Id_before = [[orginalDic objectForKey:key] intValue];
                if(Id_before == Id)
                {
                    [array removeObjectAtIndex:i];
                    i--;
                    break;
                }
            }
        }
    }
    return array;
}

//获取星座
+(NSString *)getAstroWithMonth:(NSDate *)date
{
    if(!date)
    {
        return nil;
    }
    NSUInteger componentFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSDateComponents *components = [[NSCalendar currentCalendar] components:componentFlags fromDate:date];
    NSInteger m = [components month];
    NSInteger d = [components day];
    
    NSString *astroString = @"魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯";
    NSString *astroFormat = @"102123444543";
    NSString *result;
    if (m < 1||m > 12||d < 1||d > 31){
        return nil;//@”错误日期格式!”;
    }
    if(m==2 && d>29)
    {
        return nil;//@”错误日期格式!!”;
    }else if(m==4 || m==6 || m==9 || m==11) {
        if (d>30) {
            return nil;//@”错误日期格式!!!”;
        }
    }
    result=[NSString stringWithFormat:@"%@",[astroString substringWithRange:NSMakeRange(m*2-(d < [[astroFormat substringWithRange:NSMakeRange((m-1), 1)] intValue] - (-19))*2,2)]];
    result = [result stringByAppendingString:@"座"];
    return result;
}

//计算年龄
+(int) getAge:(NSString *)stringTime
{
    if(!stringTime || (NSNull *)stringTime == [NSNull null])
    {
        return 18;
    }
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat : @"yyyy-MM-dd"];
    NSDate *dateTime = [formatter dateFromString:stringTime];
    int year = 18;
    if(dateTime)
    {
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        unsigned int unitFlags = NSYearCalendarUnit;
        NSDateComponents *comps = [gregorian components:unitFlags fromDate:dateTime  toDate:[NSDate date]  options:0];
        year= [comps year];
        [gregorian release];
    }
    [formatter release];
    return year;
}

//获取时间字符串，昨天，今天。。。。
//ctime:要算的时间
//currentTime：当前时间，最好拿服务器的上面的
+(NSString *) getTimeString:(double) ctime nowTime:(double) currentTime
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat : @"HH:mm"];
    NSString *timeStr;
    
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:ctime];
    
    NSDate *today = [NSDate dateWithTimeIntervalSince1970:currentTime];//[NSDate date];
    NSDate * yesterday = [NSDate dateWithTimeIntervalSinceNow:-86400];
    NSDate * beforeYesterday = [NSDate dateWithTimeIntervalSinceNow:-86400*2];
    // 10 first characters of description is the calendar date:
    NSString * todayString = [[today description] substringToIndex:10];
    NSString * yesterdayString = [[yesterday description] substringToIndex:10];
    NSString * beforeYesterdayString = [[beforeYesterday description] substringToIndex:10];
    NSString * refDateString = [[date description] substringToIndex:10];
    
    if ([refDateString isEqualToString:todayString])
    {
        timeStr = [NSString stringWithFormat:@"%@  %@",[BPLanguage getStringForKey:@"BPToday" InTable:@"BPMultiLanguage"], [formatter stringFromDate:date]];
        [formatter release];
        return timeStr;
    }
    else if ([refDateString isEqualToString:yesterdayString])
    {
        timeStr = [NSString stringWithFormat:@"%@  %@",[BPLanguage getStringForKey:@"BPYestoday" InTable:@"BPMultiLanguage"], [formatter stringFromDate:date]];
        [formatter release];
        return timeStr;
    }
    else if ([refDateString isEqualToString:beforeYesterdayString])
    {
        timeStr = [NSString stringWithFormat:@"%@ %@",[BPLanguage getStringForKey:@"BPTheDayBeforeYestoday" InTable:@"BPMultiLanguage"], [formatter stringFromDate:date]];
        [formatter release];
        return timeStr;
    }
    else
    {
        [formatter setDateFormat : @"yyyy-MM-dd"];
        timeStr = [formatter stringFromDate:date];
        [formatter release];
        return timeStr;
    }
    [formatter release];
}







+(NSString*)URLEncodeString:(NSString*)unencodedString{
    
//    NSString *encodedString=nil;
//    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0f) {
    
        
        NSString *encodedString = (NSString *)
        CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                  (CFStringRef)unencodedString,
                                                                  NULL,
                                                                  (CFStringRef)@"!*'(); :@&=+$,/?%#[]",
                                                                  kCFStringEncodingUTF8));
  //  }
    
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"%20" withString:@"+"];
    
    return encodedString;
}
+(NSString *)URLDecodedString:(NSString *)str
{
    NSString *decodedString=( NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL, (__bridge CFStringRef)str, CFSTR(""), CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    
    return decodedString;
}








// 正则判断手机号码地址格式
+(BOOL) isMobileNumber:(NSString *)mobileNum
{
    
    /**
     * 手机号码
     * 移动：134[0-8],135,136,137,138,139,150,151,157,158,159,182,183,184,147,178,187,188，
     * 联通：130,131,132,152,155,156,185,186
     * 电信：133,1349,153,180,189,181,177
     */
    NSString * MOBILE = @"^1\\d{10}$";
    /**
     10         * 中国移动：China Mobile
     11         * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188,  183,184,147,178
     12         */
    NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[23478]|47)\\d)\\d{7}$";
    
    /**
     15         * 中国联通：China Unicom
     16         * 130,131,132,152,155,156,185,186,176
     17         */
    NSString * CU = @"^1(3[0-2]|5[256]|8[56]|45|76)\\d{8}$";
    /**
     20         * 中国电信：China Telecom
     21         * 133,1349,153,180,189
     22         */
    NSString * CT = @"^1((33|81|77|53|8[09])[0-9]|349)\\d{7}$";
    /**
     25         * 大陆地区固话及小灵通
     26         * 区号：010,020,021,022,023,024,025,027,028,029
     27         * 号码：七位或八位
     28         */
    // NSString * PHS = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    
    if (([regextestmobile evaluateWithObject:mobileNum] == YES)
        || ([regextestcm evaluateWithObject:mobileNum] == YES)
        || ([regextestct evaluateWithObject:mobileNum] == YES)
        || ([regextestcu evaluateWithObject:mobileNum] == YES))
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
//判断邮箱是否有效
+(BOOL) isValidateEmail:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


//获取当前的viewController
+(UIViewController *) getCurrentViewController
{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows)
        {
            if (tmpWin.windowLevel == UIWindowLevelNormal)
            {
                window = tmpWin;
                break;
            }
        }
    }
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    if ([nextResponder isKindOfClass:[UIViewController class]])
    result = nextResponder;
    else
    result = window.rootViewController;
    return result;
}


//发送退出平台的消息
+(void) postPlatformExitNotification
{
//    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:from,@"from", nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPPlatformExitNotification object:nil userInfo:nil];
    [BPCustomPromptBox BPHidePromptBox];
    
    if([[ShuZhiZhangUserPreferences CurrentUserID] intValue] > 0)
    {
#ifndef ShuZhiZhangSDK_MiNi
        [BPButtonBoard showDefaultButtonBoardWithPosition:-4 Position_Y:-4];
#endif
    }
}

//获取过敏词
+(NSArray*)getWordLibrary
{
    NSString * path = @"";
    path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"sensitiveWords.txt"]];
    
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"BPSensitiveWordsFileName"];
    if (str) {
        path = [[BPFilePathManager applicationDocumentsDirectoryPath] stringByAppendingPathComponent:str];
    }
    
    NSError *error;
    
    NSString *textFileContents = [NSString
                                  
                                  stringWithContentsOfFile:path
                                  
                                  encoding:NSUTF8StringEncoding
                                  
                                  error: & error];
    
    
    if (textFileContents == nil) {
        
        ////////NSLog(@"Error reading text file. %@", [error localizedFailureReason]);
        
    }
    
    textFileContents = [textFileContents stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSArray *lines = [textFileContents componentsSeparatedByString:@"、"];
    return lines;
}

//过滤敏感词
+(NSString*)filterSomeWord:(NSMutableArray*)wordArray theContent:(NSString*)content{
    
    for (NSString *str in wordArray) {
        
        NSString *str1 = @"";
        
        for (int i=0;i<str.length;i++) {
            str1 = [NSString stringWithFormat:@"%@*",str1];
        }
        
        content = [content stringByReplacingOccurrencesOfString:str withString:str1];
        
    }
    
    //////////NSLog(@"textStr ======== %@",content);
    
    //////////NSLog(@"Number of lines in the file:%d", [wordArray count] );
    
    return content;
}



//保存账号密码，删除后重新安装应用也能读到以前的账号密码
+(void) saveAccountAndPasswordToKeyChain:(NSString *)account AndPassword:(NSString *)password
{
    BPKeychainItemWrapper *keyChain = [[BPKeychainItemWrapper alloc] initWithIdentifier:@"BPAccountAndPasswordInKeyChain" accessGroup:nil];
    [keyChain setObject:@"BPAccountAndPasswordInfo" forKey:kSecAttrService];
    if(account && account.length>0)
    {
        [keyChain setObject:account forKey:kSecAttrAccount];
    }
    if(password && password.length>0)
    {
        [keyChain setObject:password forKey:kSecValueData];
    }
    [keyChain release];
}

//从KeyChain中获取账号密码
+(NSDictionary *) getAccountAndPasswordFromKeyChain
{
    BPKeychainItemWrapper *keyChain = [[BPKeychainItemWrapper alloc] initWithIdentifier:@"BPAccountAndPasswordInKeyChain" accessGroup:nil];
    NSString *password = [keyChain objectForKey:kSecValueData];
    NSString *account = [keyChain objectForKey:kSecAttrAccount];
    if(password && password.length>0 && account && account.length>0)
    {
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:account,@"BPAccount",password,@"BPPassword", nil];
        [keyChain release];
        return dic;
    }
    [keyChain release];
    return nil;
    
}

//获取文件名，从图片地址编码出一个文件名
+ (NSString *)getFileNameWithURLStr:(NSString *)urlStr
{
    if(!urlStr || (NSNull *)urlStr == [NSNull null] || urlStr.length<1)
    {
        return nil;
    }
    NSString *str = sha1([urlStr UTF8String]);
    return str;
}

//获取屏幕大小
+ (CGRect)myScreenBounds {
    CGRect bounds = [UIScreen mainScreen].bounds;
    if (BP_IS_OS_8_OR_LATER && UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    return bounds;
}

//设备类型
+(NSString *) platformString
{
    // Gets a string with the device model
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    if ([platform isEqualToString:@"iPhone1,1"])    return @"iPhone 2G";
    if ([platform isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([platform isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([platform isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,3"])    return @"iPhone 4 (CDMA)";
    if ([platform isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([platform isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    if ([platform isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    if ([platform isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([platform isEqualToString:@"iPhone7,1"])    return @"iPhone 6plus";
    
    if ([platform isEqualToString:@"iPod1,1"])      return @"iPod Touch (1 Gen)";
    if ([platform isEqualToString:@"iPod2,1"])      return @"iPod Touch (2 Gen)";
    if ([platform isEqualToString:@"iPod3,1"])      return @"iPod Touch (3 Gen)";
    if ([platform isEqualToString:@"iPod4,1"])      return @"iPod Touch (4 Gen)";
    if ([platform isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
    
    if ([platform isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([platform isEqualToString:@"iPad1,2"])      return @"iPad 3G";
    if ([platform isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([platform isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([platform isEqualToString:@"iPad2,4"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
    if ([platform isEqualToString:@"iPad2,6"])      return @"iPad Mini";
    if ([platform isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,1"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,2"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,3"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,4"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,5"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,6"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad4,1"])      return @"iPad Air WiFi";
    if ([platform isEqualToString:@"iPad4,2"])      return @"iPad Air Cellular";
    if ([platform isEqualToString:@"iPad4,4"])      return @"iPad mini 2G Wi‑Fi";
    if ([platform isEqualToString:@"iPad4,5"])      return @"iPad mini 2G Cellular";
    
    if ([platform isEqualToString:@"i386"])         return @"Simulator";
    if ([platform isEqualToString:@"x86_64"])       return @"Simulator";
    return platform;
}
@end
