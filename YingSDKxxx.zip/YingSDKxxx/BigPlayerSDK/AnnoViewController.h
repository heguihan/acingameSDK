//
//  AnnoViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-7-8.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnnoViewController : UIViewController

@end
