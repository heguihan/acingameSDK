//
//  AnnoViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-7-8.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "AnnoViewController.h"
#import "BPPlatformEntry.h"

@interface AnnoViewController ()

@end

@implementation AnnoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *imageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"notice_bg2.png"]];
    imageview.frame = CGRectMake(0, 0, 480, 320);
    [self.view addSubview:imageview];
    imageview.tag = 111;
    [imageview release];
    
    UIButton *back = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    back.frame = CGRectMake(20, 20, 70, 40);
    [back setTitle:@"返回" forState:UIControlStateNormal];
    back.backgroundColor = [UIColor clearColor];
    [back addTarget:self action:@selector(clickBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:back];
}

-(void) viewDidAppear:(BOOL)animated
{
//    [BPPlatformEntry BPShowGameAnno:1 AnnoFrame:CGRectMake(25, 65, 200, 220) msgType:2];
//    
//    [BPPlatformEntry BPShowGameAnno:1 AnnoFrame:CGRectMake(260, 65, 200, 220) msgType:1];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) clickBack
{
    [self dismissModalViewControllerAnimated:YES];
}
@end
