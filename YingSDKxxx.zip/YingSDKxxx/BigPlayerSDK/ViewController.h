//
//  ViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-5-30.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
