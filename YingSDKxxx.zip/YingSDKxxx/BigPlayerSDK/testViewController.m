//
//  testViewController.m
//  BigPlayerSDK
//

//

#import "testViewController.h"
#import "BPPlatformEntry.h"
#import "BPGameRoleInfo.h"
#import "BPCustomNoticeBox.h"
#import "BPLoginPublic.h"
//#import "BPPayMethodView.h"
//#import "BPQQLoginViewController.h"
//#import "BPweChatViewController.h"
//#import "BPWeChatPayViewController.h"
//#import "BPAlipayViewController.h"
//#import "BPUnionPayViewController.h"
#import "BPRegisterSelectView.h"
#import "TPBindSmallView.h"
#import "TPCommonUrlModel.h"
#import "BPShowLoginPrompt.h"
#import "BPBindPhoneView.h"
#import "BPVistorTipsView.h"
#import "BPBindCustomPhoneView.h"


#define  SCREEN_witdh  [[UIScreen mainScreen]bounds].size.width
#define  SCREEN_height  [[UIScreen mainScreen]bounds].size.height

@interface testViewController ()

@end

@implementation testViewController
@synthesize myBackMusic;

-(void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BPLoginResultNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BPPayResultNotification object:nil];
    [fileDic release];
    
    [myBackMusic release];  myBackMusic = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
      [BPPlatformEntry BPSDKInit];
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    
    
    fileDic = [[NSMutableDictionary alloc] initWithCapacity:0];
    
    UIImageView *imageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"strat.png"]];
    imageview.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    
//   imageview.frame = CGRectMake(0, 0, 480, 320);

    [self.view addSubview:imageview];
    imageview.tag = 111;
    [imageview release];
    
//    [self performSelector:@selector(loginTest) withObject:nil afterDelay:0.5];

    
#pragma mark -- 按钮屏幕内移动方法
//    [community addTarget:self action:@selector(wasDragged:withEvent:) forControlEvents:UIControlEventTouchDragInside];
    
    
#pragma mark -- 苹果支付
    
    UIButton *UiTestButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UiTestButton.frame = CGRectMake(30, 100, 100, 30);
    [UiTestButton setTitle:@"综合支付" forState:UIControlStateNormal];
    UiTestButton.backgroundColor = [UIColor blueColor];
    [UiTestButton addTarget:self action:@selector(purchaseMethodChoose:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:UiTestButton];
    
    UIButton *share = [UIButton buttonWithType:UIButtonTypeCustom];
    share.frame = CGRectMake  (30, 150, 100, 30);
    //    [community setTitle:@"" forState:UIControlStateNormal];
    share.backgroundColor = [UIColor blueColor];
    [share addTarget:self action:@selector(IApPaymentTestAction) forControlEvents:UIControlEventTouchUpInside];
    [share setTitle:@"苹果支付" forState:UIControlStateNormal];
    [self.view addSubview:share];
    

    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame =CGRectMake(30, 200, 100, 30);
        [button setTitle:@"支付宝支付" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor blueColor];
    [button addTarget:self action:@selector(alipayAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    UIButton *loginOut = [UIButton buttonWithType:UIButtonTypeCustom];
    loginOut.frame = CGRectMake(30, 250, 100, 30);
    [loginOut setTitle:@"银联支付" forState:UIControlStateNormal];
    loginOut.backgroundColor = [UIColor blueColor];
    [loginOut addTarget:self action:@selector(unionpayAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginOut];

    
    UIButton *payChoose = [UIButton buttonWithType:UIButtonTypeCustom];
    payChoose.frame = CGRectMake(30, 300, 100, 30);
    [payChoose setTitle:@"微信支付" forState:UIControlStateNormal];
    payChoose.backgroundColor = [UIColor blueColor];
    [payChoose addTarget:self action:@selector(weChatPayAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:payChoose];
    
    
    
    
    UILabel *vistorLable = [[UILabel alloc]initWithFrame:CGRectMake(30, 10, 280, 30)];
    vistorLable.font = [UIFont systemFontOfSize:15];
    vistorLable.text = @"登录方式:";
    vistorLable.textColor = [UIColor whiteColor];
    vistorLable.tag = 2016;
    vistorLable.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:vistorLable];
    
    UILabel *choselable = [[UILabel alloc]initWithFrame:CGRectMake(30, 50, 280, 30)];
//    choselable.backgroundColor = [UIColor blueColor];
    choselable.textColor = [UIColor whiteColor];
    choselable.text = @"用户ID:";
    choselable.font = [UIFont systemFontOfSize:15];
    choselable.tag = 2017;
    choselable.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:choselable];

    
#pragma mark --- 开始按钮,弹出登陆小窗
    UIButton *community = [UIButton buttonWithType:UIButtonTypeCustom];
    community.frame = CGRectMake(200, 100, 100, 30);
    [community setTitle:@"开始登陆" forState:UIControlStateNormal];
    [community setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //    [community setTitle:@"" forState:UIControlStateNormal];
    community.backgroundColor = [UIColor orangeColor];
    [community addTarget:self action:@selector(communityTest) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:community];

    
    UIButton *record = [UIButton buttonWithType:UIButtonTypeCustom];
    record.frame = CGRectMake(200, 200, 100, 30);
    [record setTitle:@"微信登录" forState:UIControlStateNormal];
    record.backgroundColor = [UIColor blueColor];
    [record addTarget:self action:@selector(weChatLogin) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:record];
    
    UIButton *recordOver = [UIButton buttonWithType:UIButtonTypeCustom];
    recordOver.frame = CGRectMake(200, 250, 100, 30);
    [recordOver setTitle:@"QQ登录" forState:UIControlStateNormal];
    recordOver.backgroundColor = [UIColor blueColor];
    [recordOver addTarget:self action:@selector(QQLogin) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:recordOver];
    
    UIButton *play = [UIButton buttonWithType:UIButtonTypeCustom];
    play.frame = CGRectMake(200, 150, 100, 30);
    [play setTitle:@"游客登录" forState:UIControlStateNormal];
    play.backgroundColor = [UIColor blueColor];
    [play addTarget:self action:@selector(vistorLogin) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:play];
    
    
    
    UIButton *noticeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    noticeButton.frame = CGRectMake(200, 300, 100, 30);
    [noticeButton setTitle:@"提示测试" forState:UIControlStateNormal];
    noticeButton.backgroundColor = [UIColor blueColor];
    [noticeButton addTarget:self action:@selector(noticeButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:noticeButton];
    
    
    UIButton *requestButton = [UIButton buttonWithType:UIButtonTypeCustom];
    requestButton.frame = CGRectMake(30, 370, 100, 30);
    [requestButton setTitle:@"接口测试" forState:UIControlStateNormal];
    requestButton.backgroundColor = [UIColor blueColor];
    [requestButton addTarget:self action:@selector(requestButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:requestButton];
    
    
    UIButton *userInfoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    userInfoButton.frame = CGRectMake(200, 370, 100, 30);
    [userInfoButton setTitle:@"用户信息" forState:UIControlStateNormal];
    userInfoButton.backgroundColor = [UIColor orangeColor];
    [userInfoButton addTarget:self action:@selector(userInfoButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:userInfoButton];
    
    
    UIButton *orderIdButton = [UIButton buttonWithType:UIButtonTypeCustom];
    orderIdButton.frame = CGRectMake(200, 410, 100, 30);
    [orderIdButton setTitle:@"下单接口" forState:UIControlStateNormal];
    orderIdButton.backgroundColor = [UIColor orangeColor];
    [orderIdButton addTarget:self action:@selector(orderIdButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:orderIdButton];
    
    
    UIButton *pwddButton = [UIButton buttonWithType:UIButtonTypeCustom];
    pwddButton.frame = CGRectMake(30, 410, 100, 30);
    [pwddButton setTitle:@"修改密码" forState:UIControlStateNormal];
    pwddButton.backgroundColor = [UIColor orangeColor];
    [pwddButton addTarget:self action:@selector(pwddButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:pwddButton];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(LoginResult:) name:BPLoginResultNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(InitDidFinish:) name:BPInitDidFinishedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(exiOurSdk) name:BPPlatformExitNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pauseSound) name:BPShouldPauseSoundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playSound) name:BPShouldPlaySoundNotification object:nil];
    

    [BPPlatformEntry BPSetScreenOrientation:BPInterfaceOrientationProtrait];

    [self.view setBackgroundColor:[UIColor blackColor]];
    
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(BPPayResult:) name:BPPayResultNotification object:nil];
    
}
// 修改密码
-(void)pwddButton:(UIButton*)button{



}

// 下单
-(void)orderIdButton:(UIButton*)button{

        
        NSString  *appid = [BPUserPreferences CurrentAppId];
        NSString  *appsecret = [BPUserPreferences CurrentAppSecret];
        NSString  *channelId = [BPUserPreferences CurrentChannelId];
        NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
        
        
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        
        
        [dict setObject:channelId forKey:@"channelID"];
        [dict setObject:@"2"forKey:@"type"];
        [dict setObject:dateStr forKey:@"ts"];
    
        
        NSString *sortStr = [BPUtility sortHttpString:dict];
        NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
        NSString *sign = [BPUtility md5String:signStr];
        NSString *urlStr = [NSString stringWithFormat:@"http://192.168.1.35/www/index.php?__msgID=userInfo&__appID=%@",appid];
        urlStr = [NSString stringWithFormat:@"%@&%@&sign=%@",urlStr,sortStr,sign];
        NSLog(@"获取用户信息urlStr = %@",urlStr);
        
        [BPHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
            
            NSLog(@"获取用户信息= %@,urlStr = %@",data,urlStr);
            
            
            
        } failure:^(NSError *error) {
            
            
            
        }];
        
    }
    



// 用户信息 
-(void)userInfoButton:(UIButton *)button{
 
     
    [[BPRegisterAndLoginRequest BPSharedRequest] requestUserInfo:@"" phoneNumber:@"18875912393"];

}




-(void)requestButton:(UIButton *)button{

//
//    int  x = arc4random() %100;
//    
//    NSLog(@"x==== %d",x);
//    
//    return;
   // [[[BPRegisterSelectView alloc] init] requestForPhoneVertifyCode:@"18875912393"];

  //  [[TPBindSmallView getShareInstance] showBindSmallVies];

   // [BPShowLoginPrompt showWithAccount:@"张三"];
    
//    [TPCommonUrlModel ChooseSDKEnvironment];
    
//   [[BPBindPhoneView ShareInstance] showBindPhoneTipsThings];
    
    
   // [self.view addSubview: [[BPVistorTipsView alloc] init]];
    
    
   // [[BPBindCustomPhoneView getShareInstance] showBindSmallVies];
    
    
    [BPPlatformEntry BPUploadUserOfRoleInfo:@{@"roleId":@"fan1234",@"roleName":@"勇士",@"level":@"50",@"viplevel":@"8"}];
    
}


- (void)LoginResult:(NSNotification *)notify
{
  
    UILabel *loginTypeLable = (UILabel *)[self.view viewWithTag:2016];
    UILabel *userIdlable = (UILabel *)[self.view viewWithTag:2017];
    NSDictionary *dic = [notify userInfo];
    
    NSLog(@"登录成功消息Dict = %@",dic);
    
    if([[dic objectForKey:@"result"] isEqualToString:@"BPLoginSuccess"])
    {
        if ([[dic objectForKey:@"LoginType"] isEqualToString:@"weChat"]) {
            loginTypeLable.text = @"登录方式:   微信登录";
            userIdlable.text = [NSString stringWithFormat:@"用户ID:   %@", [dic objectForKey:@"openId"]];
        }
        if ([[dic objectForKey:@"LoginType"] isEqualToString:@"QQ"]) {
            loginTypeLable.text = @"登录方式:   QQ登录";
            userIdlable.text = [NSString stringWithFormat:@"用户ID:   %@", [dic objectForKey:@"openId"]];
        }
        NSLog(@"登录成功");
      //  [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];

    // [BPPlatformEntry BPShowPendant:50 Position_Y:300];
        
    }
    else if([[dic objectForKey:@"result"] isEqualToString:@"BPLogoutSuccess"])
    {
        NSLog(@"注销成功");
        
    }
    else if([[dic objectForKey:@"result"] isEqualToString:@"BPUserCancelLogin"])
    {
        NSLog(@"取消登陆");
    }
    
    
    
}

-(void) BPPayResult:(NSNotification *)notify
{
    NSDictionary *dic = [notify userInfo];
    NSLog(@"Paydic = %@",dic);
    if([[dic objectForKey:@"result"] isEqualToString:@"UserCancel"])
    {
        NSLog(@"用户取消购买");
    }
    if([[dic objectForKey:@"result"] isEqualToString:@"BPPaySuccess"])
    {
        NSLog(@"我是通知哈哈哈哈购买成功");
    }
    if([[dic objectForKey:@"result"] isEqualToString:@"BPPayFailed"])
    {
        NSLog(@"我是通知哈哈哈哈购买失败");
    }
}


-(void)weChatLogin{
    
//    [[[BPweChatViewController alloc] init] weixinLoginActionForYingSDK];
    
    NSLog(@"微信登录");

}

//QQ登录
- (void)QQLogin{
    
//    BPQQLoginViewController *qqlogin = [[BPQQLoginViewController alloc]init];
//    [qqlogin TencentQQConnectLogin];
    
}

//游客登录
- (void)vistorLogin{
    
    
    
}


-(void)exiOurSdk
{
    NSLog(@"exit-----");
}


//test
- (void)record:(id)sender{
    
    NSDictionary * dic = @{
                           @"OrderStatus": @"1",
                           @"callbackUrl" : @"http://121.199.44.109:8087/callbackDemo/callback.php",
                           @"channelId" : @"58929",
                           @"deviceId" : @"53A33183-E276-4894-8010-D6F743936313",
                           @"gameOrderId" : @"soijeofjowef435555",
                           @"jsonDataString" : @"{\n  \"productId\" : \"com.palmpioneer.ldlm.d300\",\n  \"money\" : \"30\",\n  \"uid\" : \"16\",\n  e\" : \"fandaye\",\n  \"serverId\" : \"999\",\n  \"sign\" : \"449510662d23c4e4eb57766d7cba3c42\"\n}",
                           @"money": @"30",
                           @"orderId" : @"1000000215339013",
                           @"productId" :@"com.palmpioneer.ldlm.d300",
                           @"receipt" : @"MII3kgYWJ/YYpvvcw89d3HH77evlCPCdyEUre0Qu8V/snHJIZKW5xMcTkPF320v/oFezI4Mo3gC9+b7JaBQN+L",
                           @"serverId" : @"999",
                           @"sign" : @"449510662d23c4e4eb57766d7cba3c42",
                           @"token" : @"c4d759b5dde1c0bfc3c0652573f463c7",
                           @"uid" : @"16",
                        };

     NSMutableDictionary *dicc = [NSMutableDictionary dictionaryWithDictionary:dic];
    [BPLoginPublic savePaymentInfoToDatabase:dicc];
    
}



#pragma mark -- 开始登陆按钮可拖动

-(void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    // get the touch
    UITouch *touch = [[event touchesForView:button] anyObject];
    
    // get delta
    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;
    
    // move button
    button.center = CGPointMake(button.center.x + delta_x,
                                button.center.y + delta_y);

}

-(void) InitDidFinish:(NSNotification *)notify
{
    [BPPlatformEntry BPLogin];
}

// 综合支付
-(void)purchaseMethodChoose:(UIButton *)button{
    
    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
    orderInfo.productName = @"雪刀群侠传-新手大礼包";
    orderInfo.userID= @"123456789";
    orderInfo.money = @"0.01";
    orderInfo.gameCallbackUrl= @"http://182.254.225.137:8889/yingserver/www2/test_gameCallback.php";
    orderInfo.cpOrderID = [self receiveAcormString];
    orderInfo.extension = @"你付款,我拿钱";
    orderInfo.productID = @"com.tanyu.zwsgApp.zwsg10110104";
    
  // [BPPlatformEntry BPPayAccess:orderInfo];
    
    [BPPlatformEntry BPApplyForPurchase:orderInfo];
    
  //  [[BPIAPPurchaseClass SharedBPApplePayPlatform] ApplePurchaseWithProductInfo:orderInfo];

}



// iap 支付
-(void) IApPaymentTestAction
{
    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
    orderInfo.productName = @"雪刀群侠传-新手大礼包";
    orderInfo.userID= @"123456789";
    orderInfo.money = @"0.01";
    orderInfo.gameCallbackUrl= @"http://182.254.225.137:8889/yingserver/www2/test_gameCallback.php";
    orderInfo.cpOrderID = [self receiveAcormString];
    orderInfo.extension = @"苹果支付";
    orderInfo.productCount = 1;
    orderInfo.productID = @"com.acingame.lswxfygold_apps6";
    [[BPIAPPurchaseClass SharedBPApplePayPlatform] ApplePurchaseWithProductInfo:orderInfo];
    
}


// 银联
-(void)unionpayAction:(UIButton *)unionButton
{
//    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
//    orderInfo.productName = @"雪刀群侠传-新手大礼包";
//    orderInfo.userID= @"123456789";
//    orderInfo.money = @"0.01";
//    orderInfo.extension = @"银联支付";
//
//    orderInfo.gameCallbackUrl= @"http://182.254.225.137:8889/yingserver/www2/test_gameCallback.php";
//    orderInfo.cpOrderID = [self receiveAcormString];
//    orderInfo.extension = @"";
//    orderInfo.productCount = 1;
//    orderInfo.productID = @"com.Acigame.zwsgApp.zwsg10110104";
//
//    BPUnionPayViewController *unionpay = [[BPUnionPayViewController alloc] init];
//    [unionpay payForUnionPay:orderInfo];

    
}


#pragma mark -------微信支付-------
-(void)weChatPayAction:(UIButton *)button
{
//    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
//    orderInfo.productName = @"雪刀群侠传-新手大礼包";
//    orderInfo.userID= @"123456789";
//    orderInfo.money = @"0.01";
//    orderInfo.gameCallbackUrl= @"http://182.254.225.137:8889/yingserver/www2/test_gameCallback.php";
//    orderInfo.cpOrderID = [self receiveAcormString];
//    orderInfo.extension = @"";
//    orderInfo.productCount = 1;
//    orderInfo.productID = @"com.Acigame.zwsgApp.zwsg10110104";
//
//    [[BPWeChatPayViewController SharedWechatPayPlatform] payForWechat:orderInfo];

    
    
}


// 调用支付宝支付页面
-(void)alipayAction
{
//    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
//    orderInfo.productName = @"雪刀群侠传-新手大礼包";
//    orderInfo.userID= @"123456789";
//    orderInfo.money = @"0.01";
//    orderInfo.gameCallbackUrl= @"http://sdk.Acigame.com/v5/IOS_BPSDKPayNotice/payNotice/MzAzMjU%3D/";
//    orderInfo.cpOrderID = [self receiveAcormString];
//    orderInfo.extension = @"支付宝牛逼";
//    orderInfo.productCount = 1;
//    orderInfo.productID = @"com.Acigame.zwsgApp.zwsg10110104";
//
//    BPAlipayViewController *viewController = [[BPAlipayViewController alloc]init];
//    [viewController PayWithAliPayOrderInfo:orderInfo];   // 调用支付宝支付接口
    
}



// 开始按钮
-(void) communityTest
{
    
    [BPPlatformEntry BPLogin];
    
}



-(void)noticeButtonAction{

 
   // [BPCustomPromptBox showWithTitle:@"温馨提示明天有雨" AndDisappearSecond:2];
    [BPCustomNoticeBox showCenterWithText:@"温馨提示后天有雨" duration:2.0];
  
   // [BPIAPPurchaseClass verifyReceiptFromCompanyServerWhenAccident];
    
}


// 随机字符串
-(NSString *)receiveAcormString{


    NSString *string = [[NSString alloc]init];
    for (int i = 0; i < 32; i++) {
        int number = arc4random() % 36;
        if (number < 10) {
            int figure = arc4random() % 10;
            NSString *tempString = [NSString stringWithFormat:@"%d", figure];
            string = [string stringByAppendingString:tempString];
        }else {
            int figure = (arc4random() % 26) + 97;
            char character = figure;
            NSString *tempString = [NSString stringWithFormat:@"%c", character];
            string = [string stringByAppendingString:tempString];
        }
    }
    
    return string;

}






- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{

    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);

}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    

    return UIInterfaceOrientationMaskAll;//

}





@end
