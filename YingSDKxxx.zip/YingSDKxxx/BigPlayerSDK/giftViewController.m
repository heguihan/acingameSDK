//
//  giftViewController.m
//  BigPlayerSDK
//

//

#import "giftViewController.h"
//#import "BPLoginPublic.h"

@interface giftViewController ()

@end

@implementation giftViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blackColor];
    
//    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
//    passwordField.placeholder = @"请输入礼包激活码";
//    [BPLoginPublic setTextFieldProperty:passwordField withDelegate:self];
//    [self.view addSubview:passwordField];
//    passwordField.returnKeyType = UIReturnKeyNext;
//    passwordField.tag = 102;
//    passwordField.frame = CGRectMake(20, 60, 160, 40);
//    [self.view addSubview:passwordField];
//    [passwordField release];
    
    UIButton *back = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    back.frame = CGRectMake(0, 0, 40, 40);
    [back setTitle:@"返回" forState:UIControlStateNormal];
    back.backgroundColor = [UIColor clearColor];
    [back addTarget:self action:@selector(clickBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:back];
    
    UIButton *get = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    get.frame = CGRectMake(210, 60, 40, 40);
    [get setTitle:@"兑换" forState:UIControlStateNormal];
    get.backgroundColor = [UIColor clearColor];
    [get addTarget:self action:@selector(clickGet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:get];
}

-(void) clickBack
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}


-(void) clickGet
{

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
