//
//  shopViewController.m
//  BigPlayerSDK

//

#import "shopViewController.h"
#import "BPPlatformEntry.h"

@interface shopViewController ()

@end

@implementation shopViewController

-(void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BPPayResultNotification object:nil];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blackColor];
    
    UIButton *back = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    back.frame = CGRectMake(20, 20, 70, 40);
    [back setTitle:@"返回" forState:UIControlStateNormal];
    back.backgroundColor = [UIColor clearColor];
    [back addTarget:self action:@selector(clickBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:back];
    
    UIButton *pay_100 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    pay_100.frame = CGRectMake(40, 80, 70, 40);
    [pay_100 setTitle:@"100金币" forState:UIControlStateNormal];
    pay_100.backgroundColor = [UIColor clearColor];
    [pay_100 addTarget:self action:@selector(clickPay_100) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:pay_100];
    
    UIButton *pay_1000 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    pay_1000.frame = CGRectMake(40, 140, 70, 40);
    [pay_1000 setTitle:@"1000金币" forState:UIControlStateNormal];
    pay_1000.backgroundColor = [UIColor clearColor];
    [pay_1000 addTarget:self action:@selector(clickPay_1000) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:pay_1000];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(BPPayResult:) name:BPPayResultNotification object:nil];
}

-(void) BPPayResult:(NSNotification *)notify
{
    NSDictionary *dic = [notify userInfo];
    if([[dic objectForKey:@"result"] isEqualToString:@"UserCancel"])
    {
        NSLog(@"用户取消购买000");
    }
    if([[dic objectForKey:@"result"] isEqualToString:@"BPPaySuccess"])
    {
        NSLog(@"购买成功");
    }
    if([[dic objectForKey:@"result"] isEqualToString:@"BPPayFailed"])
    {
        NSLog(@"购买失败");
    }
    NSLog(@"---%@",notify);
}

-(void) clickPay_100
{
    BPOrderInfo *orderInfo = [[BPOrderInfo alloc] init];
    orderInfo.productName = @"100金币";
    [BPPlatformEntry BPPayAccess:orderInfo];
    [orderInfo release];
}

-(void) clickPay_1000
{
    
}


-(void) clickBack
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //    return YES;
    //
    //    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskAll;//UIInterfaceOrientationMaskLandscape;  //UIInterfaceOrientationMaskAll;//
}

- (BOOL)shouldAutorotate
{
    return YES;
    //    return UIInterfaceOrientationMaskLandscape;
}
@end
