//
//  AppDelegate.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-5-30.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "testViewController.h"
#import "BPPlatformEntry.h"
//#import "WXApi.h"

@protocol WxGetAuthoDelegate <NSObject>


-(void)loginSuccessByCode:(NSString *)code;

@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>{

}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) testViewController *viewController;

@property(nonatomic,strong) id<WxGetAuthoDelegate> wxDelegate;


@end
