//
//  giftViewController.h
//  BigPlayerSDK
//

//

#import "ViewController.h"

@interface giftViewController : UIViewController



@end
