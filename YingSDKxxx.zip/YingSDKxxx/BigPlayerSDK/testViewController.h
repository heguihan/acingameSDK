//
//  testViewController.h
//  BigPlayerSDK

//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#define IsProtrait

@interface testViewController : UIViewController{
    NSMutableDictionary *fileDic;
}


@property (nonatomic,retain) AVAudioPlayer *myBackMusic;
@end
