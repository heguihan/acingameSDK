//
//  BigPlayerSDKBase+BPCheckUpdate.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-7-2.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase+BPCheckUpdate.h"
#import "BPCheckUpdateWaitView.h"
#import "BPCustomNoticeBox.h"
#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "ShuZhiZhangUserPreferences.h"

@implementation BigPlayerSDKBase (BPCheckUpdate)


-(void)requestForTheSDKConfigSeting
{
    
    NSString *urlStrNew = [NSString stringWithFormat:@"%@%@%@?channel_id=%@",GLOBAL_LOGIN_API_URL,@"channelPay/",[ShuZhiZhangUserPreferences CurrentAppId],[ShuZhiZhangUserPreferences CurrentChannelId]];
    //     NSString *urlStr = [NSString stringWithFormat:@"%@?channelID=%@",GLOBAL_Config_API_URL,[BPUserPreferences CurrentChannelId]];
    //   @"https://u8svr.acingame.com/config/getConfig?channelID=1712"
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"BPGameIds" ofType:@"plist"]];
    ////////NSLog(@"adadadadadadadadadadadadaddadadadadadadad");
    ////////NSLog(@"url=%@",urlStrNew);
    ////////NSLog(@"dict=%@",dic);
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStrNew parameters:nil success:^(NSDictionary *data) {
        
        NSLog(@"data = %@",data);
        ////////NSLog(@"data ret == %@",[data objectForKey:@"ret"]);
        NSString *retStr = [NSString stringWithFormat:@"%@",data[@"ret"]];
        if ([retStr isEqualToString:@"0"]) {
            ////////NSLog(@"切支付成功");
            ////////NSLog(@"chpay=%@",data[@"chpay"]);
            ////////NSLog(@"返回地址url=%@",data[@"url"]);
            NSString *payway = [NSString stringWithFormat:@"%@",data[@"chpay"]];
            NSString *maiUrl = [NSString stringWithFormat:@"%@",data[@"url"]];
            [[NSUserDefaults standardUserDefaults] setObject:maiUrl forKey:@"maiurl"];
            [[NSUserDefaults standardUserDefaults] setObject:payway forKey:@"maiWay"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            ////////NSLog(@"搞定xxxxxx");
        }
        //         NSString *configStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        //         [[NSUserDefaults standardUserDefaults] setObject:configStr forKey:@"PurchaseConfigJson"];
        
        
        
    } failure:^(NSError *error) {
        
        [BPCustomNoticeBox showCenterWithText:@" 网络错误" duration:2.0];
        
    }];
    
    
}



-(BOOL)compareNowtimeToSmalltime:(NSString *)smalltime  bigTime:(NSString *)bigtime{

    NSDateFormatter *formatter = [[NSDateFormatter alloc]init]; //初始化格式器。
    [formatter setDateFormat:@"HH:mm:ss"];//定义时间为这种格式： YYYY-MM-dd hh:mm:ss 。
    NSString *currentTime = [formatter stringFromDate:[NSDate date]];//将NSDate  ＊对象 转化为 NSString ＊对象。
    ////////NSLog(@"%@", currentTime);//控制台打印出当前时间。

    if ([smalltime compare:currentTime] && [currentTime compare:bigtime]) {
        
        return YES;    // 在时间段内
        
    }else{
    
    
        return NO;
    }
    
}


// 星期几
- (NSString*)weekdayStringFromDate:(NSDate*)inputDate {
    
    
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null], @"day7", @"day1", @"day2", @"day3", @"day4", @"day5", @"day6",  nil];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSTimeZone *timeZone = [[NSTimeZone alloc] initWithName:@"Asia/Beijing"];
    
    [calendar setTimeZone: timeZone];
    
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:inputDate];
    
    return [weekdays objectAtIndex:theComponents.weekday];
    
}





//获取游戏信息
-(NSMutableDictionary *) getGamInfoFromLocal
{
    NSString *name =[[NSUserDefaults standardUserDefaults ] objectForKey:@"BPGameName"];
    NSString *iconUrl =[[NSUserDefaults standardUserDefaults ] objectForKey:@"BPGameIconURL"];
    if(!name || (NSNull *)name == [NSNull null] || name.length<1)
    {
        name = @"";
    }
    if(!iconUrl || (NSNull *)iconUrl == [NSNull null] || iconUrl.length<1)
    {
        iconUrl = @"";
    }
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:name,@"game_name",iconUrl,@"game_icon", nil];

}



#pragma mark ---------alertView delegate-------
-(void) gotoDownloadGame
{
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"BPGameDownloadURLStr"];
    if(!str || (NSNull *)str == [NSNull null] || str.length<1)
    {

    }
    else
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}


#pragma mark -----request delegate -----


-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    //检测更新
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"checkGameUpdate"])
    {
        [BPQLoadingView hideWithAnimated:NO];
       
    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPLogin"] || [[userInfo objectForKey:@"RequestTag"] isEqualToString:@"qqAccountLogin"] || [[userInfo objectForKey:@"RequestTag"] isEqualToString:@"SinaWeiboLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [BPQLoadingView hideWithAnimated:NO];
        
        
        [BPCustomNoticeBox showCenterWithText:@"登陆失败，请检查你的网络状态" duration:2.0];
        
        
       }
}



@end
