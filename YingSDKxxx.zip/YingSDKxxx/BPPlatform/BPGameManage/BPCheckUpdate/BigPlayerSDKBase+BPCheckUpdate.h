//
//  BigPlayerSDKBase+BPCheckUpdate.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-7-2.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase.h"

@interface BigPlayerSDKBase (BPCheckUpdate)
//获取游戏信息
-(NSMutableDictionary *) getGamInfoFromLocal;

//检测游戏是否有更新
-(void) checkGameVersionUpdate;
-(void)requestForTheSDKConfigSeting;
//检测更新请求成功
-(void) checkGameVersionUpdataDidFinished:(ASIHTTPRequest *)request;

-(void) gotoDownloadGame;




@end
