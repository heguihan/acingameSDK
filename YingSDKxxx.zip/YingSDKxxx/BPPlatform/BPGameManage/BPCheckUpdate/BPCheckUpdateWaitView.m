//
//  BPCheckUpdateWaitView.m
//  BigPlayerSDK
//
//  Copyright (c) 2016年 John FAN All rights reserved.
//

#import "BPCheckUpdateWaitView.h"
#import "BigPlayerSDKBase.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"

@implementation BPCheckUpdateWaitView
@synthesize loopNum;
- (id)initWithFrame:(CGRect)frame
{
    int screen_w = REAL_SCREEN_WIDTH;//[UIScreen mainScreen].bounds.size.width;
    int screen_h = REAL_SCREEN_HEIGHT;//[UIScreen mainScreen].bounds.size.height;
    
//    if(SCREEN_IS_LANDSCAPE)
//    {
//        screen_h = [UIScreen mainScreen].bounds.size.width;
//        screen_w = [UIScreen mainScreen].bounds.size.height;
//    }
    self = [super initWithFrame:CGRectMake(0, 0, screen_w, screen_h)];
    if (self) {
        // Initialization code
        
        self.userInteractionEnabled = YES;
        
        UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_w, screen_h)];
        backView.backgroundColor = [UIColor blackColor];
        backView.alpha = 0.6;
        [self addSubview:backView];
        backView.userInteractionEnabled = YES;
        [backView release];
        

    
        

        UIImageView *bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_loading.png"]];
        bgImageView.frame = CGRectMake((screen_w - BPBackImageWidth)/2, (screen_h - BPBackImageWidth)/2, BPBackImageWidth, BPBackImageHeight);
        

        
        [self addSubview:bgImageView];
        bgImageView.tag = 19000;
        [bgImageView release];
        
        UILabel *buttonTitle = [[UILabel alloc] init];
        NSString *str = [BPLanguage getStringForKey:@"BPCheckUpdate" InTable:@"BPMultiLanguage"];
        CGSize size = [str sizeWithFont:[UIFont systemFontOfSize:16]];
        
        buttonTitle.frame = CGRectMake((BPBackImageWidth - size.width)/2, 250, size.width,16);

        buttonTitle.textAlignment = NSTextAlignmentCenter;
        buttonTitle.backgroundColor = [UIColor clearColor];
        buttonTitle.text = str;
        buttonTitle.font = [UIFont systemFontOfSize:16];
        buttonTitle.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        [bgImageView addSubview:buttonTitle];
        [buttonTitle release];
        
        
        UIImageView *dotImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_checkUpdate1.png"]];

        dotImageView.frame = CGRectMake(110, 230, 10, 10);

        dotImageView.tag = 19006;
        [bgImageView addSubview:dotImageView];
        [dotImageView release];
        
        
        for(int i=0;i<4;i++)
        {
            UIImageView *dotImageView2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_checkUpdate2.png"]];
            dotImageView2.frame = CGRectMake(110+i*20, 230, 10, 10);
            [bgImageView addSubview:dotImageView2];
            [dotImageView2 release];
        }
        
        dotTimer = [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(dotShowLoop) userInfo:nil repeats:YES];
        
    }
    return self;
}

//显示点动画
-(void) dotShowLoop
{
    UIImageView *bgImageView = (UIImageView *)[self viewWithTag:19000];
    UIImageView *dotImageView = (UIImageView *)[bgImageView viewWithTag:19006];
//    dotImageView.frame = CGRectMake(100+currentLocation*17, 230, 10, 10);

    dotImageView.frame = CGRectMake(110+currentLocation*20, 230, 10, 10);
    currentLocation++;
    loopNum++;
    if(currentLocation>=4)
    {
        currentLocation = 0;
    }
}


-(void) stopDotTimer
{
    [dotTimer invalidate];
    dotTimer = nil;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    BPLog(@"+++++++");
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
}

static BPCheckUpdateWaitView *updateWaitView;


+ (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //普通更新提示
    if(alertView.tag == 11000)
    {
        if(alertView.cancelButtonIndex != buttonIndex)
        {
            [[BigPlayerSDKBase getSharedBPPlatform] gotoDownloadGame];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:BPInitDidFinishedNotification object:nil userInfo:nil];
        [BigPlayerSDKBase getSharedBPPlatform].BPHasInitFinish = YES;
    }
    //强制更新提示
    else if(alertView.tag == 11001)
    {
        [[BigPlayerSDKBase getSharedBPPlatform] gotoDownloadGame];
        exit(0);
    }
}


@end
