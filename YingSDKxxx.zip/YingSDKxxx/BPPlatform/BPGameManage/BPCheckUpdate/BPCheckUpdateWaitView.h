//
//  BPCheckUpdateWaitView.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-9-11.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPLoginPublic.h"


@interface BPCheckUpdateWaitView : UIView
{
    NSTimer *dotTimer;
    int currentLocation;
}

@property (nonatomic,assign) int loopNum;






@end
