//
//  BPGameRoleInfo.h
//  BigPlayerSDK
//

//

#import <Foundation/Foundation.h>

@interface BPGameRoleInfo : NSObject
{
    
}


@property(nonatomic,strong)NSString *roleID;
@property(nonatomic,strong)NSString *roleLevel;
@property(nonatomic,strong)NSString *roleName;
@property(nonatomic,strong)NSString *serverID;
@property(nonatomic,strong)NSString *serverName;
@property(nonatomic,strong)NSString *opType; //类型: 2-创建角色,3-等级提升

@end
