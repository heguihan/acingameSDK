//
//  BPGameRoleInfo.m
//  BigPlayerSDK
//

//

#import "BPGameRoleInfo.h"

@implementation BPGameRoleInfo

@end
