//
//  BPExperiencePublic.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-8-8.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BPExperiencePublic : NSObject
//计算经验条的值
+(NSMutableDictionary *) getExprienceWidth:(NSMutableDictionary*)userInfoDic;
//将等级升级表保存到数据库
+(void) saveExperienceInfoToTable:(NSMutableArray *)exp_array;
@end
