//
//  SUNButtonBoard.h
//  ButtonBoardTest
//
//  Created by 孙 化育 on 13-8-28.
//  Copyright (c) 2016年 孙 化育. All rights reserved.
//

#import <Foundation/Foundation.h>



@protocol BPButtonBoardDelegate <NSObject>

@optional

- (void)buttonBoardWillOpen;
- (void)buttonBoardDidOpen;
- (void)buttonBoardWillClose;
- (void)buttonBoardDidClose;

    //某个按钮被点击时回调，参数为buttonIndex
- (void)buttonBoardClickButtonAtIndex:(int)index;


@end

@class BoardView;

@interface BPButtonBoard : NSObject<UIGestureRecognizerDelegate>{
//    UIWindow        *_boardWindow;
    UIView        *_boardWindow;
    BOOL            _running;
    BoardView       *_boardView;
//    CGRect          _boardRect;
    CGRect          _boardViewRect;
    NSMutableArray  *_buttonArray;
    NSMutableArray  *_buttonPositionArray;
    BOOL            _animating;
    BOOL            _movedWithKeyboard;
    
    UIInterfaceOrientation currentOrientation;
    BOOL showSecondTime;
    
    UIView *expandImageBg;
    
    BOOL showMessagePromptDot;
}

//使用单例类，方便在全局控制, 显示悬浮球
+ (BPButtonBoard *)showDefaultButtonBoardWithPosition:(int)x Position_Y:(int)y;
//隐藏悬浮球
+(void) hideDefaultButtonBoard;
+(void) hideDefaultButtonBoardAndClose;

//设置悬浮球的初始位置
//+(void) setButtonBoardPosition:(int)x Position_Y:(int)y;


//@property (nonatomic,retain)UIView        *_boardWindow;

    //虽然提供了delegate，但是ButtonBoard不是针对某个界面的，全局性太大，所以还是建议用notification
@property (nonatomic,assign) id<BPButtonBoardDelegate> delegate;


    //按钮的个数
@property (nonatomic,assign)int     buttonNumber;


    //按钮板的背景图
//@property (nonatomic,assign)UIImage *boardImage;


    //按钮图片的数组，按顺序提供每个按钮的图片，请保证数组里都是UIImage
//@property (nonatomic,retain)NSArray *buttonImageArray;


    //按钮标题的数组，提供每个按钮的标题，实际作用不大，因为按钮太小，加了文字就不好看了；
//@property (nonatomic,retain)NSArray *buttonTitleArray;


    //按钮板的尺寸，建议设置在30到60之间，默认为50
@property (nonatomic,assign)float boardSize;


    //是否自动定位到屏幕边缘，默认为YES
@property (nonatomic,assign)BOOL    autoPosition;


    //是否正在显示
@property (nonatomic,readonly)BOOL    running;


    //是否处于打开状态
@property (nonatomic,readonly)BOOL      isOpen;


    //当前在屏幕的位置frame
@property (nonatomic,readonly)CGRect    currentFrame;


    //开始显示
- (void)startRunning;


    //停止显示
- (void)stopRunning;


    //设置按钮板位置,point指的是center
- (void)setBoardPosition:(CGPoint)point animate:(BOOL)animate;

- (void)boardClose;

@end



    //所有的通知

extern NSString *const SUNButtonBoardWillOpenNotification;

extern NSString *const SUNButtonBoardDidOpenNotification;

extern NSString *const SUNButtonBoardWillCloseNotification;

extern NSString *const SUNButtonBoarDidCloseNotification;


    //notification附带的object是NSNumber，就是所点击button的index
extern NSString *const SUNButtonBoarButtonClickNotification;


//-------------------------------------------------------------------------//

@interface MyBoardButton : UIButton
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
@end

//-------------------------------------------------------------------------//
@interface BoardView : UIView{
    CGPoint     _beginPoint;
    CGPoint     _endPoint;
    CGPoint     _selfBeginCenter;
    int         _direction;
    
    MyBoardButton *boardButton;
    
//    CGRect touchBegin; //down的时候，鼠标位置
//    CGRect touchEnd; //up的时候，鼠标位置
}

@property (nonatomic,assign)BPButtonBoard *selfBoard;
@property (nonatomic,readonly)BOOL moving;
@property (nonatomic,retain)UIImageView *backgroundImageView;
@property (nonatomic,assign) MyBoardButton *boardButton;

- (int)directByPoint:(CGPoint)point;
//- (int)directByPoint_open:(CGPoint)point;
@end








