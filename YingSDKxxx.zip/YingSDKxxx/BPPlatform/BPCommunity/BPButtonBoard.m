//
//  SUNButtonBoard.m
//  ButtonBoardTest
//
//  Created by 孙 化育 on 13-8-28.
//  Copyright (c) 2016年 孙 化育. All rights reserved.
//

#import "BPButtonBoard.h"
#import "BigPlayerSDKBase.h"
#import "ShuEnter.h"
#import "BPPublicHandle.h"

#define POST_NOTIFICATION(X) [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:X object:nil]];

#define TRY_TO_PERFORM(X) if ([_delegate wocaolecao:@selector(X)]) {[_delegate X];}

#define ExpandButtonWidth (BPDevice_is_ipad?70:58)
#define ExpandButtonHeight (BPDevice_is_ipad?70:58)
#define ExpandButtonWidth_Small (ExpandButtonWidth - 20)
#define ExpandButtonHeight_Small (ExpandButtonWidth - 20)
#define kDCCovertAngelToRadian(x) ((x)*M_PI)/180
static BPButtonBoard *__board = nil;
static int buttonBoard_x;
static int buttonBoard_y;
int screen_w;// = SCREEN_WIDTH;
int screen_h;// = SCREEN_HEIGHT;

NSString *const SUNButtonBoardWillOpenNotification = @"SUNButtonBoardWillOpenNotification";

NSString *const SUNButtonBoardDidOpenNotification = @"SUNButtonBoardDidOpenNotification";

NSString *const SUNButtonBoardWillCloseNotification = @"SUNButtonBoardWillCloseNotification";

NSString *const SUNButtonBoarDidCloseNotification = @"SUNButtonBoarDidCloseNotification";

NSString *const SUNButtonBoarButtonClickNotification = @"SUNButtonBoarButtonClickNotification";

@interface BPButtonBoard()

@property (nonatomic,assign)BOOL  animating;
@property (nonatomic,assign)BOOL  movedWithKeyboard;
@end


@implementation BPButtonBoard
@synthesize running = _running;
@synthesize animating = _animating;
@synthesize movedWithKeyboard = _movedWithKeyboard;
//@synthesize _boardWindow;


- (void)dealloc
{
    [_boardView removeFromSuperview];
    [_boardWindow removeFromSuperview];      [_buttonArray release];
    [_buttonPositionArray release];
    [expandImageBg release];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

//显示功能球，设定位置坐标
+ (BPButtonBoard *)showDefaultButtonBoardWithPosition:(int)x Position_Y:(int)y{
    @synchronized(__board)
    {
#ifdef ShuZhiZhangSDK_MiNi
#else
#endif
        if([[ShuZhiZhangUserPreferences CurrentUserID] intValue] <= 0)
        {
            return nil;
        }
        if(__board == nil)
        {
            __board =[[BPButtonBoard alloc] init];
            __board.buttonNumber = 5;
        }

        //hghdelayqqqqqqqqqqqq
        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self showButtonBoardAfterDelay];
        });
        
        if(x>=0)
        {
            buttonBoard_x = x;
        }
        if(y>=0)
        {
            buttonBoard_y = y;
        }
        if(x>=0||y>=0)
        [__board setbuttonBoardPossition];
        return __board;
    }
}

+(void) showButtonBoardAfterDelay
{
    if (!__board.running) {
        [__board startRunning];
    }
}

//隐藏功能球
+(void) hideDefaultButtonBoard
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showButtonBoardAfterDelay) object:nil];
    if (__board.running) {
        [__board stopRunning];
    }
    [__board boardClose];
}

+(void) hideDefaultButtonBoardAndClose
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showButtonBoardAfterDelay) object:nil];
    if (__board.running) {
        [__board stopRunning];
    }
    [__board boardClose];
}

- (id)init{
    self = [super init];
    if (self) {
        screen_w = SCREEN_WIDTH;
        screen_h = SCREEN_HEIGHT;
        if(BPDevice_is_ipad)
        {
            if(SCREEN_IS_LANDSCAPE)
            {
                screen_w = 1024;
                screen_h = 768;
            }
            else
            {
                screen_w = 768;
                screen_h = 1024;
            }
        }
        self.autoPosition = YES;
        _boardSize = ExpandButtonWidth;
        
        _boardWindow = [[UIView alloc] initWithFrame:CGRectMake(buttonBoard_x,buttonBoard_y, ExpandButtonWidth_Small, ExpandButtonHeight_Small)];
        _boardWindow.backgroundColor = [UIColor clearColor];

        _boardWindow.clipsToBounds = NO;

        _boardWindow.hidden = YES;
        UIWindow* window = nil;//[UIApplication sharedApplication].keyWindow;
        if (!window)
        {
            window = [[UIApplication sharedApplication].windows objectAtIndex:0];
        }
        [window addSubview:_boardWindow]; //.rootViewController.view
        
        [self showBackgroundViews];
        
        _boardView = [[BoardView alloc] initWithFrame:CGRectMake(0, 0, ExpandButtonWidth_Small, ExpandButtonHeight_Small)];
        _boardView.backgroundColor = [UIColor clearColor];
        _boardView.selfBoard = self;
        _boardView.backgroundImageView.frame = CGRectMake(0, 0, ExpandButtonWidth_Small, ExpandButtonHeight_Small);
        _boardView.backgroundImageView.backgroundColor = [UIColor clearColor];
        _boardView.autoresizingMask = UIViewAutoresizingNone;
        
        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesHundel:)];
        [_boardView addGestureRecognizer:gesture];
        gesture.delegate = self;
        [gesture release];
        
        _boardView.userInteractionEnabled = YES;
        [_boardWindow addSubview:_boardView];
        [_boardView release];
        
        _buttonArray = [[NSMutableArray alloc] init];
        _buttonPositionArray = [[NSMutableArray alloc] init];
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(HasGotMessage) name:BPHasGotMessageNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NoMessageHidePrompt) name:BPNoMessageHidePromptNotification object:nil];
        [[BPPublicHandle sharedPublicHandle] showMessageTag];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(changeFrames:)
                                                     name:UIDeviceOrientationDidChangeNotification
                                                   object:nil];

        [self setbuttonBoardPossition];
        
        if([UIApplication sharedApplication].statusBarOrientation != UIInterfaceOrientationPortrait)
        {
            [self changeBrowerToOrientation:[UIApplication sharedApplication].statusBarOrientation];
        }
        
    }
    return self;
}


-(void) showBackgroundViews
{
    expandImageBg = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_w, screen_h)];
    expandImageBg.hidden = YES;
    [_boardWindow addSubview:expandImageBg];
    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_w, screen_h)];
    [expandImageBg addSubview:backView];
    backView.backgroundColor = [UIColor blackColor];
    backView.alpha = 0.5;
    [backView release];
    
    UIImageView *imageBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_widget_icon_bg.png"]];
    imageBg.frame = CGRectMake((screen_w-172)/2, (screen_h-172)/2, 172, 172);
    if(BPDevice_is_ipad)
        imageBg.frame = CGRectMake((screen_w-244)/2, (screen_h-244)/2, 244, 244);
    imageBg.tag = 1233215;
    [expandImageBg addSubview:imageBg];
    imageBg.alpha = 0.0f;
    [imageBg release];
}


-(void) setbuttonBoardPossition
{
    int x=buttonBoard_x,y=buttonBoard_y;
    if(!BP_IS_OS_8_OR_LATER)
    {
        if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeRight)
        {
            y = buttonBoard_x;
            x = screen_h - buttonBoard_y- ExpandButtonHeight_Small;
        }
        else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeLeft)
        {
            y =screen_w - buttonBoard_x- ExpandButtonWidth_Small;
            x =buttonBoard_y;
        }
        else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)
        {
            x =screen_w - buttonBoard_x - ExpandButtonWidth_Small;
            y = screen_h - buttonBoard_y- ExpandButtonHeight_Small;
        }
    }
    int direction = [_boardView directByPoint:CGPointMake(x, y)];
    CGRect newRect;
    switch (direction) {
        case 0:
            newRect = CGRectMake(x,
                                 0,
                                 ExpandButtonWidth_Small,
                                 ExpandButtonHeight_Small);
            break;
        case 1:
            newRect = CGRectMake([[UIScreen mainScreen] bounds].size.width - ExpandButtonWidth_Small,
                                 y,
                                 ExpandButtonWidth_Small,
                                 ExpandButtonHeight_Small);
            break;
        case 2:
            newRect = CGRectMake(x,
                                 [[UIScreen mainScreen] bounds].size.height - ExpandButtonHeight_Small,
                                 ExpandButtonWidth_Small,
                                 ExpandButtonHeight_Small);
            break;
        case 3:
        {
            newRect = CGRectMake(0,
                                 y,
                                 ExpandButtonWidth_Small,
                                 ExpandButtonHeight_Small);
        }
            break;
            
        default:
            break;
    }
    _boardWindow.frame = newRect;
}

#pragma mark ----红点
//显示红点
-(void) HasGotMessage
{
        showMessagePromptDot = YES;
    
    if(_isOpen && _buttonArray.count>4)
    {
        UIButton *button = [_buttonArray objectAtIndex:4];
        UIImageView *promptDot = (UIImageView *)[button viewWithTag:32103];
        if(!promptDot)
        {
            promptDot = [[UIImageView alloc] initWithFrame:CGRectMake(36, 3, 8, 9)];
            [button addSubview:promptDot];
            promptDot.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/PB_news_prompt_dot.png"];
            promptDot.tag = 32103;
            [promptDot release];
        }
    }
    else
    {
        UIImageView *promptDot = (UIImageView *)[_boardView viewWithTag:32102];
        if(!promptDot)
        {
            promptDot = [[UIImageView alloc] initWithFrame:CGRectMake(36, 3, 8, 9)];
            [_boardView addSubview:promptDot];
            promptDot.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/PB_news_prompt_dot.png"];
            promptDot.tag = 32102;
            [promptDot release];
        }
    }
}
//隐藏红点
-(void) NoMessageHidePrompt
{
    UIImageView *promptDot = (UIImageView *)[_boardView viewWithTag:32102];
    [promptDot removeFromSuperview];
    showMessagePromptDot = NO;
    
    if(_isOpen && _buttonArray.count>4)
    {
        UIButton *button = [_buttonArray objectAtIndex:4];
        UIImageView *promptDot = (UIImageView *)[button viewWithTag:32103];
        [promptDot removeFromSuperview];
    }
}

- (void)startRunning{
    if (_running) {
        return;
    }
    _boardWindow.hidden = NO;
    _running = YES;
}

- (void)stopRunning{
    if (!_running) {
        return;
    }
    
    _boardWindow.hidden = YES;
    _running = NO;
}

- (void)setBoardImage:(UIImage *)boardImage{
    _boardView.backgroundImageView.image = boardImage;
}

- (UIImage *)boardImage{
    return _boardView.backgroundImageView.image;
}

- (void)setBoardSize:(float)boardSize{
    if (_isOpen) {
        return;
    }
    _boardSize = boardSize;
    _boardWindow.frame = CGRectMake(_boardWindow.frame.origin.x,
                                    _boardWindow.frame.origin.y,
                                    boardSize,
                                    boardSize);
    _boardView.frame = CGRectMake(_boardView.frame.origin.x,
                                  _boardView.frame.origin.y,
                                  boardSize,
                                  boardSize);
}

- (CGRect)currentFrame{
    if (_isOpen) {
        return _boardView.frame;
    }else{
        return _boardWindow.frame;
    }
    
}

- (void)setBoardPosition:(CGPoint)point animate:(BOOL)animate{
    if (_isOpen) {
        return;
    }
    if (animate) {
        [UIView animateWithDuration:0.3 animations:^{
            _boardWindow.center = point;
        }];
    }else{
        _boardWindow.center = point;
    }
}


#pragma mark- gesture
- (void)tapGesHundel:(UITapGestureRecognizer *)gesture{
    if (_animating) {
        return;
    }
    if (!_isOpen) {
        [self boardOpen];
    }else{
        [self boardClose];
    }
}

- (void)windowTaped:(UITapGestureRecognizer *)gesture{
    if (_animating) {
        return;
    }else{
        
    }
    
    if (_isOpen) {
        [self boardClose];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass:[UIButton class]])
    {
        return NO;
    }
    return YES;
}

#pragma mark- button
//点击功能球上的按钮
- (void)buttonAction:(UIButton *)sender{

    switch (sender.tag - 100) {
        case 0:
        {
            NSString *str = [[NSUserDefaults standardUserDefaults ] objectForKey:@"BP_ButtonBoard_nav_me"];
            if(str && [str intValue]<0)
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
            
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] duration:2.0];

            }
            else
            {
               //  [ShuEnter BPAccessAccountManager];
            }
        }
            break;
        case 1:
        {

            NSString *str = [[NSUserDefaults standardUserDefaults ] objectForKey:@"BP_ButtonBoard_nav_bbs"];
            if(str && [str intValue]<0)
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
                
                 [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] duration:1.0];
            }
            else
            {
           //     [ShuEnter BPAccessForum];
            }
        }
            break;
        case 2:
        {
        //    [ShuEnter BPAccessExperience];
        }
            break;
        case 3:
        {
            NSString *str = [[NSUserDefaults standardUserDefaults ] objectForKey:@"BP_ButtonBoard_nav_raiders"];
            if(str && [str intValue]<0)
            {
               //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
                
                  [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] duration:1.0];
            }
            else
            {
        //        [ShuEnter BPAccessStrategy];
            }
        }
            break;
        case 4:
        {
            NSString *str = [[NSUserDefaults standardUserDefaults ] objectForKey:@"BP_ButtonBoard_nav_msg"];
            if(str && [str intValue]<0)
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
                
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPNotComplete" InTable:@"BPMultiLanguage"] duration:1.0];

                
            }
            else
            {
     
       //         [ShuEnter BPAccessMessageCenter];
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark- method
//展开功能球
- (void)boardOpen{
    _animating = YES;
    _boardView.frame = _boardWindow.frame;
    _boardWindow.frame = [UIScreen mainScreen].bounds;
    expandImageBg.hidden = NO;
    
    if(!BP_IS_OS_8_OR_LATER)
    {
        if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)
        {
            CGRect frame = _boardView.frame;
            frame.origin.x = screen_w - frame.origin.x-ExpandButtonWidth_Small;
            frame.origin.y = screen_h - frame.origin.y-ExpandButtonHeight_Small;
            _boardView.frame = frame;
        }
        else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeRight)
        {
            CGRect frame = _boardView.frame;
            int x = frame.origin.x;
            frame.origin.x = frame.origin.y;//screen_h - frame.origin.y-ExpandButtonWidth;
            frame.origin.y = screen_h- x-ExpandButtonHeight_Small;
            _boardView.frame = frame;
        }
        else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeLeft)
        {
            CGRect frame = _boardView.frame;
            int y = frame.origin.y;
            frame.origin.y = frame.origin.x;//screen_h - frame.origin.y-ExpandButtonWidth;
            frame.origin.x = screen_w- y-ExpandButtonHeight_Small;
            _boardView.frame = frame;
        }
    }
    
    
    _boardViewRect = _boardView.frame;
    NSArray *imageArray = [NSArray arrayWithObjects:@"BPButtonBoard.bundle/BP_widget_icon_account.png",@"BPButtonBoard.bundle/BP_widget_icon_forum.png",@"BPButtonBoard.bundle/BP_widget_icon_message.png",@"BPButtonBoard.bundle/BP_widget_icon_strategy.png",@"BPButtonBoard.bundle/BP_widget_icon_service.png", nil];
    NSArray *imageSelArray = [NSArray arrayWithObjects:@"BPButtonBoard.bundle/BP_widget_icon_account_sel.png",@"BPButtonBoard.bundle/BP_widget_icon_forum_sel.png",@"BPButtonBoard.bundle/BP_widget_icon_message_sel.png",@"BPButtonBoard.bundle/BP_widget_icon_strategy_sel.png",@"BPButtonBoard.bundle/BP_widget_icon_service_sel.png", nil];
    float angel = 360/self.buttonNumber;
    for (int i = 0; i < self.buttonNumber; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:_boardView.frame];
        button.adjustsImageWhenHighlighted = NO;
        button.titleEdgeInsets = UIEdgeInsetsMake(20, 0, 0, 0);
        [button setBackgroundImage:[UIImage imageNamed:[imageArray objectAtIndex:i]] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:[imageSelArray objectAtIndex:i]] forState:UIControlStateHighlighted];
        button.titleLabel.font = [UIFont systemFontOfSize:12];
        if(BPDevice_is_ipad)
            button.frame = CGRectMake(-100, -100, 66, 66);
        else
        button.frame = CGRectMake(-100, -100, 50, 50);
        [_boardWindow addSubview:button];

        [_buttonArray addObject:button];
        button.backgroundColor = [UIColor clearColor];
        button.tag = i+100;
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        if(i==4 && showMessagePromptDot)
        {
            UIImageView *promptDot = (UIImageView *)[button viewWithTag:32103];
            if(!promptDot)
            {
                promptDot = [[UIImageView alloc] initWithFrame:CGRectMake(36, 3, 8, 9)];
                [button addSubview:promptDot];
                promptDot.tag = 32103;
                promptDot.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/PB_news_prompt_dot.png"];
                [promptDot release];
            }
            promptDot = (UIImageView *)[_boardView viewWithTag:32102];
            [promptDot removeFromSuperview];
        }
        [button release];
        CGPoint point = CGPointMake(
                                    (screen_w)/2 + 80 * sinf(kDCCovertAngelToRadian(i*angel+180)),
                                    (screen_h)/2 + 80 * cosf(kDCCovertAngelToRadian(i*angel+180)));
        if(BPDevice_is_ipad)
            point = CGPointMake(
                                (screen_w)/2 + 120 * sinf(kDCCovertAngelToRadian(i*angel+180)),
                                (screen_h)/2 + 120 * cosf(kDCCovertAngelToRadian(i*angel+180)));
        [_buttonPositionArray addObject:[NSValue valueWithCGPoint:point]];
    }
    [UIView animateWithDuration:0.3
                     animations:^{
                         CGRect frame = _boardView.frame;
                         frame.origin.x = (screen_w- ExpandButtonWidth)/2;
                         frame.origin.y = (screen_h- ExpandButtonHeight)/2;
                         _boardView.frame = frame;
                         
                         frame = _boardView.boardButton.frame;
                         frame.size.height=ExpandButtonWidth;
                         frame.size.width=ExpandButtonHeight;
                         _boardView.boardButton.frame = frame;
                     }
                     completion:^(BOOL finished) {
                         _animating = NO;
                         _isOpen = YES;
                         UITapGestureRecognizer *windowTapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(windowTaped:)];
                         [_boardWindow addGestureRecognizer:windowTapGes];
                         windowTapGes.delegate = self;
                         [windowTapGes release];
                         for(int i=0;i<self.buttonNumber;i++)
                         {
                             [self button:[_buttonArray objectAtIndex:i] appearAt:[[_buttonPositionArray objectAtIndex:i] CGPointValue] withDalay:0.3*i duration:0.3];
                         }
                         
                         UIImageView *imageBg = (UIImageView *)[expandImageBg viewWithTag:1233215];
                         [UIView animateWithDuration:0.3
                                          animations:^{
                                              imageBg.alpha = 1.0f;
                                          }
                                          completion:^(BOOL finished) {
                                              
                                          }];
                     }];
}

-(void) boardCloseAfterDelay
{
    for (int i = 0; i<_buttonArray.count; i++){
        UIButton *button = [_buttonArray objectAtIndex:i];
        [button removeFromSuperview];
    }
    expandImageBg.hidden = YES;
    UIImageView *imageBg = (UIImageView *)[expandImageBg viewWithTag:1233215];
    imageBg.frame = CGRectMake((screen_w-172)/2, (screen_h-172)/2, 172, 172);
    if(BPDevice_is_ipad)
        imageBg.frame = CGRectMake((screen_w-244)/2, (screen_h-244)/2, 244, 244);
    imageBg.alpha = 0.0f;
    if(showMessagePromptDot)
    {
        UIImageView *promptDot = (UIImageView *)[_boardView viewWithTag:32102];
        if(!promptDot)
        {
            UIImageView *promptDot = [[UIImageView alloc] initWithFrame:CGRectMake(36, 3, 8, 9)];
            [_boardView addSubview:promptDot];
            promptDot.tag = 32102;
            promptDot.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/PB_news_prompt_dot.png"];
            [promptDot release];
        }
    }
    
    [_buttonArray removeAllObjects];
    [UIView animateWithDuration:0.3
                     animations:^{
                         _boardView.frame = _boardViewRect;
                         CGRect frame = _boardView.boardButton.frame;
                         frame.size.height=ExpandButtonWidth_Small;
                         frame.size.width=ExpandButtonHeight_Small;
                         _boardView.boardButton.frame = frame;
                     }
                     completion:^(BOOL finished) {
                         _animating = NO;
                         _isOpen = NO;
                         
                         if(!BP_IS_OS_8_OR_LATER)
                         {
                             if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)
                             {
                                 CGRect frame = _boardView.frame;
                                 frame.origin.x = screen_w - frame.origin.x-ExpandButtonWidth_Small;
                                 frame.origin.y = screen_h - frame.origin.y-ExpandButtonHeight_Small;
                                 _boardWindow.frame = frame;
                             }
                             else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeRight)
                             {
                                 CGRect frame = _boardView.frame;
                                 int x = frame.origin.x;
                                 frame.origin.x = screen_h- frame.origin.y-ExpandButtonWidth_Small;
                                 frame.origin.y = x;
                                 _boardWindow.frame = frame;
                             }
                             else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeLeft)
                             {
                                 CGRect frame = _boardView.frame;
                                 int y = frame.origin.y;
                                 frame.origin.y = screen_w - frame.origin.x-ExpandButtonWidth_Small;
                                 frame.origin.x = y;
                                 _boardWindow.frame = frame;
                             }
                             else
                             {
                                 _boardWindow.frame = _boardView.frame;
                             }
                         }
                         else
                         {
                             _boardWindow.frame = _boardView.frame;
                         }
                         _boardView.frame = CGRectMake(0, 0, _boardSize, _boardSize);
                         [_boardWindow removeGestureRecognizer:[[_boardWindow gestureRecognizers] lastObject]];
                     }];
}


- (void)boardClose{
    if(!_isOpen)
    {
        return;
    }
    _animating = YES;
    for (int i = 0; i<_buttonArray.count; i++){
        [self button:[_buttonArray objectAtIndex:i]
            shrinkAt:[[_buttonPositionArray objectAtIndex:i] CGPointValue]
         offsetAxisX:0//-20.0f
         offSEtAxisY:[self offsetAxisY:0.0f withAngel:180.0/self.buttonNumber]//-20.0f
           withDelay:0.5
     rotateDirection:1 animationDuration:1];
    }
    [self centerButtonAnimation];
    
    UIImageView *imageBg = (UIImageView *)[expandImageBg viewWithTag:1233215];
    [UIView animateWithDuration:0.6
                     animations:^{
                         imageBg.frame = CGRectMake(screen_w/2, screen_h/2, 0, 0);
                     }
                     completion:^(BOOL finished) {
                         
                     }];

    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 0.5*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self boardCloseAfterDelay];
    });
}



- (void)keyboardFrameWillChange:(NSNotification *)noti{
    NSValue *value = [noti.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect rect = [value CGRectValue];
    float yPoint = rect.origin.y;
    
    CGRect newRect;
    
    if (yPoint == [ShuZhiZhangUtility myScreenBounds].size.height) {
        if (_movedWithKeyboard) {
            newRect = CGRectMake(_boardWindow.frame.origin.x,
                                 yPoint - _boardWindow.frame.size.height,
                                 _boardWindow.frame.size.width,
                                 _boardWindow.frame.size.height);
            _movedWithKeyboard = NO;
            [UIView animateWithDuration:0.3
                             animations:^{
                                 _boardWindow.frame = newRect;
                             }
                             completion:^(BOOL finished) {
                                 
                             }];
        }
    }else{
        if (_boardWindow.frame.origin.y > yPoint) {
            newRect = CGRectMake(_boardWindow.frame.origin.x,
                                 yPoint - _boardWindow.frame.size.height,
                                 _boardWindow.frame.size.width,
                                 _boardWindow.frame.size.height);
            _movedWithKeyboard = YES;
            [UIView animateWithDuration:0.3
                             animations:^{
                                 _boardWindow.frame = newRect;
                             }
                             completion:^(BOOL finished) {
                                 
                             }];
        }
    }
    
}


- (void)centerButtonAnimation{
    CAKeyframeAnimation *centerZoom = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    centerZoom.duration = 0.5f;
    centerZoom.values = @[[NSValue valueWithCATransform3D:CATransform3DMakeScale(1, 1, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.5, 1.5, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1, 1, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1, 1, 1)]];
    centerZoom.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [_boardView.layer addAnimation:centerZoom forKey:@"buttonScale"];
}

#pragma mark ------------change frame
-(BOOL) checkCanRation:(UIInterfaceOrientation) orientation
{
    if(currentOrientation == orientation)
    {
        return NO;
    }
    switch ([BigPlayerSDKBase getSharedBPPlatform].bpOrientation)
    {
        case BPInterfaceOrientationProtraitDown:
            if(!orientation == UIInterfaceOrientationMaskPortrait)
            {
                return NO;
            }
            break;
        case BPInterfaceOrientationProtraitUp:
            if(!orientation == UIInterfaceOrientationPortraitUpsideDown)
            {
                return NO;
            }
            break;
        case BPInterfaceOrientationLandscapeLeft:
            if(!orientation == UIInterfaceOrientationLandscapeLeft)
            {
                return NO;
            }
            break;
        case BPInterfaceOrientationLandscapeRight:
            if(!orientation == UIInterfaceOrientationLandscapeRight)
            {
                return NO;
            }
            break;
        case BPInterfaceOrientationProtrait:
            if(UIDeviceOrientationIsLandscape(orientation))
            {
                return NO;
            }
            break;
        case BPInterfaceOrientationLandscape:
            if(!UIDeviceOrientationIsLandscape(orientation))
            {
                return NO;
            }
            break;
        default:
            break;
    }
    return YES;
}

//屏幕翻转操作
-(void) changeBrowerToOrientation:(UIInterfaceOrientation) orientation
{
    if(BP_IS_OS_8_OR_LATER)
    {
        return;
    }
    if(![self checkCanRation:orientation])
    {
        return;
    }
    CGAffineTransform rotation;
    switch (orientation)
    {
        case UIInterfaceOrientationPortrait:
            rotation = CGAffineTransformIdentity;
            break;
        case UIInterfaceOrientationPortraitUpsideDown:
            rotation = CGAffineTransformMakeRotation(M_PI);
            break;
            
        case UIInterfaceOrientationLandscapeRight:
            rotation = CGAffineTransformMakeRotation(M_PI_2);
            break;
        case UIInterfaceOrientationLandscapeLeft:
            rotation = CGAffineTransformMakeRotation(-M_PI_2);
            break;
        default:
            return;
            break;
    }
    
    if(showSecondTime)
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.6];
        [_boardWindow setTransform:rotation];
        CGRect frame = _boardWindow.frame;
        if(SCREEN_IS_LANDSCAPE)
        {
            frame.origin.x = screen_h - frame.origin.x - _boardWindow.frame.size.width;//-ExpandButtonWidth;
            frame.origin.y = screen_w - frame.origin.y- _boardWindow.frame.size.height;//-ExpandButtonHeight;
        }
        else
        {
            frame.origin.x = screen_w - frame.origin.x - _boardWindow.frame.size.width;//-ExpandButtonWidth;
            frame.origin.y = screen_h - frame.origin.y- _boardWindow.frame.size.height;//-ExpandButtonHeight;
        }
        _boardWindow.frame = frame;
        [UIView commitAnimations];
    }
    else
    {
        [_boardWindow setTransform:rotation];
    }
    
    showSecondTime = YES;
    
    currentOrientation = orientation;
}
-(void) changeFrames:(NSNotification *)notification
{
    if(BP_IS_OS_8_OR_LATER)
    {
        return;
    }
    [self changeBrowerToOrientation:(UIInterfaceOrientation)[[UIDevice currentDevice] orientation]];
}

- (void)button:(UIButton *)button appearAt:(CGPoint)location withDalay:(CGFloat)delay duration:(CGFloat)duration{
    button.center = location;
    CAKeyframeAnimation *scaleAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    scaleAnimation.duration = duration;
    scaleAnimation.values = @[[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.3, 1.3, 1)],[NSValue valueWithCATransform3D:CATransform3DMakeScale(1, 1, 1)]];
    scaleAnimation.calculationMode = kCAAnimationLinear;
    scaleAnimation.keyTimes = @[[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:delay],[NSNumber numberWithFloat:1.0f]];
    button.layer.anchorPoint = CGPointMake(0.5f, 0.5f);
    [button.layer addAnimation:scaleAnimation forKey:@"buttonAppear"];
}

- (CGFloat)matchRotationOrientation:(int)orientation{
    if (orientation == 0) {
        return M_PI;//*2
    }
    return -M_PI;
}

- (CGFloat)offsetAxisY:(CGFloat)axisX withAngel:(CGFloat)angel{
    return (axisX / tanf(kDCCovertAngelToRadian(angel)));
}

- (void)button:(UIButton *)button shrinkAt:(CGPoint)location offsetAxisX:(CGFloat)axisX offSEtAxisY:(CGFloat)axisY withDelay:(CGFloat)delay rotateDirection:(int)orientation animationDuration:(CGFloat)duration{
    CAKeyframeAnimation *rotation = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotation.duration = duration * delay;
    rotation.values = @[[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:[self matchRotationOrientation:orientation]],[NSNumber numberWithFloat:0.0f]];
    rotation.keyTimes = @[[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:delay],[NSNumber numberWithFloat:1.0f]];
    
    CAKeyframeAnimation *shrink = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    shrink.duration = duration * (1 - delay);
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, location.x, location.y);
    CGPathAddLineToPoint(path, NULL, location.x + axisX, location.y + axisY);
    CGPathAddLineToPoint(path, NULL, screen_w/2, screen_h/2);
    shrink.path = path;
    
    CGPathRelease(path);
    
    CAAnimationGroup *totalAnimation = [CAAnimationGroup animation];
    totalAnimation.duration = 1.0f;
    totalAnimation.animations = @[rotation,shrink];
    totalAnimation.fillMode = kCAFillModeForwards;
    totalAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    totalAnimation.delegate = self;
    
    button.layer.anchorPoint = CGPointMake(0.5f, 0.5f);
    button.center = CGPointMake(-screen_w/2, -screen_h/2);
    [button.layer addAnimation:totalAnimation forKey:@"buttonDismiss"];
}
@end

//-------------------------------------------------------------------------//
@implementation MyBoardButton
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesBegan:touches withEvent:event];
    [super touchesBegan:touches withEvent:event];
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesMoved:touches withEvent:event];
    [super touchesMoved:touches withEvent:event];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesEnded:touches withEvent:event];
    [super touchesEnded:touches withEvent:event];
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesCancelled:touches withEvent:event];
    [super touchesCancelled:touches withEvent:event];
}
@end
//-------------------------------------------------------------------------//


@implementation BoardView
@synthesize boardButton;

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        boardButton = [MyBoardButton buttonWithType:UIButtonTypeCustom];
        boardButton.frame = CGRectMake(0, 0, ExpandButtonWidth_Small, ExpandButtonWidth_Small);
        [boardButton setImage:[UIImage imageNamed:@"BPButtonBoard.bundle/BP_pendant_switcher.png"] forState:UIControlStateNormal];
        [boardButton setImage:[UIImage imageNamed:@"BPButtonBoard.bundle/BP_pendant_switcher.png"] forState:UIControlStateHighlighted];
        [boardButton addTarget:self action:@selector(clickBoardButton) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:boardButton];
    }
    return self;
}


-(void) clickBoardButton
{
    CGRect frame = self.frame;
    frame = self.superview.frame;
    if(fabsf(_beginPoint.x - _endPoint.x)<3 && fabsf(_beginPoint.y - _endPoint.y)<3)
    [self.selfBoard tapGesHundel:nil];
}

- (void)dealloc{
    self.backgroundImageView = nil;
    [super dealloc];
}

- (void)setFrame:(CGRect)frame{
    [super setFrame:frame];
    _backgroundImageView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    if (_selfBoard.animating) {
        return;
    }

    UITouch *touch = [touches anyObject];
    _beginPoint = [touch locationInView:self.superview];
    _endPoint = _beginPoint;
    _selfBeginCenter = self.center;
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    if (_selfBoard.animating) {
        return;
    }
    if (_selfBoard.isOpen) {
        return;
    }
    _moving = YES;
    UITapGestureRecognizer *ges = [self.gestureRecognizers lastObject];
    ges.enabled = NO;
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.superview];

    self.center = CGPointMake(_selfBeginCenter.x+(point.x - _beginPoint.x),
                              _selfBeginCenter.y+(point.y - _beginPoint.y));
    
    UITouch *previousTouch = [touches anyObject];
    CGPoint previousPoint = [previousTouch previousLocationInView:self.superview];
    
    _direction = -1;
    return;
    int velocity = [self velocityByPoint:point andPoint:previousPoint];
    if (abs(velocity) > 15) {
        int velocityX = point.x - previousPoint.x;
        int velocityY = point.y - previousPoint.y;
        if (abs(velocityX) > abs(velocityY)) {
            if (velocity>0) {
                _direction = 1;
            }else{
                _direction = 3;
            }
        }else{
            if (velocity>0) {
                _direction = 2;
            }else{
                _direction = 0;
            }
        }
    }
    
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    if (_moving) {
        _moving = NO;
        UITapGestureRecognizer *ges = [self.gestureRecognizers lastObject];
        ges.enabled = YES;
        UITouch *touch = [touches anyObject];
        
        UIWindow* window = nil;//[UIApplication sharedApplication].keyWindow;
        if (!window)
        {
            window = [[UIApplication sharedApplication].windows objectAtIndex:0];
        }
        
        
        CGPoint point = [touch locationInView:self.superview];
        _endPoint = point;
        if(!BP_IS_OS_8_OR_LATER)
        {
            if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)
            {
                self.superview.center = CGPointMake(self.superview.center.x - (point.x - _beginPoint.x),
                                                    self.superview.center.y - (point.y - _beginPoint.y));
            }
            else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeRight)
            {
                self.superview.center = CGPointMake(self.superview.center.x - (point.y - _beginPoint.y),
                                                    self.superview.center.y + (point.x - _beginPoint.x));
            }
            else if([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeLeft)
            {
                self.superview.center = CGPointMake(self.superview.center.x + (point.y - _beginPoint.y),
                                                    self.superview.center.y - (point.x - _beginPoint.x));
            }
            else
            {
                self.superview.center = CGPointMake(self.superview.center.x + (point.x - _beginPoint.x),
                                                    self.superview.center.y + (point.y - _beginPoint.y));
            }
        }
        else
        {
            self.superview.center = CGPointMake(self.superview.center.x + (point.x - _beginPoint.x),
                                                self.superview.center.y + (point.y - _beginPoint.y));
        }
        self.frame = CGRectMake(0, 0, self.superview.frame.size.width, self.superview.frame.size.height);
        
        
        if (self.selfBoard.autoPosition) {
            int direction = INT16_MAX;
            
            
            if (_direction != -1) {
                direction = _direction;
            }else{
                direction = [self directByPoint:self.superview.center];
            }
            
            
            
            CGRect newRect;
            int y,x;
            switch (direction) {
                case 0:
                    x = self.superview.frame.origin.x;
                    if(x>[[UIScreen mainScreen] bounds].size.width-ExpandButtonHeight)
                    {
                        x = [[UIScreen mainScreen] bounds].size.width-ExpandButtonHeight;
                    }
                    else if(x < 0)
                    {
                        x = 0;
                    }
                    newRect = CGRectMake(x,
                                         0,
                                         self.superview.frame.size.width,
                                         self.superview.frame.size.height);
                    break;
                case 1:
                    y = self.superview.frame.origin.y;
                    if(y>[[UIScreen mainScreen] bounds].size.height-ExpandButtonHeight)
                    {
                        y = [[UIScreen mainScreen] bounds].size.height-ExpandButtonHeight;
                    }
                    else if(y < 0)
                    {
                        y = 0;
                    }
                    newRect = CGRectMake([[UIScreen mainScreen] bounds].size.width - self.superview.frame.size.width,
                                         y,
                                         self.superview.frame.size.width,
                                         self.superview.frame.size.height);
                    break;
                case 2:
                    x = self.superview.frame.origin.x;
                    if(x>[[UIScreen mainScreen] bounds].size.width-ExpandButtonHeight)
                    {
                        x = [[UIScreen mainScreen] bounds].size.width-ExpandButtonHeight;
                    }
                    else if(x < 0)
                    {
                        x = 0;
                    }
                    newRect = CGRectMake(x,
                                         [[UIScreen mainScreen] bounds].size.height - self.superview.frame.size.height,
                                         self.superview.frame.size.width,
                                         self.superview.frame.size.height);
                    break;
                case 3:
                {
                    y = self.superview.frame.origin.y;
                    if(y>[[UIScreen mainScreen] bounds].size.height-ExpandButtonHeight)
                    {
                        y = [[UIScreen mainScreen] bounds].size.height-ExpandButtonHeight;
                    }
                    else if(y < 0)
                    {
                        y = 0;
                    }
                    newRect = CGRectMake(0,
                                         y,
                                         self.superview.frame.size.width,
                                         self.superview.frame.size.height);
                }
                    break;
                    
                default:
                    break;
            }

            [UIView animateWithDuration:0.3
                             animations:^{
                                 self.superview.frame = newRect;
                             }
                             completion:^(BOOL finished) {
                                 
                             }];
            self.selfBoard.movedWithKeyboard = NO;
        }
    }
}


- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    [self touchesEnded:touches withEvent:event];
}



#pragma mark- tool

- (int)directByPoint:(CGPoint)point{
    int dir = INT_MAX;
    int min = INT_MAX;
    if (fabsf(point.x - 0)<min) {
        min = fabsf(point.x - 0);
        dir = 3;
    }
    if (fabsf([[UIScreen mainScreen] bounds].size.width - point.x)<min) {
        min = fabsf([[UIScreen mainScreen] bounds].size.width - point.x);
        dir = 1;
    }
    if (fabsf(point.y - 0)<min) {
        min = fabsf(point.y - 0);
        dir = 0;
    }
    if (fabsf([[UIScreen mainScreen] bounds].size.height - point.y)<min) {
        min = fabsf([[UIScreen mainScreen] bounds].size.width - point.x);
        dir = 2;
    }
    return dir;
}

- (int)velocityByPoint:(CGPoint)point1 andPoint:(CGPoint)point2{
    int velocityX = point1.x - point2.x;
    int velocityY = point1.y - point2.y;
    
    if (abs(velocityX) > abs(velocityY)) {
        return velocityX;
    }else{
        return velocityY;
    }
}


@end











