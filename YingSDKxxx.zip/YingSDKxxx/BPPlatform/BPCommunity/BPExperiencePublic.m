//
//  BPExperiencePublic.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-8-8.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPExperiencePublic.h"
#import "BPRegisterAndLoginRequest.h"

@implementation BPExperiencePublic
//计算经验条的值
+(NSMutableDictionary *) getExprienceWidth:(NSMutableDictionary*)userInfoDic
{
    int i=0;
    int width=0;
    int startExp = 0;
    int upExp = 0;
    NSMutableArray *experienceInfoArray;
    BPOperateTable *experienceInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    experienceInfoArray = [experienceInfoTable queryForDataWithSql:[NSString stringWithFormat:@"select * from %@",ExperienceInfoTableName]];
    [experienceInfoTable release];
    [BPUtility sortArrayWithKey:@"id" SortArray:experienceInfoArray isAscending:YES];
    
    if(experienceInfoArray && experienceInfoArray>0)
    {
        if([[userInfoDic objectForKey:@"level"] intValue]<=0)
        {
            startExp = 0;
            upExp = [[[experienceInfoArray objectAtIndex:0] objectForKey:@"up_experience"] intValue];
        }
        else
        {
            for(i=0;i<[experienceInfoArray count];i++)
            {
                NSMutableDictionary *dic = [experienceInfoArray objectAtIndex:i];
                if([[dic objectForKey:@"id"] intValue] == [[userInfoDic objectForKey:@"level"] intValue]+1)
                {
                    break;
                }
            }
            NSMutableDictionary *dic = [experienceInfoArray objectAtIndex:i-1];
            NSMutableDictionary *dic2 = [experienceInfoArray objectAtIndex:i];
            
            startExp = [[dic objectForKey:@"total_experience"] intValue];
            upExp = [[dic2 objectForKey:@"up_experience"] intValue];
        }
        if(SCREEN_IS_LANDSCAPE)
        {
            width = (double)([[userInfoDic objectForKey:@"experience"] intValue] - startExp)/upExp * 210;
        }
        else
        {
            width = (double)([[userInfoDic objectForKey:@"experience"] intValue] - startExp)/upExp * 160;
        }
    }
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:startExp], @"startExp",[NSNumber numberWithInt:upExp], @"upExp",[NSNumber numberWithInt:width], @"expWidth",nil];
    return dic;
}

//将等级升级表保存到数据库
+(void) saveExperienceInfoToTable:(NSMutableArray *)exp_array
{
    if(!exp_array || exp_array.count<1)
    {
        return;
    }
    NSMutableArray *experienceInfoArray = nil;
    BPOperateTable *experienceInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    if(![experienceInfoTable TableExists:ExperienceInfoTableName])
    {
        [experienceInfoTable CreateTableToDataBase:@"experienceInfo" SQLString:@"id int primary key, up_experience int, total_experience int, ctime double"];
    }
    else
    {
        experienceInfoArray = [experienceInfoTable queryForDataWithSql:[NSString stringWithFormat:@"select * from %@",ExperienceInfoTableName]];
    }
    if(experienceInfoArray && experienceInfoArray.count > 0)
    {
        exp_array = [BPUtility removeSameObject:exp_array InOriginalArray:experienceInfoArray withKey:@"id"];
        [experienceInfoArray addObjectsFromArray:exp_array];
    }
    else
    {
        experienceInfoArray = exp_array;
    }
    [BPUtility sortArrayWithKey:@"id" SortArray:experienceInfoArray isAscending:YES];
    [experienceInfoTable EraseTable:ExperienceInfoTableName];
    [experienceInfoTable insertDataToTable:[NSString stringWithFormat:@"insert into %@ (id,up_experience,total_experience,ctime) values (:id, :up_experience, :total_experience, :ctime)",@"experienceInfo"] withDictionaryInArray:experienceInfoArray];
    [experienceInfoTable release];
}

@end
