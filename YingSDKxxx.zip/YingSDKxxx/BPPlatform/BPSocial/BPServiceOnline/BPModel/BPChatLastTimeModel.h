//
//  BPChatLastTimeModel.h
//  ShuZhiZhangSDKSDK_Mini
//
//  Created by Frank on 13-10-15.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//  最后一条消息的时间戳,方便获取离线信息

#import <Foundation/Foundation.h>
#import "LKDaoBase.h"
@interface BPChatLastTimeModelBase:LKDAOBase

@end


@interface BPChatLastTimeModel : LKModelBase{
    int lastTime;
}

@property(nonatomic)int lastTime;

- (id)initWithJsonDictionary:(NSDictionary*)dic;

@end
