//
//  BPChatLastTimeModel.m
//  ShuZhiZhangSDKSDK_Mini
//
//  Created by Frank on 13-10-15.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import "BPChatLastTimeModel.h"

@implementation BPChatLastTimeModelBase

+(Class)getBindingModelClass
{
    return [BPChatLastTimeModel class];                                            //返回实体
}
const static NSString *tablename = @"LastTime";                                    //表名

+(const NSString *)getTableName
{
    return tablename;
}
@end

@implementation BPChatLastTimeModel
@synthesize lastTime;

-(id)init
{
    self = [super init];
    if (self)
    {
        self.primaryKey = @"lastTime";                                              //主健
    }
    return self;
}

- (id)initWithJsonDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self)
    {
        self.lastTime = [[dic objectForKey:@"lastTime"] intValue];
    }
    return self;
}


-(void)dealloc
{
    [super dealloc];
}


@end
