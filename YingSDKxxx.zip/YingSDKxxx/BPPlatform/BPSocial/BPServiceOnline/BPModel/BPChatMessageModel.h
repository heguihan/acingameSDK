//
//  BPChatMessageModel.h
//  BigPlayerSDK
//
//  Created by Frank on 13-9-11.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKDaoBase.h"

@interface BPChatMessageModelBase:LKDAOBase

@end

@interface BPChatMessageModel:LKModelBase{
    int fid;
    int tid;
    int msgtype;                 //1-文本 2-图片 3-声音 4-GPS 
    int oppositeId;
    int status;                  //0-发送中  1-失败  2-成功
    int theType;                 //0-发送 1-接收 2-时间
    NSString *nickname;
    NSString *image;
    NSString *picname;
    NSString *lpicname;
    NSString *soundfile;
    NSString *lsoundfile;
    NSString *content;
    NSString *soundlength;
    NSString *position;
    NSString *gps;
    NSString *ltime;
    NSString *time;
    NSString *systype;
    NSString *identifier;

}

@property(nonatomic) int fid;
@property(nonatomic) int tid;
@property(nonatomic) int msgtype;
@property(nonatomic) int oppositeId;
@property(nonatomic) int status;
@property(nonatomic) int theType;

@property(nonatomic ,copy) NSString *nickname;
@property(nonatomic ,copy) NSString *image;
@property(nonatomic ,copy) NSString *picname;
@property(nonatomic ,copy) NSString *lpicname;
@property(nonatomic ,copy) NSString *soundfile;
@property(nonatomic ,copy) NSString *lsoundfile;
@property(nonatomic ,copy) NSString *content;
@property(nonatomic ,copy) NSString *soundlength;
@property(nonatomic ,copy) NSString *position;
@property(nonatomic ,copy) NSString *gps;
@property(nonatomic ,copy) NSString *ltime;
@property(nonatomic ,copy) NSString *time;
@property(nonatomic ,copy) NSString *systype;
@property(nonatomic ,copy) NSString* identifier;

- (id)initWithJsonDictionary:(NSDictionary*)dic;

@end
