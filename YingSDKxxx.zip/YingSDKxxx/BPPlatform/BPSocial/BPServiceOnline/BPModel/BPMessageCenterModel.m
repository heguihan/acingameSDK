//
//  BPMessageCenterModel.m
//  BigPlayerSDK
//

//

#import "BPMessageCenterModel.h"

@implementation BPMessageCenterModelBase
+(Class)getBindingModelClass
{
    return [BPMessageCenterModel class];                            //返回实体
}
const static NSString* tablename = @"msgeCenter_2_6";                   //表名
+(const NSString *)getTableName
{
    return tablename;
}
@end


@implementation BPMessageCenterModel
@synthesize fid,tid,msgtype,oppositeId,status,theType,msgeCount;
@synthesize nickname,image,picname,soundfile,content,soundlength,position,gps,ltime,time,systype,lpicname,lsoundfile,identifier;

-(id)init
{
    self = [super init];
    if (self)
    {
        self.primaryKey = @"identifier";                            //主健
    }
    return self;
}

- (id)initWithJsonDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self)
    {
        self.fid = [[dic objectForKey:@"fid"] intValue];
        self.tid = [[dic objectForKey:@"tid"] intValue];
        self.msgtype = [[dic objectForKey:@"msgtype"] intValue];
        
        if ([[ShuZhiZhangUserPreferences CurrentUserID] intValue] == fid) {
            self.oppositeId = [[dic objectForKey:@"tid"] intValue];
            self.theType = 0;
        }else if([[ShuZhiZhangUserPreferences CurrentUserID] intValue] == tid){
            self.theType = 1;
            self.oppositeId = [[dic objectForKey:@"fid"] intValue];
        }
        
        self.status = [[dic objectForKey:@"status"] intValue];
        
        self.nickname = [dic objectForKey:@"nickname"];
        self.image = [dic objectForKey:@"image"];
        self.picname = [dic objectForKey:@"picname"];
        self.soundlength = [dic objectForKey:@"soundlength"];
        self.content = [dic objectForKey:@"content"];
        self.soundfile = [dic objectForKey:@"soundfile"];
        self.position = [dic objectForKey:@"position"];
        self.gps = [dic objectForKey:@"gps"];
        self.ltime = [dic objectForKey:@"ltime"];
        self.time = [dic objectForKey:@"time"];
        self.systype = [dic objectForKey:@"systype"];
        
        self.lsoundfile = [dic objectForKey:@"lsoundfile"];
        self.lpicname = [dic objectForKey:@"lpicname"];
        
        
        //唯一标
        NSString *ex = [NSString stringWithFormat:@"%d%d%@%@",self.fid,self.tid,self.ltime,self.time];
        self.identifier = ex;
    }
    return self;
}

- (id)initWithModel:(BPChatMessageModel *)model{
    self = [super init];
    if (self)
    {
        self.fid = model.fid;
        self.tid = model.tid;
        self.msgtype = model.msgtype;
        
        if ([[ShuZhiZhangUserPreferences CurrentUserID] intValue] == fid) {
            self.oppositeId = model.tid;
            self.theType = 0;
        }else if([[ShuZhiZhangUserPreferences CurrentUserID] intValue] == tid){
            self.theType = 1;
            self.oppositeId = model.fid;
        }
        
        //self.status = [[dic objectForKey:@"status"] intValue];
        
        self.nickname = model.nickname;
        self.image = model.image;
        self.picname = model.picname;
        self.soundlength = model.soundlength;
        self.content = model.content;
        self.soundfile = model.soundfile;
        self.position = model.position;
        self.gps = model.gps;
        self.ltime = model.ltime;
        self.time = model.time;
        self.systype = @"service";
        self.msgeCount = 0;
        
        self.lsoundfile = model.lsoundfile;
        self.lpicname = model.lpicname;
        
        //唯一标
        NSString *ex = [NSString stringWithFormat:@"%d%d%@%@",self.fid,self.tid,self.ltime,self.time];
        self.identifier = ex;
    }
    return self;
}

-(void)dealloc
{
    [nickname release];
    [image release];
    [picname release];
    [soundlength release];
    [content release];
    [soundfile release];
    [position release];
    [gps release];
    [ltime release];
    [time release];
    [systype release];
    [lsoundfile release];
    [lpicname release];
    
    [super dealloc];
}
@end
