//
//  TestModel.h
//  BigPlayers
//  Created by Frank on 13-5-29.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKDaoBase.h"
@interface TestModelBase:LKDAOBase

@end

@interface TestModel:LKModelBase

@property(copy,nonatomic)NSString *Bid;
@property(copy,nonatomic)NSString *StoreName;
@property(copy,nonatomic)NSString *Longitude;
@property(copy,nonatomic)NSString *Latitude;

- (id)initWithJsonDictionary:(NSDictionary*)dic;

@end
