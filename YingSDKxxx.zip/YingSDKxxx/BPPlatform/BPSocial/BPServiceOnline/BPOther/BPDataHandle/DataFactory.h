//
//  DataFactory.h
//  BigPlayers
//  Created by Frank on 13-5-29.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//
//  一个数据库处理工厂

#import <Foundation/Foundation.h>
#import "SandboxFile.h"
#import "FMDatabaseQueue.h"
#import "TestModel.h"
#import "BPChatMessageModel.h"
#import "BPMessageCenterModel.h"
#import "BPChatLastTimeModel.h"
#import "BPExperienceModel.h"


#define USER_ID_FILE_NAME @"user_%@"

#define GetDataBasePath [[FilePathManager globalDocumentPath] stringByAppendingPathComponent:@"GlobalDatabase.db"]

@interface DataFactory : NSObject
@property(retain,nonatomic)id classValues;
typedef enum
{
    test,                        //测试
    chatModel,
    messageModel,
    lastTime,
    experien,
    
}
FSO;//这个是枚举是区别不同的实体,我这边就写一个test;
+(DataFactory *)shardDataFactory;
//是否存在数据库
-(BOOL)IsDataBase;
//创建数据库
-(void)CreateDataBase;
//创建表
-(void)CreateTable:(id)model;
//添加数据
-(void)insertToDB:(id)Model Classtype:(FSO)type;
//修改数据
-(void)updateToDB:(id)Model Classtype:(FSO)type;
//删除单条数据
-(void)deleteToDB:(id)Model Classtype:(FSO)type;
//删除表的数据
-(void)clearTableData:(FSO)type;
//删除重复数据
- (void)deleteRepeatData:(NSString *)str model:(id)Model Classtype:(FSO)type;
//根据条件删除数据
-(void)deleteWhereData:(NSDictionary *)Model Classtype:(FSO)type;
//查找数据
-(void)searchWhere:(NSDictionary *)where orderBy:(NSString *)columeName offset:(int)offset count:(int)count Classtype:(FSO)type callback:(void(^)(NSArray *))result;

//查询聊天消息
-(void)searchChatMesg:(NSString*)str orderBy:(NSString *)columeName offset:(int)offset count:(int)count Classtype:(FSO)type callback:(void (^)(NSArray *))result;
@end
