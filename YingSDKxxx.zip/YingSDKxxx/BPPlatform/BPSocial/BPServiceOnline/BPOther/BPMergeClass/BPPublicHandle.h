//
//  BPPublicHandle.h
//  BigPlayerSDK
//
//

#import <Foundation/Foundation.h>
#import "Reachability.h"
#import "HJObjManager.h"
#import "BPSendMessageRequest.h"
#import "HJManagedImageV.h"

@interface BPPublicHandle : NSObject{
    Reachability *hostReach;
    HJObjManager *userImageManager;
    BPSendMessageRequest *messageQuest;
    int ctrType;
    BOOL connectAgain;
}


+(BPPublicHandle *)sharedPublicHandle;

//开启应用调用
+(void)appDidFinishLaunching;



//图片缓存地址
+(void)cheangeImagePath;



//处理时间
+(NSString *) getTimeString:(float) ctime  needType:(int)type;

//处理头像
- (void)getImage:(id<HJMOUser>)user headImageUrl:(NSString *)url;

//处理其他图像
- (void)getImage:(id<HJMOUser>)user OtherImageUrl:(NSString *)url;



//标记客服界面
- (void)markController:(int)type;

- (void)showMessageTag;


//更新最后通信时间
- (void)updateLastTime:(NSString*)time;


//获取最后通信时间
- (NSString *)getLastChatTime;

//获取离线消息
- (void)getOffLineMessage;

//判断设备型号
- (NSString *) platformString;


//iphone5,5s ipad3,ipad4 ----->>> YES  other --------->>> NO
-(BOOL)showPhoto;
@end
