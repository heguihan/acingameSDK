//
//  BPPublicHandle.m
//  BigPlayerSDK
//
//

#import "BPPublicHandle.h"
//#import "BPNetworkReachable.h"
#import "BPChatMessageModel.h"
#import "BPMessageCenterModel.h"
#import "DataFactory.h"
#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#import "BigPlayerSDKBase.h"

#define IMAGE_PATH_1 @"/Library/Caches/user/user_%d/BP_image/"

@implementation BPPublicHandle


+(BPPublicHandle *)sharedPublicHandle{
    static BPPublicHandle *instance = nil;
    if(instance == nil) {
        instance = [[BPPublicHandle alloc] init];
    }
    return instance;
}

-(id)init
{
    if( (self = [super init]) ) {
       
    }
    return self;
}

+(void)appDidFinishLaunching{
    
    [[BPPublicHandle sharedPublicHandle] checkNetwork];
    
}


+(void)cheangeImagePath{
    [[BPPublicHandle sharedPublicHandle] cheangeImagePath];
    
}

-(void)markController:(int)type{
    ctrType = type;
}



- (void)showMessageTag{
    NSMutableArray *resultArray = [NSMutableArray arrayWithCapacity:10];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100 Classtype:messageModel callback:^(NSArray *result)
     {
         [resultArray addObjectsFromArray:result];
     }];
    
    int number = 0;
    for (BPMessageCenterModel *theModel in resultArray) {
        number = number + theModel.msgeCount;
    }
    if (number>0) {
        [[NSNotificationCenter defaultCenter] postNotificationName:BPHasGotMessageNotification object:nil];
    }
}

-(void)checkNetwork{
    // Observe the kNetworkReachabilityChangedNotification. When that notification is posted, the
    // method "reachabilityChanged" will be called.
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(reachabilityChanged:) name: kReachabilityChangedNotification object: nil];
    //Change the host name here to change the server your monitoring
	hostReach = [[Reachability reachabilityWithHostName: @"www.baidu.com"] retain];
	[hostReach startNotifier];
	//[self updateInterfaceWithReachability: hostReach];
}




//存放社交图片信息路径
- (void)cheangeImagePath{
    
    NSString *str = [NSString stringWithFormat:IMAGE_PATH_1,[[ShuZhiZhangUserPreferences CurrentUserID] intValue]];
    NSString *cacheDirectory = [NSHomeDirectory() stringByAppendingString:str];
	HJMOFileCache *fileCache = [[[HJMOFileCache alloc] initWithRootPath:cacheDirectory] autorelease];
	userImageManager.fileCache = fileCache;
}

//头像
- (void)getImage:(id<HJMOUser>)user headImageUrl:(NSString *)url{
    [[(HJManagedImageV *)user layer] setShadowOffset:CGSizeMake(2.0, 2.0)];
    ((HJManagedImageV*)user).layer.masksToBounds = YES;
    ((HJManagedImageV*)user).layer.cornerRadius = 4.0;
    ((HJManagedImageV*)user).layer.borderColor = [[UIColor lightGrayColor] CGColor];
    ((HJManagedImageV*)user).layer.borderWidth = 0.0;
    //[(HJManagedImageV*)user showLoadingWheel];
    user.url = [NSURL URLWithString:url];
    [userImageManager manage:user];
}

//图片
- (void)getImage:(id<HJMOUser>)user OtherImageUrl:(NSString *)url{
    [[(HJManagedImageV *)user layer] setShadowOffset:CGSizeMake(0.0, 0.0)];
    [[(HJManagedImageV *)user layer] setShadowRadius:0.0];
    [[(HJManagedImageV *)user layer] setShadowOpacity:0.0];
    [[(HJManagedImageV *)user layer] setShadowColor:[UIColor lightGrayColor].CGColor];
    user.url = [NSURL URLWithString:url];
    [userImageManager manage:user];
}


//插入数据
-(void)insertDataToDB:(BPChatMessageModel*)model{
    
    NSString *timeSp = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    //插入时间
    NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],@"10000",@"5",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",nil];
    NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
    BPChatMessageModel *timeModel = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
    timeModel.ltime = timeSp;
    timeModel.theType = 2;
    
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    [[DataFactory shardDataFactory]searchChatMesg:[NSString stringWithFormat:@"oppositeId = '%d'",10000] orderBy:@"rowid" offset:0 count:1 Classtype:chatModel callback:^(NSArray *result){
        
        //////////NSLog(@"%@",result);
        if (result.count>0) {
            result = [[result reverseObjectEnumerator] allObjects];
            [array addObjectsFromArray:result];
        }
    }];
    
    //判断和前一条消息的间隔时间
    if (array.count>0) {
        BPChatMessageModel *lastModel  = [array objectAtIndex:array.count-1];
        //判断两个日期间隔是否超过3分钟
        if ([timeModel.ltime floatValue]-[lastModel.ltime floatValue]>180) {
            [[DataFactory shardDataFactory] insertToDB:timeModel Classtype:chatModel];
        }
    }else {
        //以前没有内容
        [[DataFactory shardDataFactory] insertToDB:timeModel Classtype:chatModel];
    }
    [timeModel release];
    
    //标记发送中
    model.status = 0;
    model.ltime = timeSp;
    model.theType = 1;
    [[DataFactory shardDataFactory] insertToDB:model Classtype:chatModel];
}


- (void) didSubscribe: (NSUInteger)messageId grantedQos:(NSArray*)qos{ }
- (void) didUnsubscribe: (NSUInteger)messageId{ }
- (void) didPublish: (NSUInteger)messageId{ }


// 连接成功
- (void) didConnect:(NSUInteger)code
{
    //////////NSLog(@"**连接成功**");
	////////NSLog(@"didConnect");
}

// 断开连接
- (void) didDisconnect
{
    //////////NSLog(@"**退出连接**");
    ////////NSLog(@"didDisconnect");
    if (connectAgain) {
        
    }
}


// 处理连接改变后的情况
// 连接改变
- (void) reachabilityChanged: (NSNotification* )note
{
	Reachability* curReach = [note object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	[self updateInterfaceWithReachability: curReach];
}

// 网络变化
- (void) updateInterfaceWithReachability: (Reachability*) curReach
{
    NetworkStatus netStatus = [curReach currentReachabilityStatus];
    BOOL connectionRequired= [curReach connectionRequired];
    NSString* statusString= @"";
    switch (netStatus)
    {
        case NotReachable:
        {
            statusString = @"Access Not Available";
            //Minor interface detail- connectionRequired may return yes, even when the host is unreachable.  We cover that up here...
            connectionRequired= NO;
            break;
        }
            
        case ReachableViaWWAN:
        {
            statusString = @"Reachable WWAN";
            connectionRequired = YES;
            break;
        }
        case ReachableViaWiFi:
        {
            statusString= @"Reachable WiFi";
            connectionRequired = YES;
            break;
        }
    }
    
    
    if(connectionRequired)
    {
        statusString= [NSString stringWithFormat: @"%@, Connection Required", statusString];
        ////////NSLog(@"网络状态-正常");
        //////////NSLog(@"网络变化");
        // 在线重连，取离线消息
        if (![ShuZhiZhangUserPreferences CurrentUserID] && ![[ShuZhiZhangUserPreferences CurrentUserID] isEqualToString:@""]&&![[ShuZhiZhangUserPreferences CurrentUserID] isEqualToString:@"-1"]) {
            [self getOffLineMessage];
        }
        
    }else{
        //////////NSLog(@"网络状态-断开");
        [BPCustomPromptBox showWithTitle:@"当前网络不可用，请检查您的网络状态"AndDisappearSecond:2];
    }
}




//获取时间
/**********
 type:
 1-获取时间差值;
 2-时间显示格式(1);
 **********/
+(NSString *) getTimeString:(float) ctime  needType:(int)type{
    
    if (type == 1) {
        NSDate *compareDate = [NSDate dateWithTimeIntervalSince1970:ctime];
        NSTimeInterval  timeInterval = [compareDate timeIntervalSinceNow];
        timeInterval = -timeInterval;
        int temp = 0;
        NSString *result;
        
        if (timeInterval < 60) {
            
            result = [NSString stringWithFormat:@"1分钟"];
            
        }else if((temp = timeInterval/60) <60){
            
            result = [NSString stringWithFormat:@"%d分钟",temp];
            
        } else if((temp = temp/60) <24){
            
            result = [NSString stringWithFormat:@"%d小时",temp];
            
        }else if((temp = temp/24) <365){
            
            result = [NSString stringWithFormat:@"%d天",temp];
            
        }
        /*else if((temp = temp/30) <12){
         
         result = [NSString stringWithFormat:@"%d月前",temp];
         
         }*/
        else{
            
            temp = temp/12;
            result = [NSString stringWithFormat:@"%d年前",temp];
        }
        return  result;
        
    }else if (type == 2){
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat : @"HH:mm"];
        NSString *timeStr;
        
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:ctime];
        
        NSDate *today = [NSDate date];
        NSDate * yesterday = [NSDate dateWithTimeIntervalSinceNow:-86400];
        NSDate * beforeYesterday = [NSDate dateWithTimeIntervalSinceNow:-86400*2];
        // 10 first characters of description is the calendar date:
        NSString * todayString = [[today description] substringToIndex:10];
        NSString * yesterdayString = [[yesterday description] substringToIndex:10];
        NSString * beforeYesterdayString = [[beforeYesterday description] substringToIndex:10];
        NSString * refDateString = [[date description] substringToIndex:10];
        
        if ([refDateString isEqualToString:todayString])
        {
            timeStr = [NSString stringWithFormat:@"%@", [formatter stringFromDate:date]];
            [formatter release];
            return timeStr;
        }
        else if ([refDateString isEqualToString:yesterdayString])
        {
            timeStr = [NSString stringWithFormat:@"昨天 %@", [formatter stringFromDate:date]];
            [formatter release];
            return timeStr;
        }
        else if ([refDateString isEqualToString:beforeYesterdayString])
        {
            timeStr = [NSString stringWithFormat:@"前天 %@", [formatter stringFromDate:date]];
            [formatter release];
            return timeStr;
        }
        else
        {
            [formatter setDateFormat : @"yyyy"];
            timeStr = [formatter stringFromDate:date];
            NSString *str = [formatter stringFromDate:[NSDate date]];
            if ([str intValue]-[timeStr intValue]!=0) {
                [formatter setDateFormat : @"yyyy-MM-dd"];
                timeStr = [formatter stringFromDate:date];
                [formatter release];
                return timeStr;
            }else{
                [formatter setDateFormat : @"MM-dd"];
                timeStr = [formatter stringFromDate:date];
                [formatter release];
                return timeStr;
            }
            
        }
        [formatter release];
    }
    return nil;
}


- (void)updateLastTime:(NSString*)time{
    NSDictionary *timeDic = [NSDictionary dictionaryWithObject:time forKey:@"lastTime"];
    BPChatLastTimeModel *timeModel = [[BPChatLastTimeModel alloc]initWithJsonDictionary:timeDic];
    [[DataFactory shardDataFactory]insertToDB:timeModel Classtype:lastTime];
    [timeModel release];
}


- (NSString*)getLastChatTime{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:0];
    [[DataFactory shardDataFactory]searchWhere:nil orderBy:@"rowid DESC" offset:0 count:1 Classtype:lastTime callback:^(NSArray *result){
        //////////NSLog(@"result : %@",result);
        [array addObjectsFromArray:result];
    }];
    
    NSString *str = nil;
    if (array.count>0) {
        BPChatLastTimeModel *model = (BPChatLastTimeModel*)[array objectAtIndex:0];
        str = [NSString stringWithFormat:@"%d",model.lastTime];
    }else{
        str = @"0";
    }
    return str;
}


- (void)getOffLineMessage{
    
    //////////NSLog(@"game_id ======== %@  user_id ======== %@  time ======= %@",[ShuZhiZhangUserPreferences CurrentGameId],[ShuZhiZhangUserPreferences CurrentUserID],[self getLastChatTime]);
    [messageQuest getOffLineMessage:[ShuZhiZhangUserPreferences CurrentGameId] theUid:[ShuZhiZhangUserPreferences CurrentUserID] lastTime:[self getLastChatTime]];
}


//请求失败
-(void)requestDidFailed:(ASIHTTPRequest *)request{
}

-(void)dealloc
{
    [userImageManager release];
    
    for (ASIHTTPRequest *activeRequest in [messageQuest.RequestQueue operations]) {
        [activeRequest clearDelegatesAndCancel];
    }
    
    [messageQuest release];
    messageQuest = nil;
    [super dealloc];
}

- (NSString *) platformString{
    // Gets a string with the device model
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    if ([platform isEqualToString:@"iPhone1,1"])    return @"iPhone 2G";
    if ([platform isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([platform isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([platform isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,3"])    return @"iPhone 4 (CDMA)";
    if ([platform isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([platform isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    if ([platform isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    
    if ([platform isEqualToString:@"iPod1,1"])      return @"iPod Touch (1 Gen)";
    if ([platform isEqualToString:@"iPod2,1"])      return @"iPod Touch (2 Gen)";
    if ([platform isEqualToString:@"iPod3,1"])      return @"iPod Touch (3 Gen)";
    if ([platform isEqualToString:@"iPod4,1"])      return @"iPod Touch (4 Gen)";
    if ([platform isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
    
    if ([platform isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([platform isEqualToString:@"iPad1,2"])      return @"iPad 3G";
    if ([platform isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([platform isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([platform isEqualToString:@"iPad2,4"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
    if ([platform isEqualToString:@"iPad2,6"])      return @"iPad Mini";
    if ([platform isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,1"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,2"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,3"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,4"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,5"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,6"])      return @"iPad 4";
    
    if ([platform isEqualToString:@"i386"])         return @"Simulator";
    if ([platform isEqualToString:@"x86_64"])       return @"Simulator";
    return platform;
}

-(BOOL)showPhoto{
    if ([[self platformString]isEqualToString:@"iPhone 5"]||[[self platformString]isEqualToString:@"iPhone 5S"]||[[self platformString]isEqualToString:@"iPad 3"]||[[self platformString]isEqualToString:@"iPad 4"]) {
        return YES;
    }else{
        return NO;
    }
}



@end
