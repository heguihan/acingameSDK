//
//  BPMapViewController.m
//  BigPlayerSDK
//
//  Created by Frank on 13-9-16.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPMapViewController.h"
#import "BPPublicHandle.h"

@interface BPMapViewController ()

@end

@implementation BPMapViewController
@synthesize message,navTittleStr,delegate,peopleGps,theType;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

-(void)dealloc{
    map.delegate = nil;
    [map release];
    [Geocoder release];
    delegate = nil;
    [gpsArray release];
    gpsArray = nil;
    [super dealloc];
    //NSLog(@"BPMapViewController release");
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (theType == 0) {
        navTittleStr = [BPLanguage getStringForKey:@"BPAddress" InTable:@"BPMultiLanguage"];
        [BPUtility customNavigationButton:self isleftButton:NO NormalImage:@"BPSDKResource.bundle/BP_finish.png" HighLightedImage:@"BPSDKResource.bundle/BP_finish_sel.png"];
    }else{
        navTittleStr = [BPLanguage getStringForKey:@"BPSeeAddress" InTable:@"BPMultiLanguage"];
    }
    
    [BPUtility customNavigationTitle:navTittleStr ViewController:self];
    
    address = @"";
    gpsArray = [[NSMutableArray alloc]initWithCapacity:0];
    
    //地图
    map = [[MKMapView alloc] initWithFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV)];
    map.mapType = MKMapTypeStandard;
    map.delegate = self;
    map.showsUserLocation = YES;
    //map.zoomEnabled = NO;
    //map.scrollEnabled = NO;
    [self.view insertSubview:map belowSubview:self.navigationController.navigationBar];
    
    Geocoder = [[CLGeocoder alloc]init];
	
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[BPPublicHandle sharedPublicHandle] markController:1];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(void) leftButtonItemAction
{
    [BPCustomPromptBox BPHidePromptBox];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - MKMapViewDelegate mothed
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    CLLocationCoordinate2D coordinate;
    
    if (theType == 0) {
        [BPCustomPromptBox showWithTitle:@"正在获取当前位置"AndDisappearSecond:1];
    }
    
    [gpsArray removeAllObjects];
    if (userLocation) {
        [gpsArray addObject:[NSString stringWithFormat:@"%f",userLocation.coordinate.latitude]];
        [gpsArray addObject:[NSString stringWithFormat:@"%f",userLocation.coordinate.longitude]];
        CLLocation *location = [[CLLocation alloc]initWithLatitude:[[gpsArray objectAtIndex:0] floatValue] longitude:[[gpsArray objectAtIndex:1] floatValue]];
        [self getCity:location];
        [location release];
    }
    coordinate.latitude = userLocation.coordinate.latitude;
    coordinate.longitude = userLocation.coordinate.longitude;
    
    if (theType == 1) {
        if (![peopleGps isEqualToString:@""]) {
            NSArray *array = [peopleGps componentsSeparatedByString:@","];
            coordinate.latitude = [[array objectAtIndex:0] floatValue];
            coordinate.longitude = [[array objectAtIndex:1] floatValue];
            [gpsArray removeAllObjects];
            [gpsArray addObjectsFromArray:array];
        }
    }
    
    //设置显示范围
    MKCoordinateRegion region;
    region.span.latitudeDelta = 0.005;
    region.span.longitudeDelta = 0.005;
    region.center = coordinate;
    //设置显示位置(动画)
    [map setRegion:region animated:YES];
    [map regionThatFits:region];
}

-(void)rightButtonItemAction{
    
    if (gpsArray.count>1) {
        if([delegate respondsToSelector:@selector(sendAddressMessage: userlongitude: addressStr:)])
        {
            [delegate sendAddressMessage:[gpsArray objectAtIndex:0] userlongitude:[gpsArray objectAtIndex:1] addressStr:address];
        }
        //[self dismissViewControllerAnimated:YES completion:^(void){
            
        //}];
        [self.navigationController popViewControllerAnimated:YES];
        
    }else{
        [BPCustomPromptBox showWithTitle:@"发送失败"AndDisappearSecond:2];
    }
    
}

//获取详细的地理位置
- (void)getCity:(CLLocation *)location {
    [Geocoder reverseGeocodeLocation:location
                   completionHandler:^(NSArray *placemarks, NSError *error) {
                       if (error == nil &&
                           [placemarks count] > 0){
                           CLPlacemark *placemark = [placemarks objectAtIndex:0];
                           map.userLocation.subtitle = [[placemark.addressDictionary objectForKey:@"FormattedAddressLines"]objectAtIndex:0];
                           address = [[placemark.addressDictionary objectForKey:@"FormattedAddressLines"]objectAtIndex:0];
                           //NSLog(@"address ============ %@",address);
                       }
                       
                       else if (error == nil &&
                                
                                [placemarks count] == 0){
                           
                           //NSLog(@"No results were returned.");
                           
                       }
                       
                       else if (error != nil){
                           
                           //NSLog(@"An error occurred = %@", error);
                           
                       }
                       
                   }];
    
}  


- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation{
    
//    CLLocationCoordinate2D coordinate;
//    if (gpsArray.count>0) {
//        coordinate.latitude = [[gpsArray objectAtIndex:0] floatValue];
//        coordinate.longitude = [[gpsArray objectAtIndex:1] floatValue];
//        [annotation setCoordinate:coordinate];
//    }
//    
    NSString* identifier = @"Pin";
    MKPinAnnotationView* newAnnotation = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    
    if(nil == newAnnotation) {
        newAnnotation = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier] autorelease];
    }
    
    //MKPinAnnotationView *newAnnotation = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"annotation"]autorelease];
    newAnnotation.pinColor = MKPinAnnotationColorGreen;
    newAnnotation.animatesDrop = YES;
    newAnnotation.canShowCallout= YES;
    mapView.userLocation.title = @"位置";
    
    if (gpsArray.count>0) {
        CLLocation *location = [[CLLocation alloc]initWithLatitude:[[gpsArray objectAtIndex:0] floatValue] longitude:[[gpsArray objectAtIndex:1] floatValue]];
        [self getCity:location];
        [location release];
    }
    
    return newAnnotation;
    
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
    
}


- (void)mapView:(MKMapView *)mapView didFailToLocateUserWithError:(NSError *)error{
    [BPCustomPromptBox showWithTitle:@"无法获取当前位置"AndDisappearSecond:2];
}

@end
