//
//  BPMapViewController.h
//  BigPlayerSDK
//
//  Created by Frank on 13-9-16.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@protocol mapViewDelegate<NSObject>
@optional
-(void)sendAddressMessage:(NSString*)userLatitude userlongitude:(NSString*)userlongitude addressStr:(NSString*)address;
@end

@interface BPMapViewController : BPBaseViewController<MKMapViewDelegate>{
    MKMapView *map;                   //地图
    int theType;                      //类型 0 - 发送位置 1-查看位置
    NSString *message;
    NSString *peopleGps;
    CLGeocoder *Geocoder;             //CLGeocoder
    NSString *navTittleStr;
    NSString *address;
    id <mapViewDelegate> delegate;
    UIButton * rightBtn;
    NSMutableArray *gpsArray;
}

@property (nonatomic ,assign) id <mapViewDelegate> delegate;
@property (nonatomic)int theType;
@property (nonatomic ,copy)NSString *message;
@property (nonatomic ,copy)NSString *navTittleStr;
@property (nonatomic ,copy)NSString *peopleGps;

@end
