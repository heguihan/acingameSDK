//
//  BPInforViewController.h
//  BigPlayerSDK
//
//  Created by Frank on 13-9-10.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPBaseViewController.h"

@interface BPInforViewController : BPBaseViewController<UIWebViewDelegate>{
    UIWebView *faqWebView;
    NSString *webHttpUrl;
}

@property(nonatomic , copy)NSString *webHttpUrl;

@end
