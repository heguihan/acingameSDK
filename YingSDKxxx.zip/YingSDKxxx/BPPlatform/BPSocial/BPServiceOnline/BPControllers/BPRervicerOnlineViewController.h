//
//  BPRervicerOnlineViewController.h
//  BigPlayerSDK
//
//

#import "BPBaseViewController.h"
#import "EGORefreshTableHeadView.h"
#import "BPSendMessageRequest.h"
//#import "BPMapViewController.h"
#import "HJManagedImageV.h"
//#import "RecordManager.h"
//#import "PlayManager.h"


@interface BPRervicerOnlineViewController : BPBaseViewController<UITableViewDataSource,UITableViewDelegate,UITextViewDelegate,UIGestureRecognizerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,EGORefreshTableHeaderDelegate>//mapViewDelegate,
{
    UITableView *chatMesgeTableV;                   //消息列表
    UIView *showListView;                           //弹出视图
    UITableView *showListTabView;                   //展开列表
    
    UIView *footBarView;                            //底部Bar
    UIImageView *footViewBg;                        //footBar背景
    
    UIImageView *inputViewBg;                       //输入框背景
    UITextView *inputView;                          //输入框
    
    UIButton *btnOne;                               //语音文本切换按钮
    UIButton *btnTwo;                               //更多选择按钮
    UIButton *btnThree;                             //表情选择按钮
    UIButton *btnFour;                              //按住说话
    
    UIScrollView *footScr;
    UIScrollView *emotionScr;
    UIPageControl *pageControl;
    
    UIView *animView;
    UIImageView *speakAnimV;
    UILabel *alertLab;
    
    UIView *bigImageView;
    HJManagedImageV *bigImageV;
    
    CGRect keyboardEndFrame;
    
    BPSendMessageRequest *sendMsgeRequest;
//    RecordManager *recordManager;                   //录音管理器
//    PlayManager   *playManager;                     //音频播放管理
    
    EGORefreshTableHeadView *_refreshHeaderView;
    
    UIPopoverController *popover;
    
    
    NSMutableArray *dataArray;
    NSArray *speakImageArray;
    NSArray *rightImagesArray;                       //右端音频播放图片
    NSMutableArray *showIconArray;                   //存放弹出列表Icon
    NSMutableArray *showTittleArray;                 //弹出列表标签
    NSMutableArray *showIconSelArray;                //存放选中Icon
    NSMutableArray *faceArray;
    NSMutableArray *wordArray;                       //存放敏感字符
    
    NSString *textViewStr;
    
    int btnOneMark;
    int btnTwoMark;
    int btnThreeMark;
    int selectMark;
    
    CGPoint point;
    
    float hight;
    
    BOOL sendSound;
    BOOL isPlay;
    BOOL rightBtnAction;
    //BOOL showQuitMsge;
    
    int markPlayCell;
    int markNumber;
    
    int autoResponse;                               //标记问答模式 0:人工  1:智能
    
    
    NSString *gameName;
    
    //UILabel *testMessage;
    
}
@property (nonatomic,assign) BOOL fromGameFlag;
@end
