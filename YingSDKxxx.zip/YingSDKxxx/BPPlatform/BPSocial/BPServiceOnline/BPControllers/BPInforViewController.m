//
//  BPInforViewController.m
//  BigPlayerSDK
//
//  Created by Frank on 13-9-10.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPInforViewController.h"

@interface BPInforViewController ()

@end

@implementation BPInforViewController
@synthesize webHttpUrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [BPUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPFAQ" InTable:@"BPMultiLanguage"] ViewController:self];
    }
    return self;
}

-(void)dealloc{
    [faqWebView release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    faqWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-44)];
    [faqWebView setBackgroundColor:[UIColor clearColor]];
    faqWebView.scrollView.bounces = NO;
    [faqWebView setOpaque:NO];
    [faqWebView setDelegate:self];
    [self.view addSubview:faqWebView];
    [self showWebViewActionButtons];
    
    NSLog(@"webHttpUrl ============= %@",webHttpUrl);
    [self loadWebPageWithString:webHttpUrl];
	
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(void) showWebViewActionButtons
{
    //    self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-44);
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT_NAV-44, SCREEN_WIDTH, 44)];
    backView.tag = 61200;
    backView.backgroundColor = [UIColor colorWithRed:239/255.0f green:239/255.0f blue:239/255.0f alpha:1];
    //    backView.alpha = 0.5;
    [self.view addSubview:backView];
    [backView release];
    
    //返回
    UIButton *goBack =[UIButton buttonWithType:UIButtonTypeCustom];
    goBack.frame = CGRectMake(10, SCREEN_HEIGHT_NAV-37, 30, 30);
    goBack.tag = 61201;
    [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateNormal];
    [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateHighlighted];
    [goBack addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:goBack];
    //前进
    UIButton *goForward =[UIButton buttonWithType:UIButtonTypeCustom];
    goForward.frame = CGRectMake(80, SCREEN_HEIGHT_NAV-37, 30, 30);
    goForward.tag = 61202;
    [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateNormal];
    [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateHighlighted];
    [goForward addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:goForward];
    
    //刷新
    UIButton *refresh =[UIButton buttonWithType:UIButtonTypeCustom];
    refresh.frame = CGRectMake(SCREEN_WIDTH - 50, SCREEN_HEIGHT_NAV-37, 30, 30);
    refresh.tag = 61203;
    [refresh setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_refresh.png"] forState:UIControlStateNormal];
    [refresh setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_refresh_sel.png"] forState:UIControlStateHighlighted];
    [refresh addTarget:self action:@selector(clickButtons:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:refresh];
}

-(void) refreshButtonStatus
{
    UIButton *goBack = (UIButton *)[self.view viewWithTag:61201];
    UIButton *goForward = (UIButton *)[self.view viewWithTag:61202];
    if(!goBack || !goForward)
    {
        return;
    }
    if (faqWebView.canGoBack)
    {
        [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back.png"] forState:UIControlStateNormal];
        [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back_sel.png"] forState:UIControlStateHighlighted];
    }
    else
    {
        [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateNormal];
        [goBack setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_back_dis.png"] forState:UIControlStateHighlighted];
    }
    if (faqWebView.canGoForward)
    {
        [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward.png"] forState:UIControlStateNormal];
        [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward_sel.png"] forState:UIControlStateHighlighted];
    }
    else
    {
        [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateNormal];
        [goForward setImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_FAQ_forward_dis.png"] forState:UIControlStateHighlighted];
    }
}

-(void) clickButtons:(UIButton *)sender
{
    int index = sender.tag - 61201;
    switch (index) {
        case 0:
            if (faqWebView.canGoBack)
            {
                [faqWebView goBack];
            }
            break;
        case 1:
            if (faqWebView.canGoForward)
            {
                [faqWebView goForward];
            }
            break;
        case 2:
            [faqWebView reload];
            break;
        default:
            break;
    }
    
}

-(void) leftButtonItemAction
{
    [self dismissModalViewControllerAnimated:YES];
}


- (void)loadWebPageWithString:(NSString*)urlString
{
    NSURL *url =[NSURL URLWithString:urlString];
    NSURLRequest *request =[NSURLRequest requestWithURL:url];
    [faqWebView loadRequest:request];
    [faqWebView reload];
}

- (void )webViewDidFinishLoad:(UIWebView *)webView
{
    [self refreshButtonStatus];
}

@end
