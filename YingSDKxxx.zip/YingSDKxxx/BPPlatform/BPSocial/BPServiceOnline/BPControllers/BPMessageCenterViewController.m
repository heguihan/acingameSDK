//
//  BPMessageCenterViewController.m
//  BigPlayerSDK
//

#import "BPMessageCenterViewController.h"
#import "BPRervicerOnlineViewController.h"
#import "BPMessageCenterCell.h"
#import "BPMessageCenterModel.h"
#import "DataFactory.h"

@interface BPMessageCenterViewController ()


@end

@implementation BPMessageCenterViewController
@synthesize type;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal];
        
            [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPMessage"
                                                                 InTable:@"BPMultiLanguage"] ViewController:self];
            [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:[BPLanguage getStringForKey:@"BPBackToGame" InTable:@"BPMultiLanguage"]];
    }
    return self;
}

- (void)dealloc{
    [mesgeCenterTable release];
    [dataArray release];
    dataArray = nil;
    [remindLable release];
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:@"updateMessageCell" object:nil];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    remindLable = [[UILabel alloc] initWithFrame:CGRectMake(0.0,(SCREEN_HEIGHT_NAV-15.0)/2 , SCREEN_WIDTH,15.0)];
    [remindLable setBackgroundColor:[UIColor clearColor]];
    [remindLable setTextAlignment:UITextAlignmentCenter];
    [remindLable setTextColor:[UIColor grayColor]];
    [remindLable setText:[BPLanguage getStringForKey:@"BPRemindMessage" InTable:@"BPMultiLanguage"]];
    remindLable.hidden = YES;
    [self.view addSubview:remindLable];
    
    
    mesgeCenterTable = [[UITableView alloc] initWithFrame:CGRectMake(0.0,0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV) style:UITableViewStylePlain];
    [mesgeCenterTable setBackgroundColor:[UIColor clearColor]];
    mesgeCenterTable.delegate = self;
    mesgeCenterTable.dataSource = self;
    [self.view addSubview:mesgeCenterTable];
    

    //去除列表底部多余白条
    UIView *footView = [[UIView alloc]init];
    [footView setBackgroundColor:[UIColor whiteColor]];
    [mesgeCenterTable setTableFooterView:footView];
    [footView release];
    
    UIView *headView = [[UIView alloc]init];
    [headView setBackgroundColor:[UIColor whiteColor]];
    [mesgeCenterTable  setTableHeaderView:headView];
    [headView release];
    
    
    dataArray = [[NSMutableArray alloc] initWithCapacity:10];
    
    [self getDataFromDB];
    
    //显示接收到的消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateMessageCell:)
                                                 name:@"updateMessageCell"
                                               object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void) leftButtonItemAction
{
//    [self.navigationController popViewControllerAnimated:YES];
    if (type == 1) {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    [self dismissModalViewControllerAnimated:YES];
    [ShuZhiZhangUtility postPlatformExitNotification];
}

#pragma mark - UITableViewDelegate mothed
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80.0;
}




#pragma mark - UITableViewDataSource mothed

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *str = @"cell";
    BPMessageCenterCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    
    if (cell == nil) {
        cell = [[[BPMessageCenterCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str] autorelease];
        cell.backgroundColor = [UIColor clearColor];
    }

    BPMessageCenterModel *model = [dataArray objectAtIndex:indexPath.row];
    [cell addDataWithModel:model];
    
    cell.showsReorderControl = YES;
    [cell setShouldIndentWhileEditing:YES];
    UIImageView *selectBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_msge_sel.png"]];
    [selectBg setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, 40.0)];
    [cell setSelectedBackgroundView:selectBg];
    [selectBg release];
    UIView *view = [[UIView alloc] init];
    [cell setAccessoryView:view];
    [view release];
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    BPRervicerOnlineViewController *theController = [[BPRervicerOnlineViewController alloc] init];
    theController.fromGameFlag = NO;
    [self.navigationController pushViewController:theController animated:YES];
    [theController release];
}



- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        //////////NSLog(@"%d", indexPath.row);
        BPMessageCenterModel *model = (BPMessageCenterModel*)[dataArray objectAtIndex:indexPath.row];
        [[DataFactory shardDataFactory]deleteToDB:model Classtype:messageModel];
        [dataArray removeObjectAtIndex:[indexPath row]];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationRight];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"updateMessageCell" object:nil];
        NSMutableArray *resultArray = [NSMutableArray arrayWithCapacity:10];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100 Classtype:messageModel callback:^(NSArray *result)
         {
             [resultArray addObjectsFromArray:result];
         }];
        
        int number = 0;
        for (BPMessageCenterModel *theModel in resultArray) {
            number = number + theModel.msgeCount;
        }
        if (number == 0) {
            [[NSNotificationCenter defaultCenter] postNotificationName:BPNoMessageHidePromptNotification object:nil];
        }
    }
    
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
     //return UITableViewCellEditingStyleDelete;
    return UITableViewCellEditingStyleNone;
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
}

#pragma mark - Notification Method

//刷新列表
-(void)updateMessageCell:(NSNotification *)notification{
      //BPMessageCenterModel *model = [notification object];
    [self getDataFromDB];
}

- (void)getDataFromDB{
    [dataArray removeAllObjects];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100000 Classtype:messageModel callback:^(NSArray *result)
     {
         //////////NSLog(@"theResult ======== %@",result);
         result = [[result reverseObjectEnumerator] allObjects];
         [dataArray addObjectsFromArray:result];
         [mesgeCenterTable reloadData];
         if (result.count == 0) {
             remindLable.hidden = NO;
         }else{
             remindLable.hidden = YES;
         }
         
     }];
}

@end
