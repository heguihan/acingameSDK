//
//  BPMessageCenterViewController.h
//  BigPlayerSDK
//

//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"

@interface BPMessageCenterViewController : BPBaseViewController<UITableViewDataSource,UITableViewDelegate>{
    UITableView *mesgeCenterTable;
    NSMutableArray *dataArray;
    int type;
    UILabel *remindLable;
}
@property(nonatomic)int type;

@end
