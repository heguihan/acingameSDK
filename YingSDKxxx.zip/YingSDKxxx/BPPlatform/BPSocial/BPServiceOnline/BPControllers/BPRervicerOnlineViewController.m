//
//  BPRervicerOnlineViewController.m
//  BigPlayerSDK
//

#import "BPRervicerOnlineViewController.h"
#import "EGORefreshTableHeadView.h"
//#import "BPInforViewController.h"
#import "TestModel.h"
#import "DataFactory.h"
#import "BPChatMessageModel.h"
#import "BPRervicerOnlineCell.h"
#import "BPShowTableListCell.h"
#import "BPPublicHandle.h"
#import "BigPlayerSDKBase.h"
//#import "AMRFileCodec.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"
#import "BPWebViewBaseViewController.h"

//#define degreesToRadinas(x) (M_PI * (x)/180.0)


@interface BPRervicerOnlineViewController ()

@end

@implementation BPRervicerOnlineViewController
@synthesize fromGameFlag;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
       //////////NSLog(@"dic ======= %@",[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal]);
        //[ShuZhiZhangUtility customNavigationTitle:navTitleStr ViewController:self];

    }
    return self;
}

- (void)dealloc{
    [chatMesgeTableV release];
    [showListView release];
    [showListTabView release];
    [showIconArray release];
    [showIconSelArray release];
    [showTittleArray release];
    [wordArray release];
    [_refreshHeaderView release];
    [footBarView release];
    [footViewBg release];
    [inputViewBg release];
    [inputView release];
    [footScr release];
    [emotionScr release];
    [pageControl release];
    [dataArray release];
    [speakImageArray release];
    [rightImagesArray release];
    
    if (popover) {
       [popover release];
        popover = nil;
    }
    
    [animView release];
    [speakAnimV release];
    [alertLab release];
    [bigImageView release];
    [faceArray release];
    
    
//    recordManager.delegate = nil;
//    if (recordManager) {
//        [recordManager release];
//        recordManager = nil;
//    }

    
//    if (playManager) {
//        [playManager release];
//        playManager = nil;
//    }
    
    for (ASIHTTPRequest *activeRequest in [sendMsgeRequest.RequestQueue operations]) {
        [activeRequest clearDelegatesAndCancel];
    }
    
    [sendMsgeRequest release];
    sendMsgeRequest = nil;
    
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:@"updateCell" object:nil];
    
    [super dealloc];
}

-(void) leftButtonItemAction
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [[BPPublicHandle sharedPublicHandle] markController:0];
    //在社区中心内打开界面
    if(!fromGameFlag)
    {
        //        self.navigationController.navigationBarHidden = NO;
        [self.navigationController popViewControllerAnimated:YES];
    }
    //游戏内打开界面
    else
    {
        [self dismissModalViewControllerAnimated:YES];
        [ShuZhiZhangUtility postPlatformExitNotification];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateMessageCell" object:nil];
    NSMutableArray *resultArray = [NSMutableArray arrayWithCapacity:10];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100 Classtype:messageModel callback:^(NSArray *result)
     {
         [resultArray addObjectsFromArray:result];
     }];
    
    int number = 0;
    for (BPMessageCenterModel *theModel in resultArray) {
        number = number + theModel.msgeCount;
    }
    if (number == 0) {
        [[NSNotificationCenter defaultCenter] postNotificationName:BPNoMessageHidePromptNotification object:nil];
    }
//    [self cancelRequest];
}
-(void) showTitleAfterDelay:(NSString *)str
{
    [ShuZhiZhangUtility customNavigationTitle:str ViewController:self];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //////////NSLog(@"dic ===== %@",[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal]);
    wordArray = [[NSMutableArray alloc] initWithCapacity:10];
    [wordArray addObjectsFromArray:[ShuZhiZhangUtility getWordLibrary]];
    
    if (fromGameFlag) {
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:NO Title:[BPLanguage getStringForKey:@"BPTitleButtonMore" InTable:@"BPMultiLanguage"]];
         [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:[BPLanguage getStringForKey:@"BPBackToGame" InTable:@"BPMultiLanguage"]];
    }else{
         [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:NO Title:[BPLanguage getStringForKey:@"BPTitleButtonMore" InTable:@"BPMultiLanguage"]];
    }
    rightBtnAction = YES;
    selectMark = 5;
    autoResponse = 0;
    //showQuitMsge = NO;
    
    if(SCREEN_IS_LANDSCAPE)
    {
        hight = 39.0;
    }else{
        hight = 48.0; 
    }
    
    [[BPPublicHandle sharedPublicHandle] markController:1];
    gameName = [(NSMutableDictionary*)[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_name"];
    NSString *navTitleStr = [NSString stringWithFormat:@"%@%@",gameName,[BPLanguage getStringForKey:@"BPHelper" InTable:@"BPMultiLanguage"]];
    if(fromGameFlag)
    {

        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 2*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self showTitleAfterDelay:navTitleStr];
        });
        
    }
    else
    {
        [ShuZhiZhangUtility customNavigationTitle:navTitleStr ViewController:self];
    }
    

    dataArray = [[NSMutableArray alloc] initWithCapacity:10];
    
    speakImageArray = [[NSArray alloc]initWithObjects:
                       @"ShuZhiZhang.bundle/BP_chat_mic_01.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_02.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_03.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_04.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_05.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_01.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_02.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_03.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_04.png",
                       @"ShuZhiZhang.bundle/BP_chat_mic_05.png",
                       nil];
    
    
    rightImagesArray = [[NSArray alloc]initWithObjects:
                        [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_03.png"],
                        [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_04.png"],
                        [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_05.png"],
                        [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_06.png"],
                        nil];

    [BPPublicHandle cheangeImagePath];
    
    //录音管理器
//    recordManager = [[RecordManager alloc] init];
//    recordManager.delegate = self;
    
    
    [self loadChatView];

    sendMsgeRequest = [[BPSendMessageRequest alloc] initWithDelegate:self];
}

-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    [[BPPublicHandle sharedPublicHandle] markController:1];
    
    //监测键盘位置的变化，让输入框显示在键盘上面
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(keyboardWillShow:)
                                                name:UIKeyboardWillShowNotification
                                              object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(keyboardWillHide:)
                                                name:UIKeyboardWillHideNotification
                                              object:nil];
}


-(void)viewWillDisappear:(BOOL)animated{
    
//    if (playManager) {
//      [playManager stopPlayQueue];
//    }
    
    
    //注销键盘通知
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:UIKeyboardWillHideNotification object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


#pragma mark - loadView method


- (void)loadChatView{
    
    chatMesgeTableV = [[UITableView alloc] initWithFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH,SCREEN_HEIGHT_NAV-hight) style:UITableViewStylePlain];
    [chatMesgeTableV setBackgroundColor:[UIColor clearColor]];
    [chatMesgeTableV setDataSource:self];
    [chatMesgeTableV setDelegate:self];
    [chatMesgeTableV setSeparatorColor:[UIColor clearColor]];
    [self.view addSubview:chatMesgeTableV];

    _refreshHeaderView =  [[EGORefreshTableHeadView alloc] initWithFrame:CGRectMake(0.0f, -chatMesgeTableV.frame.size.height, chatMesgeTableV.frame.size.width, chatMesgeTableV.frame.size.height) withType:0];
    _refreshHeaderView.delegate = self;
    [chatMesgeTableV addSubview:_refreshHeaderView];
    
    UITapGestureRecognizer* singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    singleTap.delegate = self;
    singleTap.cancelsTouchesInView = NO;
    [chatMesgeTableV addGestureRecognizer:singleTap];
    [singleTap release];
    
    [self loadFootView];
    
    showListView = [[UIView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-138.0,-167.0, 132.0, 167.0)];
    [showListView setBackgroundColor:[UIColor clearColor]];
    [self.view insertSubview:showListView belowSubview:self.navigationController.navigationBar];
    
    UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake(97.5, 0.0, 16.0, 3.0)];
    [imageV setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_show_image_01.png"]];
    [showListView addSubview:imageV];
    [imageV release];
    
    showIconArray = [[NSMutableArray alloc] initWithCapacity:3];
    showIconSelArray = [[NSMutableArray alloc] initWithCapacity:3];
    showTittleArray = [[NSMutableArray alloc] initWithCapacity:3];
    NSArray *icon = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_show_icon_01.png",@"ShuZhiZhang.bundle/BP_show_icon_02.png",@"ShuZhiZhang.bundle/BP_show_icon_03.png",@"ShuZhiZhang.bundle/BP_show_icon_04.png",nil];
    NSArray *iconSel = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_show_icon_01_sel.png",@"ShuZhiZhang.bundle/BP_show_icon_02_sel.png",@"ShuZhiZhang.bundle/BP_show_icon_03_sel.png",@"ShuZhiZhang.bundle/BP_show_icon_04_sel.png",nil];
    NSArray *tittle = [NSArray arrayWithObjects:[BPLanguage getStringForKey:@"BPFAQ" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPCallCentre" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPQuestion" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPClearMessage" InTable:@"BPMultiLanguage"],nil];
    [showIconArray addObjectsFromArray:icon];
    [showIconSelArray addObjectsFromArray:iconSel];
    [showTittleArray addObjectsFromArray:tittle];
    
    
    showListTabView = [[UITableView alloc] initWithFrame:CGRectMake(0.0,3.0 , 132.0, 164.0)];
    [showListTabView setBackgroundColor:[UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:0.8]];
    [showListTabView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [showListTabView setDataSource:self];
    [showListTabView setDelegate:self];
    [showListTabView setScrollEnabled:NO];
    
    CALayer *layer = [showListTabView layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:4.0];
    [layer setBorderWidth:1];
    [layer setBorderColor:[[UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:0.95] CGColor]];
    [showListView  addSubview:showListTabView];
    
    
//    playManager = [[PlayManager alloc] init];
//    playManager.playDelegate = self;
    
    [self getDataFromDB];


    [self deleteMessageCenterData];
    isPlay = NO;
    markPlayCell = 0;
    markNumber = 0;
    
    //显示接收到的消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateCell:)
                                                 name:@"updateCell"
                                               object:nil];
}

//加载底部按钮
- (void)loadFootView{
    btnOneMark = 0;
    btnTwoMark = 0;
    btnThreeMark = 0;
    sendSound = NO;
    
    footBarView = [[UIView alloc]initWithFrame:CGRectMake(0.0,SCREEN_HEIGHT_NAV-hight, SCREEN_WIDTH, 260.0)];
    if(SCREEN_IS_LANDSCAPE)
    {
        footBarView.frame = CGRectMake(0.0,SCREEN_HEIGHT_NAV-hight, SCREEN_WIDTH, 100.0+hight);
        
    }else{
        
        if(BPDevice_is_ipad){
            
            footBarView.frame = CGRectMake(0.0,SCREEN_HEIGHT_NAV-hight, SCREEN_WIDTH, 100.0+hight);
 
        }else{
            
           footBarView.frame = CGRectMake(0.0,SCREEN_HEIGHT_NAV-hight, SCREEN_WIDTH, 260.0);   
        }     
    }
    
    [footBarView setBackgroundColor:[UIColor clearColor]];
    [footBarView setUserInteractionEnabled:YES];
    [self.view addSubview:footBarView];
    
    footViewBg = [[UIImageView alloc]initWithFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, hight)];
    [footViewBg setBackgroundColor:[UIColor clearColor]];
    [footViewBg setUserInteractionEnabled:YES];
    [footViewBg setImage:[[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_bottom.png"]resizableImageWithCapInsets:UIEdgeInsetsMake(1.0f,1.0f, 1.0f,1.0f)]];
    [footBarView addSubview:footViewBg];
 
    btnTwo = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnTwo setFrame:CGRectMake(23.0,btnOne.frame.origin.y,41.0, 44.0)];
    [btnTwo setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_add_icon_pic.png"] forState:UIControlStateNormal];
    [btnTwo setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_add_icon_pic.png"] forState:UIControlStateHighlighted];
    [btnTwo setBackgroundColor:[UIColor clearColor]];
    [btnTwo setContentMode:UIViewContentModeCenter];
     btnTwo.tag = 1001011;
    [btnTwo addTarget:self action:@selector(imagePickButton) forControlEvents:UIControlEventTouchUpInside];
    [footViewBg addSubview:btnTwo];
 
    inputViewBg = [[UIImageView alloc]initWithImage:[[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_text_bg.png"]resizableImageWithCapInsets:UIEdgeInsetsMake(14.5f,6.0f, 14.5f,6.0f)]];
    [inputView setUserInteractionEnabled:YES];
    [inputViewBg setFrame:CGRectMake(66.0, 9.0, footBarView.frame.size.width - 132, 30.0-48.0+hight)];
    [footViewBg addSubview:inputViewBg];
    
    //输入框
    inputView = [[UITextView alloc] init];
    if (SCREEN_IS_LANDSCAPE) {
        [inputView setFrame:CGRectMake(66.0, 10.0, footBarView.frame.size.width - 132.0, 28.0-48.0+hight)];
        inputView.contentInset = UIEdgeInsetsMake(-8, 0, 0, 0);
        inputView.font = [UIFont systemFontOfSize:15];
    }else{
        [inputView setFrame:CGRectMake(66.0, 9.0, footBarView.frame.size.width - 132.0, 30.0-48.0+hight)];
        inputView.contentInset = UIEdgeInsetsMake(-2, 0, 0, 0);
        inputView.font = [UIFont systemFontOfSize:16];
    }
    inputView.returnKeyType = UIReturnKeySend;
    inputView.delegate = self;
    inputView.backgroundColor = [UIColor clearColor];
    inputView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    inputView.scrollEnabled = NO;
    if(BP_Show_IOS7)
    {
        inputView.scrollEnabled = YES;
    }
    inputView.showsHorizontalScrollIndicator = NO;
    [footViewBg addSubview:inputView];
    
    
    footScr = [[UIScrollView alloc] initWithFrame:CGRectMake(0.0,footViewBg.frame.size.height, SCREEN_WIDTH,footBarView.frame.size.height-footViewBg.frame.size.height)];
    [footScr setBackgroundColor:[UIColor clearColor]];
    [footBarView addSubview:footScr];
    
    NSArray *tittleArray = nil;
    NSArray *iconImageArray = nil;
    if (![[BPPublicHandle sharedPublicHandle] showPhoto]) {
        tittleArray = [NSArray arrayWithObjects:[BPLanguage getStringForKey:@"BPPicture" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPAddress" InTable:@"BPMultiLanguage"],@"",@"",@"",@"", nil];
        iconImageArray = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_add_icon_pic.png",@"ShuZhiZhang.bundle/BP_add_icon_location.png",@"",@"",@"",@"",nil];
        
        if([BigPlayerSDKBase getSharedBPPlatform].BPCloseAddressLocation)
        {
            tittleArray = [NSArray arrayWithObjects:[BPLanguage getStringForKey:@"BPPicture" InTable:@"BPMultiLanguage"],@"",@"",@"",@"",@"", nil];
            iconImageArray = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_add_icon_pic.png",@"",@"",@"",@"",@"",nil];
        }
    }else{
        tittleArray = [NSArray arrayWithObjects:[BPLanguage getStringForKey:@"BPPicture" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPPhoto" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPAddress" InTable:@"BPMultiLanguage"],@"",@"",@"", nil];
        iconImageArray = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_add_icon_pic.png",@"ShuZhiZhang.bundle/BP_add_icon_photo.png",@"ShuZhiZhang.bundle/BP_add_icon_location.png",@"",@"",@"",nil];
        if([BigPlayerSDKBase getSharedBPPlatform].BPCloseAddressLocation)
        {
            tittleArray = [NSArray arrayWithObjects:[BPLanguage getStringForKey:@"BPPicture" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPPhoto" InTable:@"BPMultiLanguage"],@"",@"",@"",@"", nil];
            iconImageArray = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_add_icon_pic.png",@"ShuZhiZhang.bundle/BP_add_icon_photo.png",@"",@"",@"",@"",nil];
        }
    }
    
    int count = 0;
    if(SCREEN_IS_LANDSCAPE)
    {
        count = 5;
    }else{
        if (BPDevice_is_ipad) {
            count = 5;
        }else{
            count = 6;
        }
    }
    
    for (int i=0; i<count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        if(SCREEN_IS_LANDSCAPE)
        {
            [btn setFrame:CGRectMake(0.0+i*(1+(SCREEN_WIDTH-4)/5), 0.0,(SCREEN_WIDTH-4)/5,footScr.frame.size.height)];
            //////////NSLog(@"宽:%f   高:%f",(SCREEN_WIDTH-4)/5,footScr.frame.size.height);
            [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_more_chat.png"] forState:UIControlStateNormal];
            [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_more_chat_sel.png"] forState:UIControlStateHighlighted];
        }else{
            if (BPDevice_is_ipad) {
                [btn setFrame:CGRectMake(0.0+i*(1+(SCREEN_WIDTH-4)/5), 0.0,(SCREEN_WIDTH-4)/5,footScr.frame.size.height)];
                //////////NSLog(@"宽:%f   高:%f",(SCREEN_WIDTH-4)/5,footScr.frame.size.height);
                [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_more_chat.png"] forState:UIControlStateNormal];
                [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_more_chat_sel.png"] forState:UIControlStateHighlighted];
            }else{
                if (i>2) {
                    [btn setFrame:CGRectMake(0.0+(i-3)*107.0, 108.5, 106.0, 107.5)];
                    
                }else{
                    
                    [btn setFrame:CGRectMake(0.0+i*107.0, 0.0, 106.0, 107.5)];
                    
                }
            }
        }
        
        btn.tag = 2016+i;
        [btn setBackgroundColor:[UIColor colorWithRed:245/255.0 green:243.0/255.0 blue:237/255.0 alpha:1]];
        [btn addTarget:self action:@selector(choiceBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [footScr addSubview:btn];
        
        UIImageView *iconImage = [[UIImageView alloc]initWithFrame:CGRectMake((btn.frame.size.width-35)/2,20.0,35.0, 30.0)];
        [iconImage setBackgroundColor:[UIColor clearColor]];
        [iconImage setUserInteractionEnabled:NO];
        [iconImage setImage:[UIImage imageNamed:[iconImageArray objectAtIndex:i]]];
        [btn addSubview:iconImage];
        [iconImage release];
        
        UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(0.0, btn.frame.size.height-30.0, btn.frame.size.width, 13.0)];
        [lab setBackgroundColor:[UIColor clearColor]];
        [lab setFont:[UIFont systemFontOfSize:12.0f]];
        [lab setTextColor:[UIColor colorWithRed:100/255.0 green:100/255.0 blue:100/255.0 alpha:1]];
        [lab setTextAlignment:NSTextAlignmentCenter];
        [lab setText:[tittleArray objectAtIndex:i]];
        [btn addSubview:lab];
        [lab release];
        
    }
    
    emotionScr = [[UIScrollView alloc] initWithFrame:CGRectMake(0.0,footViewBg.frame.size.height, SCREEN_WIDTH,footScr.frame.size.height)];
    //[emotionScr setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"add_bg.png"]]];
    [emotionScr setBackgroundColor:[UIColor colorWithRed:245/255.0 green:243.0/255.0 blue:237/255.0 alpha:1]];
    [emotionScr setContentSize:CGSizeMake(2 * SCREEN_WIDTH,emotionScr.frame.size.height)];
    emotionScr.scrollEnabled = YES;
    emotionScr.pagingEnabled = YES;
    emotionScr.showsHorizontalScrollIndicator = NO;
    emotionScr.showsVerticalScrollIndicator = NO;
    emotionScr.delegate = self;
    
    [footBarView addSubview:emotionScr];
    [self updateDots];
    [footBarView addSubview:pageControl];
    
    
}


- (void)updateDots
{
    for(int i = 0; i< [pageControl subviews].count; i++) {
        UIImageView* dot = [[pageControl subviews] objectAtIndex:i];
        CALayer *layer = [dot layer];
        [layer setMasksToBounds:YES];
        [layer setCornerRadius:2.2];
        if(i == pageControl.currentPage){
            [dot setBackgroundColor:[UIColor colorWithRed:213/255.0 green:156/255.0 blue:35/255.0 alpha:1]];

            
        }else{
            [dot setBackgroundColor:[UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:1]];

        }
        
    }
    
}

-(void) rightButtonItemAction
{
    [self showList:rightBtnAction];
    
}

-(void)cancelBtnAction:(id)sender{
    self.navigationController.navigationBarHidden = NO;
    [bigImageView removeFromSuperview];
}

-(void) imagePickButton
{
    //图片
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = NO;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    if (BPDevice_is_ipad) {
        if (popover) {
            [popover release];
            popover = nil;
        }
        popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
        [popover presentPopoverFromRect:CGRectMake(0,100, 300, 300) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }else{
        
        [self presentViewController:imagePickerController animated:YES completion:^{}];
    }
    
    [imagePickerController release];
}

-(void)messageBgAction:(id)sender{
    UIButton *btn = (UIButton*)sender;
    //////////NSLog(@"btn.tag ======== %d",btn.tag);
    BPChatMessageModel *model = [dataArray objectAtIndex:btn.tag];
    BPRervicerOnlineCell *cellOne = (BPRervicerOnlineCell *)btn.superview;
    if(BP_Show_IOS7)
    {
        if (BP_IS_OS_8_OR_LATER) {
            
        }else{
            cellOne = (BPRervicerOnlineCell *)btn.superview.superview;
        }
    }
    if (model.msgtype==3) {
        if (isPlay) {
            //////////NSLog(@"markPlayCell ======== %d",markPlayCell);
            if (markPlayCell == btn.tag) {
//                if (playManager) {
//                    if ([playManager isPlaying]) {
//                        [playManager stopPlayQueue];
//                        [[NSNotificationCenter defaultCenter] postNotificationName:BPShouldPlaySoundNotification object:nil];
//                    }
//                }
                [cellOne.playView stopAnimating];
                isPlay = NO;
                markPlayCell = 0;
            }else{
                BPRervicerOnlineCell *oldCell = (BPRervicerOnlineCell*)[chatMesgeTableV cellForRowAtIndexPath:[NSIndexPath indexPathForRow:markPlayCell inSection:0]];
//                if (playManager) {
//                    [playManager stopPlayQueue];
//                }
                [oldCell.playView stopAnimating];
                isPlay = NO;
                markPlayCell = 0;
                
                /*if (playManager) {
                    [playManager release];
                    playManager = nil;
                }
                playManager = [[PlayManager alloc] init];*/
                /*playManager.endPlay = ^(){
                    [cellOne.playView stopAnimating];
                    //isPlay = NO;
                    //markPlayCell = 0;
                };*/
                
                if (![[NSFileManager defaultManager] fileExistsAtPath:model.lsoundfile]) {
                    //调用接口取音频文件
                    [sendMsgeRequest downloadFile:model index:btn.tag];
                }else{
                    //播放缓存文件
                    isPlay = YES;
                    markPlayCell = btn.tag;
//                    [playManager playWithFilePath:model.lsoundfile];
                    cellOne.playView.animationImages = rightImagesArray;
                    cellOne.playView.animationDuration = 1.0;
                    cellOne.playView.animationRepeatCount = 0;
                    [cellOne.playView startAnimating];
                }
            }
            
        }else{
            
            /*if (playManager) {
                [playManager release];
                playManager = nil;
            }
            
            playManager = [[PlayManager alloc] init];
            playManager.playDelegate = self;*/
            /*playManager.endPlay = ^(){
                [cellOne.playView stopAnimating];
            };*/
            
            
            //////////NSLog(@"markPlayCell ========= %d",markPlayCell);
            if (![[NSFileManager defaultManager] fileExistsAtPath:model.lsoundfile]) {
                //调用接口取音频文件
                [sendMsgeRequest downloadFile:model index:btn.tag];
            }else{
                //播放缓存文件
                isPlay = YES;
                markPlayCell = btn.tag;
//                [playManager playWithFilePath:model.lsoundfile];
                cellOne.playView.animationImages = rightImagesArray;
                cellOne.playView.animationDuration = 1.0;
                cellOne.playView.animationRepeatCount = 0;
                [cellOne.playView startAnimating];
            }
        }
        //////////NSLog(@"model.soundfile ============= %@  ; model.locfile ================ %@",model.soundfile,model.lsoundfile);
    }else{
        if (model.msgtype == 2) {
            [inputView resignFirstResponder];
            BPRervicerOnlineCell *cellOne = (BPRervicerOnlineCell *)btn.superview;
            if(BP_Show_IOS7)
            {
                if (BP_IS_OS_8_OR_LATER) {
                }else{
                    cellOne = (BPRervicerOnlineCell *)btn.superview.superview;
                }
            }
            //////////NSLog(@"model.picname ========= %@",model.picname);
            if (model.fid == [[ShuZhiZhangUserPreferences CurrentUserID] intValue]) {
                [self showBigImage:model.picname smallImage:cellOne.photoMessView.image index:btn.tag];
            }else{
                //NSString *str = [model.picname stringByReplacingOccurrencesOfString:@"http://121.199.44.109:8082//" withString:@"http://121.199.44.109:8082/"];
                [self showBigImage:model.picname smallImage:cellOne.photoMessView.image index:btn.tag];
            }
        }
        return;
    }
}

#pragma mark - Other Method

//显示弹出列表
-(void)showList:(BOOL)admin{
    [UIView animateWithDuration:0.2
                     animations:^{
                         if (admin) {
                             showListView.hidden = NO;
                             [showListView setFrame:CGRectMake(showListView.frame.origin.x,5.0, 132.0, 167.0)];
                         }else{
                             [showListView setFrame:CGRectMake(showListView.frame.origin.x, -167, 132.0, 126.0)];
                         }
                         rightBtnAction = !rightBtnAction;
                     }completion:^(BOOL finish){
                         if (selectMark != 5) {
                             switch (selectMark) {
                                 case 0:{
                                     
                                     NSString *str = [NSString stringWithFormat:@"%@html/faq/index.html?gameId=%@&channelId=%@&cmsmid=%@",GLOBAL_DOMAIN_URL,[ShuZhiZhangUserPreferences CurrentGameId],[ShuZhiZhangUserPreferences  CurrentChannelId],[ShuZhiZhangUserPreferences  CurrentClientId]];
                                     BPWebViewBaseViewController *inforController = [[BPWebViewBaseViewController alloc] initWithUrl:str AndTitle:[BPLanguage getStringForKey:@"BPFAQ" InTable:@"BPMultiLanguage"]];
                                     [inforController showWebViewActionButtons];
                                     [self.navigationController pushViewController:inforController animated:YES];
                                     [inforController release];
                                 }  
                                     break;
                                 case 1:{
                                     
                                     NSString *deviceType = [UIDevice currentDevice].model;
                                     if([deviceType  isEqualToString:@"iPod touch"]||[deviceType  isEqualToString:@"iPad"]||[deviceType  isEqualToString:@"iPhone Simulator"]||BPDevice_is_ipad){
                                         
                                         BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:[BPLanguage getStringForKey:@"BPPrompt" InTable:@"BPMultiLanguage"] message:@"您的设备不能打电话"  delegate:self cancelButtonTitle:[BPLanguage getStringForKey:@"BPYesIKnow" InTable:@"BPMultiLanguage"] otherButtonTitles: nil,nil];
                                         [alert show];
                                         [alert release];
                                     }else {
                                     //呼叫客服
                                         UIWebView*callWebview =[[UIWebView alloc] init];
                                         NSString *telUrl = [NSString stringWithFormat:@"tel:%@", [ShuZhiZhangUserPreferences currentAccountServicePhone]];
                                         NSURL *telURL =[NSURL URLWithString:telUrl];
                                         [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
                                         [self.view addSubview:callWebview];
                                         [callWebview release];
                                     }
                                 }
                                     
                                     break;
                                 case 2:{
                                     //智能问答
//                                     ////////NSLog(@"---%@---%@",[ShuZhiZhangUserPreferences CurrentNickname],[ShuZhiZhangUserPreferences currentUserHeadURLStr]);
                                     autoResponse = 1;
                                     NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences currentChatId],@"7",@"",[ShuZhiZhangUserPreferences CurrentNickname],[ShuZhiZhangUserPreferences currentUserHeadURLStr],@"",@"",@"?",@"",@"",@"",@"",@"",@"",@"",@"",nil];
                                     NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
                                     NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
                                     BPChatMessageModel *model = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
                                     //[self sendMessage:model];
                                     [sendMsgeRequest sendMessage:model autoresponse:autoResponse];
                                     [btnOne setEnabled:NO];
                                     [btnTwo setEnabled:NO];
                                     [btnThree setEnabled:NO];
                                     
                                     btnFour.hidden = YES;
                                     inputView.hidden = NO;
                                     inputViewBg.hidden = NO;
                                     [btnOne setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_microphone.png"] forState:UIControlStateNormal];
                                     [btnOne setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_microphone_sel.png"] forState:UIControlStateHighlighted];
                                     btnOneMark = 0;
                                     
                                     [model release];
                                 }
                                     
                                     break;
                                 case 3:{
                                     BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:[BPLanguage getStringForKey:@"BPPrompt" InTable:@"BPMultiLanguage"] message:[BPLanguage getStringForKey:@"BPClearReminder" InTable:@"BPMultiLanguage"]  delegate:self cancelButtonTitle:[BPLanguage getStringForKey:@"BPNo" InTable:@"BPMultiLanguage"] otherButtonTitles:[BPLanguage getStringForKey:@"BPYes" InTable:@"BPMultiLanguage"],nil, nil];
                                     [alert show];
                                     [alert release];
                                     
                                 }
                                     break;
                                 default:
                                     break;
                             }
                         }
                         selectMark = 5;
                         [showListTabView reloadData];
                     }];
}

//显示弹出小菜单
- (void)showMenu:(id)cell theType:(int)type
{
    UIView *view = [cell superview];
    if(BP_Show_IOS7)
    {
        view = [[cell superview] superview];
    }
    [view becomeFirstResponder];
    UIMenuController * menu = [UIMenuController sharedMenuController];
    if (type == 1) {
        UIMenuItem *flag0 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPCopyMessage" InTable:@"BPMultiLanguage"]   action:@selector(copy1:)];
        [menu setMenuItems:[NSArray arrayWithObjects:flag0,nil]];
        [flag0 release];
    }else if(type == 0){
        UIMenuItem *flag0 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPCopyMessage" InTable:@"BPMultiLanguage"]action:@selector(copy1:)];
        UIMenuItem *flag1 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPDeleteMessage" InTable:@"BPMultiLanguage"]action:@selector(delete1:)];
        UIMenuItem *flag2 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPSendAgain" InTable:@"BPMultiLanguage"]action:@selector(resend1:)];
        [menu setMenuItems:[NSArray arrayWithObjects:flag0,flag1,flag2,nil]];
        [flag0 release];
        [flag1 release];
        [flag2 release];
    }else{
        UIMenuItem *flag1 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPDeleteMessage" InTable:@"BPMultiLanguage"] action:@selector(delete1:)];
        UIMenuItem *flag2 = [[UIMenuItem alloc] initWithTitle:[BPLanguage getStringForKey:@"BPSendAgain" InTable:@"BPMultiLanguage"] action:@selector(resend1:)];
        [menu setMenuItems:[NSArray arrayWithObjects:flag1,flag2,nil]];
        [flag1 release];
        [flag2 release];
    }
    [menu setTargetRect: [cell frame] inView: view];
    [menu setMenuVisible: YES animated: YES];
}


//删除发送失败的消息
-(void)deleteMessage:(int)index{
    BPChatMessageModel *model = [dataArray objectAtIndex:index];
    //////////NSLog(@"model.time ==== ===== %@",model.time);
    NSMutableDictionary *dicc = [NSMutableDictionary dictionary];
    [dicc setObject:model.time forKey:@"time"];
    [[DataFactory shardDataFactory]searchWhere:dicc orderBy:nil offset:0 count:3 Classtype:chatModel callback:^(NSArray *result)
     {
         if (result.count==1) {
             [dataArray removeObject:model];
             NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:index inSection:0];
             [chatMesgeTableV deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath1, nil] withRowAnimation:UITableViewRowAnimationRight];
         }
         if (result.count==2) {
             BPChatMessageModel *model1 = [dataArray objectAtIndex:index-1];
             [dataArray removeObject:model];
             [dataArray removeObject:model1];
             NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:index inSection:0];
             NSIndexPath *indexPath2 = [NSIndexPath indexPathForRow:index-1 inSection:0];
             [chatMesgeTableV deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath1,indexPath2, nil] withRowAnimation:UITableViewRowAnimationRight];
         }
         [chatMesgeTableV reloadData];
     }];
    
    [[DataFactory shardDataFactory]deleteWhereData:dicc Classtype:chatModel];
    
}

//重发失败消息
-(void)sendAgain:(int)index{
    BPChatMessageModel *theModel = [dataArray objectAtIndex:index];
    //////////NSLog(@"model.picname2111========= %@",theModel.picname);
    //////////NSLog(@"model.soundfile2111========= %@",theModel.soundfile);
    if (theModel.status == 1) {
        NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],[NSString stringWithFormat:@"%d",theModel.tid],[NSString stringWithFormat:@"%d",theModel.msgtype],@"",[ShuZhiZhangUserPreferences CurrentNickname],[ShuZhiZhangUserPreferences currentUserHeadURLStr],@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",nil];
        NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
        NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
        BPChatMessageModel *model = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
        model.lpicname = theModel.lpicname;
        model.lsoundfile = theModel.lsoundfile;
        model.soundfile = theModel.soundfile;
        model.picname = theModel.picname;
        model.content = theModel.content;
        model.position = theModel.position;
        model.gps = theModel.gps;
        model.soundlength = theModel.soundlength;
        if (model.msgtype==2||model.msgtype == 3) {
            if (model.msgtype == 2) {
                if ([model.picname isEqualToString:@""]) {
                    NSData *imageData = [NSData dataWithContentsOfFile:model.lpicname];
                    [self uploadFile:model userId:[ShuZhiZhangUserPreferences CurrentUserID] theData:imageData theType:1];
                }else{
                    [self insertDataToDB:model];
                    [self sendMessage:model];
                }
            }
            
            if (model.msgtype == 3) {
                if ([model.soundfile isEqualToString:@""]) {
                    NSData *soundData = [NSData dataWithContentsOfFile:model.lsoundfile];
                    [self uploadFile:model userId:[ShuZhiZhangUserPreferences CurrentUserID] theData:soundData theType:0];
                }else{
                    [self insertDataToDB:model];
                    [self sendMessage:model];
                }
            }
        }else{
            [self sendMessage:model];
        }
        [model release];
    }
}


-(void)deleteMessageCenterData{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:@"service" forKey:@"systype"];
    [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100000 Classtype:messageModel callback:^(NSArray *result)
     {
         [array addObjectsFromArray:result];
     }];
    if (array.count>0) {
        for (BPMessageCenterModel *theModel in array) {
            theModel.msgeCount = 0;
            [[DataFactory shardDataFactory] updateToDB:theModel Classtype:messageModel];
        }
    }
}


//取数据<------数据库
-(void)getDataFromDB{
    
    [[DataFactory shardDataFactory]searchChatMesg:[NSString stringWithFormat:@"oppositeId = '%@'",[ShuZhiZhangUserPreferences currentChatId]] orderBy:@"rowid" offset:markNumber count:10 Classtype:chatModel callback:^(NSArray *result){
        NSMutableArray *chatMessageArray = [NSMutableArray arrayWithCapacity:0];
        //////////NSLog(@"%@",result);
        if (result.count>0) {
            //result = [[result reverseObjectEnumerator] allObjects];
            //[dataArray addObjectsFromArray:result];
            
            result = [[result reverseObjectEnumerator] allObjects];
            [chatMessageArray addObjectsFromArray:result];
            [dataArray removeObjectsInArray:chatMessageArray];
            [chatMessageArray addObjectsFromArray:dataArray];
            [dataArray removeAllObjects];
            [dataArray addObjectsFromArray:chatMessageArray];
            
            if (result.count<10) {
                _refreshHeaderView.hidden = YES;
                if (markNumber != 0){
                 //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPGetHistoryFinish" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
                    
                      [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPGetHistoryFinish" InTable:@"BPMultiLanguage"] duration:2.0];
                    
                }
            }
        }else{
            _refreshHeaderView.hidden = YES;
            if (markNumber != 0){
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPGetHistoryFinish" InTable:@"BPMultiLanguage"] AndDisappearSecond:1];
                
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPGetHistoryFinish" InTable:@"BPMultiLanguage"] duration:2.0];

                
            }
        }
        
        
        if (markNumber == 0) {
            
            NSString *timeSp = [NSString stringWithFormat:@"%d",0];
            if (dataArray.count>0) {
                BPChatMessageModel *lastModel  = [dataArray objectAtIndex:dataArray.count-1];
                timeSp = lastModel.ltime;
            }
            
            NSString *imageUrl = [[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"];
            if(!imageUrl)
            {
                imageUrl = @"";
            }
            NSString *str = [NSString stringWithFormat:[BPLanguage getStringForKey:@"BPHelperFirstMsge" InTable:@"BPMultiLanguage"],gameName];
            NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences currentChatId],[ShuZhiZhangUserPreferences CurrentUserID],@"1",@"",@"",imageUrl,@"",@"",str,@"",@"",@"",timeSp,@"",@"",@"",@"",nil];
            NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
            NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
            BPChatMessageModel *model = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
            model.theType = 1;
            [dataArray addObject:model];
            [model release];

            if (dataArray.count>0) {
                [chatMesgeTableV scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
            }
            
        }else{
            
            [chatMesgeTableV reloadData];
            
        }
        
        
    }];
}

//插入数据
-(void)insertDataToDB:(BPChatMessageModel*)model{
    
    NSString *timeSp = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    //插入时间
    NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences currentChatId],@"5",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",nil];
    NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
    BPChatMessageModel *timeModel = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
    timeModel.ltime = timeSp;
    timeModel.time = timeSp;
    timeModel.theType = 2;

    
    //判断和前一条消息的间隔时间
    if (dataArray.count>0) {
        BPChatMessageModel *lastModel  = [dataArray objectAtIndex:dataArray.count-1];
        //判断两个日期间隔是否超过3分钟
        if ([timeModel.ltime floatValue]-[lastModel.ltime floatValue]>180) {
            [[DataFactory shardDataFactory] insertToDB:timeModel Classtype:chatModel];
            markNumber = markNumber +1;
            //////////NSLog(@"插入时间成功");
            [dataArray addObject:timeModel];
        }
    }else {
        //以前没有内容
        [[DataFactory shardDataFactory] insertToDB:timeModel Classtype:chatModel];
        markNumber = markNumber +1;
        //////////NSLog(@"插入时间成功");
        [dataArray addObject:timeModel];
    }
    [timeModel release];
    
    //标记发送中
    model.status = 0;
    model.ltime = timeSp;
    model.time = timeSp;
    [[DataFactory shardDataFactory] insertToDB:model Classtype:chatModel];
    markNumber = markNumber +1;
    [dataArray addObject:model];
    [chatMesgeTableV reloadData];
    if (dataArray.count>0) {
        [chatMesgeTableV scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}


//上传文件
-(void)uploadFile:(BPChatMessageModel*)model userId:(NSString*)uid theData:(NSData*)fileData theType:(int)type{
    [self insertDataToDB:model];
    [sendMsgeRequest uploadChatGroupFile:model theId:uid fileData:fileData theType:type];
}

//发送消息
-(void)sendMessage:(BPChatMessageModel*)model{
    if (model.msgtype == 1||model.msgtype == 4) {
        [self insertDataToDB:model];
    }
    
    
    [sendMsgeRequest sendMessage:model autoresponse:autoResponse];
    if([[model.content lowercaseString] isEqualToString:@"qt"]){
        //切换回人工模式
        /*if (autoResponse == 1) {
            showQuitMsge = YES;
        }else{
            showQuitMsge = NO;
        }*/
        autoResponse = 0;
        [btnOne setEnabled:YES];
        [btnTwo setEnabled:YES];
        [btnThree setEnabled:YES];
    }
    //[sendMsgeRequest sendMessage:model];
    
    [self updateMessageCenter:model];
    
}

//查看图片
-(void)showBigImage:(NSString*)imageurl smallImage:(UIImage*)image index:(int)index{
    
    bigImageView = [[UIView alloc] initWithFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH,SCREEN_HEIGHT)];
    
    [bigImageView setBackgroundColor:[UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1]];

    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundColor:[UIColor clearColor]];
    [btn setFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH,SCREEN_HEIGHT)];
    [btn addTarget:self action:@selector(cancelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [bigImageView addSubview:btn];
    
    
    bigImageV = [[HJManagedImageV alloc]initWithFrame:CGRectMake(0.0,22.0, SCREEN_WIDTH,SCREEN_HEIGHT_NAV)];
    [bigImageV setUserInteractionEnabled:NO];
    [bigImageV setContentMode:UIViewContentModeScaleAspectFit];
    [bigImageV setImage:image];
    [bigImageV setBackgroundColor:[UIColor clearColor]];
    [btn addSubview:bigImageV];
    [bigImageV release];
    self.navigationController.navigationBarHidden = YES;
    [self.navigationController.view addSubview:bigImageView];
    //[[[[UIApplication sharedApplication] delegate] window] addSubview:bigImageView];
}



#pragma mark - PlayerEnd delegte
-(void)audioPlayerDidFinishPlaying{
    BPRervicerOnlineCell *oldCell = (BPRervicerOnlineCell*)[chatMesgeTableV cellForRowAtIndexPath:[NSIndexPath indexPathForRow:markPlayCell inSection:0]];
    [oldCell.playView stopAnimating];
    isPlay = NO;
    markPlayCell = 0;
}

#pragma mark - image picker delegte
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{

    if (BPDevice_is_ipad) {
         [popover dismissPopoverAnimated:YES];
    }

    [picker dismissViewControllerAnimated:YES completion:^{
            
        }];
    
    //////////NSLog(@"FinishPickingMediaWithInfo ======= %@",info);
    NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences currentChatId],@"2",@"",[ShuZhiZhangUserPreferences CurrentNickname],[ShuZhiZhangUserPreferences currentUserHeadURLStr],@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",nil];
    NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
    BPChatMessageModel *model = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
    
    //压缩图片
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    //UIGraphicsBeginImageContext(CGSizeMake(228.0, 228.0));
    //[image drawInRect:CGRectMake(0,0,228,228.0)];
    
    float i=1;
    if (image.size.width>500.0) {
        i = 500/image.size.width;
    }
    
    UIGraphicsBeginImageContext(CGSizeMake(image.size.width*i,image.size.height*i));
    [image drawInRect:CGRectMake(0,0,image.size.width*i,image.size.height*i)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    //NSData *imageData = UIImagePNGRepresentation(newImage);
    NSData *imageData = UIImageJPEGRepresentation(newImage, 1.0);
    
    //存储image
    NSString *timeSp = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"/user/user_%@/sendFile/",[ShuZhiZhangUserPreferences CurrentUserID]]];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    NSString *imagePath  =  [path stringByAppendingPathComponent:timeSp];
    [imageData writeToFile:imagePath atomically:YES];
    model.picname = imagePath;
    model.lpicname= imagePath;
    [self uploadFile:model userId:[ShuZhiZhangUserPreferences CurrentUserID] theData:imageData theType:1];
    [model release];
    
    
    //UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    
}

#pragma mark - UIAlertView Delegate Method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        [[DataFactory shardDataFactory] clearTableData:chatModel];
        [[DataFactory shardDataFactory] clearTableData:messageModel];
        [dataArray removeAllObjects];
        [chatMesgeTableV reloadData];
        _refreshHeaderView.hidden = YES;
    }
}


#pragma mark - UIScrollViewDelegate
- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
	point =scrollView.contentOffset;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == chatMesgeTableV) {
        CGPoint pt =scrollView.contentOffset;
	    if (point.y < pt.y) {//向上提加载更多
        }
        else {
            if (_refreshHeaderView.hidden) {
                return;
            }
            [_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
            
      	}
    }else{
        CGFloat pageWidth = scrollView.frame.size.width;
        int page = floor((scrollView.contentOffset.x - pageWidth / 3) / pageWidth) + 1;
        pageControl.currentPage = page;
        [self updateDots];
    }
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    CGPoint pt =scrollView.contentOffset;
	if (point.y < pt.y) {//向上提加载更多
        
	}
	else {//向下拉加载更多
        if (_refreshHeaderView.hidden) {
            return;
        }
		[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	}
}

#pragma mark - EGORefreshTableHeaderDelegate Methods

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeadView *)view {
    return NO;
}

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeadView*)view{
	

    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 0.5*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self doneLoadingTableViewData];
    });
}

#pragma mark - UpdateHeaderViewAndFooterView

- (void)doneLoadingTableViewData{
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:chatMesgeTableV];
    markNumber = markNumber + 10;
    [self getDataFromDB];
}

#pragma mark - TableView DataSource && Delegate Method
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == showListTabView) {
        return 41;
    }else if (tableView == chatMesgeTableV){
        BPChatMessageModel *model = [dataArray objectAtIndex:indexPath.row];
        return   [BPRervicerOnlineCell getCellHight:model];
    }
    return 0.0;
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView==showListTabView) {
        return 4;
    }else if (tableView == chatMesgeTableV){
       return dataArray.count;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView == showListTabView) {
        static NSString *str1 = @"showListTableCell";
        BPShowTableListCell *cell = [tableView dequeueReusableCellWithIdentifier:str1];
        if (cell == nil) {
            cell = [[[BPShowTableListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str1] autorelease];
        }
        
        UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height)];
        backView.backgroundColor = [UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1];
        [cell.contentView addSubview:backView];
        [backView release];
        
        [cell.iconImage setImage:[UIImage imageNamed:[showIconArray objectAtIndex:indexPath.row]]];
        [cell.optionsLab setText:[showTittleArray objectAtIndex:indexPath.row]];
        [cell.optionsLab setTextColor:[UIColor whiteColor]];
        
        if (indexPath.row == selectMark) {
            [cell.iconImage setImage:[UIImage imageNamed:[showIconSelArray objectAtIndex:indexPath.row]]];
            [cell.optionsLab setTextColor:[UIColor colorWithRed:213/255.0 green:156/255.0 blue:35/255.0 alpha:0.95]];
        }else{
            [cell.iconImage setImage:[UIImage imageNamed:[showIconArray objectAtIndex:indexPath.row]]];
        }
        
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(4.0, 0.0, cell.frame.size.width, cell.frame.size.height)];
        [view setBackgroundColor:[UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:0.95]];
        [cell setSelectedBackgroundView:view];
        [view release];
        return cell;
    }
    
    if (tableView == chatMesgeTableV) {
        BPChatMessageModel *model = [dataArray objectAtIndex:indexPath.row];
        static NSString *str = @"cell";
        switch (model.msgtype) {
            case 1:
                str = @"textCell";
                break;
            case 2:
                str = @"photoCell";
                break;
            case 3:
                str = @"soundCell";
                break;
            case 4:
                str = @"mapCell";
                break;
            case 5:
                str = @"timeCell";
                break;
            default:
                break;
        }
        
        BPRervicerOnlineCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
        
        if (!cell) {
            cell = [[[BPRervicerOnlineCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str] autorelease];
            cell.backgroundColor = [UIColor clearColor];
        }
        [cell loadDataWithModel:model withType:model.theType];
        
        __block BPRervicerOnlineViewController *controller = self;
        __block BPChatMessageModel *chatModel = model;
        cell.getCopyMessage = ^(int type){
            if (type == 0) {
                //////////NSLog(@"复制消息");
                UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
                if (chatModel.msgtype == 1) {
                    [pasteboard setString:chatModel.content];
                }else if (chatModel.msgtype == 4){
                    [pasteboard setString:chatModel.position];
                }
            }else if (type == 1){
                //////////NSLog(@"删除消息");
                [controller deleteMessage:indexPath.row];
            }else if (type == 2){
                //////////NSLog(@"重发消息");
                [controller sendAgain:indexPath.row];
            }
        };
        
        __block BPRervicerOnlineCell *chatCell = cell;
        cell.showCopyView = ^(){
            if (chatModel.msgtype == 2||chatModel.msgtype == 3) {
                if (chatModel.status == 1) {
                    [controller showMenu:chatCell.messageBg theType:3];
                }
                return;
            }
            if (chatModel.status!=1) {
                [controller showMenu:chatCell.messageBg theType:1];
            }else{
                [controller showMenu:chatCell.messageBg theType:0];
            }
        };
        
        if (model.msgtype == 3&&model.theType == 0) {
            //[cell.playView setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_06.png"]];
            if (isPlay) {
                if (indexPath.row == markPlayCell) {
                    cell.playView.animationImages = rightImagesArray;
                    cell.playView.animationDuration = 1.0;
                    cell.playView.animationRepeatCount = 0;
                    [cell.playView startAnimating];
                }
            }
        }
        [cell.messageBtn setTag:indexPath.row+1000];
        [cell.messageBtn addTarget:self action:@selector(mapShowAction:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.messageBg.tag = indexPath.row;
        [cell.messageBg addTarget:self action:@selector(messageBgAction:) forControlEvents:UIControlEventTouchUpInside];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        return cell;
    }
    return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == showListTabView) {
        selectMark = indexPath.row;
        [showListTabView reloadData];
        rightBtnAction = NO;
        [self showList:rightBtnAction];
    }
    
    [inputView resignFirstResponder];
    if (btnTwoMark == 1||btnThreeMark == 1) {
        [chatMesgeTableV reloadData];
        [UIView animateWithDuration:0.2
                         animations:^{
                             footBarView.frame = CGRectMake(0.0, SCREEN_HEIGHT_NAV-hight,SCREEN_WIDTH,footBarView.frame.size.height);
                            [chatMesgeTableV setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-(SCREEN_HEIGHT_NAV-footBarView.frame.origin.y))];
                         }completion:^(BOOL finish){
                             btnTwoMark = 0;
                             btnThreeMark = 0;
                             footScr.hidden = YES;
                             emotionScr.hidden = YES;
                             pageControl.hidden = YES;
                         }];
    }
}

#pragma mark - UITextView Delegate Method
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (text.length<1&&range.length<1) {
        return YES;
    }
    
    if ([text isEqualToString:@""]) {
        NSMutableString *TextViewStr = [[NSMutableString alloc] initWithString:textView.text];
        NSString *str = [TextViewStr substringWithRange:range];
        if ([str isEqualToString:@"]"]) {
            //光标停留在"]"右端时
            if (range.location+1==TextViewStr.length) {
                //光标停留在"XX XX[XX XX]|"时删除
                if ([textView.text rangeOfString:@"["].location == NSNotFound){
                    //没有检测到"["
                    textViewStr = [NSString stringWithFormat:@"%@",[textView.text substringToIndex:textView.text.length]];
                } else {
                    //////////NSLog(@"textViewStr ========== %@",[TextViewStr substringFromIndex:range.location-3]);
                    //判断是否为表情
                    if (range.location+1>=4) {
                        for (NSString *str in faceArray) {
                            if ([str isEqualToString:[TextViewStr substringFromIndex:range.location-3]]) {
                                textViewStr = [NSString stringWithFormat:@"%@",[textView.text substringToIndex:[textView.text rangeOfString:@"[" options:NSBackwardsSearch].location+1]];
                                textView.text = textViewStr;
                                return YES;
                            }
                        }
                    }
                }
            }else{
                //光标停留在"[XX XX]| XX XX [XX XX]"时删除
                if ([[TextViewStr substringToIndex:range.location+1] rangeOfString:@"["].location != NSNotFound) {
                    if(range.location+1>=4){
                        NSRange test;
                        test.length = 4;
                        test.location = range.location-3;
                        //判断表情符
                        for (NSString *str in faceArray) {
                            if ([str isEqualToString:[TextViewStr substringWithRange:test]]) {
                                [TextViewStr deleteCharactersInRange:test];
                                textViewStr = [NSString stringWithFormat:@"%@]",[TextViewStr substringFromIndex:0]];
                                textView.text = textViewStr;
                                return YES;
                            }
                        }
                        return YES;
                    }
                }
            }
        }else if ([str isEqualToString:@"["]){
            //光标停留在"[|XX XX]"时删除
            if (TextViewStr.length-range.location>=4) {
                NSRange test;
                test.length = 4;
                test.location = range.location;
                for (NSString *str in faceArray) {
                    if ([str isEqualToString:[TextViewStr substringWithRange:test]]) {
                        [TextViewStr deleteCharactersInRange:test];
                        //////////NSLog(@"range.location.range.location.range.location ========== %@",[TextViewStr substringFromIndex:0]);
                        textViewStr = [NSString stringWithFormat:@"%@]",[TextViewStr substringFromIndex:0]];
                        textView.text = textViewStr;
                        return YES;
                    }
                }
            }
            
        }else {
            //光标停留在"[XX | XX]或[XX XX|]"时删除
            NSRange test1;
            test1.length = 1;
            test1.location = range.location-1;
            
            NSRange test2;
            test2.length = 1;
            test2.location = range.location-2;
            
            if (range.location>=1) {
                if ([[TextViewStr substringWithRange:test1] isEqualToString:@"["]) {
                    //光标停留在"[XX|XX]"内部时删除
                    test1.length = 4;
                    if (test1.location+4<=TextViewStr.length) {
                        for (NSString *str in faceArray) {
                            if ([str isEqualToString:[TextViewStr substringWithRange:test1]]) {
                                [TextViewStr deleteCharactersInRange:test1];
                                textViewStr = [NSString stringWithFormat:@"%@]",[TextViewStr substringFromIndex:0]];
                                textView.text = textViewStr;
                                return YES;
                            }
                        }
                    }
                }else{
                    if (range.location>=2) {
                        if ([[TextViewStr substringWithRange:test2] isEqualToString:@"["]){
                            //光标停留在"[XX XX|]"内部时删除
                            test2.length = 4;
                            if (test2.location+4<=TextViewStr.length) {
                                for (NSString *str in faceArray) {
                                    if ([str isEqualToString:[TextViewStr substringWithRange:test2]]) {
                                        [TextViewStr deleteCharactersInRange:test2];
                                        textViewStr = [NSString stringWithFormat:@"%@]",[TextViewStr substringFromIndex:0]];
                                        textView.text = textViewStr;
                                        return YES;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            textViewStr = [NSString stringWithFormat:@"%@",[textView.text stringByReplacingOccurrencesOfString:str withString:@""]];
        }
        //textView.text = textViewStr;
        [TextViewStr release];
    }
    
    if (inputView.contentSize.height<36&&inputView.contentSize.height>0) {
        
        if(!BP_Show_IOS7)
        {
            inputView.scrollEnabled = NO;
        }
    }else{
        inputView.scrollEnabled = YES;
    }
    
    if ([text isEqualToString:@"\n"])
        
    {
        if ([textView.text isEqualToString:@""]) {
            /*UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"消息不能为空" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            [alertView release];*/
            
            BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:[BPLanguage getStringForKey:@"BPPrompt" InTable:@"BPMultiLanguage"] message:[BPLanguage getStringForKey:@"BPCouldNoMessage" InTable:@"BPMultiLanguage"]  delegate:self cancelButtonTitle:[BPLanguage getStringForKey:@"BPDetermined" InTable:@"BPMultiLanguage"] otherButtonTitles: nil];
            [alert show];
            [alert release];
            return NO;
        }
        
        NSString *imageHead = @"";
        if ([ShuZhiZhangUserPreferences currentUserHeadURLStr]) {
            imageHead = [ShuZhiZhangUserPreferences currentUserHeadURLStr];
        }
        //////////NSLog(@"[ShuZhiZhangUserPreferences currentUserHeadURLStr] ======== %@",[ShuZhiZhangUserPreferences currentUserHeadURLStr]);
        NSArray *messsage = [NSArray arrayWithObjects:[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences currentChatId],@"1",@"",[ShuZhiZhangUserPreferences CurrentNickname],imageHead,@"",@"",textView.text,@"",@"",@"",@"",@"",@"",@"",@"",nil];
        NSArray *keysArray = [NSArray arrayWithObjects:@"fid",@"tid",@"msgtype",@"status",@"nickname",@"image",@"picname",@"soundlength",@"content",@"soundfile",@"position",@"gps",@"ltime",@"time",@"systype",@"lsoundfile",@"lpicname",nil];
        NSDictionary *dic = [NSDictionary dictionaryWithObjects:messsage forKeys:keysArray];
        BPChatMessageModel *model = [[BPChatMessageModel alloc] initWithJsonDictionary:dic];
        model.content = [ShuZhiZhangUtility filterSomeWord:wordArray theContent:model.content];  // 敏感词
        [self sendMessage:model];
        [model release];
        [textView setText:@""];
        
        if (!SCREEN_IS_LANDSCAPE) {
            inputView.contentInset = UIEdgeInsetsMake(0, 0,-4, 0);
            inputView.scrollEnabled = NO;
        }
        
        return NO;
    }
    return YES;
}


- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;
{
    return YES;
}


#pragma mark - RecordManagerDelegate
-(void)updateSoundViewWithAvg:(CGFloat )avg peak:(CGFloat)peak
{
    NSInteger imageIndex = 0;
    
    if (avg >= -160 && avg < -100)
        imageIndex = 0;
    else if (avg >= -100 && avg < -80)
        imageIndex = 1;
    else if (avg >= -80 && avg < -40)
        imageIndex = 2;
    else if (avg >= -40 && avg < -35)
        imageIndex = 3;
    else if (avg >= -35 && avg < -30)
        imageIndex = 4;
    else if (avg >= -30 && avg < -25)
        imageIndex = 5;
    else if (avg >= -20 && avg < -15)
        imageIndex = 6;
    else if (avg >= -15 && avg < -10)
        imageIndex = 7;
    else if (avg >= -10 && avg < -6)
        imageIndex = 8;
    else if (avg >= -6 && avg <=0)
        imageIndex = 9;
    [speakAnimV setImage:[UIImage imageNamed:[speakImageArray objectAtIndex:imageIndex]]];
}

#pragma mark - keybord mothed
- (void)keyboardWillShow:(NSNotification *)notification
{
    
    if(SCREEN_IS_LANDSCAPE)
    {
       showListView.hidden = YES;
       [self.navigationController setNavigationBarHidden:YES animated:YES];
    }
 	NSDictionary *userInfo = [notification userInfo];
    
    // Get animation info from userInfo
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    //////////NSLog(@"keyboardEndFrame:%@",NSStringFromCGRect(keyboardEndFrame));
    //重新设置inputContainer高度，让输入框出现在键盘上面
    CGRect inputFrame = footBarView.frame;
    //64＝20＋44。20是statusbar的高度，44是navigationbar的高度
    //取到的keyboardEndFrame的orgin是相对于window的
    CGSize kbSize=[[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    //////////NSLog(@"hight.size ======== %f",[[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height);
    if(SCREEN_IS_LANDSCAPE && !BP_IS_OS_8_OR_LATER)
    {
        if (BPDevice_is_ipad) {
            
            //inputFrame.origin.y = REAL_SCREEN_HEIGHT - hight - kbSize.width;
            inputFrame.origin.y = SCREEN_HEIGHT_NAV-252+406-kbSize.width;
//            if (BPDeviceSystemVersion_IOS7)
//            {
//                inputFrame.origin.y = SCREEN_HEIGHT_NAV-272+406-kbSize.width;
//            }
        }else{
            
            inputFrame.origin.y = SCREEN_HEIGHT_NAV-kbSize.width-6;
            
        }
    }else{
        if (BPDevice_is_ipad) {
            
            inputFrame.origin.y = SCREEN_HEIGHT_NAV-252+406-kbSize.height;
//            if (BPDeviceSystemVersion_IOS7)
//            {
//                inputFrame.origin.y = SCREEN_HEIGHT_NAV-262+406-kbSize.height;
//            }
        }else{
            
            inputFrame.origin.y = SCREEN_HEIGHT_NAV-kbSize.height-48; 
        }
 
    }
    
    if (!rightBtnAction) {
        rightBtnAction = NO;
        selectMark = 5;
        [self showList:rightBtnAction];
    }
    [UIView animateWithDuration:0.2
                     animations:^{
                         btnTwoMark = 0;
                         btnThreeMark = 0;
                         footScr.hidden = YES;
                         emotionScr.hidden = YES;
                         pageControl.hidden = YES;
                         footBarView.frame = inputFrame;
                         [chatMesgeTableV setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-(SCREEN_HEIGHT_NAV-inputFrame.origin.y))];
                         ////////NSLog(@"decelerating ==== %d",chatMesgeTableV.decelerating);
                         //[chatMessageTable reloadData];
                         if (dataArray.count>0&&!chatMesgeTableV.decelerating) {
                             [chatMesgeTableV scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
                         }
                     }completion:^(BOOL finish){
                         
                     }];
    
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    if(SCREEN_IS_LANDSCAPE)
    {
       [self.navigationController setNavigationBarHidden:NO];
    }
	//////////NSLog(@"keyboardWillHide");
 	NSDictionary *userInfo = [notification userInfo];
    
    // Get animation info from userInfo
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    //把输入框位置下移
    CGRect inputFrame = footBarView.frame;
    //64＝20＋44。20是statusbar的高度，44是navigationbar的高度
    //取到的keyboardEndFrame的orgin是相对于window的

    inputFrame.origin.y = SCREEN_HEIGHT_NAV-hight;
    [chatMesgeTableV reloadData];
    [UIView animateWithDuration:0.2
                     animations:^{
                         footBarView.frame = inputFrame;
                         //if (btnTwoMark == 0&&btnThreeMark == 0&&btnOneMark == 0) {
                             [chatMesgeTableV setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-(SCREEN_HEIGHT_NAV-inputFrame.origin.y))];
                         //}
                     }completion:^(BOOL finish){
                         
                     }];
    
}

#pragma mark - DPHttpRequestBase delegate mothed
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    //////////NSLog(@"url=%@,data=%@",request.url,[request responseString]);
    id model = [request.userInfo objectForKey:@"RequestTag"];
    //NSMutableDictionary *requestDic = [request.responseString JSONValue];
    //////////NSLog(@"model ********-------->>>>%@",model);
    //////////NSLog(@"request.tag ================ %d",request.tag);
    switch (request.tag) {
        case 1008611:{
            //发送消息
            BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
            if (msgModel.msgtype != 7) {
                msgModel.time = [request responseString];
                msgModel.status = 2;
                [[BPPublicHandle sharedPublicHandle] updateLastTime:[request responseString]];
                [[DataFactory shardDataFactory] updateToDB:msgModel Classtype:chatModel];
                [chatMesgeTableV reloadData];
            }

        }
            break;
        case 100002:{
            //上传聊天图片
            BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
            msgModel.picname = [NSString stringWithFormat:@"%@%@",GLOBAL_DOMAIN_URL,[request responseString]];
            [self sendMessage:msgModel];
            [[DataFactory shardDataFactory] updateToDB:msgModel Classtype:chatModel];
            
        }
            break;
            
        case 100003:{
            //上传语音
            BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
            msgModel.soundfile = [NSString stringWithFormat:@"%@%@",GLOBAL_DOMAIN_URL,[request responseString]];
            msgModel.status = 2;
            [self sendMessage:msgModel];
            [[DataFactory shardDataFactory] updateToDB:msgModel Classtype:chatModel];
        }
            break;
        case 200000:{
            //////////NSLog(@"index ======= %@",[request.userInfo objectForKey:@"fileIndex"]);
            //下载文件
            BPChatMessageModel *msgeModel = (BPChatMessageModel*)model;
            NSData *fileData = [request responseData];
            
            ////////NSLog(@"%@",model);
            
            NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"/user/user_%@/sendFile/",[ShuZhiZhangUserPreferences CurrentUserID]]];
            if(![[NSFileManager defaultManager] fileExistsAtPath:path])
            {
                [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
            }
            

            
            NSString *imagePath  =  [path stringByAppendingPathComponent:[ShuZhiZhangUtility getFileNameWithURLStr:msgeModel.soundfile]];

            [fileData writeToFile:imagePath atomically:YES];
            msgeModel.lsoundfile = imagePath;
            msgeModel.rowid = 0;
            //msgeModel.primaryKey = @"oppositeId";
            //msgeModel.oppositeId
            //////////NSLog(@"msgeModel.locfile =========== %@",msgeModel.lsoundfile);
            
            [[DataFactory shardDataFactory] updateToDB:msgeModel Classtype:chatModel];
//            [playManager playWithAMRData:fileData];
        }
            break;
        default:
            break;
    }

}

-(void)requestDidFailed:(ASIHTTPRequest *)request{
    
    id model = [request.userInfo objectForKey:@"RequestTag"];
    if (request.tag != 200000) {
        BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
        if (msgModel.msgtype != 7) {
            msgModel.status = 1;
            [[DataFactory shardDataFactory] updateToDB:msgModel Classtype:chatModel];
            /*for (BPChatMessageModel *model in dataArray) {
             if (model.theType == 0&&model.msgtype == msgModel.msgtype&&model.rowid == msgModel.rowid) {
             model.status = msgModel.status;
             }
             }*/
            [chatMesgeTableV reloadData];
        }
    }
}


#pragma mark - UIGestureRecognizerDelegate
//点击空白--->收键盘
-(void)handleSingleTap:(UIGestureRecognizer *)gestureRecognizer
//-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    rightBtnAction = NO;
    [self showList:rightBtnAction];
    [inputView resignFirstResponder];
    if (btnTwoMark == 1||btnThreeMark == 1) {
        [chatMesgeTableV reloadData];
        [UIView animateWithDuration:0.2
                         animations:^{
                             footBarView.frame = CGRectMake(0.0, SCREEN_HEIGHT_NAV-hight,SCREEN_WIDTH,footBarView.frame.size.height);
                             [chatMesgeTableV setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV-(SCREEN_HEIGHT_NAV-footBarView.frame.origin.y))];
                         }completion:^(BOOL finish){
                             btnTwoMark = 0;
                             btnThreeMark = 0;
                             footScr.hidden = YES;
                             emotionScr.hidden = YES;
                             pageControl.hidden = YES;
                         }];
    }
}

#pragma mark - Notification Method

//刷新列表
-(void)updateCell:(NSNotification *)notification{
    
    BPChatMessageModel *model = [notification object];
    [self updateMessageCenter:model];
    [self insertDataToDB:model];
}


- (void)updateMessageCenter:(BPChatMessageModel*)model{
    NSString *timeSp = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    BPMessageCenterModel *msgeModel = [[BPMessageCenterModel alloc] initWithModel:model];
    msgeModel.ltime = timeSp;
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:@"service" forKey:@"systype"];
    [[DataFactory shardDataFactory]searchWhere:dic orderBy:nil offset:0 count:100000 Classtype:messageModel callback:^(NSArray *result)
     {
         [array addObjectsFromArray:result];
     }];
    if (array.count>0) {
        for (BPMessageCenterModel *theModel in array) {
            [[DataFactory shardDataFactory] deleteToDB:theModel Classtype:messageModel];
        }
    }
    
    [[DataFactory shardDataFactory] insertToDB:msgeModel Classtype:messageModel];
    [msgeModel release];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}
@end
