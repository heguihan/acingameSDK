//
//  BPMessageCenterCell.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import "HJManagedImageV.h"
#import "BPMessageCenterModel.h"

@interface BPMessageCenterCell : UITableViewCell{
    HJManagedImageV *iconImage;        //icon
    UILabel *nickNameLab;              //消息来自...
    HJManagedImageV *smallIcon;        //smallIcon
    UILabel *contentLab;               //消息简介
    UILabel *timeLab;                  //时间
    UILabel *countLab;                 //消息计数
    UIImageView *countBg;              //背景图
}

@property(nonatomic,retain)UILabel *nickNameLab;
@property(nonatomic,retain)UILabel *contentLab;
@property(nonatomic,retain)UILabel *timeLab;
@property(nonatomic,retain)UILabel *countLab;
@property(nonatomic,retain)UIImageView *countBg;

@property(nonatomic,retain)HJManagedImageV *smallIcon;
@property(nonatomic,retain)HJManagedImageV *iconImage;


-(void)addDataWithModel:(BPMessageCenterModel*)model;

@end
