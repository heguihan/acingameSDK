//
//  EmoticonTextView.m
//  BigPlayers
//
//  Created by Jun on 9/5/13.
//  Copyright (c) 2016 teamtop3. All rights reserved.
//

#import "EmoticonTextView.h"


#define kBeginFlag @"["
#define kEndFlag @"]"

#define kInterval    5
#define kRowledge     1

@interface EmoticonTextView (){
    
    float maxWidth;
    
    float faceWidth;
    float faceHeight;
}
@property (nonatomic,retain) NSString * text;
@property (nonatomic,retain) NSString * primary;
@property (nonatomic,retain) NSString * secondary;
@property (nonatomic,retain) NSString * separator;

@property (nonatomic,retain) UIFont * font;
@property (nonatomic,retain) UIColor * textColor;

@property (nonatomic,retain) NSDictionary * emoticonDic;
@end

@implementation EmoticonTextView
@synthesize text;
@synthesize primary;
@synthesize secondary;
@synthesize separator;

@synthesize textColor;
@synthesize font;
@synthesize emoticonDic;

- (void)dealloc
{
    [text release]; text = nil;
    [primary release]; primary = nil;
    [secondary release]; secondary = nil;
    [separator release]; separator = nil;
    
    [font release]; font = nil;
    [textColor release]; textColor = nil;
    [emoticonDic release]; emoticonDic = Nil;
    [super dealloc];
}

/**
 * _text 内容
 * _font 字体
 * _color 颜色
 **/
- (id)initWithFrame:(CGRect)frame
               text:(NSString *)_text
               font:(UIFont *)_font
          textColor:(UIColor *)_color
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor  = [UIColor whiteColor];
        NSString * path = @"";
        path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
        path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"faceMap_receive.plist"]];
        self.emoticonDic = [NSDictionary dictionaryWithContentsOfFile:path];
        
        maxWidth = frame.size.width - kInterval * 2;
        
        faceWidth = _font.pointSize + 6;
        faceHeight = _font.pointSize + 6 + kRowledge;
        
        self.text = _text;
        self.primary = @"";
        self.secondary = @"";
        self.separator = @"";
        
        self.font = _font;
        self.textColor = _color;
        
    }
    return self;
}



/**
 * _text 内容
 * _primary 主
 * _secondary 次
 * _separator 分隔符
 * _font 字体
 * _color 颜色
 **/
- (id)initWithFrame:(CGRect)frame
               text:(NSString *)_text
            primary:(NSString *)_primary
          secondary:(NSString *)_secondary
          separator:(NSString *)_separator
               font:(UIFont *)_font
          textColor:(UIColor *)_color
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor  = [UIColor whiteColor];
        NSString * path = @"";
        path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
        path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"faceMap_receive.plist"]];
        self.emoticonDic = [NSDictionary dictionaryWithContentsOfFile:path];
        
        
        maxWidth = frame.size.width - kInterval * 2;
        faceWidth = _font.pointSize + 6;
        faceHeight = _font.pointSize + 6 + kRowledge;
        
        self.text = _text;
        self.primary = _primary;
        self.secondary = _secondary;
        self.separator = _separator;
        
        self.font = _font;
        self.textColor = _color;
        
        [self headLabelLayout];
    }
    return self;
}

// 回复布局
- (void)headLabelLayout{
    
    CGFloat upX = 0;
    CGFloat upY = 0;
    CGFloat X = 0;
    CGFloat Y = 0;
    
    NSMutableArray * array = [[NSMutableArray alloc] init];
    int lastIndex = 0;
    
    NSArray * heads = [NSArray arrayWithObjects:primary,separator,secondary, nil];
    
    for (int index = 0; index < [heads count]; index ++) {
        
        NSString * content = [heads objectAtIndex:index];
        
        lastIndex = 0;
        
        //primary
        for (int j = 0; j < [content length]; j++) {
            NSString * temp = [content substringWithRange:NSMakeRange(j, 1)];
            
            
            CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
            
            if (upX + size.width >= maxWidth)
            {
                NSRange range;
                range.location = lastIndex;
                range.length = j - lastIndex;
                
                NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                      [content substringWithRange:NSMakeRange(lastIndex, j - lastIndex)],@"text",
                                      [NSNumber numberWithInt:index],@"tag", nil];
                
                [array addObject:dic];
                lastIndex = j;
                
                upY = upY + faceHeight;
                upX = 0;
                X = maxWidth;
                Y =upY;
            }
            
            upX=upX+size.width;
            if (X<maxWidth) {
                X = upX;
            }
        }
        
        NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:
                              [content substringFromIndex:lastIndex],@"text",
                              [NSNumber numberWithInt:index],@"tag", nil];
        [array addObject:dic];
    }
    
    float sub_x = 0;
    float sub_y = 0;
    
    for (int index = 0; index < [array count]; index ++) {
        
        NSString * temp = [[array objectAtIndex:index] objectForKey:@"text"];
        CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
        
        if (sub_x + size.width >= maxWidth) {
            sub_x = 0;
            sub_y = sub_y + faceHeight;
        }
        
        int tag = [[[array objectAtIndex:index] objectForKey:@"tag"] intValue];
        
        UIButton * sub = [UIButton buttonWithType:UIButtonTypeCustom];
        sub.tag = 1000 + [[[array objectAtIndex:index] objectForKey:@"tag"] intValue];
        sub.frame = CGRectMake(sub_x,sub_y,size.width,size.height);
        [sub setTitleColor:[UIColor colorWithRed:(float)(53.0f/255.0f) green:(float)(71.0f/255.0f) blue:(float)(140.0f/255.0f) alpha:1.0f] forState:UIControlStateNormal];
        [sub setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
        [sub setTitleColor:[UIColor blackColor] forState:UIControlStateDisabled];
        [sub setTitle:temp forState:UIControlStateNormal];
        sub.titleLabel.font = font;
        sub.titleLabel.lineBreakMode = UILineBreakModeTailTruncation;
        sub.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [sub addTarget:self action:@selector(selectText:) forControlEvents:UIControlEventTouchDragInside | UIControlEventTouchDown];
        [sub addTarget:self action:@selector(cancelSelectText:) forControlEvents:UIControlEventTouchDragOutside | UIControlEventTouchUpInside];
        [self addSubview:sub];
        
        if (tag == 1) {
            sub.enabled = NO;
        }
        sub_x = sub_x + size.width;
        
    }
}


- (void)selectText:(UIButton *)sender
{
    for (UIButton * sub in [[sender superview] subviews]) {
        if (sub.tag == sender.tag) {
            [sub setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
    }
}

- (void)cancelSelectText:(UIButton *)sender
{
    for (UIButton * sub in [[sender superview] subviews]) {
        if (sub.tag == sender.tag) {
            [sub setTitleColor:[UIColor colorWithRed:(float)(53.0f/255.0f) green:(float)(71.0f/255.0f) blue:(float)(140.0f/255.0f) alpha:1.0f] forState:UIControlStateNormal];
        }
    }
}


- (void)updateView{
    
    [self setNeedsDisplay];
}


-(void)getImageRange:(NSString*)string array:(NSMutableArray*)array
{
    NSRange range=[string rangeOfString: kBeginFlag];
    NSRange range1=[string rangeOfString: kEndFlag];
    
    //判断是否还有表情
    if (range.length>0 && range1.length>0) {
        
        if (range.location > 0) {
            
            [array addObject:[string substringToIndex:range.location]];
            [array addObject:[string substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)]];
            NSString *str=[string substringFromIndex:range1.location+1];
            [self getImageRange:str array:array];
            
        }else {
            
            NSString *nextstr=[string substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)];
            //排除文字是“”的
            if (![nextstr isEqualToString:@""]) {
                [array addObject:nextstr];
                NSString *str=[string substringFromIndex:range1.location+1];
                [self getImageRange:str array:array];
            }else {
                return;
            }
        }
        
    } else if (string != nil) {
        [array addObject:string];
    }
}


+ (void)getImageRange:(NSString*)string array:(NSMutableArray*)array
{
    NSRange range=[string rangeOfString: kBeginFlag];
    NSRange range1=[string rangeOfString: kEndFlag];
    
    //判断是否还有表情
    if (range.length>0 && range1.length>0) {
        
        if (range.location > 0) {
            
            [array addObject:[string substringToIndex:range.location]];
            [array addObject:[string substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)]];
            NSString *str=[string substringFromIndex:range1.location+1];
            [self getImageRange:str array:array];
            
        }else {
            
            NSString *nextstr=[string substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)];
            //排除文字是“”的
            if (![nextstr isEqualToString:@""]) {
                [array addObject:nextstr];
                NSString *str=[string substringFromIndex:range1.location+1];
                [self getImageRange:str array:array];
            }else {
                return;
            }
        }
        
    } else if (string != nil) {
        [array addObject:string];
    }
}






/**
 * 计算height
 * text 内容
 * font 字体
 * maxWidth 显示宽度
 **/
+ (CGSize)viewHeightText:(NSString *)text
                   font:(UIFont *)_font
               maxWidth:(float)maxWidth
{
    
    return [self viewHeightText:text
                        primary:@""
                      secondary:@""
                      separator:@""
                           font:_font
                       maxWidth:maxWidth];
}

/**
 * 计算height
 * text 内容
 * primary 主
 * secondary 次
 * separator 分隔符
 * font 字体
 * maxWidth 显示宽度
 **/
+ (CGSize)viewHeightText:(NSString *)text
                primary:(NSString *)primary
              secondary:(NSString *)secondary
              separator:(NSString *)separator
                   font:(UIFont *)font
               maxWidth:(float)maxWidth
{
    
    NSString * path = @"";
    path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"faceMap_receive.plist"]];
    NSDictionary * emoticonDic = [NSDictionary dictionaryWithContentsOfFile:path];

    
    maxWidth = maxWidth - kInterval * 2;
    
    
    float faceWidth = font.pointSize + 6;
    float faceHeight = font.pointSize + 6 + kRowledge;
    
    float max_w = 0;
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [self getImageRange:text array:array];
    NSArray * data = array;
    
    //UIFont * textFont = [UIFont systemFontOfSize:fontSize];
    
    CGFloat upX = 0;
    CGFloat upY = 0;
    CGFloat X = 0;
    CGFloat Y = 0;
    
    // primary+separator+secondary (eg:Jun@zong)
    if (primary || secondary || separator) {
        
        primary = primary ? primary: @"";
        secondary = secondary ? secondary: @"";
        separator = separator ? separator: @"";
        
        NSString * headLable = [NSString stringWithFormat:@"%@%@%@",primary,separator,secondary];
        
        //headLable
        for (int j = 0; j < [headLable length]; j++) {
            NSString *temp = [headLable substringWithRange:NSMakeRange(j, 1)];
            
            CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
            
            if (upX + size.width >= maxWidth)
            {
                upY = upY + faceHeight;
                upX = 0;
                X = maxWidth;
                Y =upY;
            }
            
            
            upX=upX+size.width;
            if (X<maxWidth) {
                X = upX;
            }
            
            if (max_w < upX) {max_w = upX;}//最大width
        }
    }
    
    
    //conentLable
    if (data) {
        
        // 遍历
        for (int i=0;i < [data count];i++) {
            NSString *str=[data objectAtIndex:i];
            
            if ([str hasPrefix: kBeginFlag] && [str hasSuffix: kEndFlag] && emoticonDic && [emoticonDic objectForKey:[str stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"[]"]]])
            {
                // 表情
                if (upX + faceWidth >= maxWidth)
                {
                    upY = upY + faceHeight;
                    upX = 0;
                    X = maxWidth;
                    Y = upY;
                }
                
                
                upX=faceWidth+upX;
                if (X<maxWidth) X = upX;
                
                if (max_w < upX) {max_w = upX;}//最大width

            }else {
                // 文本
                
                for (int j = 0; j < [str length]; j++) {
                    NSString *temp = [str substringWithRange:NSMakeRange(j, 1)];
                    
                    if ([temp isEqualToString:@"\n"]) {// is \n
                        
                        upY = upY + faceHeight;
                        upX = 0;
                        X = maxWidth;
                        Y =upY;
                        
                    }else{
                        
                        CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
                        if (upX+ size.width >= maxWidth)
                        {
                            upY = upY + faceHeight;
                            upX = 0;
                            X = maxWidth;
                            Y =upY;
                        }
                        
                        upX=upX+size.width;
                        if (X<maxWidth) {
                            X = upX;
                        }
                        
                        if (max_w < upX) {max_w = upX;}//最大width

                    }// !\n
                }
            }
        }
    }
    
    [array release];
    
    CGSize v_size = CGSizeMake(max_w, Y + faceHeight);
    return v_size;
}




- (void)drawRect:(CGRect)rect
{
    NSMutableArray *array = [[[NSMutableArray alloc] init] autorelease];
    [self getImageRange:text array:array];
    NSArray * data = array;
    
    CGFloat upX = 0;
    CGFloat upY = 0;
    CGFloat X = 0;
    CGFloat Y = 0;
    
    ////headLable  primary+separator+secondary (eg:Jun@zong)
    if (primary || secondary || separator) {
        
        primary = primary ? primary: @"";
        secondary = secondary ? secondary: @"";
        separator = separator ? separator: @"";
        
        NSString * headLable = [NSString stringWithFormat:@"%@%@%@",primary,separator,secondary];
        
        for (int j = 0; j < [headLable length]; j++) {
            NSString *temp = [headLable substringWithRange:NSMakeRange(j, 1)];
            
            CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
            
            if (upX + size.width >= maxWidth)
            {
                upY = upY + faceHeight;
                upX = 0;
                X = maxWidth;
                Y =upY;
            }
                        
            upX=upX+size.width;
            if (X<maxWidth) {
                X = upX;
            }
        }
    }
    
    //conentLable
    if (data) {
        
        // 遍历
        for (int i=0;i < [data count];i++) {
            NSString *str=[data objectAtIndex:i];
            
            if ([str hasPrefix: kBeginFlag] && [str hasSuffix: kEndFlag] && emoticonDic && [emoticonDic objectForKey:[str stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"[]"]]])
            {
                // 表情
                if (upX + faceWidth >= maxWidth)
                {
                    upY = upY + faceHeight;
                    upX = 0;
                    X = maxWidth;
                    Y = upY;
                }
                
                NSString * name= [str stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"[]"]];
                NSString * path = [emoticonDic objectForKey:name];
                UIImage * emoticon= [UIImage imageNamed:[NSString stringWithFormat:@"ShuZhiZhang.bundle/face/BP_%@.png",path]];
                
                [emoticon drawInRect:CGRectMake(upX, upY, faceWidth, faceHeight - kRowledge)];
                
                upX=faceWidth+upX;
                if (X<maxWidth) X = upX;
                
                
            }else {
                // 文本
                
                for (int j = 0; j < [str length]; j++) {
                    NSString *temp = [str substringWithRange:NSMakeRange(j, 1)];
                    
                    if ([temp isEqualToString:@"\n"]) {// is \n
                        
                        upY = upY + faceHeight;
                        upX = 0;
                        X = maxWidth;
                        Y =upY;

                    }else{
                        
                        CGSize size = [temp sizeWithFont:font constrainedToSize:CGSizeMake(maxWidth, 40) lineBreakMode:UILineBreakModeTailTruncation];
                        if (upX+ size.width >= maxWidth)
                        {
                            upY = upY + faceHeight;
                            upX = 0;
                            X = maxWidth;
                            Y =upY;
                        }
                        
                        [textColor set];
                        [temp drawInRect:CGRectMake(upX,upY,size.width,size.height) withFont:font lineBreakMode:UILineBreakModeTailTruncation alignment:UITextAlignmentLeft];
                        
                        upX=upX+size.width;
                        if (X<maxWidth) {
                            X = upX;
                        }
                    }//!\n
                }
            }
        }
    }
}


@end
