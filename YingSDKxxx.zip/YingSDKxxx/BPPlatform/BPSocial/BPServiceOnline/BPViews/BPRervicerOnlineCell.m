//
//  BPRervicerOnlineCell.m
//  BigPlayerSDK
//

#import "BPRervicerOnlineCell.h"
#import "BPChatMessageModel.h"
#import "BPPublicHandle.h"
#import "BigPlayerSDKBase.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"


#define BEGIN_FLAG @"["
#define END_FLAG @"]"

#define MSGE_WIDTH  (SCREEN_IS_LANDSCAPE ? 220 : 140)


@implementation BPRervicerOnlineCell
NSString *userLatitude;

NSString *userlongitude;

@synthesize headImage,headImageBtn,messageBg,photoMessView,leftLine,timeLab,rightLine,map,mark,messageBtn,soundLength,returnView,cellHight,stateLab;

@synthesize playView = _palyView;
@synthesize getCopyMessage = _getCopyMessage;
@synthesize showCopyView = _showCopyView;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        if ([reuseIdentifier isEqualToString:@"timeCell"]) {
            
            self.backgroundColor = [UIColor clearColor];
            
            //虚线左
            leftLine = [[UIImageView alloc]initWithFrame:CGRectZero];
            [leftLine setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_line_date.png"]];
            [leftLine setBackgroundColor:[UIColor clearColor]];
            [self addSubview:leftLine];
            
            //时间
            timeLab = [[UILabel alloc]initWithFrame:CGRectZero];
            //[timeLab setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@""]]];
            [timeLab setBackgroundColor:[UIColor clearColor]];
            [timeLab setFont:[UIFont systemFontOfSize:10.0f]];
            [timeLab setTextColor:[UIColor colorWithRed:150/255.0 green:150/255.0 blue:150/255.0 alpha:1]];
            [self addSubview:timeLab];
         
            
            //虚线右
            rightLine = [[UIImageView alloc]initWithFrame:CGRectZero];
            [rightLine setBackgroundColor:[UIColor clearColor]];
            [rightLine setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_line_date.png"]];
            [self addSubview:rightLine];
           
        }
        else{
            //头像
            headImage = [[HJManagedImageV alloc]initWithFrame:CGRectZero];
            [headImage setBackgroundColor:[UIColor clearColor]];
            [headImage setImage:[UIImage imageNamed:@"photo_01.png"]];
            [self addSubview:headImage];
           
            
            headImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            [headImageBtn setBackgroundColor:[UIColor clearColor]];
            [headImageBtn setFrame:CGRectZero];
            [self addSubview:headImageBtn];
            
            //消息背景
            messageBg = [UIButton buttonWithType:UIButtonTypeCustom];
            [messageBg setFrame:CGRectZero];
            [messageBg setBackgroundColor:[UIColor clearColor]];
            UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(btnLong:)];
            longPress.minimumPressDuration = 0.5;        //定义按的时间
            [messageBg addGestureRecognizer:longPress];
            [self addSubview:messageBg];
            
            failImageV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_alert.png"]];
            [failImageV setBackgroundColor:[UIColor clearColor]];
            [self addSubview:failImageV];
            
            //发送状态
            stateLab = [[UILabel alloc]initWithFrame:CGRectZero];
            [stateLab setBackgroundColor:[UIColor clearColor]];
            [stateLab setFont:[UIFont systemFontOfSize:10.0]];
            [stateLab setTextAlignment:NSTextAlignmentLeft];
            [stateLab setTextColor:[UIColor colorWithRed:150/255.0 green:150/255.0 blue:150/255.0 alpha:1]];
            [self addSubview:stateLab];
           
            
            if ([reuseIdentifier isEqualToString:@"textCell"]) {

//                faceArray = [[NSMutableArray alloc]initWithCapacity:10];
//                NSString * path = @"";
//                path = [[NSBundle mainBundle] pathForResource:@"ShuZhiZhang" ofType:@"bundle"];
//                path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"faceMap_send.plist"]];
//                NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
//                for (int i=1;i<49 ;i++) {
//                    NSString *str = [dic objectForKey:[NSString stringWithFormat:@"%03d",i]];
//                    [faceArray addObject:str];
//                }
                
            }else if ([reuseIdentifier isEqualToString:@"soundCell"]){
                //播放
                _palyView = [[UIImageView alloc]initWithFrame:CGRectZero];
                [_palyView setTag:11000];
                [_palyView setBackgroundColor:[UIColor clearColor]];
                [self addSubview:_palyView];
           
                
                //音频长度
                soundLength = [[UILabel alloc]initWithFrame:CGRectZero];
                [soundLength setBackgroundColor:[UIColor clearColor]];
                [soundLength setFont:[UIFont systemFontOfSize:13.0f]];
                [soundLength setTextColor:[UIColor grayColor]];
                [messageBg addSubview:soundLength];
             
                
            }else if ([reuseIdentifier isEqualToString:@"photoCell"]){
                //图片消息
                photoMessView = [[HJManagedImageV alloc]initWithFrame:CGRectZero];
                [photoMessView setBackgroundColor:[UIColor clearColor]];
                //photoMessView.contentMode = UIViewContentModeScaleAspectFit;
                [messageBg addSubview:photoMessView];
              
            }else if ([reuseIdentifier isEqualToString:@"mapCell"]){
                //地图
                userLatitude = @"";
                userlongitude = @"";
                map = [[MKMapView alloc] initWithFrame:CGRectZero];
                map.mapType = MKMapTypeStandard;
                [map setUserInteractionEnabled:NO];
                map.showsUserLocation = YES;
                map.zoomEnabled = NO;
                map.scrollEnabled = NO;
                [messageBg addSubview:map];
                
                
                messageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                [messageBtn setBackgroundColor:[UIColor clearColor]];
                messageBtn.frame = CGRectZero;
                [map addSubview:messageBtn];
                
              
            }
            
        }
        
        mark = NO;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
}

-(void)loadDataWithModel:(id)model withType:(int)type{
    BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
    if (type == 0) {
        if (![[ShuZhiZhangUserPreferences currentUserHeadURLStr] isEqual:[NSNull null]]&&![[ShuZhiZhangUserPreferences currentUserHeadURLStr] isEqualToString:@""]) {

            [headImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
            //NSString *gameIcon = [(NSMutableDictionary*)[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"];
            if (msgModel.theType == 0&&msgModel.msgtype != 5) {
               [[BPPublicHandle sharedPublicHandle] getImage:headImage headImageUrl:[ShuZhiZhangUserPreferences currentUserHeadURLStr]];
            }

        }else{
            [headImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
            
        }
    }else if (type == 1){
         NSString * helperHead = [[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"];
        // ////////NSLog(@"helperHead ======== %@",helperHead);
        if (![helperHead isEqual:[NSNull null]]&&![helperHead isEqualToString:@""]) {
            [headImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
            if (msgModel.theType == 1&&msgModel.msgtype != 5){
                [[BPPublicHandle sharedPublicHandle] getImage:headImage headImageUrl:helperHead];
            }
            
        }else{
            [headImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
            
        }
        
    }
    switch (type) {
        case 1:{
            
            //接收
            stateLab.hidden = YES;
            failImageV.hidden = YES;
            if (msgModel.msgtype == 1) {
                [emoticonView removeFromSuperview];
                CGSize size = [EmoticonTextView viewHeightText:msgModel.content font:[UIFont systemFontOfSize:13.0f] maxWidth:MSGE_WIDTH];
                
                emoticonView = [[EmoticonTextView alloc] initWithFrame:CGRectMake(5.0, 5.0,MSGE_WIDTH,size.height) text:msgModel.content font:[UIFont systemFontOfSize:13.0f] textColor:[UIColor blackColor]];
                [emoticonView setUserInteractionEnabled:NO];
                [emoticonView setBackgroundColor:[UIColor clearColor]];
                emoticonView.frame = CGRectMake(10.0, 5.0,size.width,size.height);
                [messageBg addSubview:emoticonView];
                
            }
            
            if (msgModel.msgtype == 2) {

            }
            
            
            if (msgModel.msgtype == 3) {
                if ([msgModel.soundlength intValue]>60) {
                    [soundLength setText:[NSString stringWithFormat:@"%d'%d''",[msgModel.soundlength intValue]/60,[msgModel.soundlength intValue]%60]];
                }else{
                    [soundLength setText:[NSString stringWithFormat:@"%d''",[msgModel.soundlength intValue]]];
                }
            }
            
            [self layoutViews:msgModel.msgtype msgeFrom:0];
            
            headImageBtn.hidden = NO;
            [headImage setFrame:CGRectMake(15.0, 18.0, 35.0, 35.0)];
            headImageBtn.frame = headImage.frame;
            if (messageBg.frame.size.height>35.0) {
                [self setFrame:CGRectMake(0.0, 20.0, SCREEN_WIDTH, messageBg.frame.size.height+18.0*2)];
            }else{
                [self setFrame:CGRectMake(0.0, 20.0, SCREEN_WIDTH, headImage.frame.size.height+18.0*2)];
            }
        }
            break;
        case 0:{
            stateLab.hidden = YES;
            failImageV.hidden = YES;
            //发送
            if (msgModel.status == 2) {
                stateLab.hidden = NO;
                [stateLab setText:@"送达"];
            }
            
            if (msgModel.status == 1) {
                failImageV.hidden = NO;
            }
            
            if (msgModel.msgtype == 1) {
    
                [emoticonView removeFromSuperview];
                CGSize size = [EmoticonTextView viewHeightText:msgModel.content font:[UIFont systemFontOfSize:13.0f] maxWidth:MSGE_WIDTH];
                               
                emoticonView = [[EmoticonTextView alloc] initWithFrame:CGRectMake(5.0, 5.0,MSGE_WIDTH,size.height) text:msgModel.content font:[UIFont systemFontOfSize:13.0f] textColor:[UIColor blackColor]];
                [emoticonView setBackgroundColor:[UIColor clearColor]];
                [emoticonView setUserInteractionEnabled:NO];
                emoticonView.frame = CGRectMake(5.0, 5.0,size.width,size.height);
                [messageBg addSubview:emoticonView];
                //[emoticonView release];
                
            }
            
            if (msgModel.msgtype == 2) {
                if ([UIImage imageWithContentsOfFile:msgModel.lpicname]) {
                    [photoMessView setImage:[UIImage imageWithContentsOfFile:msgModel.lpicname]]; 
                }else{
                    [photoMessView setImage:[UIImage imageWithContentsOfFile:msgModel.picname]];
                }
            }
            
            if (msgModel.msgtype == 3) {
                if ([msgModel.soundlength intValue]>60) {
                    [soundLength setText:[NSString stringWithFormat:@"%d'%d''",[msgModel.soundlength intValue]/60,[msgModel.soundlength intValue]%60]];
                }else{
                    [soundLength setText:[NSString stringWithFormat:@"%d''",[msgModel.soundlength intValue]]];
                }
            }
            
            if (msgModel.msgtype == 4) {
                CLLocationCoordinate2D coordinate;
                //////////NSLog(@"model.gps ========= %@",msgModel.gps);
                if (![msgModel.gps isEqualToString:@""]) {
                    NSArray *array = [msgModel.gps componentsSeparatedByString:@","];
                    coordinate.latitude = [[array objectAtIndex:0] floatValue];
                    coordinate.longitude = [[array objectAtIndex:1] floatValue];
                }
                
                //设置显示范围
                MKCoordinateRegion region;
                region.span.latitudeDelta = 0.005;
                region.span.longitudeDelta = 0.005;
                region.center = coordinate;
                //设置显示位置(动画)
                [map setRegion:region animated:YES];
                [map regionThatFits:region];
            }
            
            
            [self layoutViews:msgModel.msgtype msgeFrom:1];
            
            headImageBtn.hidden = NO;
            [headImage setFrame:CGRectMake(SCREEN_WIDTH-50.0, 18.0, 35.0, 35.0)];
            headImageBtn.frame = headImage.frame;
            
            if (messageBg.frame.size.height>35.0) {
                [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, messageBg.frame.size.height+18.0*2)];
            }else{
                [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, headImage.frame.size.height+18.0*2)];
            }
            
            [stateLab setFrame:CGRectMake(messageBg.frame.origin.x-30,18.0+(messageBg.frame.size.height-12.0)/2 , 30.0, 12.0)];
        }
            break;
        case 2:{
            NSString *str = [BPPublicHandle getTimeString:[msgModel.ltime floatValue]  needType:2];
            CGSize titleSize = [str sizeWithFont:[UIFont systemFontOfSize:10.0f] constrainedToSize:CGSizeMake(MAXFLOAT, 12.0) lineBreakMode:NSLineBreakByWordWrapping];
            [timeLab setText:str];
            [timeLab setFrame:CGRectMake((SCREEN_WIDTH-titleSize.width)/2, 6.0, titleSize.width, 13.0)];
            
            [rightLine setFrame:CGRectMake(timeLab.frame.origin.x-60.0, 13, 47.0, 1.0)];
            [leftLine setFrame:CGRectMake(timeLab.frame.origin.x+titleSize.width+13.0, 13, 47.0, 1.0)];
            [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, 18.0)];
        }
            break;
        default:
            break;
    }
}

- (void)layoutViews:(int)msgeType msgeFrom:(int)type{
    switch (msgeType) {
        case 1:{
            //文本
            if (type == 0) {
                //接收
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 10.0f, 13.0f, 13.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 10.0f, 13.0f, 13.0f)];
                
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
                [messageBg setFrame:CGRectMake(60.0, 18.0, emoticonView.frame.size.width+17.0,emoticonView.frame.size.height+10.0)];
            }else{
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 10.0f, 10.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 10.0f, 10.0f)];
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                [messageBg setFrame:CGRectMake(SCREEN_WIDTH-60.0-emoticonView.frame.size.width-17.0, 18.0, emoticonView.frame.size.width+17.0,emoticonView.frame.size.height+10.0)];
                [failImageV setFrame:CGRectMake(messageBg.frame.origin.x-24, 18.0+(messageBg.frame.size.height-13.0)/2, 16.0, 13.0)];
                
            }
        }
            
            break;
        case 2:{
            //图片
            if (type == 0) {
                
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 10.0f, 13.0f, 13.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 10.0f, 13.0f, 13.0f)];
                
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
                [photoMessView setFrame:CGRectMake(10.0, 5.0,114.0,114.0)];
                [messageBg setFrame:CGRectMake(60.0, 35.0, photoMessView.frame.size.width+17.0, photoMessView.frame.size.height+12.0)];
                
                
            }else{
                
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 13.0f, 10.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 13.0f, 10.0f)];
                
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
                CGSize testSize = CGSizeMake(114.0, 114.0);
                CGSize theSize = [self imageByScalingToSize:testSize image:photoMessView.image];
                [photoMessView setFrame:CGRectMake(6.0, 5.0,theSize.width,theSize.height)];
                [messageBg setFrame:CGRectMake(60.0, 18.0, photoMessView.frame.size.width+17.0, photoMessView.frame.size.height+10.0)];
                [messageBg setFrame:CGRectMake(SCREEN_WIDTH-60.0-photoMessView.frame.size.width-17.0, 18.0, photoMessView.frame.size.width+17.0,photoMessView.frame.size.height+12.0)];
                [failImageV setFrame:CGRectMake(messageBg.frame.origin.x-24, 18.0+(messageBg.frame.size.height-13.0)/2, 16.0, 13.0)];
                
                if (messageBg.frame.size.height>35.0) {
                    [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, messageBg.frame.size.height+18.0*2)];
                }else{
                    [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, headImage.frame.size.height+18.0*2)];
                }
                
            }
        }
            
            break;
        case 3:{
            //音频
            if (type == 0) {
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(22.0f, 10.0f, 13.0f, 13.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_01_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(22.0f, 10.0f, 13.0f, 13.0f)];
                
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
                [_palyView setFrame:CGRectMake(75.0, 43.5,17.0,22.0)];
                [_palyView setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_03.png"]];
                [soundLength setFrame:CGRectMake(45.0, 12.0, 40.0, 14.0)];
                [soundLength setTextAlignment:NSTextAlignmentLeft];
                [messageBg setFrame:CGRectMake(60.0, 18.0, _palyView.frame.size.width+65.0, _palyView.frame.size.height+10.0)];
            }else{
                
                UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(22.0f, 13.0f, 13.0f, 10.0f)];
                UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(22.0f, 13.0f, 13.0f, 10.0f)];
                
                [_palyView setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_voice_06.png"]];
                [messageBg setBackgroundImage:image forState:UIControlStateNormal];
                [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
                [_palyView setFrame:CGRectMake(SCREEN_WIDTH-60.0-34.0,25.5,17.0,22.0)];
                [soundLength setFrame:CGRectMake(0.0, 12.0, 45.0, 14.0)];
                [soundLength setTextAlignment:NSTextAlignmentRight];
                [messageBg setFrame:CGRectMake(SCREEN_WIDTH-60.0-85.0, 18.0, 85.0,40.0)];
                [failImageV setFrame:CGRectMake(messageBg.frame.origin.x-24, 18.0+(messageBg.frame.size.height-13.0)/2, 16.0, 13.0)];
                
                if (messageBg.frame.size.height>35.0) {
                    [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, messageBg.frame.size.height+18.0*2)];
                }else{
                    [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, headImage.frame.size.height+18.0*2)];
                }
            }
        }
            
            break;
        case 4:{
            
            if (type == 0) {
                
            }else{
                
            map.showsUserLocation = NO;
            UIImage *image = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 13.0f, 10.0f)];
            UIImage *image_sel = [[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_dialogue_bg_02_sel.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(25.0f, 13.0f, 13.0f, 10.0f)];
                
            [messageBg setBackgroundImage:image forState:UIControlStateNormal];
            [messageBg setBackgroundImage:image_sel forState:UIControlStateHighlighted];
                
            [map setFrame:CGRectMake(6.0, 5.0,100.0,80.0)];
            [messageBg setFrame:CGRectMake(60.0, 18.0, map.frame.size.width+17.0, map.frame.size.height+10.0)];
            [messageBg setFrame:CGRectMake(SCREEN_WIDTH-60.0-map.frame.size.width-17.0, 18.0, map.frame.size.width+17.0,map.frame.size.height+12.0)];
            [failImageV setFrame:CGRectMake(messageBg.frame.origin.x-24, 18.0+(messageBg.frame.size.height-13.0)/2, 16.0, 13.0)];
                
            if (messageBg.frame.size.height>35.0) {
                [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, messageBg.frame.size.height+18.0*2)];
            }else{
                [self setFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, headImage.frame.size.height+18.0*2)];
            }
                
            [map setUserInteractionEnabled:YES];
            messageBtn.frame = CGRectMake(0.0, 0.0, map.frame.size.width, map.frame.size.height);
                
            }
        }
            break;
            
        default:
            break;
    }
}


//图文混排

-(void)getImageRange:(NSString*)message : (NSMutableArray*)array {
    NSRange range = [message rangeOfString: BEGIN_FLAG];
    NSRange range1 = [message rangeOfString: END_FLAG];
    //判断当前字符串是否还有表情的标志。
    if (range.length>0 && range1.length>0) {
        if (range.location > 0) {
            [array addObject:[message substringToIndex:range.location]];
            [array addObject:[message substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)]];
            NSString *str=[message substringFromIndex:range1.location+1];
            [self getImageRange:str :array];
        }else {
            NSString *nextstr=[message substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)];
            //排除文字是“”的
            if (![nextstr isEqualToString:@""]) {
                [array addObject:nextstr];
                NSString *str=[message substringFromIndex:range1.location+1];
                [self getImageRange:str :array];
            }else {
                return;
            }
        }
        
    } else if (message != nil) {
        [array addObject:message];
    }
}

#define KFacialSizeWidth  18
#define KFacialSizeHeight 18
#define MAX_WIDTH 140
-(UIView *)assembleMessageAtIndex : (NSString *) message
{
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:10];
    [self getImageRange:message :array];
    NSArray *data = array;
    UIFont *fon = [UIFont systemFontOfSize:13.0f];
    CGFloat upX = 0;
    CGFloat upY = 0;
    CGFloat X = 0;
    CGFloat Y = 0;
    if (data) {
        for (int i=0;i < [data count];i++) {
            NSString *str=[data objectAtIndex:i];
            NSMutableDictionary *dictionary = nil;
            if ([self detectionUrl:str]) {
                dictionary = [self detectionUrl:str];
            }
            
            if ([str hasPrefix: BEGIN_FLAG] && [str hasSuffix: END_FLAG]&&[self isFace:str])
            {
                if (upX >= MAX_WIDTH)
                {
                    upY = upY + KFacialSizeHeight;
                    upX = 0;
                    X = 150;
                    Y = upY;
                }

                upX=KFacialSizeWidth+upX;
                if (X<150) X = upX;
                
                
            } else {
                for (int j = 0; j < [str length]; j++) {
                    NSString *temp = [str substringWithRange:NSMakeRange(j, 1)];
                    if (upX >= MAX_WIDTH)
                    {
                        upY = upY + KFacialSizeHeight;
                        upX = 0;
                        X = 150;
                        Y =upY;
                    }
                    CGSize size=[temp sizeWithFont:fon constrainedToSize:CGSizeMake(150, 40)];
                    UILabel *la = [[UILabel alloc] initWithFrame:CGRectMake(upX,upY,size.width,size.height)];
                    la.font = fon;
                    la.text = temp;
                    if (dictionary) {
                        if ([[dictionary objectForKey:@"index"] intValue]-1<j&&j<[[dictionary objectForKey:@"index"] intValue]+[[dictionary objectForKey:@"length"] intValue]) {
                            [la setTextColor:[UIColor colorWithRed:16/255.0 green:132/255.0 blue:255/255.0 alpha:1]];
                        }
                    }
                    la.backgroundColor = [UIColor clearColor];
                    [returnView addSubview:la];
                    upX=upX+size.width;
                    if (X<150) {
                        X = upX;
                    }
                }
            }
        }
    }
    
  
    returnView.frame = CGRectMake(15.0f,1.0f, X, Y+KFacialSizeHeight); //@ 需要将该view的尺寸记下，方便以后使用
    cellHight =  Y+KFacialSizeHeight;
    return returnView;
}


//判断是否有网页连接
-(NSMutableDictionary*)detectionUrl:(NSString*)str{
    NSArray *array = [NSArray arrayWithObjects:@"http",@"ftp:",@"rtsp",@"mms:",@"www.", nil];
    for (int i = 0; i<str.length; i++) {
        NSString *string2 = [str substringWithRange:NSMakeRange(i,str.length-i)];
        if (string2.length>4) {
            for (NSString *str in  array) {
                if ([[string2 substringWithRange:NSMakeRange(0,4)] isEqualToString:str]) {
                    for (int k = string2.length;k>3;k--) {
                        NSString *string3 = [string2 substringWithRange:NSMakeRange(0,k)];
                        NSError *PasswrodError1;
                        NSRegularExpression * regex1 = [NSRegularExpression regularExpressionWithPattern:@"^(http|https|ftp|rtsp|mms):(//|\\\\)[A-Za-z0-9%-_@]|^(www).[A-Za-z0-9]+.[A-Za-z0-9%-_@]+[A-Za-z0-9./=\?%-&_~`@:+!;]*$" options:0 error:&PasswrodError1];
                        
                        if (regex1 != nil) {
                            
                            NSTextCheckingResult * result1 =[regex1 firstMatchInString:string3 options:0 range:NSMakeRange(0, [string3 length])];
                            
                            if (result1) {
                                NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
                                [dictionary setObject:[NSString stringWithFormat:@"%d",i] forKey:@"index"];
                                [dictionary setObject:[NSString stringWithFormat:@"%d",k] forKey:@"length"];
                                return dictionary;
                            }
                        }
                    }
                }
            }
        }
    }
    return nil;
}

//判断是否是表情符
-(BOOL)isFace:(NSString*)string{
    for (NSString *str in faceArray) {
        if ([str isEqualToString:string]) {
            return YES;
        }
    }
    return NO;
}

+(BPRervicerOnlineCell *)sharedCell
{
    static BPRervicerOnlineCell *instance = nil;
    if(instance == nil) {
        instance = [[BPRervicerOnlineCell alloc] init];
        
    }
    return instance;
}

+(float)getCellHight:(id)model{
    CGFloat cellHight = 0.0;
    BPChatMessageModel *msgeModel = (BPChatMessageModel*)model;
    switch (msgeModel.msgtype) {
        case 1:{
            CGFloat hight;
            hight = [EmoticonTextView viewHeightText:msgeModel.content font:[UIFont systemFontOfSize:13.0f] maxWidth:MSGE_WIDTH].height;
            if (hight<28) {
                hight = 27.0;
            }
            cellHight = hight+10;
            if (hight>35) {
                cellHight = hight+18*2;
            }else{
                cellHight = 35+18*2;
            }
            
        }
            break;
        case 2:{
            cellHight =  124+18*2;
        }
            break;
        case 3:{
            cellHight = 35+18*2;
        }
            break;
        case 4:{
            cellHight = 90+18*2;
        }
            break;
        case 5:{
            cellHight = 18.0;
        }
            break;
        default:
            break;
    }
    /*if (msgeModel.msgtype == 1) {
        return cellHight+15;
    }*/
    return cellHight;
}

- (CGSize)imageByScalingToSize:(CGSize)targetSize image:(UIImage*)image
{
    if(!image)
    {
        return targetSize;
    }
    CGSize imageSize = image.size;
    
    CGFloat width = imageSize.width;
    
    CGFloat height = imageSize.height;
    
    CGFloat targetWidth = targetSize.width;
    
    CGFloat targetHeight = targetSize.height;
    
    CGFloat scaleFactor = 0.0;
    
    CGFloat scaledWidth = targetWidth;
    
    CGFloat scaledHeight = targetHeight;
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO) {
        
        CGFloat widthFactor = targetWidth / width;
        
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor < heightFactor)
            
            scaleFactor = widthFactor;
        
        else
            
            scaleFactor = heightFactor;
        
        scaledWidth  = width * scaleFactor;
        
        scaledHeight = height * scaleFactor;
        
        
        //////////NSLog(@"scaledWidth ============ %f,scaledHeight ============ %f",scaledWidth,scaledHeight);
        
    }
       CGSize testSize = CGSizeMake(scaledWidth, scaledHeight);

       return testSize;
}



-(BOOL) canBecomeFirstResponder{
    
    return YES;
    
}


- (BOOL)canPerformAction:(SEL)action withSender:(id)sender{
    if (action == @selector(cut:)){
        return NO;
    }
    else if(action == @selector(copy:)){
        return NO;
        
    }else if (action == @selector(copy1:)){
        return YES;
    }
    else if (action == @selector(delete1:)){
        return YES;
    }else if (action == @selector(resend1:)){
        return YES;
    }
    else if(action == @selector(paste:)){
        return NO;
    }
    else if(action == @selector(select:)){
        return NO;
    }
    else if(action == @selector(selectAll:)){
        return NO;
    }
    else
    {
        return [super canPerformAction:action withSender:sender];
    }
}

- (void)copy1:(id)sender {
    _getCopyMessage(0);
}
- (void)delete1:(id)sender {
    _getCopyMessage(1);
}
- (void)resend1:(id)sender {
    _getCopyMessage(2);
}

-(void)btnLong:(UILongPressGestureRecognizer *)gestureRecognizer{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        /*////////NSLog(@"长按事件");
         UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"消息" message:@"确定删除该模式吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"删除", nil];
         [alert show];*/
        _showCopyView();
    }
}

@end
