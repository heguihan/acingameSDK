//
//  BPShowTableListCell.m
//  BigPlayerSDK
//

//

#import "BPShowTableListCell.h"

@implementation BPShowTableListCell
@synthesize bgView,selectImage,iconImage,optionsLab,lineImage;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        lineImage = [[UIImageView alloc]initWithFrame:CGRectMake(6.0, 40.0, 120.0, 1.0)];
        [lineImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_chat_line.png"]];
        [self addSubview:lineImage];
        [lineImage release];
        
        selectImage = [[UIImageView alloc]initWithFrame:CGRectMake(-0.5,5.0,4.0, 30.0)];
        [selectImage setBackgroundColor:[UIColor clearColor]];
        [self addSubview:selectImage];
        [selectImage release];
        
        iconImage = [[UIImageView alloc]initWithFrame:CGRectMake(15.0, 0.0, 40.0, 40.0)];
        [iconImage setBackgroundColor:[UIColor clearColor]];
        [self addSubview:iconImage];
        [iconImage release];
        
        optionsLab = [[UILabel alloc]initWithFrame:CGRectMake(50.0, 0.0,70.0, 40.0)];
        [optionsLab setBackgroundColor:[UIColor clearColor]];
        [optionsLab setTextAlignment:NSTextAlignmentCenter];
        [optionsLab setFont:[UIFont systemFontOfSize:14.0f]];
        [optionsLab setTextColor:[UIColor colorWithRed:100/255.0 green:100/255.0 blue:100/255.0 alpha:1]];
        [self addSubview:optionsLab];
        [optionsLab release];
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
