//
//  BPMessageCenterCell.m
//  BigPlayerSDK
//

#import "BPMessageCenterCell.h"
#import "BPPublicHandle.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"

@implementation BPMessageCenterCell
@synthesize nickNameLab,contentLab,timeLab,countLab,smallIcon,iconImage,countBg;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        iconImage = [[HJManagedImageV alloc]initWithFrame:CGRectMake(15.0, 10.0, 60.0, 60.0)];
        [iconImage setBackgroundColor:[UIColor clearColor]];
        [iconImage setUserInteractionEnabled:NO];
        [self.contentView addSubview:iconImage];
        
        
        nickNameLab = [[UILabel  alloc]initWithFrame:CGRectMake(87.0, 21.0,120.0, 14.0)];
        [nickNameLab setBackgroundColor:[UIColor clearColor]];
        [nickNameLab setFont:[UIFont systemFontOfSize:13.0]];
        [nickNameLab setTextColor:[UIColor blackColor]];
        [nickNameLab setTextAlignment:NSTextAlignmentLeft];
        [nickNameLab setUserInteractionEnabled:NO];
        [nickNameLab setText:@"用户昵称"];
        [self.contentView addSubview:nickNameLab];
        
        smallIcon = [[HJManagedImageV alloc]initWithFrame:CGRectMake(87.0, 45.0, 13.0, 12.0)];
        [smallIcon setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_message_center.png"]];
        [self.contentView addSubview:smallIcon];
        
        
        contentLab = [[UILabel alloc]initWithFrame:CGRectMake(105.0,44.0, SCREEN_WIDTH-105-50, 13.0)];
        [contentLab setBackgroundColor:[UIColor clearColor]];
        [contentLab setFont:[UIFont systemFontOfSize:13.0]];
        [contentLab setTextColor:[UIColor grayColor]];
        [contentLab setTextAlignment:NSTextAlignmentLeft];
        [contentLab setUserInteractionEnabled:NO];
        //[contentLab setText:@"XXXXXXX发来一条消息.."];
        [self.contentView addSubview:contentLab];
        
        timeLab = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-115.0, 23.0, 100.0, 12.0)];
        [timeLab setBackgroundColor:[UIColor clearColor]];
        [timeLab setFont:[UIFont systemFontOfSize:13.0]];
        [timeLab setTextColor:[UIColor grayColor]];
        [timeLab setTextAlignment:NSTextAlignmentRight];
        [timeLab setUserInteractionEnabled:NO];
        [timeLab setText:@"13:32"];
        [self.contentView addSubview:timeLab];
        
        countBg = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-45.0, 42.0, 30.0, 18.0)];
        [countBg setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_message_count_bg.png"]];
        [countBg setBackgroundColor:[UIColor clearColor]];
        [countBg setUserInteractionEnabled:NO];
        [self.contentView addSubview:countBg];
        
        countLab = [[UILabel alloc]initWithFrame:CGRectMake(0.0, 2.0, 30.0, 14.0)];
        [countLab setBackgroundColor:[UIColor clearColor]];
        [countLab setFont:[UIFont boldSystemFontOfSize:12.0f]];
        [countLab setTextColor:[UIColor whiteColor]];
        [countLab setTextAlignment:NSTextAlignmentCenter];
        [countLab setUserInteractionEnabled:NO];
        [countLab setText:@"9"];
        [countBg addSubview:countLab];
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

-(void)dealloc{
    [iconImage release];
    [nickNameLab release];
    [smallIcon release];
    [contentLab release];
    [timeLab release];
    
    
    [countBg release];
    [countLab release];
    [super dealloc];
}


-(void)addDataWithModel:(BPMessageCenterModel*)model{
    
    if (model.theType == 1) {
        [nickNameLab setText:[NSString stringWithFormat:@"%@%@",[(NSMutableDictionary*)[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_name"],[BPLanguage getStringForKey:@"BPHelper" InTable:@"BPMultiLanguage"]]];
    }else{
        [nickNameLab setText:model.nickname];  
    }
    if (![[[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"] isEqual:[NSNull null]]&&![[[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"] isEqualToString:@""]) {
        
        [iconImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
        [[BPPublicHandle sharedPublicHandle] getImage:iconImage headImageUrl:[[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_icon"]];
        
    }else{
        [iconImage setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"]];
        
    }
    
    switch (model.msgtype) {
        case 1:{//文本
            contentLab.text = model.content;
        }
            break;
        case 2:{//图片
            contentLab.text = @"[图片]";
        }
            break;
        case 3:{//声音
            contentLab.text = @"[语音]";
        }
            break;
        case 4:{//GPS
            contentLab.text = @"[位置]";
        }
            break;
            
        default:
            break;
    }
    
    //////////NSLog(@"model.ltime ============ %@",model.ltime);
    NSString *str = [BPPublicHandle getTimeString:[model.ltime floatValue]  needType:2];
    [timeLab setText:str];
    
    
    if (model.msgeCount == 0) {
        countBg.hidden = YES;
        countLab.hidden = YES;
    }else{
        countBg.hidden = NO;
        countLab.hidden = NO;
        countLab.text = [NSString stringWithFormat:@"%d",model.msgeCount];
    }
}

@end
