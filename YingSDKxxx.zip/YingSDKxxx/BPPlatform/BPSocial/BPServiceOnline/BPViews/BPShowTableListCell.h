//
//  BPShowTableListCell.h
//  BigPlayerSDK

//

#import <UIKit/UIKit.h>

@interface BPShowTableListCell : UITableViewCell{
    UIView *bgView;             //背景
    UIImageView *lineImage;     //分割线
    UIImageView *selectImage;   //标记选中
    UIImageView *iconImage;     //icon
    UILabel *optionsLab;        //选项
    
}

@property(nonatomic,retain)UIView *bgView;
@property(nonatomic,retain)UIImageView *lineImage;
@property(nonatomic,retain)UIImageView *selectImage;
@property(nonatomic,retain)UIImageView *iconImage;
@property(nonatomic,retain)UILabel *optionsLab;

@end
