//
//  BPRervicerOnlineCell.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "HJManagedImageV.h"

#import "EmoticonTextView.h"

@interface BPRervicerOnlineCell : UITableViewCell{
    HJManagedImageV *headImage;        //头像
    UIButton *headImageBtn;
    UIButton *messageBg;               //消息背景
    HJManagedImageV *photoMessView;    //图片消息
    UIImageView *_palyView;             //播放
    
    UIImageView *leftLine;             //左端虚线
    UILabel *timeLab;                  //时间
    UIImageView *rightLine;            //右端虚线
    
    UILabel *stateLab;                 //发送,送达
    
    MKMapView *map;                    //地图
    UIButton *messageBtn;              //消息触发
    UIView *returnView;                //表情
    EmoticonTextView *emoticonView;   
    
    UILabel *soundLength;              //音频长度
    UIImageView *failImageV;           //发送失败Icon
    
    NSMutableArray *faceArray;         //存放表情
    
    CGFloat cellHight;
    BOOL mark;
}

@property (nonatomic ,retain)HJManagedImageV *headImage;
@property (nonatomic ,retain)UIButton *headImageBtn;
@property (nonatomic ,retain)UIButton *messageBg;
@property (nonatomic ,retain)HJManagedImageV *photoMessView;
@property (nonatomic ,strong)UIImageView *playView;
@property (nonatomic ,retain)UIImageView *leftLine;
@property (nonatomic ,retain)UILabel *timeLab;
@property (nonatomic ,retain)UILabel *stateLab;
@property (nonatomic ,retain)UIImageView *rightLine;
@property (nonatomic ,retain)UIButton *messageBtn;
@property (nonatomic ,retain)MKMapView *map;
@property (nonatomic ,retain)UIView *returnView;
@property (nonatomic ,retain)UILabel *soundLength;
@property (nonatomic ) CGFloat cellHight;
@property (nonatomic)BOOL mark;

@property (nonatomic, strong) void (^getCopyMessage)(int type);
@property (nonatomic, strong) void (^showCopyView)();

//type:0-接收  1-发送 2-时间
-(void)loadDataWithModel:(id)model withType:(int)type;

+(BPRervicerOnlineCell *)sharedCell;
+(float)getCellHight:(id)model;

@end
