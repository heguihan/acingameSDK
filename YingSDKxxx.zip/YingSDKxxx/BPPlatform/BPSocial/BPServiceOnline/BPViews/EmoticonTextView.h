//
//  EmoticonTextView.h
//  BigPlayers
//
//  Created by Jun on 9/5/13.
//  Copyright (c) 2016 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmoticonTextView : UIView


//** emoticon 文本 **//
/**
 * _text 内容
 * _font 字体
 * _color 颜色
 **/
- (id)initWithFrame:(CGRect)frame
               text:(NSString *)_text
               font:(UIFont *)_font
          textColor:(UIColor *)_color;


/**
 * 计算height
 * text 内容
 * font 字体
 * maxWidth 显示宽度
 **/
+ (CGSize)viewHeightText:(NSString *)text
                   font:(UIFont *)_font
               maxWidth:(float)maxWidth;




//** emoticon 回复 + 文本 **//

/**
 * _text 内容
 * _primary 主
 * _secondary 次
 * _separator 分隔符
 * _font 字体
 * _color 颜色
 **/
- (id)initWithFrame:(CGRect)frame
               text:(NSString *)_text
            primary:(NSString *)_primary
          secondary:(NSString *)_secondary
          separator:(NSString *)_separator
               font:(UIFont *)_font
          textColor:(UIColor *)_color;


/**
 * 计算height
 * text 内容
 * primary 主
 * secondary 次
 * separator 分隔符
 * font 字体
 * maxWidth 显示宽度
 **/
+ (CGSize)viewHeightText:(NSString *)text
                primary:(NSString *)primary
              secondary:(NSString *)secondary
              separator:(NSString *)separator
                   font:(UIFont *)font
               maxWidth:(float)maxWidth;


- (void)updateView;
@end
