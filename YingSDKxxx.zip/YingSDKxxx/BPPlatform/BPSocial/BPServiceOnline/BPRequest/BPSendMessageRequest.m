//
//  BPSendMessageRequest.m
//  BigPlayerSDK
//

//

#import "BPSendMessageRequest.h"
#import "BPChatMessageModel.h"
//#import "BPNetworkReachable.h"

@implementation BPSendMessageRequest

-(ASIFormDataRequest *)CreateRequestWithUrl:(NSString *)urlStr SetInfo:(id)InfoTag
{
    NSURL *url = [NSURL URLWithString:urlStr];
    if(!url)
    {
        return nil;
    }
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL: url];
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    [userInfo setObject:InfoTag forKey:@"RequestTag"];
    [request setUserInfo:userInfo];
    [request setTimeOutSeconds:10];
    [request setRequestMethod:@"POST"];
    [request setNumberOfTimesToRetryOnTimeout:2];
    request.delegate = self;
    return request;
}


//上传文件
-(void)uploadChatGroupFile:(id)model
                     theId:(NSString*)uid
                  fileData:(NSData*)data
                   theType:(int)type{
    NSString *url = nil;
    ASIFormDataRequest *request=nil;
    switch (type) {
        case 1:{
            //聊天图片
            url = [NSString stringWithFormat:@"%@/files/uploadChatPic",ChatMessageDomainURL];
            request = [self CreateRequestWithUrl:url SetInfo:model];
            if (!request) {
                return;
            }
            [request setTag:100002];
            [request addData:data withFileName:@"send.jpg" andContentType:@"image/jpeg" forKey:@"picname"];
        }
            break;
        case 0:{
            //聊天语音
            url = [NSString stringWithFormat:@"%@/files/uploadChatSound",ChatMessageDomainURL];
            request = [self CreateRequestWithUrl:url SetInfo:model];
            if (!request) {
                return;
            }
            [request setTag:100003];
            [request addData:data withFileName:@"voice.amr" andContentType:@"audio/AMR" forKey:@"soundfile"];
        }
            break;
        default:
            break;
    }
    
    [request addPostValue:uid forKey:@"uid"];
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
}


//发送消息
-(void)sendMessage:(id)model autoresponse:(int)type{
//-(void)sendMessage:(id)model{
    
   BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
    
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@/userchat/sendMsg",ChatMessageDomainURL];
    request = [self CreateRequestWithUrl:str SetInfo:model];
    request.tag = 1008611;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"fid"];
    [request addPostValue:[NSString stringWithFormat:@"%d",msgModel.tid] forKey:@"tid"];
    ////////NSLog(@"autoResponse========%@",[NSString stringWithFormat:@"%d",type]);
    [request addPostValue:[NSString stringWithFormat:@"%d",type] forKey:@"autoResponse"];
    //[request addPostValue:[ShuZhiZhangUserPreferences CurrentGameId] forKey:@"tid"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentNickname] forKey:@"nickname"];
    [request addPostValue:msgModel.image forKey:@"image"];
    [request addPostValue:[NSString stringWithFormat:@"%d",msgModel.msgtype] forKey:@"msgtype"];
    [request addPostValue:msgModel.content forKey:@"content"];
    [request addPostValue:[msgModel.picname stringByReplacingOccurrencesOfString:GLOBAL_DOMAIN_URL withString:@""] forKey:@"picname"];
    [request addPostValue:[msgModel.soundfile stringByReplacingOccurrencesOfString:GLOBAL_DOMAIN_URL withString:@""] forKey:@"soundfile"];
    [request addPostValue:msgModel.soundlength forKey:@"soundlength"];
    [request addPostValue:msgModel.position forKey:@"position"];
    [request addPostValue:msgModel.gps forKey:@"gps"];
    [request addPostValue:[ShuZhiZhangUtility macaddress] forKey:@"mac"];
    [RequestQueue addOperation:request];
    [RequestQueue go];
}

//下载文件
-(void)downloadFile:(id)model index:(int)index{
    
    BPChatMessageModel *msgModel = (BPChatMessageModel*)model;
    NSURL *url = [NSURL URLWithString:msgModel.soundfile];
    if(!url)
    {
        return;
    }
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    // request = [self CreateRequestWithUrl:msgModel.soundfile SetInfo:model];
    
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    [userInfo setObject:model forKey:@"RequestTag"];
    [userInfo setObject:[NSNumber numberWithInt:index] forKey:@"fileIndex"];
    [request setUserInfo:userInfo];
    request.tag = 200000;
    
    if (!request) {
        return;
    }
    
    [request setTimeOutSeconds:8];
    [request setNumberOfTimesToRetryOnTimeout:2];
    [request setDownloadCache:[ASIDownloadCache sharedCache]];
    [request setCachePolicy:ASIOnlyLoadIfNotCachedCachePolicy];
    [request setCacheStoragePolicy:ASICachePermanentlyCacheStoragePolicy];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
}

-(void)getOffLineMessage:(NSString*)game_id
                  theUid:(NSString*)uid
                lastTime:(NSString*)uptime{
    
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@/chat/getSDKOffLineChats",ChatOffLineURL];
    request = [self CreateRequestWithUrl:str SetInfo:@"getSDKOffLineChats"];
    request.tag = 1008611;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentGameId] forKey:@"game_id"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"uid"];
    [request addPostValue:uptime forKey:@"uptime"];
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
}

@end
