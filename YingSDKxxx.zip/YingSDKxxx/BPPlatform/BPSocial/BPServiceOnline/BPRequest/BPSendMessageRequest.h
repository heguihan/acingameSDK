//
//  BPSendMessageRequest.h
//  BigPlayerSD
//

#import <Foundation/Foundation.h>
#import "BPHttpRequestBase.h"

@interface BPSendMessageRequest : BPHttpRequestBase

/*******
 type:
 1-上传聊天图片
 0-上传语音文件
 ********/
-(void)uploadChatGroupFile:(id)model
                     theId:(NSString*)uid
                  fileData:(NSData*)data
                   theType:(int)type;




/*******
 发送消息
 *******/
-(void)sendMessage:(id)model autoresponse:(int)type;
//-(void)sendMessage:(id)model;

/*******
 下载文件
********/
-(void)downloadFile:(id)model index:(int)index;

/******
 获取离线消息
 ******/
-(void)getOffLineMessage:(NSString*)game_id
                  theUid:(NSString*)uid
                lastTime:(NSString*)uptime;
@end
