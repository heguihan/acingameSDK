//
//  BPExperienceRequest.h
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPHttpRequestBase.h"

@interface BPExperienceRequest : BPHttpRequestBase

//获取心得
- (void)getExperience:(int)type  dynamicId:(int)micId;

//获取关系
- (void)getRelation:(int)type;

//发布心得
- (void)publishExperience:(NSString *)content images:(NSArray *)images;

//赞
- (void)praise:(int)micId;

//加关注
- (void)attention:(int)rid;
@end
