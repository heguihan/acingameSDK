//
//  BPExperienceModel.m
//  BigPlayerSDK
//
//  Created by givin on 14-8-11.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPExperienceModel.h"

@implementation BPExperienceModelBase

+(Class)getBindingModelClass
{
    return [BPExperienceModel class];                                              //返回实体
}
const static NSString *tablename = @"ExperienceModel";                              //表名


+(const NSString *)getTableName
{
    return tablename;
}
@end


@implementation BPExperienceModel
@synthesize experience,experId;

-(id)init
{
    self = [super init];
    if (self)
    {
        self.primaryKey = @"experience";                    //主健
    }
    return self;
}

- (id)initWithJsonDictionary:(NSDictionary*)dic
{
    self = [super init];
    if (self)
    {
       self.experience = @"experience";
       self.experId = [[dic objectForKey:@"experience"] integerValue];
        
    }
    return self;
}


-(void)dealloc
{

    [experience release];
    [super dealloc];
}
@end
