//
//  BPPlayerExperienceViewController.h
//  BigPlayerSDK
//
//  Created by givin on 14-8-8.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPBaseViewController.h"
#import "BPExperienceRequest.h"

@interface BPPlayerExperienceViewController : BPBaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    BPExperienceRequest *experRequest;
    NSMutableArray *dataArray;
    
    NSMutableArray *relationArray;
    
    UITableView *experTable;
    
    UIView *footBar;
    UILabel *number_lab;
    
    int exper_index;
}

@end
