//
//  BPExperienceCell.h
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HJManagedImageV.h"

@interface BPExperienceCell : UITableViewCell
{
    HJManagedImageV *headView;
    
    UILabel *name_lab;
    
    UILabel *time_lab;
    
    UILabel *content_lab;
    
    UIView *imageBg;
    
    UIButton *attentionBtn;
}

@property (nonatomic ,retain) UIButton *attentionBtn;

@property (nonatomic ,strong) void (^picClickBlock)(int index,UIImage *image);

- (void)reloadData:(NSDictionary *)dic;


@end
