//
//  BPExperienceRequest.m
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPExperienceRequest.h"

@implementation BPExperienceRequest


-(ASIFormDataRequest *)CreateRequestWithUrl:(NSString *)urlStr SetInfo:(id)InfoTag
{
    NSURL *url = [NSURL URLWithString:urlStr];
    if(!url)
    {
        return nil;
    }
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL: url];
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    [userInfo setObject:InfoTag forKey:@"RequestTag"];
    [request setUserInfo:userInfo];
    [request setTimeOutSeconds:10];
    [request setRequestMethod:@"POST"];
    [request setNumberOfTimesToRetryOnTimeout:2];
    request.delegate = self;
    return request;
}



- (void)getExperience:(int)type  dynamicId:(int)micId
{
    
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@",GLOBAL_BASE_API_URL];
    request = [self CreateRequestWithUrl:str SetInfo:@"Experience"];
    request.tag = 10086;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:@"userDynamic" forKey:@"action"];
    [request addPostValue:@"getGameTopicGroupDynamic" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUtility macaddress] forKey:@"macAddress"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentGameId] forKey:@"gameId"];
    [request addPostValue:[NSString stringWithFormat:@"%d",type] forKey:@"type"];
    [request addPostValue:[NSString stringWithFormat:@"%d",micId] forKey:@"dynamicId"];
    
    NSString *sign_str = [NSString stringWithFormat:@"%@;%@;%d;%d;",[ShuZhiZhangUtility macaddress],[ShuZhiZhangUserPreferences CurrentGameId],type,micId];
    [request addPostValue:[ShuZhiZhangUtility md5String:sign_str] forKey:@"sign"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
    
}

- (void)getRelation:(int)type
{
    
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@",GLOBAL_BASE_API_URL];
    request = [self CreateRequestWithUrl:str SetInfo:@"userRelation"];
    request.tag = 1008611;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:@"userRelation" forKey:@"action"];
    [request addPostValue:@"getUserRelationList" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID]forKey:@"uid"];
    [request addPostValue:@"0" forKey:@"uptime"];
    [request addPostValue:@"0" forKey:@"start"];
    [request addPostValue:@"500" forKey:@"rows"];
    [request addPostValue:[NSString stringWithFormat:@"%d",type] forKey:@"type"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
}

- (void)publishExperience:(NSString *)content images:(NSArray *)images
{
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@",GLOBAL_BASE_API_URL];
    request = [self CreateRequestWithUrl:str SetInfo:@"userDynamic"];
    request.tag = 1008612;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:@"userDynamic" forKey:@"action"];
    [request addPostValue:@"postedDynamicNew" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"uid"];
    [request addPostValue:[ShuZhiZhangUserPreferences getCurrentToken] forKey:@"token"];
    [request addPostValue:[NSString stringWithFormat:@"%d",[images count]] forKey:@"imagesNum"];
    [request addPostValue:content forKey:@"content"];
    
    for (int i = 0;i<images.count;i++) {
        
        [request addData:[images objectAtIndex:i] withFileName:[NSString stringWithFormat:@"pic_%d.jpg",i] andContentType:@"image/jpeg" forKey:[NSString stringWithFormat:@"image%d",i]];
    }
    
    
    
    
    NSString *sign_str = [NSString stringWithFormat:@"%@;%@;%@;%d;",[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences getCurrentToken],content,images.count];
    [request addPostValue:[ShuZhiZhangUtility md5String:sign_str] forKey:@"sign"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
    
}


- (void)praise:(int)micId
{
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@",GLOBAL_BASE_API_URL];
    request = [self CreateRequestWithUrl:str SetInfo:@"praise"];
    request.tag = 1008613;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:@"userDynamic" forKey:@"action"];
    [request addPostValue:@"praise" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"uid"];
    [request addPostValue:[ShuZhiZhangUserPreferences getCurrentToken] forKey:@"token"];
    [request addPostValue:[NSString stringWithFormat:@"%d",micId] forKey:@"dynamicId"];
    
    NSString *sign_str = [NSString stringWithFormat:@"%@;%@;%@;",[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences getCurrentToken],[NSString stringWithFormat:@"%d",micId]];
    [request addPostValue:[ShuZhiZhangUtility md5String:sign_str] forKey:@"sign"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}


//加关注
- (void)attention:(int)rid
{
    NSString *str = nil;
    ASIFormDataRequest *request = nil;
    
    str = [NSString stringWithFormat:@"%@",GLOBAL_BASE_API_URL];
    request = [self CreateRequestWithUrl:str SetInfo:[NSString stringWithFormat:@"%d",rid]];
    request.tag = 1008614;
    
    if (!request) {
        return;
    }
    
    [request addPostValue:@"userRelation" forKey:@"action"];
    [request addPostValue:@"attentionUser" forKey:@"operation"];
    [request addPostValue:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"uid"];
    [request addPostValue:[NSString stringWithFormat:@"%d",rid] forKey:@"rid"];
    
    [RequestQueue addOperation:request];
    [RequestQueue go];
}


@end
