//
//  BPExperienceCell.m
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPExperienceCell.h"
#import "BPPublicHandle.h"

@implementation BPExperienceCell
@synthesize attentionBtn;
@synthesize picClickBlock;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self setBackgroundColor:[UIColor colorWithRed:233/255.0 green:231/255.0 blue:227.0/255.0 alpha:1]];
        
        headView = [[HJManagedImageV alloc] initWithFrame:CGRectMake(15.0, 15.0, 50.0, 50.0)];
        [headView setBackgroundColor:[UIColor clearColor]];
        [headView.layer setCornerRadius:50.0/2];
        [self addSubview:headView];
        
        name_lab = [[UILabel alloc] initWithFrame:CGRectMake(80.0,22.0,200.0, 16.0)];
        [name_lab setBackgroundColor:[UIColor clearColor]];
        [name_lab setTextAlignment:NSTextAlignmentLeft];
        [name_lab setFont:[UIFont systemFontOfSize:16.0f]];
        [name_lab setTextColor:[UIColor colorWithRed:119/255.0 green:118/255.0 blue:117/255.0 alpha:1]];
        [name_lab setText:@""];
        [self addSubview:name_lab];
        
        time_lab = [[UILabel alloc] initWithFrame:CGRectMake(80.0,45.0,100.0, 13.0)];
        [time_lab setBackgroundColor:[UIColor clearColor]];
        [time_lab setTextAlignment:NSTextAlignmentLeft];
        [time_lab setFont:[UIFont systemFontOfSize:13.0f]];
        [time_lab setTextColor:[UIColor colorWithRed:119/255.0 green:118/255.0 blue:117/255.0 alpha:1]];
        [time_lab setText:@""];
        [self addSubview:time_lab];
        
        content_lab = [[UILabel alloc] initWithFrame:CGRectMake(15.0,75.0,SCREEN_WIDTH-30.0,100.0)];
        [content_lab setBackgroundColor:[UIColor clearColor]];
        [content_lab setTextAlignment:NSTextAlignmentLeft];
        [content_lab setTextColor:[UIColor blackColor]];
        [content_lab setFont:[UIFont systemFontOfSize:15.0f]];
        content_lab.lineBreakMode = UILineBreakModeWordWrap;
        [self addSubview:content_lab];
        
        attentionBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [attentionBtn setFrame:CGRectMake(SCREEN_WIDTH-72.0,25.0,57.0,28.0)];
        [attentionBtn setBackgroundColor:[UIColor clearColor]];
        [attentionBtn setTitle:@"" forState:UIControlStateNormal];
        //[attentionBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [attentionBtn.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
        [self addSubview:attentionBtn];
        
        
        imageBg = [[UIView alloc] initWithFrame:CGRectMake(0.0,190.0,SCREEN_WIDTH,250.0)];
        [imageBg setBackgroundColor:[UIColor clearColor]];
        [self addSubview:imageBg];

        for (int i = 0;i<9;i++) {
            
            HJManagedImageV *imageV = [[HJManagedImageV alloc] initWithFrame:CGRectMake(15.0+(72+10)*(i%3),0.0+(72+10)*(i/3),72.0,72.0)];
            [imageV setBackgroundColor:[UIColor clearColor]];
            [imageV setTag:2000+i];
            [imageV setCallbackOnImageTap:self method:@selector(picClick:)];
            [imageBg addSubview:imageV];
            [imageV release];
        }
        
    }
    return self;
}

- (void)dealloc
{
    [headView release];
    [name_lab release];
    [time_lab release];
    [content_lab release];
    [imageBg release];
    [super dealloc];
    
}



- (void)reloadData:(NSDictionary *)dic
{
    
    //////////NSLog(@"dic ==== %@",dic);
    
    if ([dic objectForKey:@"type"]&&[[dic objectForKey:@"type"] integerValue] == 0) {
        
        [attentionBtn setHidden:YES];
        
        [name_lab setText:[ShuZhiZhangUserPreferences CurrentNickname]];
        
        if (![[ShuZhiZhangUserPreferences currentUserHeadURLStr] isEqual:[NSNull null]]&&[ShuZhiZhangUserPreferences currentUserHeadURLStr]) {
            [[BPPublicHandle sharedPublicHandle] getImage:headView headImageUrl:[ShuZhiZhangUserPreferences currentUserHeadURLStr]];
            [headView.layer setCornerRadius:50.0/2];
            [headView.layer setMasksToBounds:YES];
        }
        
        NSString *str = [BPPublicHandle getTimeString:[[NSDate date] timeIntervalSince1970] needType:2];
        [time_lab setText:str];
        
        CGSize titleSize = [[dic objectForKey:@"content"] sizeWithFont:[UIFont systemFontOfSize:15.0f] constrainedToSize:CGSizeMake(SCREEN_WIDTH-30.0,MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
        [content_lab setNumberOfLines:(int)titleSize.height/15];
        [content_lab setFrame:CGRectMake(15.0,75.0,SCREEN_WIDTH-30.0,titleSize.height)];
        [content_lab setText:[dic objectForKey:@"content"]];
        
        [imageBg setFrame:CGRectMake(0.0,content_lab.frame.size.height+content_lab.frame.origin.y+15.0,SCREEN_WIDTH,250.0)];
        
        
        int count = [[dic objectForKey:@"images"] count];
        for (int i = 0; i<9; i++) {
            
            HJManagedImageV *imageV = (HJManagedImageV*)[imageBg viewWithTag:2000+i];
            imageV.hidden = YES;
            if (count>0&&i<count) {
                
                imageV.hidden = NO;
                
                [imageV setImage:[UIImage imageWithData:[[dic objectForKey:@"images"] objectAtIndex:i]]];

            }
            
        }
        
        return;
    }
    
    
    [attentionBtn setHidden:NO];
    
    [name_lab setText:[dic objectForKey:@"nickname"]];
    
    if (![[dic objectForKey:@"userImage"] isEqual:[NSNull null]]&&[dic objectForKey:@"userImage"]) {
        [[BPPublicHandle sharedPublicHandle] getImage:headView headImageUrl:[dic objectForKey:@"userImage"]];
        [headView.layer setCornerRadius:50.0/2];
        [headView.layer setMasksToBounds:YES];
    }
    
    NSString *str = [BPPublicHandle getTimeString:[[dic objectForKey:@"createTime"] floatValue]  needType:2];
    [time_lab setText:str];
    
    CGSize titleSize = [[ShuZhiZhangUtility decodeBase64:[dic objectForKey:@"content"]] sizeWithFont:[UIFont systemFontOfSize:15.0f] constrainedToSize:CGSizeMake(SCREEN_WIDTH-30.0,MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    [content_lab setNumberOfLines:(int)titleSize.height/15];
    [content_lab setFrame:CGRectMake(15.0,75.0,SCREEN_WIDTH-30.0,titleSize.height)];
    [content_lab setText:[ShuZhiZhangUtility decodeBase64:[dic objectForKey:@"content"]]];
    
    [imageBg setFrame:CGRectMake(0.0,content_lab.frame.size.height+content_lab.frame.origin.y+15.0,SCREEN_WIDTH,250.0)];
    
    int count = [[dic objectForKey:@"json"] count];
    for (int i = 0; i<9; i++) {
        
        HJManagedImageV *imageV = (HJManagedImageV*)[imageBg viewWithTag:2000+i];
        imageV.hidden = YES;
        if (count>0&&i<count) {
            
            imageV.hidden = NO;
            if (![[[[dic objectForKey:@"json"] objectAtIndex:i] objectForKey:@"image"] isEqual:[NSNull null]]&&[[[dic objectForKey:@"json"] objectAtIndex:i] objectForKey:@"image"]) {
                
                [[BPPublicHandle sharedPublicHandle] getImage:imageV OtherImageUrl:[[[dic objectForKey:@"json"] objectAtIndex:i] objectForKey:@"image"]];
            }
        }
        
    }
    
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)picClick:(id)sender
{
    HJManagedImageV *picImageV = (HJManagedImageV *)sender;
   // ////////NSLog(@"图片点击%d",picImageV.tag);
    picClickBlock(picImageV.tag-2000,picImageV.image);
}



//- (void)dissAction:(id)sender
//{
//    HJManagedImageV *picImageV = (HJManagedImageV *)sender;
//    [picImageV.superview removeFromSuperview];
//}



@end
