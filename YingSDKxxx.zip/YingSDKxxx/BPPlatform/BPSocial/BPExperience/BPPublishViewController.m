//
//  BPPublishViewController.m
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPPublishViewController.h"
#import "BigPlayerSDKBase.h"

@interface BPPublishViewController ()

@end

@implementation BPPublishViewController
@synthesize addPicBtn;
@synthesize backBlock;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        [self setTitle:@"分享"];
        //[ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPMessage"
        //InTable:@"BPMultiLanguage"] ViewController:self];
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:@"取消"];
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:NO Title:@"发送"];
    }
    return self;
}


- (void)dealloc
{
    for (ASIHTTPRequest *activeRequest in [experRequest.RequestQueue operations]) {
        [activeRequest clearDelegatesAndCancel];
    }
    
    [experRequest release];
    experRequest = nil;
    
    [contentTextV release];
    [numberLab release];
    [popover release];
    popover = nil;
    [picViewArray release];
    picViewArray = nil;
    [picDataArray release];
    picDataArray = nil;
    [bg release];
    
    [backBlock release];
    backBlock = nil;
    
    //注销键盘通知
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self
                                                   name:UIKeyboardWillHideNotification object:nil];
    
    [super dealloc];

}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //监测键盘位置的变化，让输入框显示在键盘上面
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(keyboardWillShow:)
                                                name:UIKeyboardWillShowNotification
                                              object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(keyboardWillHide:)
                                                name:UIKeyboardWillHideNotification
                                              object:nil];
    
    picNumber = 0;
    
    experRequest = [[BPExperienceRequest alloc] initWithDelegate:self];
    
    picViewArray = [[NSMutableArray alloc] initWithCapacity:10];
    picDataArray = [[NSMutableArray alloc] initWithCapacity:10];
    
    bg = [[UIView alloc] initWithFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH,SCREEN_HEIGHT+150.0)];
    [bg setBackgroundColor:[UIColor colorWithRed:233/255.0 green:231/255.0 blue:227.0/255.0 alpha:1]];
    [self.view addSubview:bg];
    
    addPicBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addPicBtn setFrame:CGRectMake(15.0+85*picNumber,15.0,75.0,75.0)];
    [addPicBtn setBackgroundColor:[UIColor clearColor]];
    [addPicBtn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_add_pic.png"] forState:UIControlStateNormal];
    [addPicBtn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_add_pic_sel.png"] forState:UIControlStateHighlighted];
    
    [addPicBtn addTarget:self action:@selector(addPicAction:) forControlEvents:UIControlEventTouchUpInside];
    [bg addSubview:addPicBtn];
    
    UIImageView *content_bg = [[UIImageView alloc] initWithFrame:CGRectMake(15.0,105.0,SCREEN_WIDTH-30.0,150.0)];
    [content_bg setBackgroundColor:[UIColor clearColor]];
    [content_bg setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_content_bg.png"]];
    [content_bg setUserInteractionEnabled:YES];
    [bg addSubview:content_bg];
    [content_bg release];
	
    UILabel *gameNameLab = [[UILabel alloc] initWithFrame:CGRectMake(10.0,10.0,SCREEN_WIDTH-50.0,14.0)];
    [gameNameLab setBackgroundColor:[UIColor clearColor]];
    [gameNameLab setTextAlignment:NSTextAlignmentLeft];
    [gameNameLab setText:[NSString stringWithFormat:@"#%@#",[(NSMutableDictionary*)[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_name"]]];
    [gameNameLab setFont:[UIFont systemFontOfSize:13.0f]];
    [gameNameLab setTextColor:[UIColor colorWithRed:102/255.0 green:101/255.0 blue:99/255.0 alpha:1]];
    [content_bg addSubview:gameNameLab];
    [gameNameLab release];
    
    
    contentTextV = [[UITextView alloc] initWithFrame:CGRectMake(10.0,30.0,SCREEN_WIDTH-50.0,150.0-55.0)];
    [contentTextV setBackgroundColor:[UIColor clearColor]];
    [contentTextV setDelegate:self];
    contentTextV.returnKeyType = UIReturnKeyDone;
    contentTextV.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    contentTextV.scrollEnabled = NO;
    contentTextV.showsHorizontalScrollIndicator = NO;
    [content_bg addSubview:contentTextV];
    
    numberLab = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-140.0,150.0-20.0,100.0,14.0)];
    [numberLab setBackgroundColor:[UIColor clearColor]];
    [numberLab setTextAlignment:NSTextAlignmentRight];
    [numberLab setTextColor:[UIColor colorWithRed:102/255.0 green:101/255.0 blue:99/255.0 alpha:1]];
    [numberLab setFont:[UIFont systemFontOfSize:12.0f]];
    [numberLab setText:@"0/120"];
    [content_bg addSubview:numberLab];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(void) leftButtonItemAction
{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void) rightButtonItemAction


{
    if (contentTextV.text.length > 120) {
        
       // [BPCustomPromptBox showWithTitle:@"内容应小于120个字符"AndDisappearSecond:2];
        
          [BPCustomNoticeBox showCenterWithText:@"内容应小于120个字符" duration:2.0];
        
        
        
        return;
    }
    
    //发送
    if (![[contentTextV.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] isEqualToString:@""]) {
        
        NSString *game_name = [(NSMutableDictionary*)[[BigPlayerSDKBase getSharedBPPlatform] getGamInfoFromLocal] objectForKey:@"game_name"];
        
        [experRequest publishExperience:[NSString stringWithFormat:@"#%@#%@",game_name,contentTextV.text] images:picDataArray];
        
        return;
    }
    
    BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:@"提示" message:@"内容不能为空"  delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alert show];
    [alert release];


}

- (void)addPicAction:(id)sender
{
    [self choicePic];
    

    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self delayMethod];
    });
    
}

- (void)delayMethod
{
    picNumber = picNumber+1;
    
    if (picNumber == 3) {
        
        [addPicBtn setHidden:YES];
    }
    
    [addPicBtn setFrame:CGRectMake(15.0+85*picNumber,15.0,75.0,75.0)];
}


- (void)choicePic
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = NO;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    if (BPDevice_is_ipad) {
        if (popover) {
            [popover release];
            popover = nil;
        }
        popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
        [popover presentPopoverFromRect:CGRectMake(0,100, 300, 300) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }else{
        
        [self presentViewController:imagePickerController animated:YES completion:^{}];
    }
    
    [imagePickerController release];
}

#pragma mark - image picker delegte
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    if (BPDevice_is_ipad) {
        [popover dismissPopoverAnimated:YES];
    }
    
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
    
    //压缩图片
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    //UIGraphicsBeginImageContext(CGSizeMake(228.0, 228.0));
    //[image drawInRect:CGRectMake(0,0,228,228.0)];
    
    float i=1;
    if (image.size.width>500.0) {
        i = 500/image.size.width;
    }
    
    UIGraphicsBeginImageContext(CGSizeMake(image.size.width*i,image.size.height*i));
    [image drawInRect:CGRectMake(0,0,image.size.width*i,image.size.height*i)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //UIImageView *picView = [[UIImageView alloc] initWithFrame:CGRectZero];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectZero];
    //[picView setImage:newImage];
    [btn setImage:newImage forState:UIControlStateNormal];
    [btn setImage:newImage forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(picAction:) forControlEvents:UIControlEventTouchUpInside];
    [btn.layer setCornerRadius:4.0f];
    btn.layer.masksToBounds = YES;
    [picViewArray addObject:btn];
    [bg addSubview:btn];
    //[picView release];
    
    
    for (int i = 0; i<[picViewArray count];i++) {
    
        UIButton *btn = [picViewArray objectAtIndex:i];
        btn.tag = 2015+i;
        [[picViewArray objectAtIndex:i] setFrame:CGRectMake(15.0+85*i,15.0,75.0,75.0)];
        
    }
    
    
    UIGraphicsEndImageContext();
    //NSData *imageData = UIImagePNGRepresentation(newImage);
    NSData *imageData = UIImageJPEGRepresentation(newImage, 1.0);
    
    [picDataArray addObject:imageData];
    
    //存储image
    /*NSString *timeSp = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"/user/user_%@/sendFile/",[ShuZhiZhangUserPreferences CurrentUserID]]];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    NSString *imagePath  =  [path stringByAppendingPathComponent:timeSp];
    [imageData writeToFile:imagePath atomically:YES];
    
    
    //UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];*/
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    
        
    picNumber = picNumber-1;
    
    [addPicBtn setHidden:NO];
    
    [addPicBtn setFrame:CGRectMake(15.0+85*picNumber,15.0,75.0,75.0)];
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
 
}

#pragma mark - UITextView Delegate Method
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    
    [numberLab setText:[NSString stringWithFormat:@"%d/120",(int)[textView.text length]]];
    
    
   // ////////NSLog(@"字符长度 ===== %d",[self unicodeLengthOfString:textView.text]);
    if (range.length == 1) {
        
        if (range.location == 0) {
            
            [numberLab setText:[NSString stringWithFormat:@"%d/120",0]];
            
        }else{
            
            [numberLab setText:[NSString stringWithFormat:@"%d/120",(int)[textView.text length]-1]];
        }
        
        return YES;
        
    }else{
        
        if (range.location == 0) {
            
            [numberLab setText:[NSString stringWithFormat:@"%d/120",0]];
            
        }else{
           
            [numberLab setText:[NSString stringWithFormat:@"%d/120",(int)[textView.text length]+1]];
        }
    }
    
    [numberLab setText:[NSString stringWithFormat:@"%d/120",(int)[textView.text length]]];

    if ([textView.text length] == 120) {
        return NO;
    }
    
    if ([text isEqualToString:@"\n"]) {
        [contentTextV resignFirstResponder];
        return NO;
    }
    return YES;
}


-(NSUInteger) unicodeLengthOfString: (NSString *) text {
    NSUInteger asciiLength = 0;
    
    for (NSUInteger i = 0; i < text.length; i++) {
        
        
        unichar uc = [text characterAtIndex: i];
        
        asciiLength += isascii(uc) ? 1 : 2;
    }
    
    NSUInteger unicodeLength = asciiLength / 2;
    
    if(asciiLength % 2) {
        unicodeLength++;
    }
    
    return unicodeLength;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;
{
    return YES;
}


- (void)picAction:(id)sender
{
    UIButton *btn = (UIButton*)sender;
   // ////////NSLog(@"选中图片————%d",btn.tag-2015);
    
    
    BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:@"提示" message:@"确定删除？"  delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",nil];
    alert.tag = btn.tag+2015;
    [alert show];
    [alert release];
}


#pragma mark - UIAlertView Delegate Method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
       // ////////NSLog(@"btn.tag ===== %d",alertView.tag-2015);
        UIButton *pic_btn = [picViewArray objectAtIndex:alertView.tag-2015-2015];
        [pic_btn removeFromSuperview];
        [picDataArray removeObjectAtIndex:alertView.tag-2015-2015];
        [picViewArray removeObject:pic_btn];
        
        
        for (int i = 0; i<[picViewArray count];i++) {
            
            UIButton *btn = [picViewArray objectAtIndex:i];
            btn.tag = 2015+i;
            [[picViewArray objectAtIndex:i] setFrame:CGRectMake(15.0+85*i,15.0,75.0,75.0)];
            
        }
        
        picNumber = picViewArray.count;
        [addPicBtn setHidden:NO];
        [addPicBtn setFrame:CGRectMake(15.0+85*picNumber,15.0,75.0,75.0)];
        
    }
    
    
}

#pragma mark - keybord mothed
- (void)keyboardWillShow:(NSNotification *)notification
{
    
 	NSDictionary *userInfo = [notification userInfo];
    
    // Get animation info from userInfo
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];

    [UIView animateWithDuration:0.2
                     animations:^{

                         if (SCREEN_IS_LANDSCAPE) {
                            [bg setFrame:CGRectMake(0.0,-120.0,SCREEN_WIDTH,bg.frame.size.height)];
                         }
                         
                     }completion:^(BOOL finish){
                         
                     }];
}


- (void)keyboardWillHide:(NSNotification *)notification
{
    if(SCREEN_IS_LANDSCAPE)
    {
        [self.navigationController setNavigationBarHidden:NO];
    }
	//////////NSLog(@"keyboardWillHide");
 	NSDictionary *userInfo = [notification userInfo];
    
    // Get animation info from userInfo
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    
    [UIView animateWithDuration:0.2
                     animations:^{
                         
                         [bg setFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH,bg.frame.size.height)];
                     }completion:^(BOOL finish){
                         
                     }];
}


@end
