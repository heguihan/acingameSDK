//
//  BPExperienceModel.h
//  BigPlayerSDK
//
//  Created by givin on 14-8-11.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "LKDaoBase.h"
@interface BPExperienceModelBase:LKDAOBase


@end



@interface BPExperienceModel : LKModelBase{
    
    NSString *experience;
    int experId;
}

@property (nonatomic ,copy) NSString *experience;
@property (nonatomic) int experId;


- (id)initWithJsonDictionary:(NSDictionary*)dic;

@end
