//
//  BPPlayerExperienceViewController.m
//  BigPlayerSDK
//
//  Created by givin on 14-8-8.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPPlayerExperienceViewController.h"
#import "BPExperienceCell.h"
#import "BPPublicHandle.h"
#import "BPPublishViewController.h"
#import "BPExperienceModel.h"
#import "DataFactory.h"

@interface BPPlayerExperienceViewController ()

@end

@implementation BPPlayerExperienceViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        [self setTitle:@"心得"];
        //[ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPMessage"
                                                             //InTable:@"BPMultiLanguage"] ViewController:self];
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:[BPLanguage getStringForKey:@"BPBackToGame" InTable:@"BPMultiLanguage"]];
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:NO Title:@"写一条"];
        
        [self.view setBackgroundColor:[UIColor colorWithRed:233/255.0 green:231/255.0 blue:227.0/255.0 alpha:1]];
    }
    return self;
}

- (void)dealloc
{
    
    for (ASIHTTPRequest *activeRequest in [experRequest.RequestQueue operations]) {
        [activeRequest clearDelegatesAndCancel];
    }
    
    [experRequest release];
    experRequest = nil;
    
    [dataArray release];
    dataArray = nil;
    
    [relationArray release];
    relationArray = nil;
    [experTable release];
    [footBar release];
    [number_lab release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    exper_index = 0;
    
    dataArray = [[NSMutableArray alloc] initWithCapacity:10];
    relationArray = [[NSMutableArray alloc] initWithCapacity:10];
    
    experRequest = [[BPExperienceRequest alloc] initWithDelegate:self];
    [experRequest getRelation:2];
    [experRequest getExperience:1 dynamicId:0];
    
    
    [BPPublicHandle cheangeImagePath];
    experTable = [[UITableView alloc] initWithFrame:CGRectMake(0.0, 0.0,SCREEN_WIDTH,SCREEN_HEIGHT-32) style:UITableViewStylePlain];
    [experTable setDataSource:self];
    [experTable setDelegate:self];
    [experTable setBackgroundColor:[UIColor clearColor]];
    [experTable setSeparatorColor:nil];
    [experTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:experTable];
    
    footBar = [[UIView alloc] initWithFrame:CGRectMake(0.0,SCREEN_HEIGHT_NAV-32,SCREEN_WIDTH,32)];
    [footBar setBackgroundColor:[UIColor colorWithRed:33/255.0 green:33/255.0 blue:33/255.0 alpha:1]];
    [self.view addSubview:footBar];
    
    number_lab = [[UILabel alloc] initWithFrame:CGRectMake((SCREEN_WIDTH-100.0)/2, 0.0,100.0,32.0)];
    [number_lab setBackgroundColor:[UIColor clearColor]];
    [number_lab setTextAlignment:NSTextAlignmentCenter];
    [number_lab setTextColor:[UIColor whiteColor]];
    [number_lab setFont:[UIFont systemFontOfSize:15.0]];
    [number_lab setText:@""];
    [footBar addSubview:number_lab];
    
    NSArray *array_x = NULL;
    
    if (!SCREEN_IS_LANDSCAPE) {
        
        array_x = @[@"10.0",@"53.0",[NSString stringWithFormat:@"%f",SCREEN_WIDTH-78.0],[NSString stringWithFormat:@"%f",SCREEN_WIDTH-38.0]];
    }else{
        
        array_x = @[@"21.0",@"101",[NSString stringWithFormat:@"%f",SCREEN_WIDTH-126.0],[NSString stringWithFormat:@"%f",SCREEN_WIDTH-43.0]];
    }
    
    NSArray *image_array = @[@"BP_xinde_up_0.png",@"BP_xinde_do_0.png",@"BP_xinde_zan_0.png",@"BP_xinde_shua_0.png"];
    NSArray *sel_array = @[@"BP_xinde_up_sel.png",@"BP_xinde_do_sel.png",@"BP_xinde_zan_sel.png",@"BP_xinde_shua_sel.png"];
    
    for (int i = 0; i<4; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundColor:[UIColor clearColor]];
        //[btn setTitle:[array objectAtIndex:i] forState:UIControlStateNormal];
        [btn setFrame:CGRectMake([[array_x objectAtIndex:i] floatValue], 0.0,32.0,32.0)];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"ShuZhiZhang.bundle/%@",[image_array objectAtIndex:i]]] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"ShuZhiZhang.bundle/%@",[sel_array objectAtIndex:i]]] forState:UIControlStateHighlighted];
        if (i == 2) {
        [btn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_xinde_zan_l.png"] forState:UIControlStateDisabled];
        }
        btn.tag = 2015+i;
        [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        if (i==0) {
            
            [btn setEnabled:NO];
        }
        [footBar addSubview:btn];
        
    }

}



-(void) leftButtonItemAction
{

    [self dismissModalViewControllerAnimated:YES];
    [ShuZhiZhangUtility postPlatformExitNotification];
    
}

-(void) rightButtonItemAction
{
    BPPublishViewController *controller = [[BPPublishViewController alloc] init];
    
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:10];
    controller.backBlock = ^(NSString *content,NSArray *array){
        
        [dic addEntriesFromDictionary:@{@"type":@"0",@"content":content,@"images":array}];
        
        [dataArray insertObject:dic atIndex:0];
        
        exper_index = 0;
        
        [experTable reloadData];
        
        [number_lab setText:[NSString stringWithFormat:@"%d/%d",exper_index+1,dataArray.count]];
        
        UIButton *btn_up = (UIButton*)[footBar viewWithTag:2015];
        [btn_up setEnabled:NO];
        
    };
    
    
    
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

- (void)btnAction:(id)sender
{
    
    if (dataArray.count == 0) {
        return;
    }

    
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag - 2015) {
        case 0:{
            
            //上
            UIButton *btn_down = (UIButton*)[footBar viewWithTag:2015];
            [btn_down setEnabled:YES];
            exper_index = exper_index-1;
            if (exper_index == 0) {
                //禁点
                [btn setEnabled:NO];
            }

            
            UIButton *btn = (UIButton*)[footBar viewWithTag:2016];
            
            [btn setEnabled:![self cheakIsLike]];
            
            [experTable reloadData];
            
            [number_lab setText:[NSString stringWithFormat:@"%d/%d",exper_index+1,dataArray.count]];
            
        }
            break;
        case 1:{
            //下
            UIButton *btn_up = (UIButton*)[footBar viewWithTag:2015];
            [btn_up setEnabled:YES];
            exper_index = exper_index+1;
            if (exper_index == dataArray.count) {
                //取下30条数据
                ////////NSLog(@"取数据！！");
                [btn setEnabled:NO];
                [experRequest getExperience:2 dynamicId:[[[dataArray objectAtIndex:[dataArray count] -1 ] objectForKey:@"id"] integerValue]];
            }else{
                
                UIButton *btn = (UIButton*)[footBar viewWithTag:2016];
                [btn setEnabled:![self cheakIsLike]];
                
                [experTable reloadData];
                [number_lab setText:[NSString stringWithFormat:@"%d/%d",exper_index+1,dataArray.count]];
            }
        }
            
            break;
        case 2:{
            
            //赞
            [experRequest praise:[[[dataArray objectAtIndex:exper_index] objectForKey:@"id"] integerValue]];
            
        }
            break;
        case 3:{
            //刷新
            [experTable reloadData];
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


- (BOOL)cheakIsLike
{
    
    
    if (![[dataArray objectAtIndex:exper_index] objectForKey:@"id"]) {
        
        return NO;
    }
    
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    NSDictionary *dicc = @{@"experId":[[dataArray objectAtIndex:exper_index] objectForKey:@"id"]};
    [[DataFactory shardDataFactory] searchWhere:dicc orderBy:nil offset:0 count:100000 Classtype:experien callback:^(NSArray *result) {
        
        [array addObjectsFromArray:result];
    }];
    
    if (array.count >0) return YES;
    
    return NO;
    
}


#pragma mark - UITableViewDelegate mothed
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (dataArray.count>0) {
        
        return [self getHight:[dataArray objectAtIndex:exper_index]];
    }
    return SCREEN_HEIGHT_NAV-32;
}




#pragma mark - UITableViewDataSource mothed

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *str = @"cell";
    BPExperienceCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    
    if (cell == nil) {
        
        cell = [[[BPExperienceCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str] autorelease];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
    }
    
    if (dataArray.count>0) {
        
        [cell.attentionBtn setEnabled:YES];
        [cell reloadData:[dataArray objectAtIndex:exper_index]];
        [cell.attentionBtn addTarget:self action:@selector(attentionBtn:) forControlEvents:UIControlEventTouchUpInside];
        [cell.attentionBtn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_xinde_guan_0.png"] forState:UIControlStateNormal];
        [cell.attentionBtn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_xinde_guan_sel.png"]forState:UIControlStateHighlighted];
        [cell.attentionBtn setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_xinde_guan_l.png"] forState:UIControlStateDisabled];
        [cell.attentionBtn setHidden:NO];
        
        for (NSString *rid in relationArray) {
            if ([rid isEqualToString:[[dataArray objectAtIndex:exper_index] objectForKey:@"uid"]]) {
                [cell.attentionBtn setEnabled:NO];
                break;
            }
        }
        
        
        if ([[[dataArray objectAtIndex:exper_index] objectForKey:@"uid"] isEqualToString:[ShuZhiZhangUserPreferences CurrentUserID]]) {
            
            [cell.attentionBtn setHidden:YES];
        }
        
        if ([[dataArray objectAtIndex:exper_index] objectForKey:@"type"]&&[[[dataArray objectAtIndex:exper_index] objectForKey:@"type"] integerValue] == 0) {
            
            [cell.attentionBtn setHidden:YES];
        }
        
        __block BPPlayerExperienceViewController *__self = self;
        cell.picClickBlock = ^(int index,UIImage *image){
            
            [__self blockMethod:image index:index];
        };
    }
    
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}


- (float)getHight:(NSDictionary *)dic
{
    float hight = SCREEN_HEIGHT_NAV-32;
    
    NSString *content;
    
    if ([dic objectForKey:@"type"]&&[[dic objectForKey:@"type"] integerValue] == 0) {
       
        content = [dic objectForKey:@"content"];
        
    }else{
        
        content = [ShuZhiZhangUtility decodeBase64:[dic objectForKey:@"content"]];
        
    }
    
    CGSize titleSize = [content sizeWithFont:[UIFont systemFontOfSize:15.0f] constrainedToSize:CGSizeMake(SCREEN_WIDTH-30.0,MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    
    
    
    int count = [[dic objectForKey:@"json"] count];
    
    float image_hight = titleSize.height+75.0+15.0 +(72+10)*(count%3)+75.0;
    
    if (image_hight-hight>0) {
        
        hight =  image_hight;
    }
    
    return hight;
}

- (void)blockMethod:(UIImage *)image  index:(int)index
{
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0,SCREEN_WIDTH,SCREEN_HEIGHT)];
        [bgView setBackgroundColor:[UIColor blackColor]];
        [self.navigationController.view addSubview:bgView];
        HJManagedImageV *imageV = [[HJManagedImageV alloc] initWithFrame:CGRectMake(20, 40, 90, 60)];
        [imageV setCallbackOnImageTap:self method:@selector(dissAction:)];
    
    
     NSDictionary *dic = [dataArray objectAtIndex:exper_index];
    [imageV setImage:image];
    if ([dic objectForKey:@"type"]&&[[dic objectForKey:@"type"] integerValue] == 0) {
        [imageV setImage:image];
    }else{
        
        if (![[[[dic objectForKey:@"json"] objectAtIndex:index] objectForKey:@"image"] isEqual:[NSNull null]]&&[[[dic objectForKey:@"json"] objectAtIndex:index] objectForKey:@"image"]) {
            
            [[BPPublicHandle sharedPublicHandle] getImage:imageV OtherImageUrl:[[[[dic objectForKey:@"json"] objectAtIndex:index] objectForKey:@"image"] stringByReplacingOccurrencesOfString:@"small_" withString:@""]];
        }
    }
    
    
    
        [bgView addSubview:imageV];
        [imageV release];
        [bgView release];
    
        if(imageV.frame.size.height<200)
        {
            [UIView animateWithDuration:0.3
                             animations:^{
                                 imageV.frame = CGRectMake((SCREEN_WIDTH-300)/2,(SCREEN_HEIGHT-300)/2,300, 300);
                             }
                             completion:^(BOOL finished) {
                                 
                             }];
        }
        else
        {
            [UIView animateWithDuration:0.3
                             animations:^{
                                 if(BPDevice_is_ipad)
                                 {
                                     bgView.frame = CGRectZero;
                                 }
                                 else
                                 {
                                     bgView.frame = CGRectZero;
                                     
                                 }
                             }
                             completion:^(BOOL finished) {
                                 
                             }];
        }
    
}

//加关注
- (void)attentionBtn:(id)sender
{
    //加关注
    for (NSString *rid in relationArray) {
        if ([rid isEqualToString:[[dataArray objectAtIndex:exper_index] objectForKey:@"uid"]]) {
            //取消关注
            return;
        }
    }
    
    //加关注
    [experRequest attention:[[[dataArray objectAtIndex:exper_index] objectForKey:@"uid"] integerValue]];
    
}

- (void)dissAction:(id)sender
{
    HJManagedImageV *picImageV = (HJManagedImageV *)sender;
    
    [picImageV.superview removeFromSuperview];
}






@end
