//
//  BPPublishViewController.h
//  BigPlayerSDK
//
//  Created by givin on 14-8-9.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPBaseViewController.h"
#import "BPExperienceRequest.h"

@interface BPPublishViewController : BPBaseViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate>{

    UIView *bg;
    
    UIButton *addPicBtn;
    UITextView *contentTextV;
    
    UILabel *numberLab;
    
    UIPopoverController *popover;
    
    NSMutableArray *picViewArray;
    
    NSMutableArray *picDataArray;
    
    int picNumber;
    
    CGRect keyboardEndFrame;
    
    BPExperienceRequest *experRequest;
    
    
}

@property (nonatomic ,retain) UIButton *addPicBtn;
@property (nonatomic ,strong) void (^backBlock)(NSString *content,NSArray *images);


@end
