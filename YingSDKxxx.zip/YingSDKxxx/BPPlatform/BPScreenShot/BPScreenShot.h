//
//  BPScreenShot.h
//  BPbuttonBoard
//
//  Created by SkyGame on 16/7/1.
//  Copyright © 2016年 SkyGame. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/PHPhotoLibrary.h>
#import <UIKit/UIKit.h>


@interface BPScreenShot : NSObject


+ (BPScreenShot *)sharedManager;

- (NSString *)GetPickPath;// 获得路径

-(void)ScreenShot;  // 截屏
@end
