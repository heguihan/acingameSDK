//
//  BPForgotPasswordView.h
//  BigPlayerSDK
//

//

#import <UIKit/UIKit.h>
#import "BPRegisterAndLoginRequest.h"
#import "BPLoginPublic.h"

@interface BPForgotPasswordView : UIView <UITextFieldDelegate,UIActionSheetDelegate>
{
    int backType;
    int currentCountDown;   // 手机
    NSTimer *countdownTimer;
    

}

@property (nonatomic,retain) BPRegisterAndLoginRequest *bpRequest;
@end
