//
//  BPForgotPasswordView.m
//  BigPlayerSDK
//

//

#import "BPForgotPasswordView.h"

@implementation BPForgotPasswordView
@synthesize bpRequest;


-(void) dealloc
{
    [super dealloc];
}

-(void) leftButtonItemAction
{
    [UIView animateWithDuration:0.3
                     animations:^{
                         self.alpha = 0.0;
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                     }];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2, BPBackImageWidth, BPBackImageHeight);
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.0;
        [self addSubview:background];
        [background release];
        
        
        [self showThings];
    }
    return self;
}


-(void) setLabelProperty: (UILabel *)label
{
    label.textAlignment = NSTextAlignmentLeft;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    label.backgroundColor = [UIColor clearColor];
}


-(void) showThings
{
    self.alpha = 0.0;
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                     }];
    
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
    backImageView.frame = CGRectMake(0.0,0.0, BPBackImageWidth, BPBackImageHeight);
    backImageView.userInteractionEnabled = YES;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
    [backImageView release];
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 80, BPBackImageWidth,BPBackImageWidth)];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.scrollEnabled = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.tag = 999888;
    scrollView.contentOffset = CGPointMake(0, 0);
    scrollView.contentSize  =CGSizeMake(250, 150);
    [backImageView addSubview:scrollView];
    
    
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-200)/2, 0, 200, 50)];
    lab.text = @"找回密码";
    lab.textColor = [UIColor whiteColor];
    lab.font = [UIFont fontWithName:@"Helvetica-Bold" size:35];
    lab.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:lab];
    
    
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(15, 10, 25, 25);
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:leftButton];
    
    
    //通行证
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    userField.placeholder = @"手机号:";
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    userField.layer.borderWidth =1.0;
    userField.layer.cornerRadius =5.0;
    userField.font = [UIFont systemFontOfSize:14];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    userField.backgroundColor = [UIColor redColor];
    userField.textAlignment = NSTextAlignmentLeft;
    userField.delegate = self;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    userField.PlaceholderOffset_y = 2;
    userField.PlaceholderOffset_x = 10;
    userField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    userField.returnKeyType = UIReturnKeyNext;
    userField.tag = 1000;
    [scrollView addSubview:userField];
    
    
    //验证码
    BPCustomTextField *verificationField = [[BPCustomTextField alloc] init];
    verificationField.placeholder = @"验证码:";
    verificationField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    verificationField.layer.borderWidth =1.0;
    verificationField.delegate = self;
    verificationField.layer.cornerRadius =5.0;
    verificationField.font = [UIFont systemFontOfSize:14];
    verificationField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    verificationField.textAlignment = NSTextAlignmentLeft;
    verificationField.keyboardType = UIKeyboardTypeASCIICapable;
    verificationField.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    //是否纠错
    verificationField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    verificationField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    verificationField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    verificationField.PlaceholderOffset_x = 10;
    verificationField.PlaceholderOffset_y = 2;
    verificationField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    [backImageView addSubview:verificationField];
    verificationField.returnKeyType = UIReturnKeyNext;
    verificationField.tag = 2000;
    [scrollView addSubview:verificationField];
    
    // 获取验证码
    UIButton *sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sendButton.backgroundColor = [UIColor colorWithRed: 227/255.0 green:80/255.0 blue:6/255.0 alpha:1];
    [sendButton addTarget:self action:@selector(sendPhoneVerificationAction:) forControlEvents:UIControlEventTouchUpInside];
    sendButton.layer.cornerRadius = 5;
    [sendButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
    sendButton.titleLabel.font = [UIFont systemFontOfSize:14];
    sendButton.tag = 1001;
    [sendButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [scrollView addSubview:sendButton];
    [sendButton setTitleColor:[UIColor colorWithRed:5/255.0 green:189/255.0 blue:253/255.0 alpha:1]forState:UIControlStateNormal];
    
    
    
    
    //密码
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
    passwordField.placeholder = @"设置新密码:";
    passwordField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    passwordField.layer.borderWidth =1.0;
    passwordField.layer.cornerRadius =5.0;
    passwordField.font = [UIFont systemFontOfSize:14];
    passwordField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    passwordField.textAlignment = NSTextAlignmentLeft;
    passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    passwordField.secureTextEntry = YES; //密码输入
    passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    passwordField.delegate= self;
    //是否纠错
    passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    passwordField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    passwordField.PlaceholderOffset_x = 10;
    passwordField.PlaceholderOffset_y = 2;
    passwordField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    passwordField.returnKeyType = UIReturnKeyGo;
    passwordField.tag = 3000;
    [scrollView addSubview:passwordField];
    

    userField.frame = CGRectMake((BPBackImageWidth-250)/2, 5, 250, 35);
    verificationField.frame = CGRectMake((BPBackImageWidth-250)/2, 50, 120, 35);
    passwordField.frame = CGRectMake((BPBackImageWidth-250)/2, 95, 250, 35);
    sendButton.frame = CGRectMake(BPBackImageWidth -125, 50, 100, 35);
    
//    
//    // 坐标集合 0 2
//    userField.frame = CGRectMake((BPBackImageWidth-250)/2, 5, 250, 35);
//    verificationField.frame = CGRectMake((BPBackImageWidth-250)/2, 50, 125, 35);
//    passwordField.frame = CGRectMake((BPBackImageWidth-250)/2, 95, 250, 35);
//    sendButton.frame = CGRectMake(BPBackImageWidth -125, 50, 100, 35);
    
    
    
    
    UIButton *tishiButton = [UIButton buttonWithType:UIButtonTypeCustom];
    NSString *tishiStr = [BPLanguage getStringForKey:@"BPNotSetSecretSecurity" InTable:@"BPMultiLanguage"];
    tishiStr = [NSString stringWithFormat:@"%@(%@)",tishiStr,[ShuZhiZhangUserPreferences currentAccountServicePhone]];
    [tishiButton setTitle:tishiStr forState:UIControlStateNormal];
    tishiButton.titleLabel.font = [UIFont systemFontOfSize:12];
    [tishiButton setTitleColor:[UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1] forState:UIControlStateNormal];
    [tishiButton addTarget:self action:@selector(clickTishiButton) forControlEvents:UIControlEventTouchUpInside];
   // [backImageView addSubview:tishiButton];
//    userField.frame = CGRectMake(0, 0, 250, 40);
    tishiButton.frame = CGRectMake(0, 260, 300, 22);

    
    UIButton * back_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [back_button setTitle:@"提交新密码" forState:UIControlStateNormal];
    back_button.titleLabel.font = [UIFont boldSystemFontOfSize:16.0f];
    [back_button setTitleColor:[UIColor colorWithRed:98/255.0 green:18/255.0 blue:131/255.0 alpha:1]forState:UIControlStateNormal];
    [back_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
    [back_button addTarget:self action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    back_button.frame = CGRectMake((BPBackImageWidth - 250)/2.0, 225, 250, 42);
    [backImageView addSubview:back_button];
}


-(void) clickTishiButton
{
    NSString *callNumber = [ShuZhiZhangUserPreferences currentAccountServicePhone];
    
    if(!callNumber || (NSNull *)callNumber == [NSNull null] || callNumber.length<1)
    {
        callNumber = @"4006114333";
    }
    BPCustomActionSheet *callPhone = [[BPCustomActionSheet alloc] initWithtitles:[NSString stringWithFormat:@"%@ %@",[BPLanguage getStringForKey:@"BPCall" InTable:@"BPMultiLanguage"],callNumber],[BPLanguage getStringForKey:@"BPCancel" InTable:@"BPMultiLanguage"],nil];
    [callPhone showInView:self];
    callPhone.delegate = self;
    callPhone.tag = 31001;
    [callPhone release];
}

-(void)clickCancelButton{

    [self removeFromSuperview];

}





#pragma mark -------keyboard event-------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (range.location >= 18&&![string isEqualToString:@""]&&textField.tag==1000)
        return NO; // return NO to not change text
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UITextField * phoneField = (UITextField *)[self viewWithTag:3000];

    if(SCREEN_IS_LANDSCAPE){
        if (textField == phoneField) {
            
       
        UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
        
        [UIView animateWithDuration:0.3 animations:^{
            
            scroll.contentOffset = CGPointMake(0, 50);
            
        }];
        scroll.scrollEnabled = YES;
        
      }
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    [UIView animateWithDuration:0.3 animations:^{
        
        scroll.contentOffset = CGPointMake(0, 0);
        
    }];
    scroll.scrollEnabled = NO;
    
    //     [BPLoginPublic ViewScrollDown_little: self];
}

//隐藏键盘
-(void) hideAllKeyBoard
{
    BPCustomTextField *phoneText = (BPCustomTextField *)[self viewWithTag:1000];
    BPCustomTextField *codeText = (BPCustomTextField *)[self viewWithTag:2000];
    BPCustomTextField *pwdText = (BPCustomTextField *)[self viewWithTag:3000];
    [phoneText resignFirstResponder];
    [codeText resignFirstResponder];
    [pwdText resignFirstResponder];
    
    
    
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    BPCustomTextField *phoneText = (BPCustomTextField *)[self viewWithTag:1000];
    BPCustomTextField *codeText = (BPCustomTextField *)[self viewWithTag:2000];
    BPCustomTextField *pwdText = (BPCustomTextField *)[self viewWithTag:3000];
    
    if(textField == phoneText)
    {
        [phoneText resignFirstResponder];
        [codeText becomeFirstResponder];
    }else if(textField == codeText)
    {
        [codeText resignFirstResponder];
        [pwdText becomeFirstResponder];
    }
    else if(textField == pwdText)
    {
        [self hideAllKeyBoard];
        [self rightButtonItemAction];
    }
    return YES;
}

#pragma mark -------click button------------

//完成
- (void)rightButtonItemAction
{
    [self hideAllKeyBoard];
    
    BPCustomTextField *phoneText = (BPCustomTextField *)[self viewWithTag:1000];
    BPCustomTextField *codeText = (BPCustomTextField *)[self viewWithTag:2000];
    BPCustomTextField *pwdText = (BPCustomTextField *)[self viewWithTag:3000];


    if (phoneText.text.length == 0 || codeText.text.length ==  0 || pwdText.text.length == 0) {
        
          [BPCustomNoticeBox showCenterWithText:@"输入不能为空,请正确输入" duration:2.0];
        
        return;
    }  
        if([ShuZhiZhangUtility isMobileNumber:phoneText.text])
         {
            [self  requestBackPasswordWithPhoneNumber:phoneText.text SecurityCode:codeText.text passWord:pwdText.text];
             
            [BPQLoadingView showDefaultLoadingViewWithView:self];
            
            return;
         }else{
         
             [BPCustomNoticeBox showCenterWithText:@"手机号码格式不正确" duration:2.0];

         }
}

// 找回

-(void)requestBackPasswordWithPhoneNumber:(NSString *)phoneNumber SecurityCode:(NSString *)securityCode passWord:(NSString *)password{
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"code":securityCode,
                           @"phoneNumber":phoneNumber,
                           @"pwd":[ShuZhiZhangUtility md5String:password],
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]
                           };
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"update",appid,sortStr,sign];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{

        [BPQLoadingView hideWithAnimated:NO];
        ////////NSLog(@"更新密码dict = %@,urlStr = %@",data,urlStr);
        
        if ([[data objectForKey:@"ret"] intValue]==0) {
         [BPCustomNoticeBox showCenterWithText:@"密码更新成功" duration:2.0];
        [self leftButtonItemAction];
            
        }else{
            
            [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
            
        }
    });
} failure:^(NSError *error) {
        
    }];
}



// 获取手机号验证码按钮点击事件
-(void)sendPhoneVerificationAction:(UIButton *)button
{
    
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    
    if(currentCountDown== 0 && [ShuZhiZhangUtility isMobileNumber:phoneNumber.text]) {
        
        currentCountDown = 60;
        
        [self requestForPhoneVertifyCode:phoneNumber.text];
        
        
    }else if (![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
        if(phoneNumber.text.length<1)
        {
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] duration:2.0];
            [ShuZhiZhangUtility setPromptPosition];
            return;
        }
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPRegistPhoneSecuritycode" InTable:@"BPMultiLanguage"] duration:2.0];
        
    }
    
}


/*
 *  手机号验证码
 */
-(void) requestForPhoneVertifyCode:(NSString *)phonenumber
{
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"phoneNumber":phonenumber,
                           @"action":@"update",
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]

                        };
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"sendSMS",appid,sortStr,sign];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            ////////NSLog(@"手机号验证码dict = %@,urlStr = %@",data,urlStr);
            
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [BPCustomNoticeBox showCenterWithText:@"验证码发送成功" duration:2.0];
                [self createPhoneCountTimer];
            }else{
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [self stopCountDown];
            }
        });
        
    } failure:^(NSError *error) {
        
    }];
}



#pragma mark --------定时器-----
// 手机定时
-(void)createPhoneCountTimer
{
    if(countdownTimer==nil)
    {
        countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(VerifyCountDown) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:countdownTimer forMode:NSDefaultRunLoopMode];
    }
    
    [self showCountDownButton:currentCountDown];

}


//停止倒计时
-(void) stopCountDown
{
    [countdownTimer invalidate];
    countdownTimer = nil;
    currentCountDown = 0;
    
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    getVerifyCode.userInteractionEnabled = YES;
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
    
}



// 手机定时器的方法倒计时开始
-(void) VerifyCountDown
{
    currentCountDown--;
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    [self showCountDownButton:currentCountDown];
    getVerifyCode.userInteractionEnabled = NO;
    if(currentCountDown==0)
    {
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
        getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
        [countdownTimer invalidate];
        getVerifyCode.userInteractionEnabled = YES;
        countdownTimer = nil;
        return;
    }
    
}

//显示多少秒后获取验证码
-(void) showCountDownButton:(int)seconds
{
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:18];
    [getVerifyCode setTitle:[NSString stringWithFormat:@"%d S",seconds] forState:UIControlStateNormal];
    
}






- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
