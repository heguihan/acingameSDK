//
//  BPForgotPasswordViewController.m
//  BigPlayerSDK
//
//

#import "BPForgotPasswordViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "BPLoginPublic.h"
#import "BPWebViewBaseViewController.h"

@interface BPForgotPasswordViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *bpRequest;
@end

@implementation BPForgotPasswordViewController
@synthesize bpRequest;


-(void) dealloc
{
    [bpRequest release];        bpRequest = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"BP_cancel.png" HighLightedImage:@"BP_cancel_sel.png"];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:NO NormalImage:@"ShuZhiZhang.bundle/BP_finish.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_finish_sel.png"];
//
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BP_login_background.png"]];
        
//        passwordRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    }
    return self;
}

-(void) leftButtonItemAction
{
    [self.navigationController popViewControllerAnimated:YES];
    [bpRequest cancelAllRequest];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
//    self.title = [BPLanguage getStringForKey:@"BPBackSecret" InTable:@"BPMultiLanguage"];
    [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPBackSecret" InTable:@"BPMultiLanguage"] ViewController:self];
     bpRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        
    [self showThings];
}

-(void) setLabelProperty: (UILabel *)label
{
    label.textAlignment = NSTextAlignmentLeft;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    label.backgroundColor = [UIColor clearColor];
}


-(void) showThings
{
    //通行证
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    userField.placeholder = [BPLanguage getStringForKey:@"BPForgetEnter" InTable:@"BPMultiLanguage"];
    [BPLoginPublic setTextFieldProperty:userField withDelegate:self];
    userField.TextOffset_x = 15;
    userField.textAlignment = NSTextAlignmentRight;
    userField.returnKeyType = UIReturnKeyNext;
    userField.tag = 100;
    [self.view addSubview: userField];
    [userField release];

    UILabel *accoutLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
    accoutLabel.text = [BPLanguage getStringForKey:@"BPRegistAccount" InTable:@"BPMultiLanguage"];
    [self setLabelProperty:accoutLabel];
    [userField addSubview:accoutLabel];
    [accoutLabel release];
    
    //找回方式
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_inputButton_bg.png"] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_inputButton_bg.png"] forState:UIControlStateHighlighted];
    button.tag = 200;
    [button addTarget:self action:@selector(clickBackType) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
    typeLabel.text = [BPLanguage getStringForKey:@"BPForgetBackType" InTable:@"BPMultiLanguage"];
    [self setLabelProperty:typeLabel];
    [button addSubview:typeLabel];
    [typeLabel release];
    
    UILabel *typeLabel2 = [[UILabel alloc] init];
    typeLabel2.text = [BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"];
    typeLabel2.textAlignment = NSTextAlignmentRight;
    typeLabel2.font = [UIFont systemFontOfSize:14];
    typeLabel2.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    typeLabel2.backgroundColor = [UIColor clearColor];
    typeLabel2.tag  = 201;
    [button addSubview:typeLabel2];
    [typeLabel2 release];
    
    UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_list.png"]];
    [button addSubview:imgView];
    [imgView release];
    
    //手机／邮箱
    BPCustomTextField *phoneField = [[BPCustomTextField alloc] init];
    phoneField.placeholder = [BPLanguage getStringForKey:@"BPForgetEnter" InTable:@"BPMultiLanguage"];
    [BPLoginPublic setTextFieldProperty:phoneField withDelegate:self];
    phoneField.TextOffset_x = 15;
    phoneField.textAlignment = NSTextAlignmentRight;
    phoneField.returnKeyType = UIReturnKeyNext;
    phoneField.keyboardType = UIKeyboardTypeNumberPad;
    phoneField.tag = 300;
    [self.view addSubview:phoneField];
    [phoneField release];
    
    UILabel *phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
    phoneLabel.text = [BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"];
    [self setLabelProperty:phoneLabel];
    phoneLabel.tag = 301;
    [phoneField addSubview:phoneLabel];
    [phoneLabel release];
    
    UIButton *tishiButton = [UIButton buttonWithType:UIButtonTypeCustom];
    NSString *tishiStr = [BPLanguage getStringForKey:@"BPNotSetSecretSecurity" InTable:@"BPMultiLanguage"];
    tishiStr = [NSString stringWithFormat:@"%@(%@)",tishiStr,[ShuZhiZhangUserPreferences currentAccountServicePhone]];
    [tishiButton setTitle:tishiStr forState:UIControlStateNormal];
    tishiButton.titleLabel.font = [UIFont systemFontOfSize:12];
    [tishiButton setTitleColor:[UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1] forState:UIControlStateNormal];
    [tishiButton addTarget:self action:@selector(clickTishiButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tishiButton];
    CGSize size = [tishiStr sizeWithFont:[UIFont systemFontOfSize:12]];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        userField.frame = CGRectMake((SCREEN_WIDTH-300)/2, 20, 300, 40);
        button.frame = CGRectMake((SCREEN_WIDTH-300)/2, 75, 300, 40);
        typeLabel2.frame = CGRectMake(button.frame.size.width - 100, 0, 70, 40);
        imgView.frame = CGRectMake(button.frame.size.width - 20, 14, 6, 12);
        phoneField.frame = CGRectMake((SCREEN_WIDTH-300)/2, 130, 300, 40);
        
        tishiButton.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH-300)/2 - size.width, 175, size.width, 22);
        
        userField.PlaceholderOffset_x = 245;
        phoneField.PlaceholderOffset_x = 245;
    }
    else
    {
        userField.frame = CGRectMake((SCREEN_WIDTH-290)/2, 25, 290, 40);
        button.frame = CGRectMake((SCREEN_WIDTH-290)/2, 85, 290, 40);
        typeLabel2.frame = CGRectMake(button.frame.size.width - 100, 0, 70, 40);
        imgView.frame = CGRectMake(button.frame.size.width - 20, 14, 6, 12);
        phoneField.frame = CGRectMake((SCREEN_WIDTH-290)/2, 145, 290, 40);
        tishiButton.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH-290)/2 - size.width, 190, size.width, 22);
        
        userField.PlaceholderOffset_x = 238;
        phoneField.PlaceholderOffset_x = 238;
    }
    
}


-(void) clickTishiButton
{
    BPCustomActionSheet *callPhone = [[BPCustomActionSheet alloc] initWithtitles:[NSString stringWithFormat:@"%@ %@",[BPLanguage getStringForKey:@"BPCall" InTable:@"BPMultiLanguage"],[ShuZhiZhangUserPreferences currentAccountServicePhone]],[BPLanguage getStringForKey:@"BPCancel" InTable:@"BPMultiLanguage"],nil];
    [callPhone showInView:self.view];
    callPhone.delegate = self;
    callPhone.tag = 31001;
    [callPhone release];
}


#pragma mark -------keyboard event-------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (range.location >= 18&&![string isEqualToString:@""])
        return NO; // return NO to not change text
    return YES;
}

//隐藏键盘
-(void) hideAllKeyBoard
{
    UITextField * userField = (UITextField *)[self.view viewWithTag:100];
    UITextField * phoneField = (UITextField *)[self.view viewWithTag:300];
    
    [userField resignFirstResponder];
    [phoneField resignFirstResponder];
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * userField = (UITextField *)[self.view viewWithTag:100];
    UITextField * phoneField = (UITextField *)[self.view viewWithTag:300];
    
    if(textField == userField)
    {
        [userField resignFirstResponder];
        [phoneField becomeFirstResponder];
    }
    else if(textField == phoneField)
    {
        [self hideAllKeyBoard];
        [self rightButtonItemAction];
    }
    return YES;
}

#pragma mark -------click button------------

//完成
- (void)rightButtonItemAction
{
    [self hideAllKeyBoard];
    
    BPCustomTextField *userText = (BPCustomTextField *)[self.view viewWithTag:100];
    BPCustomTextField *phoneText = (BPCustomTextField *)[self.view viewWithTag:300];
    
    NSString *regularExpression = @"^[A-z0-9_@.-]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:userText.text] == NO)
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
          [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        
        return;
    }
    
    if(backType == 0)
    {
        if([ShuZhiZhangUtility isMobileNumber:phoneText.text])
        {
            [self.bpRequest backPasswordByPhoneOrMail:userText.text phoneOrMailNum:phoneText.text Type:0];
            [BPQLoadingView showDefaultLoadingViewWithView:self.view];
            return;
        }
        ////手机号无效
        //[BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPInvalidPhonePrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
          [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPInvalidPhonePrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        
        
    }
    else if(backType == 1)
    {
        if([ShuZhiZhangUtility isValidateEmail:phoneText.text])
        {
            [self.bpRequest backPasswordByPhoneOrMail:userText.text phoneOrMailNum:phoneText.text Type:1];
            [BPQLoadingView showDefaultLoadingViewWithView:self.view];
            return;
        }
        //邮箱无效
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPInvalidEmailPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPInvalidEmailPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
    }
}

-(void) clickBackType
{
    [self hideAllKeyBoard];
    
    BPCustomActionSheet *actionSheet=[[BPCustomActionSheet alloc] initWithtitles:[BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPForgetEmail" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPCancel" InTable:@"BPMultiLanguage"],nil];
    if(BPDevice_is_ipad)
    {
        [actionSheet showFromRect:CGRectMake(18,-200, 500, 310) inView:self.view animated:YES];
    }
    else
    {
        [actionSheet showInView:self.view];
    }
    actionSheet.delegate = self;
    actionSheet.tag = 31002;
    [actionSheet release];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(actionSheet.tag == 31001 && buttonIndex == 0)
    {
        [actionSheet dismissWithClickedButtonIndex:1 animated:NO];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",[ShuZhiZhangUserPreferences currentAccountServicePhone]]]];
    }
    else if(actionSheet.tag == 31002)
    {
        if(buttonIndex != 2)
        {
            backType = buttonIndex;
            NSString *str;
            UITextField * phoneField = (UITextField *)[self.view viewWithTag:300];
            if(backType ==0)
            {
                str = [BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"];
                phoneField.keyboardType = UIKeyboardTypeNumberPad;
            }
            else
            {
                str = [BPLanguage getStringForKey:@"BPForgetEmail" InTable:@"BPMultiLanguage"];
                phoneField.keyboardType = UIKeyboardTypeEmailAddress;
            }
            UIButton *button = (UIButton *)[self.view viewWithTag:200];
            UILabel *typeLabel2 = (UILabel *)[button viewWithTag:201];
            typeLabel2.text = str;
            
            BPCustomTextField *phoneText = (BPCustomTextField *)[self.view viewWithTag:300];
            UILabel *phoneLabel = (UILabel *)[phoneText viewWithTag:301];
            phoneLabel.text = str;
        }
    }
}


#pragma mark -----request delegate-----
/*****************************
 -10：参数不能为空；
 -20：检测数据失败；
 -30：账号不存在；
 -40：与用户绑定的邮箱不符；
 0：密码修改失败；
 1：新密码修改成功，已发送到邮箱
 *****************************/

-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    ////////NSLog(@"---%@=========%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPForgetPassword"])
    {
        int returnValue = [[request responseString] intValue];
        int type = [[userInfo objectForKey:@"backType"] intValue];
        if(returnValue == 1)
        {
            if(type == 0)
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneBackSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
                
                 [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneBackSuccess" InTable:@"BPMultiLanguage"] duration:2.0];
                
            }
            else
            {
               //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEmailBackSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
                  [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPEmailBackSuccess" InTable:@"BPMultiLanguage"] duration:2.0];
                
            }
        }
        else if(returnValue == -30)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccountNotExistPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
              [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountNotExistPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
            
        }
        else if(returnValue == -40)
        {
            if(type == 0)
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneNotConform" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
                
                
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneNotConform" InTable:@"BPMultiLanguage"] duration:2.0];

            }
            else
            {
               // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEmialNotConform" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
                
                 [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPEmialNotConform" InTable:@"BPMultiLanguage"] duration:2.0];
            }
        }
        else
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPasswordBackFail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordBackFail" InTable:@"BPMultiLanguage"] duration:2.0];

        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
