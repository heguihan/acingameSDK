//
//  BPForgotPasswordViewController.h
//  BigPlayerSDK

//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"


@interface BPForgotPasswordViewController : BPBaseViewController <UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>
{
    int backType;
}

//@property (nonatomic,retain) BPRegisterAndLoginRequest *passwordRequest;

//隐藏键盘
-(void) hideAllKeyBoard;

-(void) setLabelProperty: (UILabel *)label;
@end
