//
//  VistorTipsView.h
//  BigPlayerSDK
//
//  Created by SkyGame on 16/12/30.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPVistorTipsView : UIView

@property(nonatomic, strong)NSTimer *logtimer;
-(void) showRegisterTipsThings;
@end
