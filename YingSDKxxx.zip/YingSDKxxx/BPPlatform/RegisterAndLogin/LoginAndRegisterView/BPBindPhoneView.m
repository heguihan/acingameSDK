//
//  VistorTipsView.m
//  BigPlayerSDK
//
//  Created by SkyGame on 16/12/30.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import "BPBindPhoneView.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "TPBindSmallView.h"
#import "BPBindCustomPhoneView.h"

@implementation BPBindPhoneView

static BPBindPhoneView *tipsView = nil;
+(BPBindPhoneView*)ShareInstance{
    
    static  dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        
        tipsView = [[BPBindPhoneView alloc]init];
        
    });
    
    return  tipsView;
    
    
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.0;
        [self addSubview:background];
        [background release];
        
    }
    return self;
}


-(void) showBindPhoneTipsThings:(NSString *)attentionText type:(NSInteger) type
{
    
    ////////NSLog(@"hghqqqqqqq====加载提示框");
    bindType = type;
    
    [[ShuZhiZhangUtility getCurrentViewController].view addSubview:self];
    self.alpha = 0.0;
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                         
                     }];
    
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2.0,(REAL_SCREEN_HEIGHT - BPBackImageHeight)/2.0 +BPBackImageHeight/4+5, BPBackImageWidth, BPBackImageHeight/2);
    backImageView.userInteractionEnabled = YES;
    backImageView.layer.borderColor = [UIColor orangeColor].CGColor;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
    [backImageView release];
    
//    UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0,0, BPBackImageWidth, BPBackImageHeight/2)];
//    backgroundView.alpha = 0.8;
//    backgroundView.userInteractionEnabled = YES;
//    backgroundView.backgroundColor = [UIColor blackColor];
//    [backImageView addSubview:backgroundView];
//    [backgroundView release];
    
    
    UILabel *labele = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, BPBackImageWidth, 45)];
    labele.text = @"温馨提示";
    labele.textAlignment = NSTextAlignmentCenter;
    labele.font = [UIFont systemFontOfSize:20];
    [backImageView addSubview:labele];
    
    
    // 左上角小X按钮
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateHighlighted];
    leftButton.frame = CGRectMake(BPBackImageWidth-30, 5, 40, 40);
    [leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 20, 20)];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
  //  [backImageView addSubview:leftButton];

    
    
    UITextView *textView = [[UITextView alloc]initWithFrame:CGRectMake(10, 35, BPBackImageWidth-20, 100)];
    textView.text = attentionText;
    textView.scrollEnabled = YES;
    textView.editable = NO;
    textView.textColor = [UIColor blackColor];
    textView.backgroundColor = [UIColor clearColor];
    textView.font = [UIFont systemFontOfSize:14];
    [backImageView addSubview:textView];
    
    UIButton * fasterEnter = [UIButton buttonWithType:UIButtonTypeCustom];
    [fasterEnter setTitle:@"下次再说" forState:UIControlStateNormal];
    fasterEnter.titleLabel.font = [UIFont boldSystemFontOfSize:16.0f];
    [fasterEnter setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [fasterEnter setBackgroundColor:[UIColor colorWithRed: 227/255.0 green:80/255.0 blue:6/255.0 alpha:1]];
    fasterEnter.layer.cornerRadius = 5;
    [fasterEnter setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
//    [fasterEnter setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/littlepage.png"] forState:UIControlStateHighlighted];
    [fasterEnter addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
    fasterEnter.frame = CGRectMake(20, 100, (BPBackImageWidth-80)/2, 40);
    [backImageView addSubview:fasterEnter];

    
    UIButton * bindPhone = [UIButton buttonWithType:UIButtonTypeCustom];
    [bindPhone setTitle:@"立即绑定" forState:UIControlStateNormal];
    bindPhone.titleLabel.font = [UIFont boldSystemFontOfSize:16.0f];
    [bindPhone setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [bindPhone setBackgroundColor:[UIColor colorWithRed: 227/255.0 green:80/255.0 blue:6/255.0 alpha:1]];
    bindPhone.layer.cornerRadius = 5;
    [bindPhone setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
//    [bindPhone setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/littlepage.png"] forState:UIControlStateHighlighted];
    [bindPhone addTarget:self action:@selector(bindPhoneButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    bindPhone.frame = CGRectMake((BPBackImageWidth-80)/2+60, 100, (BPBackImageWidth-80)/2, 40);
    [backImageView addSubview:bindPhone];
    


}

-(void)clickCancelButton{

    [self removeFromSuperview];


}

-(void)fasterEnterButtonItemAction{

 

}


-(void)bindPhoneButtonItemAction{

    if (bindType == 2) {
        
        [[BPBindCustomPhoneView getShareInstance] showBindSmallVies];

    }else{
    
        [[TPBindSmallView getShareInstance] showBindSmallVies];
    }


    [self clickCancelButton];



}
/*
 * 游客模式
 *
 * 一秒注册，快速进入
 */
-(void) oneSecondRegiste
{
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?type=3",GLOBAL_LOGIN_API_URL,@"register",appid];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSString * signStr = [NSString stringWithFormat:@"ts=%@&type=3&key=%@",dateStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    urlStr = [NSString stringWithFormat:@"%@&ts=%@&sign=%@",urlStr,dateStr,sign];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            ////////NSLog(@"游客登录回包dict = %@,urlStr = %@",data,urlStr);
            
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [self registCompleteAndExit];
                [userInfo setObject:[[data objectForKey:@"token"] substringToIndex:8] forKey:@"password"];
                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
                [BPShowLoginPrompt showWithName:[data objectForKey:@"userID"]];
                [BPLoginPublic userDidLoginAction:userInfo];
                [BPCustomNoticeBox showCenterWithText:@"注册成功" duration:2.0];
                
            }else{
                
                [BPCustomNoticeBox showCenterWithText:@"注册失败" duration:2.0];
                [BPQLoadingView hideWithAnimated:YES];
            }
        });
        
    } failure:^(NSError *error) {
        
    }];
    
}

//游客登录成功并自动关闭界面
-(void) registCompleteAndExit
{
    [self removeFromSuperview];
    //发送注册成功消息
    ////////NSLog(@"post0000000000");
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:[ShuZhiZhangUserPreferences getCurrentToken],@"token",@"BPLoginSuccess", @"result",nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
    
    [BPShowLoginPrompt showWithName:@""];
    
}

@end
