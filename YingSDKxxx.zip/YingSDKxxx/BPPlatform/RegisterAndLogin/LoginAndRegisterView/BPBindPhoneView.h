//
//  VistorTipsView.h
//  BigPlayerSDK
//
//  Created by SkyGame on 16/12/30.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPBindPhoneView : UIView
{
 
    NSInteger bindType;
  
}

+(BPBindPhoneView*)ShareInstance;
-(void) showBindPhoneTipsThings:(NSString *)attentionText type:(NSInteger) type;
@end
