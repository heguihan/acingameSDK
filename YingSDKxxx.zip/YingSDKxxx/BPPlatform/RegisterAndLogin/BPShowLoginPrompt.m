//
//  BPShowLoginPrompt.m
//  BigPlayerSDK
//

//

#import "BPShowLoginPrompt.h"
#import <QuartzCore/CALayer.h>
#import "BPButtonBoard.h"
//#import "testtttViewController.h"
#import "BPLoginView.h"
@implementation BPShowLoginPrompt

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code

        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
//        self.frame = CGRectMake(20, 0, SCREEN_WIDTH-40, 50);
        self.frame = CGRectMake((SCREEN_WIDTH-300)/2, 0, 300, 50);
        if(BPDevice_is_ipad && SCREEN_IS_LANDSCAPE)
        {
            self.frame = CGRectMake((1024-500)/2, 0, SCREEN_WIDTH-40, 50);
        }
        else if(BPDevice_is_ipad && !SCREEN_IS_LANDSCAPE)
        {
            self.frame = CGRectMake((768-500)/2, 0, SCREEN_WIDTH-40, 50);
        }
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5;
        UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH-40, 50)];
//        backgroundView.alpha = 0.8;
        backgroundView.userInteractionEnabled = YES;

        backgroundView.backgroundColor = [UIColor clearColor];
        [self addSubview:backgroundView];
        [backgroundView release];
        
        UIImageView * backView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPAccountBack.png"]];
        backView.frame = CGRectMake(0,0, SCREEN_WIDTH-40, 50);
//        backView.userInteractionEnabled = YES;
        backView.layer.masksToBounds = YES;
        backView.contentMode = UIViewContentModeScaleToFill;
        backView.layer.cornerRadius = 5;
        [backgroundView addSubview:backView];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(55, 0, SCREEN_WIDTH-170, 50)];
       // titleLabel.backgroundColor = [UIColor greenColor];
        titleLabel.tag = 1234561;
        titleLabel.userInteractionEnabled = YES;
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.font = [UIFont systemFontOfSize:12];
        titleLabel.numberOfLines = 1;
        [self addSubview:titleLabel];
        [titleLabel release];
    
//        UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPChangeAccounctlogo.png"]];
//        headLogView.frame = CGRectMake(5,10, 50, 30);
//        headLogView.userInteractionEnabled = YES;
//        headLogView.layer.masksToBounds = YES;
//        headLogView.contentMode = UIViewContentModeScaleToFill;
//        headLogView.layer.cornerRadius = 5;
//        [self addSubview:headLogView];
        
        // 获取验证码
        UIButton *changeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        changeButton.frame = CGRectMake(220, 5, 75, 40);
        [changeButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_register_but.png"] forState:UIControlStateNormal];
        [changeButton addTarget:self action:@selector(changeButtonVerificationAction:) forControlEvents:UIControlEventTouchUpInside];
        changeButton.layer.cornerRadius = 5;
        changeButton.userInteractionEnabled = YES;
        [changeButton setTitleColor:[UIColor colorWithRed:5/255.0 green:189/255.0 blue:253/255.0 alpha:1]forState:UIControlStateNormal];
        changeButton.titleLabel.font = [UIFont systemFontOfSize:14];
        changeButton.tag = 123456789;
        [changeButton setTitle:@"切换账号" forState:UIControlStateNormal];
        [self addSubview:changeButton];

    }
    return self;
}
-(void) performHideAferDelay3:(int)second
{

        ////////NSLog(@"有没有执行 外面的");
        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self hideLoginPrompt];
            });
            
            
        });
    

    

}
-(void) performHideAferDelay5:(int)second
{
    
    ////////NSLog(@"有没有执行 外面的");
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 2*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        ////////NSLog(@"有没有执行 里面的");
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideLoginPrompt];
        });
    });
    
    
    
    
}

-(void) hideLoginPrompt
{
    ////////NSLog(@"关闭界面");
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(removeFromSuperview)];
    CGRect frame = loginPromptShare.frame;
    frame.origin.y = -50;
    loginPromptShare.frame = frame;
    [UIView commitAnimations];
}


static BPShowLoginPrompt *loginPromptShare;
+ (BPShowLoginPrompt *)getSharedLoginPrompt
{
    
    @synchronized(loginPromptShare)
    {
        if(loginPromptShare == nil)
        {
            loginPromptShare =[[BPShowLoginPrompt alloc] init];
        }
        
        return loginPromptShare;
    }
}

//显示登录名字
+ (void)showWithName:(NSString *)name
{

    ////////NSLog(@"登录完成后显示的名字d方法");
    UIWindow* window = nil;//[UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    BPShowLoginPrompt *tmp = [BPShowLoginPrompt getSharedLoginPrompt];
    [loginPromptShare removeFromSuperview];
    
    UILabel *titleLabel = (UILabel *)[loginPromptShare viewWithTag:1234561];
    titleLabel.text = [NSString stringWithFormat:@"%@%@",name,[BPLanguage getStringForKey:@"BPWelcomeBack" InTable:@"BPMultiLanguage"]];
//     titleLabel.text = @"测试用的参数";
    [window.rootViewController.view addSubview:loginPromptShare];
    
    CGRect frame = loginPromptShare.frame;
    frame.origin.y = -50;
    loginPromptShare.frame = frame;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    frame.origin.y = 10;
    loginPromptShare.frame = frame;
    [UIView commitAnimations];
    
    [tmp performHideAferDelay3:3];

}



//显示登录名字
+ (void)showWithAccount:(NSString *)account{
    
    UIWindow* window = nil;//[UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    BPShowLoginPrompt *tmp = [BPShowLoginPrompt getSharedLoginPrompt];
    [loginPromptShare removeFromSuperview];
    
    UILabel *titleLabel = (UILabel *)[loginPromptShare viewWithTag:1234561];
    titleLabel.text = [NSString stringWithFormat:@"%@%@",account,[BPLanguage getStringForKey:@"BPWelcomeBack" InTable:@"BPMultiLanguage"]];
    [window.rootViewController.view addSubview:loginPromptShare];
    
    CGRect frame = loginPromptShare.frame;
    frame.origin.y = -50;
    loginPromptShare.frame = frame;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    
    frame.origin.y = 10;
    loginPromptShare.frame = frame;
    [UIView commitAnimations];
    [tmp performHideAferDelay5:5];
    
}

// 切换账号
-(void)changeButtonVerificationAction:(UIButton *)button{

    ////////NSLog(@"切换账号");

    [self hideLoginPrompt];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPChangeAccountNotification object:nil userInfo:nil];
    
    [self  gotoLoginViewController];


}


-(void) gotoLoginViewController
{
    [BPQLoadingView hideWithAnimated:NO];
    UIViewController *currentViewControl_t = [ShuZhiZhangUtility getCurrentViewController];
    if(!currentViewControl_t)
    {

        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self gotoLoginViewController];
        });
        
        return;
    }
    
    BPLoginView *loginView = [[BPLoginView alloc] init];
    
    [currentViewControl_t.view addSubview:loginView];
    
    [loginView release];
    return;
}

@end
