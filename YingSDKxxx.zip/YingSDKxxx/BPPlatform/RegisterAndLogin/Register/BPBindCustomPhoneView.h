//
//  BPBindCustomPhoneView.h
//  BigPlayerSDK
//
//  Created by SkyGame on 17/2/20.
//  Copyright © 2017年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BPRegisterAndLoginRequest.h"
#import "BPOperateTable.h"
#import "BPPublicRequest.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPCustomTextField.h"
#import "BPLoginAccountListView.h"
#import "BPRegisterView.h"
#import "BPForgotPasswordView.h"
#import "BPPhoneLoginView.h"
#import "BPLoginView.h"


@interface BPBindCustomPhoneView : UIView

{
    int currentCountDown;
    NSTimer *countdownTimer;
}

@property (nonatomic,retain) BPRegisterAndLoginRequest *phoneRequest;
@property (nonatomic,retain) BPOperateTable *userInfoTable;

-(void)backButtonButtonItemAction; // 删除

+(BPBindCustomPhoneView*)getShareInstance;  // 单例模式


-(void) showBindSmallVies;  //显示按钮

@end
