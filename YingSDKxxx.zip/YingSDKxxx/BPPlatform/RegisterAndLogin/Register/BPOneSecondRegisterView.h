//
//  BPOneSecondRegisterView.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import "BPRegisterAndLoginRequest.h"
#import "BPLoginView.h"



@class BPLoginView;
@interface BPOneSecondRegisterView : UIView
{
    NSTimer *dotTimer;
    int currentLocation;
}
@property (nonatomic,retain) BPRegisterAndLoginRequest *registerRequest;
//@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@property (nonatomic,assign) BPLoginView *loginView;



@end
