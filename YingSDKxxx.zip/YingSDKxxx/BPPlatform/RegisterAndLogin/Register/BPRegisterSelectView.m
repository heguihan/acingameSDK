//
//  BPRegisterSelectView.m
//  BigPlayerSDK
//
//

#import "BPRegisterSelectView.h"
#import "BPLoginPublic.h"
#import "BPWebViewBaseViewController.h"
#import "BPOneSecondRegisterView.h"
#import "BPRegisterView.h"
#import "BPRegisterView.h"
#import "BPLoginPublic.h"
#import "BPLoginView.h"
#import "DatabaseDAO.h"
#import "BPPublicHandle.h"
#import "ShuZhiZhangUtility.h"
#import "BPHttpRequestBase.h" //没有用到
#import "ShuZhiZhangHttpsNetworkHelper.h"
#import <UIKit/UIKit.h>
#import "HGHUserTypeSave.h"
#import "HTTPRequest.h"
#import "Tracking.h"
#define ExperienceInfoTableName @"experienceInfo"
#define Move_Height 60

@interface BPRegisterSelectView ()<UITextFieldDelegate,ASIHTTPRequestDelegate>


@property(nonatomic,retain)UIScrollView *scrolliew;
@property(nonatomic,retain)UISegmentedControl *segmentControl;


@end

@implementation BPRegisterSelectView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
        //        self.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2, BPBackImageWidth, BPBackImageHeight);
        
        
        
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.0;
        [self addSubview:background];
     
        
        //        [registerRequest GetUserAccountWhenOneSecondRegister];
        
        [self showRegisterThings];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideAllKeyBoard)];
        [self addGestureRecognizer:tap];
    
        
        
        
        
    }
    return self;
}


-(void) showRegisterThings
{
    self.alpha = 0.0;
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                         
                     }];
    
    UIImageView *backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2.0,(REAL_SCREEN_HEIGHT - BPBackImageHeight)/2.0, BPBackImageWidth, BPBackImageHeight);
    backImageView.userInteractionEnabled = YES;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
  
    
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-100)/2, 0, 100, 50)];
    lab.text = @"注册";
    lab.textColor = [UIColor whiteColor];
    lab.font = [UIFont fontWithName:@"Helvetica-Bold" size:35];
    lab.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:lab];
    
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(15, 10, 25, 25);
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:leftButton];

    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 80, BPBackImageWidth,150)];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.scrollEnabled = NO;
//    scrollView.backgroundColor = [UIColor yellowColor];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.tag = 999888;
    scrollView.contentOffset = CGPointMake(0, 0);
    scrollView.contentSize  =CGSizeMake(250, 165);
    [backImageView addSubview:scrollView];
    
    
#pragma  手动注册的两个textField
    //通行证
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    userField.placeholder = @"请输入手机号";
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    userField.layer.borderWidth = 1.0;
    userField.layer.cornerRadius =5.0;
    userField.font = [UIFont systemFontOfSize:14];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    userField.backgroundColor = [UIColor redColor];
    userField.textAlignment = NSTextAlignmentLeft;
    userField.delegate = self;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    userField.PlaceholderOffset_y = 5;
    userField.PlaceholderOffset_x = 5;
    userField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    userField.returnKeyType = UIReturnKeyNext;
    userField.tag = 1000;
    [scrollView addSubview:userField];
  
    
    //验证码
    BPCustomTextField *verificationField = [[BPCustomTextField alloc] init];
    verificationField.placeholder = @"请输入验证码";
    verificationField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    verificationField.layer.borderWidth =1.0;
    verificationField.delegate = self;
    verificationField.layer.cornerRadius =5.0;
    verificationField.font = [UIFont systemFontOfSize:14];
    verificationField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    verificationField.textAlignment = NSTextAlignmentLeft;
    verificationField.keyboardType = UIKeyboardTypeASCIICapable;
    verificationField.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    //是否纠错
    verificationField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    verificationField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    verificationField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    verificationField.PlaceholderOffset_x = 5;
    verificationField.PlaceholderOffset_y = 5;
    verificationField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    [backImageView addSubview:verificationField];
    verificationField.returnKeyType = UIReturnKeyNext;
    verificationField.tag = 2000;
    [scrollView addSubview:verificationField];
    
    // 获取验证码
    UIButton *sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [sendButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
    [sendButton addTarget:self action:@selector(sendPhoneVerificationAction:) forControlEvents:UIControlEventTouchUpInside];
    sendButton.layer.cornerRadius = 5;
    sendButton.titleLabel.font = [UIFont systemFontOfSize:14];
    sendButton.tag = 1001;
    [sendButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [sendButton setTitleColor:[UIColor colorWithRed:5/255.0 green:189/255.0 blue:253/255.0 alpha:1]forState:UIControlStateNormal];
    [scrollView addSubview:sendButton];
    
    //密码
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
    passwordField.placeholder = @"请输入6-18位的密码";
    passwordField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    passwordField.layer.borderWidth = 1.0;
    passwordField.layer.cornerRadius = 5.0;
    passwordField.font = [UIFont systemFontOfSize:14];
    passwordField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    passwordField.textAlignment = NSTextAlignmentLeft;
    passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    passwordField.secureTextEntry = YES; //密码输入
    passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    passwordField.delegate= self;
    //是否纠错
    passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    passwordField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    passwordField.PlaceholderOffset_x = 5;
    passwordField.PlaceholderOffset_y = 5;
    passwordField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    passwordField.returnKeyType = UIReturnKeyGo;
    passwordField.tag = 10000;
    [scrollView addSubview:passwordField];
    
    
#pragma mark -- 完成注册
    UIButton * register_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [register_button setTitle:[BPLanguage getStringForKey:@"BPCompleteRegist" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    register_button.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
    [register_button setTitleColor:[UIColor colorWithRed:98/255.0 green:18/255.0 blue:131/255.0 alpha:1]forState:UIControlStateNormal];
    [register_button setBackgroundColor:[UIColor colorWithRed: 227/255.0 green:80/255.0 blue:6/255.0 alpha:1]];
    register_button.layer.cornerRadius = 5;
    [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
    [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/littlepage.png"] forState:UIControlStateHighlighted];
    [register_button addTarget:self action:@selector(finishRigisterButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    
    register_button.frame = CGRectMake((BPBackImageWidth - 250)/2.0, 235, 250, 40);
    [backImageView addSubview:register_button];
    
    
    
// 坐标集合 0 2
    userField.frame = CGRectMake((BPBackImageWidth-250)/2, 5, 250, 35);
    verificationField.frame = CGRectMake((BPBackImageWidth-250)/2, 50, 125, 35);
    passwordField.frame = CGRectMake((BPBackImageWidth-250)/2, 95, 250, 35);
    sendButton.frame = CGRectMake(BPBackImageWidth -125, 50, 100, 35);
    
    
}

// 跳转清空上一个输入框
-(void)emptyPreviousTextField{
    
    UITextField * userField1 = (UITextField *)[self viewWithTag:1000];
    UITextField * verifypassword = (UITextField *)[self viewWithTag:2000];
    UITextField * verifypassword1 = (UITextField *)[self viewWithTag:10000];
  
    verifypassword.text = @"";
    userField1.text = @"";
    verifypassword1.text = @"";
}

 // 获取手机号验证码按钮点击事件
-(void)sendPhoneVerificationAction:(UIButton *)button
{
    
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];

  if(currentCountDown== 0 && [ShuZhiZhangUtility isMobileNumber:phoneNumber.text]) {
      
       currentCountDown = 60;
      
      [self requestForPhoneVertifyCode:phoneNumber.text];
      
      
    }else if (![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
      {
        if(phoneNumber.text.length<1)
        {
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] duration:2.0];
            [ShuZhiZhangUtility setPromptPosition];
            return;
        }
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPRegistPhoneSecuritycode" InTable:@"BPMultiLanguage"] duration:2.0];

    }
}

/*
 *  手机号验证码
 */
-(void) requestForPhoneVertifyCode:(NSString *)phonenumber
{
        NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
        NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
        NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
       NSDictionary *dict = @{
                           @"phoneNumber":phonenumber,
                           @"action":@"register",
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]
                           };
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"sendSMS",appid,sortStr,sign];
        [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
            dispatch_async(dispatch_get_main_queue(), ^{

        ////////NSLog(@"手机号验证码dict = %@,urlStr = %@",data,urlStr);
            
        if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [BPCustomNoticeBox showCenterWithText:@"验证码发送成功" duration:2.0];
                [self createPhoneCountTimer];
        }else{
            
                [self stopCountDown];
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
        }
    });
    } failure:^(NSError *error) {
            
    }];
}






#pragma mark --------定时器-----
// 手机定时
-(void)createPhoneCountTimer
{
    if(countdownTimer==nil)
    {
        countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(VerifyCountDown) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:countdownTimer forMode:NSDefaultRunLoopMode];
    }
    
    [self showCountDownButton:currentCountDown];
}


//停止倒计时
-(void) stopCountDown
{
    [countdownTimer invalidate];
    countdownTimer = nil;
    currentCountDown = 0;
    
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    getVerifyCode.userInteractionEnabled = YES;
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];

}



// 手机定时器的方法倒计时开始
-(void) VerifyCountDown
{
    currentCountDown--;
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    [self showCountDownButton:currentCountDown];
    getVerifyCode.userInteractionEnabled = NO;
    if(currentCountDown==0)
    {
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    
        getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
        [countdownTimer invalidate];
        getVerifyCode.userInteractionEnabled = YES;
        countdownTimer = nil;
        return;
    }
 
}

//显示多少秒后获取验证码
-(void) showCountDownButton:(int)seconds
{
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:18];
    [getVerifyCode setTitle:[NSString stringWithFormat:@"%d S",seconds] forState:UIControlStateNormal];
    
}

#pragma mark -----textField delegate-----
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if(textField.tag == 1000 && currentCountDown <= 0)
    {
        UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1001];
        NSMutableString *phoneStr = (NSMutableString *)textField.text;
        if ([string isEqualToString:@""])
        {
            phoneStr = (NSMutableString *)[phoneStr substringToIndex:phoneStr.length-1];
        }
        else
        {
            phoneStr = (NSMutableString *)[phoneStr stringByAppendingString:string];
        }
        
        if([ShuZhiZhangUtility isMobileNumber:phoneStr])
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png.png"] forState:UIControlStateNormal];
        }
        else
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png.png"] forState:UIControlStateNormal];
        }
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}


#pragma mark -------keyboard event-------


//隐藏键盘
-(void) hideAllKeyBoard
{
 

      UITextField * verifypassword = (UITextField *)[self viewWithTag:2000];
      UITextField * userField1 = (UITextField *)[self viewWithTag:1000];
      UITextField * verifypassword1 = (UITextField *)[self viewWithTag:10000];
    
        [verifypassword resignFirstResponder];
      [userField1 resignFirstResponder];
      [verifypassword1 resignFirstResponder];
    
}


//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
  {
      
      UITextField * PhoneUserField = (UITextField *)[self viewWithTag:1000];
      UITextField * phonePasswordField = (UITextField *)[self viewWithTag:10000];
      UITextField * phoneVerifyField = (UITextField *)[self viewWithTag:2000];

  

      if (textField == PhoneUserField) {
          [phoneVerifyField resignFirstResponder];
          [phoneVerifyField becomeFirstResponder];
      }else if (textField== phoneVerifyField){
      
          [phoneVerifyField resignFirstResponder];
          [phonePasswordField becomeFirstResponder];
      }else if (textField == phonePasswordField ){
          [self finishRigisterButtonItemAction];
          [self hideAllKeyBoard];
      }
      
      
      
    
      return YES;
}



- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    scroll.scrollEnabled = YES;

   
        
    [UIView animateWithDuration:0.3 animations:^{
        
        if(SCREEN_IS_LANDSCAPE){
            
        if (textField.tag == 2000 || textField.tag == 2002 ) {
            
            scroll.contentOffset = CGPointMake(0, 45);
            
        }else if (textField.tag == 10000 || textField.tag == 10022){
        
         scroll.contentOffset = CGPointMake(0, 85);
            
        }else{
             if (textField.tag == 10000 || textField.tag == 10022){
                 
             scroll.contentOffset = CGPointMake(0, 10);
                 
             }
         }
       
    }
 }];
        
   
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    [UIView animateWithDuration:0.3 animations:^{
        
        scroll.contentOffset = CGPointMake(0, 0);
        
    }];
    scroll.scrollEnabled = NO;
    
    //     [BPLoginPublic ViewScrollDown_little: self];
}


#pragma mark -----button click-------
-(void) cancelRequest
{


}
//返回按钮
-(void) leftButtonItemAction
{
   
    [UIView animateWithDuration:0.2
                     animations:^{
                         self.alpha = 0.0;
                         
                     }
                     completion:^(BOOL finished) {
                         
                  [self removeFromSuperview];

        }];
}

//验证账号密码是否有效
-(BOOL) checkAccountAndPassword
{
    UITextField * userField = (UITextField *)[self viewWithTag:1000];
    UITextField * passwordField = (UITextField *)[self viewWithTag:10000];
    
    
    // 密码小于6位的情况
    if (userField.text.length <6) {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPRegistAccountNotice" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    
    if (passwordField.text.length <6) {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPRegistPasswordNotice" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    
    
    NSString *regularExpression = @"^[A-z0-9_@.-]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:userField.text] == NO)
    {
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];

        return NO;
    }
    if ([regextestmobile evaluateWithObject:passwordField.text] == NO)
    {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];

        return NO;
    }
    return YES;
}


// 完成注册按钮点击事件
- (void)finishRigisterButtonItemAction
{
    
    UITextField * PhoneUserField = (UITextField *)[self viewWithTag:1000];
    UITextField * phonePasswordField = (UITextField *)[self viewWithTag:10000];
    UITextField * phoneVerifyField = (UITextField *)[self viewWithTag:2000];
 
    
    if (PhoneUserField.text.length ==0 || phonePasswordField.text.length==0 || phoneVerifyField.text.length ==0) {
        
        [BPCustomNoticeBox showCenterWithText:@"输入不能为空,请正确输入" duration:2.0];

        return;
    }
    

         [self requestRegisterWithPhoneNumber:PhoneUserField.text SecurityCode:phoneVerifyField.text passWord:phonePasswordField.text];
            [BPQLoadingView showDefaultLoadingViewWithView:self];
            
    
           
        if(BPDevice_is_ipad)
        {
            if(SCREEN_IS_LANDSCAPE)
            {
                [BPQLoadingView setLoadingViewPosition:(1024-80)/2 Position_Y:(768-80)/2];
            }
            else
            {
                [BPQLoadingView setLoadingViewPosition:(768-80)/2 Position_Y:(1024-80)/2];
            }
        }
}
    

// 手机号注册

-(void)requestRegisterWithPhoneNumber:(NSString *)phoneNumber SecurityCode:(NSString *)securityCode passWord:(NSString *)password{

    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"code":securityCode,
                           @"type":@"1",
                           @"phoneNumber":phoneNumber,
                           @"pwd":[ShuZhiZhangUtility md5String:password],
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]

                           };
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"register",appid,sortStr,sign];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            ////////NSLog(@"手机号注册urlStr = %@,data = %@",urlStr, data);
        [BPQLoadingView hideWithAnimated:NO];
        if (data.count==0) {
        [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
        return ;
    }
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
            
        if ([[data objectForKey:@"ret"] intValue]==0) {

           [BPCustomNoticeBox showCenterWithText:@"注册成功" duration:2.0];
            [self leftButtonItemAction];
        
            BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
            if(view){
               [view removeFromSuperview];
            }
//            [userInfo setObject:phoneNumber forKey:@"userID"];
            [userInfo setObject:password forKey:@"password"];
            [userInfo setObject:phoneNumber forKey:@"phoneNumber"];
            [BPCustomNoticeBox showCenterWithText:@"注册成功" duration:2.0];
            [BPShowLoginPrompt showWithName:phoneNumber];
            [BPLoginPublic userDidLoginAction:userInfo];
            [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_registe_cb"];
            [[NSUserDefaults standardUserDefaults] setObject:phoneNumber forKey:@"acingamePhone"];
            [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"acingamePhonePassword"];
            [[NSUserDefaults standardUserDefaults] setObject:@"phone" forKey:@"loginway"];
            [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [HGHUserTypeSave saveUserTypeWithUsername:phoneNumber password:password field:@"hghphonelogintype"];
//            [HTTPRequest requestRegister:[NSString stringWithFormat:@"%@",[userInfo objectForKey:@"userID"]]];
            [Tracking setRegisterWithAccountID:[userInfo objectForKey:@"userID"]];
        }else{
            
            [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
            [[NSUserDefaults standardUserDefaults] setObject:phoneNumber forKey:@"acingamePhone"];
            [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"acingamePhonePassword"];
            [[NSUserDefaults standardUserDefaults] setObject:@"phone" forKey:@"loginway"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
        }
        });
    } failure:^(NSError *error) {
        
    }];
}

//// 账号注册
//-(void)requestRegisterWithAccount:(NSString *)account passWord:(NSString *)password{
//
//    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
//    NSDictionary *dict = @{
//                           @"userID":account,
//                           @"type":@"2",
//                           @"pwd":[ShuZhiZhangUtility md5String:password],
//                           @"ts":dateStr
//                           };
//    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
//    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
//    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
//    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
//    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
//    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"register",appid,sortStr,sign];
//
//    
//    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
//
//        dispatch_async(dispatch_get_main_queue(), ^{
//
//        [BPQLoadingView hideWithAnimated:NO];
//
//        ////////NSLog(@"账号注册dict = %@,urlStr = %@",data,urlStr);
//            if (data.count==0) {
//                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
//                return ;
//            }
//        if ([[data objectForKey:@"ret"] intValue]==0) {
//            ////////NSLog(@"注册成功");
//            [self leftButtonItemAction];
//            BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
//            if (view) {
//                [view removeFromSuperview];
//            }
//            NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
//            [userInfo setObject:password forKey:@"password"];
//            [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
//            [BPCustomNoticeBox showCenterWithText:@"注册成功" duration:2.0];
//            [BPShowLoginPrompt showWithName:account];
//            [BPLoginPublic userDidLoginAction:userInfo];      // 数据库存储
//
//        }else{
//
//            [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
//
//        }
//    });
//
//    } failure:^(NSError *error) {
//
//}];
//
//}

-(void)clickCancelButton{

    [self removeFromSuperview];

}




@end
