//
//  BPRegisterSelectView.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>
#import "BPRegisterAndLoginRequest.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPOperateTable.h"
#import "BPWebViewBaseViewController.h"


@interface BPRegisterSelectView : UIView
{
    BPRegisterAndLoginRequest *phoneRequest;
    int currentCountDown;   // 手机
    NSTimer *countdownTimer;
    NSTimer *EmailCountTimer; // 邮箱
    int EmailCountNumber;
    
}
@property (nonatomic,strong) void(^bindResultBlock)(NSString *result);

/*
 *  手机号验证码
 */
-(void) requestForPhoneVertifyCode:(NSString *)phonenumber;


@end
