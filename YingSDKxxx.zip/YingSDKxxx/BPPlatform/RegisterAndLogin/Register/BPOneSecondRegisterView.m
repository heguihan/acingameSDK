//
//  BPOneSecondRegisterView.m
//  BigPlayerSDK
//
//

#import "BPOneSecondRegisterView.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginView.h"
#import "DatabaseDAO.h"
#import "BPPublicHandle.h"
#import "BPScreenShot.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/PHPhotoLibrary.h>
#import "ShuZhiZhangHttpsNetworkHelper.h"

@interface BPOneSecondRegisterView ()

@end

@implementation BPOneSecondRegisterView
@synthesize registerRequest;
//@synthesize userInfoDic;
@synthesize loginView;


-(void) dealloc
{
    [registerRequest release];      registerRequest = nil;
//    [userInfoDic release];          userInfoDic = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self  oneSecondRegiste];   // 游客网络请求

        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.6;
        [self addSubview:background];
        [background release];
        
        self.alpha = 0.0;
        [UIView animateWithDuration:0.4
                         animations:^{
                             self.alpha = 1.0;
                         }
                         completion:^(BOOL finished) {
                         }];
        
        UIImageView *bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
        bgImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT - BPBackImageWidth)/2, BPBackImageWidth, BPBackImageHeight);
        bgImageView.userInteractionEnabled = YES;
        [self addSubview:bgImageView];
        bgImageView.tag = 19000;
        [bgImageView release];
        
       
        
        
        UILabel *buttonTitle = [[UILabel alloc] init];
        NSString *str = @"正在生成用户账号";
        CGSize size =[self returnCGziseOfString:str];
        buttonTitle.frame = CGRectMake((BPBackImageWidth - size.width)/2, 100, size.width,25);
        buttonTitle.textAlignment = NSTextAlignmentRight;
        buttonTitle.backgroundColor = [UIColor clearColor];
        buttonTitle.tag = 19001;
        buttonTitle.font = [UIFont systemFontOfSize:16];
        buttonTitle.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        [bgImageView addSubview:buttonTitle];
        [buttonTitle release];
        
        
//        
//        UIImageView *doctBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 220, BPBackImageWidth, 40)];
//        doctBack.backgroundColor = [UIColor clearColor];
//        doctBack.userInteractionEnabled = YES;
//        [bgImageView addSubview:doctBack];
//        doctBack.tag = 19099;
//        [doctBack release];
//        
//        UIImageView *dotImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_checkUpdate1.png"]];
//        dotImageView.frame = CGRectMake((BPBackImageWidth-80)/2, 10, 10, 10);
//        dotImageView.tag = 19006;
//        [doctBack addSubview:dotImageView];
//        [dotImageView release];
//        
//        
//        for(int i=0;i<4;i++)
//        {
//           UIImageView *dotImageView2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_checkUpdate2.png"]];
//            dotImageView2.frame = CGRectMake((BPBackImageWidth-80)/2+i*20, 10, 10, 10);
//            [doctBack addSubview:dotImageView2];
//            [dotImageView2 release];
//        }
//        
//        dotTimer = [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(dotShowLoop) userInfo:nil repeats:YES];
   }
    return self;
}


/*
 * 游客模式
 *
 * 一秒注册，快速进入
 */
-(void) oneSecondRegiste
{
    NSString *urlStr = [self BPUrlJoininTogetherwithAction:@"register" appid:@"999" type:@"3" ];
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    urlStr = [NSString stringWithFormat:@"%@&ts=%@",urlStr,dateStr];
    
    
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        ////////NSLog(@"游客登录回包dict = %@,urlStr = %@",data,urlStr);
        
        if ([[data objectForKey:@"ret"] intValue]==0) {
          

            
            [self registCompleteAndExit];
        
    }
        
        
        
    } failure:^(NSError *error) {
        
    }];
    
}


-(NSString *)BPUrlJoininTogetherwithAction:(NSString *)action appid:(NSString *)appid type:(NSString *)type{
    
    NSString *urlString = [NSString stringWithFormat:@"%@%@/%@?type=%@",GLOBAL_LOGIN_API_URL,action,appid,type];
    
    return urlString;
    
}

//游客登录成功并自动关闭界面
-(void) registCompleteAndExit
{
    //发送注册成功消息
    ////////NSLog(@"post5555555555");
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:[ShuZhiZhangUserPreferences CurrentUserID],@"uid",[ShuZhiZhangUserPreferences CurrentNickname],@"nickname",[ShuZhiZhangUserPreferences getCurrentToken],@"token",@"BPLoginSuccess", @"result",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
    
    [self removeFromSuperview];

    
    
    
}






-(CGSize)returnCGziseOfString:(NSString *)string{

    UIFont *fonts = [UIFont systemFontOfSize:16];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObject:fonts forKey:NSFontAttributeName];
    CGSize size = [string sizeWithAttributes:dict];
    return size;

}





@end
