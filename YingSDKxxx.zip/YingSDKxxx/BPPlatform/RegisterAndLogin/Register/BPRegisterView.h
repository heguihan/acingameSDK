//
//  BPRegisterView.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import "BPRegisterAndLoginRequest.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPOperateTable.h"
#import "BPWebViewBaseViewController.h"


@interface BPRegisterView : UIView<UITextFieldDelegate>

@property (nonatomic,retain) BPRegisterAndLoginRequest *registerRequest;

@end
