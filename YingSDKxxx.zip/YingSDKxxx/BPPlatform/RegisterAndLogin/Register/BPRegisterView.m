//
//  BPRegisterView.m
//  BigPlayerSDK
//
//

/*
 *  手动注册界面
 *
 */

#import "BPRegisterView.h"
#import "BPLoginPublic.h"
#import "BPLoginView.h"
#import "DatabaseDAO.h"
#import "BPPublicHandle.h"
#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "BPBindPhoneView.h"
#import "HGHUserTypeSave.h"
#import "HTTPRequest.h"
#import "Tracking.h"
@implementation BPRegisterView

@synthesize registerRequest;

-(void) dealloc
{
    [registerRequest release];
     registerRequest = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        self.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2, BPBackImageWidth, BPBackImageHeight);
        
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);

        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.0;
        [self addSubview:background];
        [background release];
        [self showRegisterThings];

    }
    return self;
}


-(void) showRegisterThings
{
    self.alpha = 0.0;
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                         
    }];

    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2.0,(REAL_SCREEN_HEIGHT - BPBackImageHeight)/2.0, BPBackImageWidth, BPBackImageHeight);
    backImageView.userInteractionEnabled = YES;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
    [backImageView release];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideAllKeyBoard)];
    [self addGestureRecognizer:tap];
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-100)/2, 0, 100, 50)];
    lab.text = @"注册";
    lab.textColor = [UIColor whiteColor];
    lab.font = [UIFont fontWithName:@"Helvetica-Bold" size:35];
    lab.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:lab];
    
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(15, 10, 25, 25);
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:leftButton];
    
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake((BPBackImageWidth-250)/2, 80, 250,150)];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.scrollEnabled = NO;
//    scrollView.backgroundColor = [UIColor greenColor];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.tag = 999888;
    scrollView.contentOffset = CGPointMake(0, 0);
    scrollView.contentSize  =CGSizeMake(250, 150);
    [backImageView addSubview:scrollView];
    

    
#pragma  手动注册的两个textField
    //通行证
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    userField.placeholder = [BPLanguage getStringForKey:@"BPRegistAccount" InTable:@"BPMultiLanguage"];
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    //    userField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    userField.layer.borderWidth =1.0;
    userField.layer.cornerRadius =5.0;
    userField.font = [UIFont systemFontOfSize:14];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    userField.delegate = self;
    userField.textAlignment = NSTextAlignmentLeft;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    
//    [BPLoginPublic setTextFieldProperty:userField withDelegate:self];
    
    userField.PlaceholderOffset_y = 2;
    userField.PlaceholderOffset_x = 40;
    userField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    [scrollView addSubview:userField];
    userField.returnKeyType = UIReturnKeyNext;
//    [userField becomeFirstResponder];
    userField.tag = 100;
    [userField release];
    
    UIImageView *userImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_user.png"]];
    [userField addSubview:userImage];
     userImage.frame = CGRectMake(0, 0, 40, 40);
    [userImage release];
    
     //密码
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
    passwordField.placeholder = [BPLanguage getStringForKey:@"BPRegistPassword" InTable:@"BPMultiLanguage"];
    
    passwordField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    passwordField.layer.borderWidth =1.0;
    passwordField.layer.cornerRadius =5.0;
    passwordField.font = [UIFont systemFontOfSize:14];
    passwordField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    
    passwordField.textAlignment = NSTextAlignmentLeft;
    passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    passwordField.delegate = self;
    passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    passwordField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];

    passwordField.PlaceholderOffset_x = 40;
    passwordField.PlaceholderOffset_y = 2;
    passwordField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    [backImageView addSubview:passwordField];
     passwordField.returnKeyType = UIReturnKeyGo;
     passwordField.tag = 102;
    passwordField.secureTextEntry = YES;
    [scrollView addSubview:passwordField];
    [passwordField release];
    
    UIImageView *passwordImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_password.png"]];
    [passwordField addSubview:passwordImage];
    passwordImage.frame = CGRectMake(0, 0, 40, 40);
    [passwordImage release];
    
    
#pragma mark -- 完成注册
    UIButton * register_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [register_button setTitle:[BPLanguage getStringForKey:@"BPCompleteRegist" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    register_button.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
    [register_button setTitleColor:[UIColor colorWithRed:98/255.0 green:18/255.0 blue:131/255.0 alpha:1] forState:UIControlStateNormal];
    [register_button setBackgroundColor:[UIColor colorWithRed: 227/255.0 green:80/255.0 blue:6/255.0 alpha:1]];
    register_button.layer.cornerRadius = 5;
    [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
    [register_button addTarget:self action:@selector(finishRigisterButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    register_button.frame = CGRectMake((BPBackImageWidth - 250)/2.0, 235, 250, 40);
    [backImageView addSubview:register_button];


    // 账户密码坐标
    userField.frame = CGRectMake(0, 20, 250, 40);
    passwordField.frame = CGRectMake(0, 80, 250, 40);
    
    
}



-(void) clickCancelButton
{
    [self leftButtonItemAction];
    
}

#pragma mark -------keyboard event-------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (range.location >= 18&&![string isEqualToString:@""])
        return NO;
    return YES;
}

//隐藏键盘
-(void) hideAllKeyBoard
{
    UITextField * userField = (UITextField *)[self viewWithTag:100];
    UITextField * passwordField = (UITextField *)[self viewWithTag:102];
    
    [userField resignFirstResponder];
    [passwordField resignFirstResponder];
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * userField = (UITextField *)[self viewWithTag:100];
    UITextField * passwordField = (UITextField *)[self viewWithTag:102];
    //    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:103];
    
    if(textField == userField)
    {
        [userField resignFirstResponder];
        [passwordField becomeFirstResponder];
    }
    else if(textField == passwordField)
    {
        [self hideAllKeyBoard];
       
        [self finishRigisterButtonItemAction];
    }

    return YES;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UITextField * userField = (UITextField *)[self viewWithTag:100];
    UITextField * passwordField = (UITextField *)[self viewWithTag:102];
    
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    
    if(SCREEN_IS_LANDSCAPE){
    [UIView animateWithDuration:0.3 animations:^{
        if (textField == userField) {
            
            scroll.contentOffset = CGPointMake(0, 55);
        }else if (textField == passwordField){
        
            scroll.contentOffset = CGPointMake(0, 100);
        }
        
    }];
     
    }
    scroll.scrollEnabled = YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    [UIView animateWithDuration:0.3 animations:^{
        
        scroll.contentOffset = CGPointMake(0, 0);
        
    }];
    scroll.scrollEnabled = NO;
    
}



#pragma mark -----button click-------
-(void) cancelRequest
{

}
//返回按钮
-(void) leftButtonItemAction
{
    [self cancelRequest];

    [UIView animateWithDuration:0.3
                     animations:^{
                         
                 self.alpha = 0.0;
                    
                }
                     completion:^(BOOL finished) {
                         
                    [self removeFromSuperview];
                         
        }];
}



//验证账号密码是否有效
-(BOOL) checkAccountAndPassword
{
    UITextField * userField = (UITextField *)[self viewWithTag:100];
    UITextField * passwordField = (UITextField *)[self viewWithTag:102];
    
    //    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:103];
    [self hideAllKeyBoard];
    
    
// 密码小于6位的情况
    if (userField.text.length <6) {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPRegistAccount" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    
    if (passwordField.text.length <6) {
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"]  duration:2.0];
        return NO;
    }
    

    NSString *regularExpression = @"^[A-z0-9_@.]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:userField.text] == NO)
    {
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    if ([regextestmobile evaluateWithObject:passwordField.text] == NO)
    {
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    return YES;
}
// 完成注册按钮点击事件
- (void)finishRigisterButtonItemAction
{
    UITextField * nameUserField = (UITextField *)[self viewWithTag:100];
    UITextField * passwordField = (UITextField *)[self viewWithTag:102];
    
    if ([self checkAccountAndPassword]) {
        ////////NSLog(@"这是用户名注册");
        [self requestRegisterWithAccount:nameUserField.text passWord:passwordField.text];
        [BPQLoadingView showDefaultLoadingViewWithView:self];
    }
    
}


// 账号注册
-(void)requestRegisterWithAccount:(NSString *)account passWord:(NSString *)password{
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"userID":account,
                           @"type":@"2",
                           @"pwd":[ShuZhiZhangUtility md5String:password],
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]
                           };
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];

    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"register",appid,sortStr,sign];
    ////////NSLog(@"registerUrl=%@",urlStr);
    
    
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            
            ////////NSLog(@"账号注册dict = %@,urlStr = %@",data,urlStr);
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            if ([[data objectForKey:@"ret"] intValue]==0) {
                ////////NSLog(@"注册成功");
                [self leftButtonItemAction];
                BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
                if (view) {
                    [view removeFromSuperview];
                }
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
                
                [userInfo setObject:password forKey:@"password"];
//                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
                [BPCustomNoticeBox showCenterWithText:@"注册成功" duration:2.0];
                [BPShowLoginPrompt showWithName:account];
                [BPLoginPublic userDidLoginAction:userInfo];      // 数据库存储
                [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_registe_cb"];
                [[NSUserDefaults standardUserDefaults] setObject:account forKey:@"acingameAccount"];
                [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"acingamePassword"];
                [[NSUserDefaults standardUserDefaults] setObject:@"2" forKey:@"loginway"];
                [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];

                [[NSUserDefaults standardUserDefaults] synchronize];
                [HGHUserTypeSave saveUserTypeWithUsername:account password:password field:@"hghuserlogintype"];
                [HTTPRequest requestRegister:[NSString stringWithFormat:@"%@",[userInfo objectForKey:@"userID"]]];
                [Tracking setRegisterWithAccountID:[userInfo objectForKey:@"userID"]];
            }else{
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePassword"];
                //                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingameAccount"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhonePassword"];
                //                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhone"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"loginway"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
            }
        });
        
    } failure:^(NSError *error) {
        ////////NSLog(@"error=%@",error);
        ////////NSLog(@"失败");
    }];
    
}




/*
 * 游客模式
 *
 * 一秒注册，快速进入
 */
-(void) oneSecondRegiste
{
    NSString *urlStr = [self BPUrlJoininTogetherwithAction:@"register" appid:@"999" type:@"3" ];
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    urlStr = [NSString stringWithFormat:@"%@&ts=%@",urlStr,dateStr];
    
    
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        ////////NSLog(@"游客登录回包dict = %@,urlStr = %@",data,urlStr);
        
        if ([[data objectForKey:@"ret"] intValue]==0) {
            
            
        }
        
    } failure:^(NSError *error) {
        
    }];
    
}


-(NSString *)BPUrlJoininTogetherwithAction:(NSString *)action appid:(NSString *)appid type:(NSString *)type{
    
    NSString *urlString = [NSString stringWithFormat:@"%@%@/%@?type=%@",GLOBAL_LOGIN_API_URL,action,appid,type];
    
    return urlString;
    
}




@end
