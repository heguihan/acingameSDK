//
//  BPBindCustomPhoneView.m
//  BigPlayerSDK
//
//  Created by SkyGame on 17/2/20.
//  Copyright © 2017年 John Cheng. All rights reserved.
//

#import "BPBindCustomPhoneView.h"
#import "BPCustomLoginView.h"
#import "BPLoginView.h"
#import "BPWebViewBaseViewController.h"
#import "BPAccountExceptionViewController.h"
#import "BPRegisterSelectView.h"
#import "BPNotificationName.h"
#import "HJManagedImageV.h"
#import "BPPublicHandle.h"
#import "BPCustomNoticeBox.h"
#import "ShuZhiZhangUserPreferences.h"

@interface BPBindCustomPhoneView ()<DropDownListDelegate,UITextFieldDelegate>

@end


@implementation BPBindCustomPhoneView

@synthesize phoneRequest;
@synthesize userInfoTable;



static BPBindCustomPhoneView *tipsView = nil;

+(BPBindCustomPhoneView*)getShareInstance{
    
    static  dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        
        tipsView = [[BPBindCustomPhoneView alloc]init];
        
    });
    
    return  tipsView;
    
    
}

- (id)init
{
    self = [super init];
    if (self) {
        
        userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
        
        // Initialization code
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        self.backgroundColor = [UIColor clearColor];
        self.tag = 9988;
        
    }
    return self;
}


//显示手机号
-(void) showBindSmallVies
{
    
    [[ShuZhiZhangUtility getCurrentViewController].view addSubview:self];
    UIImageView *backImageView = [[UIImageView alloc]initWithFrame:CGRectMake((REAL_SCREEN_WIDTH-BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT-BPBackImageHeight)/2, BPBackImageWidth, BPBackImageHeight)];
    backImageView.tag =5555;
    backImageView.userInteractionEnabled = YES;
    backImageView.layer.masksToBounds = YES;
    backImageView.backgroundColor = [UIColor colorWithRed:5 green:189 blue:253 alpha:1];
    backImageView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"];
    backImageView.contentMode = UIViewContentModeScaleToFill;
    backImageView.layer.cornerRadius = 5;
    [self addSubview:backImageView];

    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideAllKeyBoard)];
    [backImageView addGestureRecognizer:tap];
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    
    UILabel *choselable1 = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-250)/2, 75, 250, 40)];
    choselable1.backgroundColor = [UIColor clearColor];
    choselable1.font = [UIFont systemFontOfSize:12];
    choselable1.textColor = [UIColor orangeColor];
    choselable1.text =  [NSString stringWithFormat:@"您当前登录的账号是:%@",[ShuZhiZhangUserPreferences CurrentUserID] ];
    choselable1.textAlignment = NSTextAlignmentLeft;
    [backImageView addSubview:choselable1];
    
    //返回
    UIButton * backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateNormal];
    [backButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateHighlighted];
    //    backButton.backgroundColor = [UIColor yellowColor];
    [backButton addTarget:self action:@selector(backButtonButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    [backButton setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 15, 15)];
    backButton.frame = CGRectMake(BPBackImageWidth-40, 0, 40, 40);
    [backImageView addSubview:backButton];
    
   /*
    UILabel *lable1 = [[UILabel alloc]initWithFrame:CGRectMake(20, 35, BPBackImageWidth-40, 35)];
    lable1.font = [UIFont systemFontOfSize:18];
    lable1.textColor = [UIColor grayColor];
    lable1.layer.cornerRadius= 5;
    lable1.layer.masksToBounds =YES;
    lable1.textAlignment = NSTextAlignmentCenter;
    lable1.backgroundColor = [UIColor colorWithRed:221/255.0f green:221/255.0f blue:221/255.0f alpha:1];
    lable1.text = @"绑定手机";
    [backImageView addSubview:lable1];
    
    
    UITextView *textView = [[UITextView alloc]initWithFrame:CGRectMake(20, 70, BPBackImageWidth-40, 35)];
    textView.font = [UIFont systemFontOfSize:12.0f];
    textView.textColor = [UIColor grayColor];
    textView.editable = NO;
    textView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    textView.text = @"绑定手机可以确保账号安全,保护游戏资产.";
    [backImageView addSubview:textView];
    
    */
    
    
#pragma  手机注册的两个textField
    //通行证 0
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    userField.placeholder = [BPLanguage getStringForKey:@"BPEnterPhone" InTable:@"BPMultiLanguage"];
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    //    userField.layer.borderWidth =1.0;
    userField.layer.cornerRadius =5.0;
    userField.delegate = self;
    //userField.background = [UIImage imageNamed:@"ShuZhiZhang.bundle/TYInputField.png"];
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    userField.layer.borderWidth =1.2f;
    userField.font = [UIFont systemFontOfSize:14];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:40/255.0f alpha:1];
    userField.textAlignment = NSTextAlignmentLeft;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    userField.frame = CGRectMake((BPBackImageWidth-250)/2, 100, 250, 35);
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor whiteColor];
    userField.PlaceholderOffset_y = 0;
    userField.PlaceholderOffset_x = 15;
    userField.returnKeyType = UIReturnKeyNext;
    userField.tag = 1000;
    [backImageView addSubview:userField];
    
    
    //验证码 0
    BPCustomTextField *verificationField = [[BPCustomTextField alloc] init];
    verificationField.placeholder =[BPLanguage getStringForKey:@"BPEnterVerifyCode" InTable:@"BPMultiLanguage"]; // 动态验证码
    // verificationField.background = [UIImage imageNamed:@"ShuZhiZhang.bundle/TYInputField.png"];
    verificationField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    verificationField.layer.borderWidth =1.2f;
    verificationField.layer.cornerRadius =5.0;
    verificationField.font = [UIFont systemFontOfSize:14];
    verificationField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    verificationField.textAlignment = NSTextAlignmentLeft;
    verificationField.keyboardType = UIKeyboardTypeASCIICapable;
    verificationField.clearButtonMode = UITextFieldViewModeWhileEditing;
    verificationField.delegate = self;
    verificationField.frame = CGRectMake((BPBackImageWidth-250)/2, 200, 180, 35);
    //是否纠错
    verificationField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    verificationField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    verificationField.backgroundColor = [UIColor whiteColor];
    verificationField.PlaceholderOffset_x = 15;
    verificationField.PlaceholderOffset_y = 0;
    verificationField.layer.borderWidth =1.2f;
    verificationField.returnKeyType = UIReturnKeyNext;
    verificationField.tag = 1001;
    [backImageView addSubview:verificationField];
    
    
    //密码
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
    passwordField.placeholder = [BPLanguage getStringForKey:@"BPRegistPassword" InTable:@"BPMultiLanguage"];
    
    passwordField.layer.borderWidth =1.0;
    passwordField.layer.cornerRadius =5.0;
    passwordField.font = [UIFont systemFontOfSize:14];
    passwordField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    
    passwordField.textAlignment = NSTextAlignmentLeft;
    passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    passwordField.delegate = self;
    passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    
    passwordField.PlaceholderOffset_x = 15;
    passwordField.PlaceholderOffset_y = 2;
    passwordField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    passwordField.returnKeyType = UIReturnKeyGo;
    passwordField.tag = 102;
    passwordField.secureTextEntry = YES;
  //  [backImageView addSubview:passwordField];
    [passwordField release];
    
    
    
    // 获取验证码按钮
    UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
    [getVerifyCode setTitle:@"获取验证码" forState:UIControlStateNormal]; // 获取验证码
    [getVerifyCode setTitleColor:[UIColor colorWithRed:5/255.0 green:189/255.0 blue:253/255.0 alpha:1]forState:UIControlStateNormal];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:13];
    [getVerifyCode addTarget:self action:@selector(getVerifyCodeAction:) forControlEvents:UIControlEventTouchUpInside];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateHighlighted];
    getVerifyCode.tag = 1002;
    getVerifyCode.layer.cornerRadius = 5;
    getVerifyCode.layer.masksToBounds = YES;
    [backImageView addSubview:getVerifyCode];
    
    userField.frame = CGRectMake((BPBackImageWidth-250)/2, 120, 250, 35);
    verificationField.frame = CGRectMake((BPBackImageWidth-250)/2, 180, 120, 35);
    getVerifyCode.frame = CGRectMake(BPBackImageWidth -125, 180, 100, 35);
    passwordField.frame = CGRectMake((BPBackImageWidth-250)/2, 240, 250, 35);
    
    
    
    // 手机绑定的绑定按钮
    UIButton *bindPhone = [UIButton buttonWithType:UIButtonTypeCustom];
    bindPhone.frame = CGRectMake((BPBackImageWidth-250)/2, 240, 250, 35);
    bindPhone.layer.cornerRadius = 5;
    [bindPhone setTitle:@"手机绑定" forState:UIControlStateNormal];
    bindPhone.backgroundColor = [UIColor colorWithRed: 255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
    [bindPhone setTitleColor:[UIColor colorWithRed:5/255.0 green:189/255.0 blue:253/255.0 alpha:1]forState:UIControlStateNormal];
    bindPhone.titleLabel.font = [UIFont systemFontOfSize:14];
    [bindPhone addTarget:self action:@selector(bindPhoneButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    [bindPhone setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
    [bindPhone setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateHighlighted];
    bindPhone.tag = 1003;
    bindPhone.layer.masksToBounds = YES;
    [backImageView addSubview:bindPhone];
    
}



// 返回
-(void)backButtonButtonItemAction{
    
    
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"BPBindViewControllTips"];
    if ([str isEqualToString:@"jumpForm_1"]) {
        
        [ShuZhiZhangUtility postPlatformExitNotification];
        
    };
    [self leftButtonItemAction];
    
    
}

#pragma mark --------countdown------
//显示多少秒后获取验证码
-(void) showCountDownButton:(int)seconds
{
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    [getVerifyCode setTitle:[NSString stringWithFormat:@"%d%@",seconds,[BPLanguage getStringForKey:@"BPReacquireVerifyCode" InTable:@"BPMultiLanguage"]] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateHighlighted];
    
}


//点击获取验证码
-(void) getVerifyCodeAction:(UIButton *)button
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    
    if(currentCountDown== 0 && [ShuZhiZhangUtility isMobileNumber:phoneNumber.text]) {
        
        currentCountDown = 60;
        
        [self requestForPhoneVertifyCode:phoneNumber.text];
        [self showCountDownButton:currentCountDown];
        
    }else if (![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
        
        if(phoneNumber.text.length<1)
        {
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] duration:2.0];
            [ShuZhiZhangUtility setPromptPosition];
            return;
        }
        
        [button setTitle:[BPLanguage getStringForKey:@"BPGetPhoneVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPRegistPhoneSecuritycode" InTable:@"BPMultiLanguage"] duration:2.0];
        
    }
}

/*
 *  手机号验证码
 */
-(void) requestForPhoneVertifyCode:(NSString *)phonenumber
{
    ////////NSLog(@"手机号码绑定账号，获取验证码点击");
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"phoneNumber":phonenumber,
                           @"action":@"bind",
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]
                           };
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"sendSMS",appid,sortStr,sign];
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            ////////NSLog(@"手机号验证码dict = %@,urlStr = %@",data,urlStr);
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [BPCustomNoticeBox showCenterWithText:@"验证码发送成功" duration:2.0];
                [self startTimerActionCount];
            }else{
                
                [self stopCountDown];
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [BPCustomPromptBox BPHidePromptBox];
                
            }
        });
    } failure:^(NSError *error) {
        
        
    }];
}

// 创建定时器
-(void)startTimerActionCount{
    
    currentCountDown = 60;
    
    if(countdownTimer==nil)
    {
        countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(VerifyCountDown) userInfo:nil repeats:YES];
    }
    [self showCountDownButton:currentCountDown];
}

//停止倒计时
-(void) stopCountDown
{
    [countdownTimer invalidate];
    countdownTimer = nil;
    currentCountDown = 0;
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    getVerifyCode.userInteractionEnabled = YES;
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetPhoneVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
    
}

// 定时器方法
-(void) VerifyCountDown
{
    currentCountDown--;
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    getVerifyCode.userInteractionEnabled = NO;
    if(currentCountDown==0)
    {
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetPhoneVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
        [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_senfVcode.png"] forState:UIControlStateNormal];
        [countdownTimer invalidate];
        countdownTimer = nil;
        getVerifyCode.userInteractionEnabled = YES;
        return;
    }
    
    [self showCountDownButton:currentCountDown]; //显示多少秒后获取验证码
}

// 判断是不是标准手机号码
// 绑定
-(void) bindPhoneButtonItemAction
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self viewWithTag:1001];
//    UITextField *password = (UITextField *)[self viewWithTag:102];
    
    
    [self hideAllKeyBoard];
    if(VerifyCode.text.length<1 || phoneNumber.text.length<1)
    {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneOrVerifyCodeEmpty" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    else if(![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneInvalid" InTable:@"BPMultiLanguage"] duration:2.0];
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    [self requestForPhoneBind:phoneNumber.text vertifyCode:VerifyCode.text];
    
    [BPQLoadingView showDefaultLoadingViewWithView:self];
    
}


/*
 *  手机号绑定
 */
-(void) requestForPhoneBind:(NSString *)phonenumber vertifyCode:(NSString *)code {
    
    
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSDictionary *dict = @{
                           @"phoneNumber":phonenumber,
                           @"userID" :[ShuZhiZhangUserPreferences CurrentUserID],
                           @"code":code,
                           @"ts":dateStr,
                           @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId]

                           };
    
    ////////NSLog(@"手机号绑定CustomDict = %@",dict);
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:[NSMutableDictionary dictionaryWithDictionary:dict]];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"bind",appid,sortStr,sign];
    ////////NSLog(@"普通账号绑定urlStr = %@",urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            ////////NSLog(@"手机号绑定dict = %@,urlStr = %@",data,urlStr);
            
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneBindSuccess" InTable:@"BPMultiLanguage"] duration:2.0];
                // 登录时更新token
                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set phoneNumber='%@',accountType = '1' where userID= '%@' ",BPUserInfoTableName,phonenumber,[ShuZhiZhangUserPreferences CurrentUserID]];
                [userInfoTable UpdateDataToTable:sqlStr];
                
                [BPShowLoginPrompt showWithName:phonenumber];
                
                
                
                [self leftButtonItemAction];
                
            }else{
                
                [BPCustomPromptBox BPHidePromptBox];
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                
            }
        });
    } failure:^(NSError *error) {
        
    }];
}




//返回
-(void) leftButtonItemAction
{
    
    UIImageView *backImageView = (UIImageView *)[self viewWithTag:5555];
    [UIView animateWithDuration:.2
                     animations:^{
                         
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                         
                     }];
    
    
}

//隐藏键盘
-(void) hideAllKeyBoard
{
    UITextField * PhoneUserField = (UITextField *)[self viewWithTag:1000];
    UITextField * phoneVerifyField = (UITextField *)[self viewWithTag:1001];
    
    [PhoneUserField resignFirstResponder];
    [phoneVerifyField resignFirstResponder];
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindPhoneNumber"])
    {
        
        [BPCustomNoticeBox showCenterWithText:@"当前网络不可用，请检查你的网络状态" duration:2.0];
        [ShuZhiZhangUtility setPromptPosition];
    }
}

#pragma mark -----textField delegate-----
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    //    if (range.location >= 8  &&
    if(textField.tag == 1000 && currentCountDown <= 0)
    {
        NSMutableString *phoneStr = (NSMutableString *)textField.text;
        if ([string isEqualToString:@""])
        {
            phoneStr = (NSMutableString *)[phoneStr substringToIndex:phoneStr.length-1];
        }
        else
        {
            phoneStr = (NSMutableString *)[phoneStr stringByAppendingString:string];
        }
    }
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self viewWithTag:1001];
    UITextField *password = (UITextField *)[self viewWithTag:102];
    
    if(textField == phoneNumber)
    {
        [phoneNumber resignFirstResponder];
        [VerifyCode becomeFirstResponder];
    }
    else if(textField == VerifyCode)
    {
        [VerifyCode resignFirstResponder];
        [password becomeFirstResponder];
        
    }
    else if(textField == password)
    {
        [self  bindPhoneButtonItemAction];
        
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UITextField * passwordField = (UITextField * )[self viewWithTag:102];
    
    if(SCREEN_IS_LANDSCAPE){
        
        if (textField == passwordField ) {
            
            UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
            
            [UIView animateWithDuration:0.3 animations:^{
                
                scroll.contentOffset = CGPointMake(0, 50);
                
            }];
            scroll.scrollEnabled = YES;
        }
        
    }
}


- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}


@end
