//
//  BPPersonalInfoViewController.m
//  BigPlayerSDK

#import "BPPersonalInfoViewController.h"
#import "BPRegisterAndLoginRequest.h"
//#import "BPExperiencePublic.h"
#import "BigPlayerSDKBase+PlayerShare.h"

@interface BPPersonalInfoViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *personalInfoRequest;
@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@property (nonatomic,retain) UITableView *editInfoTableView;
@property (nonatomic,retain) UIImagePickerController *photoPicker;
@property (nonatomic,retain) UIPopoverController *popOver;
@property (nonatomic,retain) NSArray *sensitiveWordArray;
@end

@implementation BPPersonalInfoViewController
@synthesize personalInfoRequest;
@synthesize userInfoDic;
@synthesize editInfoTableView;
@synthesize photoPicker;
@synthesize popOver;
@synthesize accountManager;
@synthesize sensitiveWordArray;

-(void) dealloc
{
    [personalInfoRequest release];          personalInfoRequest = nil;
    [userInfoDic release];                  userInfoDic = nil;
    [editInfoTableView release];            editInfoTableView = nil;
    [photoPicker release];                  photoPicker = nil;

    [popOver release];                      popOver = nil;
    [sensitiveWordArray release];           sensitiveWordArray = nil;
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPBasicInfo" InTable:@"BPMultiLanguage"];
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPMyInfo" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_nav_back.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_nav_back_sel.png"];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:NO NormalImage:@"ShuZhiZhang.bundle/BP_finish.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_finish_sel.png"];
        self.sensitiveWordArray = [ShuZhiZhangUtility getWordLibrary];
    }
    return self;
}
-(void) cancelRequest
{
    [personalInfoRequest cancelAllRequest];
}

-(void) leftButtonItemAction
{
    [self cancelRequest];
//    [self dismissModalViewControllerAnimated:YES];
    [self.navigationController popViewControllerAnimated:YES];
//    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}

-(void) rightButtonItemAction
{
    [self hideAllKeyBoard];
    if(!hasEdited)
    {
        // [BPCustomPromptBox showWithTitle:@"您未曾更新信息" AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:@"您未曾更新信息" duration:2.0];
        
        return;
    }
    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:31000];
    UITextView *signTextField = (UITextView *)[imageView viewWithTag:31001];
    NSString *str =  signTextField.text;
    if(str.length>0 && signTextField.textColor != [UIColor lightGrayColor])
    {
        [userInfoDic setObject:str forKey:@"signature"];
    }
    else
    {
        [userInfoDic setObject:@"" forKey:@"signature"];
    }
    
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    UITextField *textField = (UITextField *)[cell viewWithTag:17000];
    
    if(textField.text.length >=2){
        
        [userInfoDic setObject:textField.text forKey:@"nickname"];
        
         if (textField.text.length >10){
        
        // [BPCustomPromptBox showWithTitle:@"昵称不能超过十个字符，请重新修改后再上传" AndDisappearSecond:2];
             
             [BPCustomNoticeBox showCenterWithText:@"昵称不能超过十个字符，请重新修改后再上传" duration:2.0];
             
             return;
         }
        
    }else{
        
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNickNameLengthPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPNickNameLengthPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return;
        
    }
    
    NSString *path = nil;
//    if(hasEditedImage)
//    {
//        NSString *str = [userInfoDic objectForKey:@"image"];
//        if(SCREEN_IS_LANDSCAPE)
//        {
//            str = [str stringByReplacingOccurrencesOfString:@"small_" withString:@""];
//        }
//        NSString *savePath  = [BPFilePathManager getCachePathWithFileName:@"UserHead" AndURLStr:str];
//        
//        path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.jpg"];
//        NSData *data = [NSData dataWithContentsOfFile:path];
//        [data writeToFile:savePath atomically:YES];
//    }
    path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.jpg"];
    [personalInfoRequest uploadImageAndUserInfo:path UserInfo:userInfoDic];
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
}

//-(void) viewWillAppear:(BOOL)animated
//{
//    [personalInfoRequest requestUserInfomation];
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    personalInfoRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    [personalInfoRequest requestUserInfomation];
    [self getUserInfoFromLocal];
    
    photoPicker = [[UIImagePickerController alloc] init];
    photoPicker.delegate = self;
    photoPicker.editing=YES;
    //photoPicker.allowsEditing=YES;
    
    
	// Do any additional setup after loading the view.
    editInfoTableView = [[UITableView alloc] initWithFrame:CGRectMake(10, 74, 270, 180) style:UITableViewStyleGrouped];
    editInfoTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    editInfoTableView.separatorColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1];
    editInfoTableView.delegate = self;
    editInfoTableView.dataSource = self;
    editInfoTableView.scrollEnabled = NO;
    [editInfoTableView setBackgroundView:nil];
    [editInfoTableView setBackgroundView:[[[UIView alloc] init] autorelease]];
    [editInfoTableView setBackgroundColor:UIColor.clearColor];
    [self.view addSubview:editInfoTableView];

    [self showHeaderView];
    [self showSignatureView];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        editInfoTableView.frame = CGRectMake(SCREEN_WIDTH-(SCREEN_WIDTH - 360)/2-210, 0, 220, 180);
        if(BP_Show_IOS7)
        {
            editInfoTableView.frame = CGRectMake(SCREEN_WIDTH-(SCREEN_WIDTH - 360)/2-200, -20, 200, 190);
        }
    }
    else
    {
        editInfoTableView.frame = CGRectMake((SCREEN_WIDTH - 307)/2, 94, 307, 180);
        if(BP_Show_IOS7)
        {
            editInfoTableView.frame = CGRectMake((SCREEN_WIDTH - 307)/2+10, 74, 287, 190);
        }
    }
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
}

-(void) showHeaderView
{
    UIImageView *HeadImageView = [[UIImageView alloc] init];
    HeadImageView.userInteractionEnabled = YES;
    HeadImageView.contentMode = UIViewContentModeScaleToFill;
    // 圆角
    HeadImageView.layer.masksToBounds = YES;
    HeadImageView.layer.cornerRadius = 6.0;
    HeadImageView.layer.borderWidth = 1.0;
    HeadImageView.layer.borderColor = [[UIColor grayColor] CGColor];
    HeadImageView.tag = 26010;
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addPhoto)];
    [HeadImageView addGestureRecognizer:tap];
    [tap release];
    
    
    
    if(SCREEN_IS_LANDSCAPE)
    {
        [self.view addSubview:HeadImageView];
        [HeadImageView release];
        HeadImageView.frame = CGRectMake((SCREEN_WIDTH-360)/2, 15, 150, 150);
    }
    else
    {
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 15, 290, 75);
        UIImage *image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_signature_bg.png"];
        image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(5,10,5,10)];
        imageView.image = image;
        [self.view addSubview:imageView];
        imageView.userInteractionEnabled = YES;
        [imageView release];
        
        UILabel *typeLabel = [[UILabel alloc] init];
        typeLabel.textAlignment = NSTextAlignmentLeft;
        typeLabel.backgroundColor = [UIColor clearColor];
        typeLabel.textColor = [UIColor blackColor];
        typeLabel.frame = CGRectMake(15, 30, 90, 20);
        typeLabel.text = [BPLanguage getStringForKey:@"BPHeadImage" InTable:@"BPMultiLanguage"];
        typeLabel.font = [UIFont systemFontOfSize:14];
        typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        [imageView addSubview:typeLabel];
        [typeLabel release];
        
        [imageView addSubview:HeadImageView];
//        [HeadImageView addGestureRecognizer:tap];
        
        [HeadImageView release];
        HeadImageView.frame = CGRectMake(imageView.frame.size.width - 68, 10, 54, 54);
    }
}

//更新头像
-(void) updateHeaderView
{
    UIImageView *HeadImageView = (UIImageView *)[self.view viewWithTag:26010];
    NSString *str = [userInfoDic objectForKey:@"image"];
    if(SCREEN_IS_LANDSCAPE)
    {
        str = [str stringByReplacingOccurrencesOfString:@"small_" withString:@""];
    }
    NSString * headPath  = [BPFilePathManager getCachePathWithFileName:@"UserHead" AndURLStr:str];
    if(![[NSFileManager defaultManager] fileExistsAtPath:headPath])
    {
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"downloadHead",@"RequestTag",headPath,@"savePath", nil];
        [personalInfoRequest downloadFileWithUrl:str UserInfo:userInfo ProgressView:nil];
        HeadImageView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"];
    }
    else
    {
        HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
    }
}

//显示个性签名
-(void) showSignatureView
{
    UIImageView *imageView = [[UIImageView alloc] init];
    UIImage *image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_signature_bg.png"];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(5,10,5,10)];
    imageView.image = image;
    imageView.tag = 31000;
    [self.view addSubview:imageView];
    imageView.userInteractionEnabled = YES;
    [imageView release];
    
    UILabel *typeLabel = [[UILabel alloc] init];
    typeLabel.textAlignment = NSTextAlignmentLeft;
    typeLabel.backgroundColor = [UIColor clearColor];
    typeLabel.textColor = [UIColor blackColor];
    typeLabel.text = [BPLanguage getStringForKey:@"BPSignature" InTable:@"BPMultiLanguage"];
    typeLabel.font = [UIFont systemFontOfSize:14];
    typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [imageView addSubview:typeLabel];
    [typeLabel release];
    
    UITextView *signTextField = [[UITextView alloc] init];
    signTextField.delegate = self;
    signTextField.backgroundColor = [UIColor clearColor];

    signTextField.autoresizingMask = UIViewAutoresizingFlexibleHeight;
//    signTextField.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
    signTextField.textAlignment = NSTextAlignmentLeft;
    signTextField.font = [UIFont systemFontOfSize:14];
    [signTextField setText:[BPLanguage getStringForKey:@"BPEnterSignaturePrompt" InTable:@"BPMultiLanguage"]];
    [signTextField setTextColor:[UIColor lightGrayColor]];
    
    [imageView addSubview:signTextField];
    signTextField.tag = 31001;
    [signTextField release];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        imageView.frame = CGRectMake((SCREEN_WIDTH - 360)/2, 180, 360, 100);
        typeLabel.frame = CGRectMake(15, 10, 90, 20);
        signTextField.frame = CGRectMake(10, 30, imageView.frame.size.width - 30, imageView.frame.size.height-40);
    }
    else
    {
        imageView.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 280, 290, 120);
        typeLabel.frame = CGRectMake(15, 10, 90, 20);
        signTextField.frame = CGRectMake(10, 34, 250, 82);
    }
}

-(void) updateSignatureView
{
    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:31000];
    UITextView *signTextField = (UITextView *)[imageView viewWithTag:31001];
    NSString *str = [userInfoDic objectForKey:@"signature"];
     if([userInfoDic objectForKey:@"signature"] != [NSNull null] && str.length >0)
     {
         signTextField.text = str;
         signTextField.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
     }
}

#pragma mark -------UITextField delegate------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField.text.length>=18 && ![string isEqualToString:@""])
    {
        return NO;
    }
    return YES;
}

- (BOOL)disablesAutomaticKeyboardDismissal {
    return NO;
}

-(void) hideAllKeyBoard
{
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    UITextField *textField = (UITextField *)[cell viewWithTag:17000];
    [textField resignFirstResponder];
    
    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:31000];
    UITextView *signTextField = (UITextView *)[imageView viewWithTag:31001];
    [signTextField resignFirstResponder];
    if(signTextField.text.length == 0){
        signTextField.textColor = [UIColor lightGrayColor];
        signTextField.text = [BPLanguage getStringForKey:@"BPEnterSignaturePrompt" InTable:@"BPMultiLanguage"];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollUp:textField WillScrollView:self.view];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollDown: self.view];
    hasEdited = YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark -------UITextView delegate------
- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    if (textView.textColor == [UIColor lightGrayColor]) {
        textView.text = @"";
        textView.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
    }
    
    return YES;
}

-(void) textViewDidChange:(UITextView *)textView
{
//    if(textView.text.length == 0){
//        textView.textColor = [UIColor lightGrayColor];
//        textView.text = @"List words or terms separated by commas";
////        [textView resignFirstResponder];
//    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
//    if([text isEqualToString:@"\n"]) {
//        [textView resignFirstResponder];
//        if(textView.text.length == 0){
//            textView.textColor = [UIColor lightGrayColor];
//            textView.text = @"List words or terms separated by commas";
//            [textView resignFirstResponder];
//        }
//        return NO;
//    }
    if(textView.text.length>120 && ![text isEqualToString:@""])
    {
        return NO;
    }
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if(!BPDevice_is_ipad && SCREEN_IS_LANDSCAPE)
    {
        [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
        [UIView setAnimationDuration:0.35f];
        CGPoint point = self.view.center;
        point.y -= 160;
        self.view.center = point;
        [UIView commitAnimations];
    }
    else
    {
        [ShuZhiZhangUtility ViewScrollUp:textView WillScrollView:self.view];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [ShuZhiZhangUtility ViewScrollDown: self.view];
    textView.text = [ShuZhiZhangUtility filterSomeWord:(NSMutableArray *)sensitiveWordArray theContent:textView.text];
    hasEdited = YES;
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark -------buttons ------
#define EditInfo_HeadImageTag 2000
#define EditInfo_CityTag 2001

//头像
-(void)addPhoto
{
    [self hideAllKeyBoard];
    BPCustomActionSheet *actionSheet=[[BPCustomActionSheet alloc] initWithtitles:[BPLanguage getStringForKey:@"BPAlbums" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPCancel" InTable:@"BPMultiLanguage"],nil]; //,[BPLanguage getStringForKey:@"BPPhotograph" InTable:@"BPMultiLanguage"]
    if(BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
        [actionSheet showFromRect:CGRectMake(120, -200, 80, 270) inView:self.view animated:YES];
        else
            [actionSheet showFromRect:CGRectMake(320, -200, 80, 270) inView:self.view animated:YES];
    }
    else
    {
        [actionSheet showInView:self.view];
    }
    actionSheet.tag = EditInfo_HeadImageTag;
    actionSheet.delegate = self;
    [actionSheet release];
}

//- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
//    // 创建一个bitmap的context
//    // 并把它设置成为当前正在使用的context
//    UIGraphicsBeginImageContext(size);
//    // 绘制改变大小的图片
//    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
//    // 从当前context中创建一个改变大小后的图片
//    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
//    // 使当前的context出堆栈
//    UIGraphicsEndImageContext();
//    // 返回新的改变大小后的图片
//    return scaledImage;
//}

- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];

    UIImage *selectedImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    //UIImage *selectedImage = [info valueForKey:UIImagePickerControllerEditedImage];
    [photoPicker dismissModalViewControllerAnimated:YES];
    selectedImage = [ShuZhiZhangUtility scaleToSize:selectedImage size:CGSizeMake(640, 640)];
    UIImageView *HeadImageView = (UIImageView *)[self.view viewWithTag:26010];
    HeadImageView.image = selectedImage;
    
    NSData *data2 = [NSData dataWithData:UIImageJPEGRepresentation(selectedImage,1.0)];//1.0f = 100% quality
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.jpg"];
    [data2 writeToFile:path atomically:YES];
    [[BigPlayerSDKBase getSharedBPPlatform] compressionImageInPath:path WhenMoreThan:1024];
//    HeadImageView.image = [UIImage imageWithContentsOfFile:path];
    hasEdited = YES;
    hasEditedImage = YES;
    
    if(BPDevice_is_ipad)
    {
        [popOver dismissPopoverAnimated:YES];
    }
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}

-(void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [photoPicker dismissModalViewControllerAnimated:YES];
//    [BigPlayerSDKBase getSharedBPPlatform].bpShouldLockOrientation = NO;
}


- (void)showImagePicker:(UIImagePickerControllerSourceType)sourceType
{
    if ([UIImagePickerController isSourceTypeAvailable:sourceType])
    {
        photoPicker.sourceType = sourceType;
        if (sourceType == UIImagePickerControllerSourceTypeCamera)
        {
            photoPicker.showsCameraControls = YES;
            photoPicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
//            [self presentModalViewController:photoPicker animated:YES];
        }
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:photoPicker];
            [popover presentPopoverFromRect:CGRectMake(50, 0, 320, 480) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            self.popOver = popover;
            [popover release];
        }
        else
        {
            [self presentModalViewController:photoPicker animated:YES];
        }
    }
    
}


//年龄
-(void)changeDate:(NSDate *)_date
{
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
    UILabel *BirthdayLabel = (UILabel *)[cell viewWithTag:17000];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat : @"yyyy-MM-dd"];
    NSString *dateStr = [formatter stringFromDate:_date];
    if(![dateStr isEqualToString:[userInfoDic objectForKey:@"birthday"]])
    {
        [userInfoDic setObject:dateStr forKey:@"birthday"];
        hasEdited = YES;
    }
    
    NSDate *dateTime = [formatter dateFromString:[userInfoDic objectForKey:@"birthday"]];
    NSString *str = [NSString stringWithFormat:@"%d/%@",[ShuZhiZhangUtility getAge:[userInfoDic objectForKey:@"birthday"]],[ShuZhiZhangUtility getAstroWithMonth:dateTime]];
    BirthdayLabel.text = str;
    [formatter release];
}


- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    return;
    UITableViewCell *cell = nil;
    if(actionSheet.tag == EditInfo_CityTag)
    {
        cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:1]];
    }
    else
    {
        cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:1]];
    }
    UIView *view = [cell viewWithTag:17000];
    [ShuZhiZhangUtility ViewScrollUp:view WillScrollView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    //if(actionSheet.tag == EditInfo_CityTag)
    //[ShuZhiZhangUtility ViewScrollDown:self.view];
}

#pragma mark -----Custom Switch delegate---------
- (void)BPCustomSwitchDidEnd:(BPCustomSwitch *)coutomSwitch selectState:(int)state
{
    NSString *str = state == 1 ?@"0":@"1";
    if([str intValue] == [[userInfoDic objectForKey:@"sex"] intValue])
    {
        return;
    }
    if(![[userInfoDic objectForKey:@"sex"] isEqualToString:str])
    {
        [userInfoDic setObject:str forKey:@"sex"];
        hasEdited = YES;
    }
}
#pragma mark -------UITableView Cell-------
-(void) addViewToTableViewCell:(NSIndexPath *)indexPath AndCell:(UITableViewCell *)cell
{
    if(!userInfoDic)
    {
        return;
    }
    for(UIView *view in cell.contentView.subviews)
    {
        [view removeFromSuperview];
    }
    
    NSMutableArray *userInfoTitle = [NSMutableArray arrayWithObjects:@"BPNickName",@"BPSex",@"BPAgeAndAstro",@"BPArea", nil];
    
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 90, 20)];
    typeLabel.tag = 21000;
    typeLabel.textAlignment = NSTextAlignmentLeft;
    typeLabel.backgroundColor = [UIColor clearColor];
    typeLabel.textColor = [UIColor blackColor];
    typeLabel.text = [BPLanguage getStringForKey:[userInfoTitle objectAtIndex:indexPath.row] InTable:@"BPMultiLanguage"];
    typeLabel.font = [UIFont systemFontOfSize:14];
    typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [cell.contentView addSubview:typeLabel];
    [typeLabel release];
    int w = 275;
    if(SCREEN_IS_LANDSCAPE)
    {
        w = 185;
    }
    switch (indexPath.row)
    {
        case 0:
        {
            //昵称
            UITextField *nickTextField = [[UITextField alloc] init];
            nickTextField.delegate = self;
            nickTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
            nickTextField.returnKeyType = UIReturnKeyDone;
            nickTextField.layer.cornerRadius = 6.0f;
            nickTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
            nickTextField.text = [userInfoDic objectForKey:@"nickname"];
            nickTextField.textAlignment = NSTextAlignmentRight;
            nickTextField.tag = 17000;
            nickTextField.font = [UIFont systemFontOfSize:14];
            nickTextField.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
            
            [cell.contentView addSubview:nickTextField];
            [nickTextField release];
            nickTextField.frame = CGRectMake(60, 0, w-60, cell.frame.size.height);

        }
            break;
        case 1:
        {
            //性别
            BPCustomSwitch * mySwitch;
            mySwitch = [[BPCustomSwitch alloc] initWithFrame:CGRectMake(w-55, 8, 0, 0)];

            mySwitch.delegate = self;
            if([userInfoDic objectForKey:@"sex"] != [NSNull null])
            {
                int sex = [[userInfoDic objectForKey:@"sex"] intValue];
                sex = sex==1?0:1;
                [mySwitch setScrollButtonLocation:sex];
            }
            [cell.contentView addSubview:mySwitch];
            cell.clipsToBounds = YES;
            [mySwitch release];
            
           
        }
            break;
        case 2:
        {
            //年龄
            UILabel *BirthdayLabel = [[UILabel alloc] init];
            BirthdayLabel.backgroundColor = [UIColor clearColor];
            BirthdayLabel.textAlignment = NSTextAlignmentRight;
            [cell.contentView addSubview:BirthdayLabel];
            BirthdayLabel.tag = 17000;
            BirthdayLabel.font = [UIFont systemFontOfSize:14];
            BirthdayLabel.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
            if([userInfoDic objectForKey:@"birthday"] != [NSNull null])
            {
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat : @"yyyy-MM-dd"];
                NSDate *dateTime = [formatter dateFromString:[userInfoDic objectForKey:@"birthday"]];
                NSString *str = [NSString stringWithFormat:@"%d/%@",[ShuZhiZhangUtility getAge:[userInfoDic objectForKey:@"birthday"]],[ShuZhiZhangUtility getAstroWithMonth:dateTime]];
                BirthdayLabel.text = str;
                [formatter release];
            }
            [BirthdayLabel release];
            
            BirthdayLabel.frame = CGRectMake(60, 0, w-60, cell.frame.size.height);

        }
            break;
            

        case 3:
        {
            //地区
            UILabel *AreaLabel = [[UILabel alloc] init];
            AreaLabel.backgroundColor = [UIColor clearColor];
            AreaLabel.textAlignment = NSTextAlignmentRight;
            [cell.contentView addSubview:AreaLabel];
            AreaLabel.tag = 17000;
            AreaLabel.font = [UIFont systemFontOfSize:14];
            AreaLabel.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
            NSString *areaStr = [NSString stringWithFormat:@"%@ %@",[userInfoDic objectForKey:@"province"],[userInfoDic objectForKey:@"city"]];
            if([areaStr rangeOfString:@"null"].location!=NSNotFound)
            {
                areaStr = @"";
            }
            AreaLabel.text = areaStr;
            [AreaLabel release];

            AreaLabel.frame = CGRectMake(60, 0, w-60, cell.frame.size.height);

        }
            break;
        default:
            break;
    }
}



#pragma mark -------UITableView delegate-----
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"detailCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    cell.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    [self addViewToTableViewCell:indexPath AndCell:cell];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self hideAllKeyBoard];
    
    switch (indexPath.row) {
        case 1:
            
            break;
        case 2:
           //  [self SetAge];
            break;
        case 3:
          //  [self SetCity];
            break;
        default:
            break;
    }
}


#pragma mark --------update table------
-(void) getUserInfoFromLocal
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    self.userInfoDic = [[userInfoTable queryForDataWithSql:[NSString stringWithFormat:@"select * from BPUserInfo where uid = '%@'",[ShuZhiZhangUserPreferences CurrentUserID]]] objectAtIndex:0];
    [userInfoTable release];
}

-(void) updateLocalTable
{
    [ShuZhiZhangUserPreferences updateUserInfoWithDic:userInfoDic];
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    [userInfoTable insertDataToTable:[NSString stringWithFormat:@"update %@ set sex = :sex, nickname = :nickname, birthday = :birthday, province = :province, city = :city, signature = :signature, image=:image where uid = %@",BPUserInfoTableName,[ShuZhiZhangUserPreferences CurrentUserID]] withParameterDictionary:userInfoDic];
    [userInfoTable release];
}

#pragma mark ------http request--------

-(void) downloadImageSuccessWithRequest:(ASIHTTPRequest *)request
{
    UIImageView *HeadImageView = (UIImageView *)[self.view viewWithTag:26010];
    NSString *str = [userInfoDic objectForKey:@"image"];
    if(SCREEN_IS_LANDSCAPE)
    {
        str = [str stringByReplacingOccurrencesOfString:@"small_" withString:@""];
    }
    NSString * headPath  = [BPFilePathManager getCachePathWithFileName:@"UserHead" AndURLStr:str];
    HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"getUserInfo"])
    {
        [self getUserInfoFromLocal];
        NSString *decodeStr = [ShuZhiZhangUtility decodeBase64:[userInfoDic objectForKey:@"signature"]];
        [userInfoDic setObject:decodeStr forKey:@"signature"];
        [self updateHeaderView];
        [self updateSignatureView];
        [editInfoTableView reloadData];
    }
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"updateUserInfo"])
    {
       //  [BPCustomPromptBox showWithTitle:@"当前网络不可用，请检查你的网络状态" AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:@"当前网络不可用，请检查你的网络状态" duration:2.0];

    }
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}
@end
