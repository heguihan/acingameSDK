//
//  BPPersonalInfoViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-24.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPPersonalInfoViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "BPExperiencePublic.h"

@interface BPPersonalInfoViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *personalInfoRequest;
@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@property (nonatomic,retain) UITableView *editInfoTableView;
@property (nonatomic,retain) UIImagePickerController *photoPicker;
@property (nonatomic,retain) UIPopoverController *popOver;
//@property (nonatomic,retain) UIImage *editHeadImage;
@end

@implementation BPPersonalInfoViewController
@synthesize personalInfoRequest;
@synthesize userInfoDic;
@synthesize editInfoTableView;
@synthesize photoPicker;
//@synthesize editHeadImage;
@synthesize popOver;

-(void) dealloc
{
    [personalInfoRequest release];          personalInfoRequest = nil;
    [userInfoDic release];                  userInfoDic = nil;
    [editInfoTableView release];            editInfoTableView = nil;
    [photoPicker release];                  photoPicker = nil;
//    [editHeadImage release];                editHeadImage = nil;
    [popOver release];                      popOver = nil;
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPBasicInfo" InTable:@"BPMultiLanguage"];
        [BPUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPBasicInfo" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
        [BPUtility customNavigationButton:self isleftButton:YES NormalImage:@"BPSDKResource.bundle/BP_nav_back.png" HighLightedImage:@"BPSDKResource.bundle/BP_nav_back_sel.png"];
        [BPUtility customNavigationButton:self isleftButton:NO NormalImage:@"BPSDKResource.bundle/BP_finish.png" HighLightedImage:@"BPSDKResource.bundle/BP_finish_sel.png"];
        
        //监测键盘位置的变化，让输入框显示在键盘上面
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(keyboardWillShow:)
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];
    }
    return self;
}
-(void) cancelRequest
{
    [personalInfoRequest cancelAllRequest];
}

-(void) leftButtonItemAction
{
    [self cancelRequest];
//    [self dismissModalViewControllerAnimated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void) rightButtonItemAction
{
    [self hideAllKeyBoard];
    if(!hasEdited)
    {
        [BPCustomPromptBox showWithTitle:@"你什么都没改，点毛啊点。" AndDisappearSecond:2];
        return;
    }
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
//    UITextView *signTextField = (UITextView *)[cell viewWithTag:17000];
//    NSString *str = [NSString stringWithFormat:@"%@",signTextField.text];
//    if(str.length>0)
//    {
//        [userInfoDic setObject:str forKey:@"signature"];
//    }
    cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
//    UITextField *textField = (UITextField *)[cell viewWithTag:17000];
//    if(textField.text.length>0)
//    [userInfoDic setObject:textField.text forKey:@"nickname"];
    
    NSString *nickName = [userInfoDic objectForKey:@"nickname"];
    if(nickName.length < 2)
    {
        [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPNickNameLengthPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        return;
    }
    
    NSString *path = nil;
    if(hasEditedImage)
    {
        NSString *savePath = [BPFilePathManager UserHeadImagePathWithUserId:[[BPUserPreferences CurrentUserID] intValue]];
        
        path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.png"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        [data writeToFile:savePath atomically:YES];
    }
    
    [personalInfoRequest uploadImageAndUserInfo:path UserInfo:userInfoDic];
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    personalInfoRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    [personalInfoRequest requestUserInfomation];
    [self getUserInfoFromLocal];
    
    photoPicker = [[UIImagePickerController alloc] init];
    photoPicker.delegate = self;
    photoPicker.editing=YES;
    photoPicker.allowsEditing=YES;
    
	// Do any additional setup after loading the view.
    editInfoTableView = [[UITableView alloc] initWithFrame:CGRectMake(15, 74, 225, 180) style:UITableViewStyleGrouped];
    editInfoTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    editInfoTableView.separatorColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1];
    editInfoTableView.delegate = self;
    editInfoTableView.dataSource = self;
    editInfoTableView.showsHorizontalScrollIndicator = NO;
    editInfoTableView.showsVerticalScrollIndicator = NO;
//    editInfoTableView.scrollEnabled = NO;
    [editInfoTableView setBackgroundView:nil];
    [editInfoTableView setBackgroundView:[[[UIView alloc] init] autorelease]];
    [editInfoTableView setBackgroundColor:UIColor.clearColor];
    editInfoTableView.frame = CGRectMake((SCREEN_WIDTH-310)/2, 5, 310, SCREEN_HEIGHT_NAV-5);
    [self.view addSubview:editInfoTableView];

    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
}



#pragma mark -------UITextField delegate------
- (BOOL)disablesAutomaticKeyboardDismissal {
    return NO;
}

-(void) hideAllKeyBoard
{
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
    UITextField *textField = (UITextField *)[cell.contentView viewWithTag:17000];
    [textField resignFirstResponder];
    cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
    UITextView *signTextField = (UITextView *)[cell.contentView viewWithTag:17000];
    [signTextField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [BPUtility ViewScrollUp:textField WillScrollView:self.view];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [BPUtility ViewScrollDown: self.view];
    hasEdited = YES;
    
    if(textField.text.length>0)
        [userInfoDic setObject:textField.text forKey:@"nickname"];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark -------UITextView delegate------
- (void)keyboardWillShow:(NSNotification *)notification
{
    //NSLog(@"keyboardWillShow");
 	NSDictionary *userInfo = [notification userInfo];
    
    // Get animation info from userInfo
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
//    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    //NSLog(@"keyboardEndFrame:%@",NSStringFromCGRect(keyboardEndFrame));
    //重新设置inputContainer高度，让输入框出现在键盘上面
//    CGRect inputFrame = footBarView.frame;
//    //64＝20＋44。20是statusbar的高度，44是navigationbar的高度
//    //取到的keyboardEndFrame的orgin是相对于window的
//    CGSize kbSize=[[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
//    if(SCREEN_IS_LANDSCAPE)
//    {
//        inputFrame.origin.y = SCREEN_HEIGHT_NAV-kbSize.width-48;
//    }else{
//        inputFrame.origin.y = SCREEN_HEIGHT_NAV-kbSize.height-48;
//        
//    }
    NSLog(@"%@",userInfo);
}

-(void) scrollUpAfterDelay:(UITextView *)textView
{
    [BPUtility ViewScrollUp:textView WillScrollView:self.view];
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
//    CGPoint point = [textView convertPoint:CGPointMake(0, 0) toView:self.view];
//    if(point.y>SCREEN_HEIGHT_NAV-30)
//    {
////        [editInfoTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
//        int aa = editInfoTableView.contentSize.height-10;
//        editInfoTableView.contentOffset = CGPointMake(0, editInfoTableView.contentSize.height-SCREEN_HEIGHT_NAV);
////        [self performSelector:@selector(scrollUpAfterDelay:) withObject:textView afterDelay:.3];
//    }
//    else
    {
        editInfoTableView.contentOffset = CGPointMake(0, editInfoTableView.contentSize.height-SCREEN_HEIGHT_NAV);
        [BPUtility ViewScrollUp:textView WillScrollView:self.view];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [BPUtility ViewScrollDown: self.view];
    hasEdited = YES;
    NSString *str = [NSString stringWithFormat:@"%@",textView.text];
    if(str.length>0)
    {
        [userInfoDic setObject:str forKey:@"signature"];
    }
    else
    {
        [userInfoDic setObject:@"" forKey:@"signature"];
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if(textView.text.length>120 && ![text isEqualToString:@""])
    {
        return NO;
    }
    return YES;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark -------buttons ------
#define EditInfo_HeadImageTag 2000
#define EditInfo_CityTag 2001

//头像
-(void)addPhoto
{
    [self hideAllKeyBoard];
    BPCustomActionSheet *actionSheet=[[BPCustomActionSheet alloc] initWithtitles:[BPLanguage getStringForKey:@"BPAlbums" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPPhotograph" InTable:@"BPMultiLanguage"],[BPLanguage getStringForKey:@"BPCancel" InTable:@"BPMultiLanguage"],nil];
    if(BPDevice_is_ipad)
    {
        [actionSheet showFromRect:CGRectMake(120, -200, 80, 270) inView:self.view animated:YES];
    }
    else
    {
        [actionSheet showInView:self.view];
    }
    actionSheet.tag = EditInfo_HeadImageTag;
    actionSheet.delegate = self;
    [actionSheet release];
}

- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    // 返回新的改变大小后的图片
    return scaledImage;
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [photoPicker dismissModalViewControllerAnimated:YES];
    
    UIImage *selectedImage = [info valueForKey:UIImagePickerControllerEditedImage];
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    UIImageView *HeadImageView = (UIImageView *)[cell.contentView viewWithTag:17000];
    selectedImage = [BPUtility scaleToSize:selectedImage size:CGSizeMake(120, 120)];
    HeadImageView.image = selectedImage;
    NSData *data2 = [NSData dataWithData:UIImagePNGRepresentation(selectedImage)];//1.0f = 100% quality
    NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.png"];
    [data2 writeToFile:path atomically:YES];
    
    hasEdited = YES;
    hasEditedImage = YES;
    
    if(BPDevice_is_ipad)
    {
        [popOver dismissPopoverAnimated:YES];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [photoPicker dismissModalViewControllerAnimated:YES];
}


- (void)showImagePicker:(UIImagePickerControllerSourceType)sourceType
{
    if ([UIImagePickerController isSourceTypeAvailable:sourceType])
    {
        photoPicker.sourceType = sourceType;
        if (sourceType == UIImagePickerControllerSourceTypeCamera)
        {
            photoPicker.showsCameraControls = YES;
            photoPicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
        }
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:photoPicker];
            [popover presentPopoverFromRect:CGRectMake(50, 0, 320, 480) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            self.popOver = popover;
            [popover release];
        } else {
            [self presentModalViewController:photoPicker animated:YES];
        }
        
    }
}

//年龄
-(void)changeDate:(NSDate *)_date
{
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:1]];
    UILabel *BirthdayLabel = (UILabel *)[cell viewWithTag:17000];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat : @"yyyy-MM-dd"];
    NSString *dateStr = [formatter stringFromDate:_date];
    [userInfoDic setObject:dateStr forKey:@"birthday"];
    hasEdited = YES;
    
    NSDate *dateTime = [formatter dateFromString:[userInfoDic objectForKey:@"birthday"]];
    NSString *str = [NSString stringWithFormat:@"%d/%@",[BPUtility getAge:[userInfoDic objectForKey:@"birthday"]],[BPUtility getAstroWithMonth:dateTime]];
    BirthdayLabel.text = str;
    [formatter release];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    UITableViewCell *cell = nil;
    if(actionSheet.tag == EditInfo_CityTag)
    {
        cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:1]];
    }
    else
    {
        cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:1]];
    }
    UIView *view = [cell viewWithTag:17000];
    [BPUtility ViewScrollUp:view WillScrollView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    [BPUtility ViewScrollDown:self.view];
}

#pragma mark -----Custom Switch delegate---------
- (void)BPCustomSwitchDidEnd:(BPCustomSwitch *)coutomSwitch selectState:(int)state
{
    NSString *str = state == 1 ?@"0":@"1";
    if([str intValue] == [[userInfoDic objectForKey:@"sex"] intValue])
    {
        return;
    }
    [userInfoDic setObject:str forKey:@"sex"];
    hasEdited = YES;
}
#pragma mark -------UITableView Cell-------
-(void) addViewToTableViewCell:(NSIndexPath *)indexPath AndCell:(UITableViewCell *)cell
{
    if(!userInfoDic)
    {
        return;
    }
    for(UIView *view in cell.contentView.subviews)
    {
        [view removeFromSuperview];
    }
    
    NSMutableArray *userInfoTitle = [NSMutableArray arrayWithObjects:@"BPHeadImage",@"BPNickName",@"BPSex",@"BPAgeAndAstro",@"BPArea",@"BPSignature", nil];
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 90, 20)];
    typeLabel.tag = 21000;
    typeLabel.textAlignment = NSTextAlignmentLeft;
    typeLabel.backgroundColor = [UIColor clearColor];
    typeLabel.textColor = [UIColor blackColor];
    if(indexPath.section == 2)
    {
        typeLabel.text = [BPLanguage getStringForKey:[userInfoTitle objectAtIndex:indexPath.row+indexPath.section+3] InTable:@"BPMultiLanguage"];
    }
    else
    {
        typeLabel.text = [BPLanguage getStringForKey:[userInfoTitle objectAtIndex:indexPath.row+indexPath.section] InTable:@"BPMultiLanguage"];
    }
    typeLabel.font = [UIFont systemFontOfSize:14];
    typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [cell.contentView addSubview:typeLabel];
    if(indexPath.section == 0)
    {
        typeLabel.frame = CGRectMake(15, 27, 90, 20);
    }
    [typeLabel release];

    if(indexPath.section == 0)
    {
        //头像
        UIImageView *HeadImageView = [[UIImageView alloc] init];
        HeadImageView.userInteractionEnabled = YES;
        HeadImageView.contentMode = UIViewContentModeScaleToFill;
        // 圆角
        HeadImageView.layer.masksToBounds = YES;
        HeadImageView.layer.cornerRadius = 6.0;
        HeadImageView.layer.borderWidth = 1.0;
        HeadImageView.layer.borderColor = [[UIColor grayColor] CGColor];
        HeadImageView.tag = 17000;
        [cell.contentView addSubview:HeadImageView];
        NSString *path = [[BPFilePathManager applicationCacheDirectoryPath] stringByAppendingPathComponent:@"head_tmp.png"];
        if(hasEditedImage && [[NSFileManager defaultManager] fileExistsAtPath:path])
        {
            HeadImageView.image = [UIImage imageWithContentsOfFile:path];
        }
        else
        {
            NSString * headPath = [BPFilePathManager UserHeadImagePathWithUserId:[[BPUserPreferences CurrentUserID] intValue]];
            if(![[NSFileManager defaultManager] fileExistsAtPath:headPath])
            {
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"downloadHead",@"RequestTag",headPath,@"savePath", nil];
                [personalInfoRequest downloadFileWithUrl:[userInfoDic objectForKey:@"image"] UserInfo:userInfo ProgressView:nil];
                HeadImageView.image = [UIImage imageNamed:@"BPSDKResource.bundle/BP_user_default_icon.png"];
            }
            else
            {
                HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
            }
        }
        HeadImageView.frame = CGRectMake(290-54-15, 10, 54, 54);
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addPhoto)];
        [HeadImageView addGestureRecognizer:tap];
        [tap release];
        [HeadImageView release];
        return;
    }
    else if(indexPath.section == 1)
    {
        switch (indexPath.row)
        {
            case 0:
            {
                //昵称
                UITextField *nickTextField = [[UITextField alloc] init];
                nickTextField.delegate = self;
                nickTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
                nickTextField.returnKeyType = UIReturnKeyDone;
                nickTextField.layer.cornerRadius = 6.0f;
                nickTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
                nickTextField.text = [userInfoDic objectForKey:@"nickname"];
                nickTextField.textAlignment = NSTextAlignmentRight;
                nickTextField.tag = 17000;
                nickTextField.font = [UIFont systemFontOfSize:14];
                nickTextField.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
                
                [cell.contentView addSubview:nickTextField];
                [nickTextField release];
                nickTextField.frame = CGRectMake(60, 0, 215, cell.frame.size.height);
            }
                break;
            case 1:
            {
                //性别
                BPCustomSwitch * mySwitch;
                mySwitch = [[BPCustomSwitch alloc] initWithFrame:CGRectMake(220, 8, 0, 0)];
                mySwitch.delegate = self;
                if([userInfoDic objectForKey:@"sex"] != [NSNull null])
                [mySwitch setScrollButtonLocation:[[userInfoDic objectForKey:@"sex"] intValue]==1?0:1];
                [cell.contentView addSubview:mySwitch];
                cell.clipsToBounds = YES;
                [mySwitch release];
                
               
            }
                break;
            case 2:
            {
                //年龄
                UILabel *BirthdayLabel = [[UILabel alloc] init];
                BirthdayLabel.backgroundColor = [UIColor clearColor];
                BirthdayLabel.textAlignment = NSTextAlignmentRight;
                [cell.contentView addSubview:BirthdayLabel];
                BirthdayLabel.tag = 17000;
                BirthdayLabel.font = [UIFont systemFontOfSize:14];
                BirthdayLabel.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
                if([userInfoDic objectForKey:@"birthday"] != [NSNull null])
                {
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    [formatter setDateFormat : @"yyyy-MM-dd"];
                    NSDate *dateTime = [formatter dateFromString:[userInfoDic objectForKey:@"birthday"]];
                    NSString *str = [NSString stringWithFormat:@"%d/%@",[BPUtility getAge:[userInfoDic objectForKey:@"birthday"]],[BPUtility getAstroWithMonth:dateTime]];
                    BirthdayLabel.text = str;
                    [formatter release];
                }
                [BirthdayLabel release];
                BirthdayLabel.frame = CGRectMake(60, 0, 215, cell.frame.size.height);

            }
                break;
            case 3:
            {
                //地区
                UILabel *AreaLabel = [[UILabel alloc] init];
                AreaLabel.backgroundColor = [UIColor clearColor];
                AreaLabel.textAlignment = NSTextAlignmentRight;
                [cell.contentView addSubview:AreaLabel];
                AreaLabel.tag = 17000;
                AreaLabel.font = [UIFont systemFontOfSize:14];
                AreaLabel.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
                NSString *areaStr = [NSString stringWithFormat:@"%@ %@",[userInfoDic objectForKey:@"province"],[userInfoDic objectForKey:@"city"]];
                if([areaStr rangeOfString:@"null"].location!=NSNotFound)
                {
                    areaStr = @"";
                }
                AreaLabel.text = areaStr;
                [AreaLabel release];
                
                AreaLabel.frame = CGRectMake(60, 0, 215, cell.frame.size.height);
            }
                break;
            default:
                break;
        }
    }
    else
    {
        UITextView *signTextField = [[UITextView alloc] init];
        signTextField.delegate = self;
        signTextField.backgroundColor = [UIColor clearColor];
//        signTextField.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        signTextField.textColor = [UIColor colorWithRed:30/255.0f green:100/255.0f blue:180/255.0f alpha:1];
        signTextField.textAlignment = NSTextAlignmentLeft;
        signTextField.font = [UIFont systemFontOfSize:14];
        [cell.contentView addSubview:signTextField];
        signTextField.tag = 17000;
        if([userInfoDic objectForKey:@"signature"] != [NSNull null])
        signTextField.text = [userInfoDic objectForKey:@"signature"];
        signTextField.frame = CGRectMake(10, 28, 280, 100);
        [signTextField release];
    }
}



#pragma mark -------UITableView delegate-----
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 1)
        return 4;
    else
        return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"detailCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    [self addViewToTableViewCell:indexPath AndCell:cell];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
        return 75;
    else if(indexPath.section == 2)
        return 120;
    return 40;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self hideAllKeyBoard];
    
    if(indexPath.section == 1)
    {
        switch (indexPath.row) {
            case 2:
                [self SetAge];
                break;
            case 3:
                [self SetCity];
                break;
            default:
                break;
        }
    }
}


#pragma mark --------update table------
-(void) getUserInfoFromLocal
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    self.userInfoDic = [[userInfoTable queryForDataWithSql:[NSString stringWithFormat:@"select * from BPUserInfo where uid = '%@'",[BPUserPreferences CurrentUserID]]] objectAtIndex:0];
    [userInfoTable release];
}

-(void) updateLocalTable
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    [userInfoTable insertDataToTable:[NSString stringWithFormat:@"update %@ set sex = :sex, nickname = :nickname, birthday = :birthday, province = :province, city = :city, signature = :signature where userId = %@",BPUserInfoTableName,[BPUserPreferences CurrentUserID]] withParameterDictionary:userInfoDic];
    [userInfoTable release];
}

#pragma mark ------http request--------
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=========%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    //用户信息
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"getUserInfo"])
    {
        self.userInfoDic = [request.responseString JSONValue];
        if(!userInfoDic || [[userInfoDic allKeys] count]<1)
        {
            [self getUserInfoFromLocal];
        }
        
        NSString *decodeStr = [BPUtility decodeBase64:[userInfoDic objectForKey:@"signature"]];
        [userInfoDic setObject:decodeStr forKey:@"signature"];
        
        //将等级升级表保存到数据库
        [BPExperiencePublic saveExperienceInfoToTable:[userInfoDic objectForKey:@"levelJson"]];
        
        [editInfoTableView reloadData];
    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"updateUserInfo"])
    {
        NSDictionary *dic = [request.responseString JSONValue];
        if([[dic objectForKey:@"result"] intValue]>0)
        {
            [self updateLocalTable];
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEditInfoSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        }
        else
        {
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEditInfoFailed" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        }
    }
}

-(void) downloadImageSuccessWithRequest:(ASIHTTPRequest *)request
{
    UITableViewCell *cell = [editInfoTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    UIImageView *HeadImageView = (UIImageView *)[cell.contentView viewWithTag:17000];
    NSString * headPath = [BPFilePathManager UserHeadImagePathWithUserId:[[BPUserPreferences CurrentUserID] intValue]];
    HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"getUserInfo"])
    {
        [self getUserInfoFromLocal];
        NSString *decodeStr = [BPUtility decodeBase64:[userInfoDic objectForKey:@"signature"]];
        [userInfoDic setObject:decodeStr forKey:@"signature"];
        [editInfoTableView reloadData];
    }
    
}

@end
