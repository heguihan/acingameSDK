//
//  BPPersonalInfoViewController.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import "BPCustomSwitch.h"
#import "BPBaseViewController.h"
#import "BPAccountManageViewController.h"

@interface BPPersonalInfoViewController : BPBaseViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,BPCustomSwitchDelegate>
{
    BOOL hasEdited; //是否有修改
    BOOL hasEditedImage; //是否有修改图片
}

@property (nonatomic,assign) BPAccountManageViewController *accountManager;
@end
