//
//  BPShowLoginPrompt.h
//  BigPlayerSDK


#import <UIKit/UIKit.h>

@interface BPShowLoginPrompt : UIView
+ (void)showWithName:(NSString *)name;
//显示登录名字
+ (void)showWithAccount:(NSString *)account;

@end
