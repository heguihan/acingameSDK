//
//  KeyChainSave.h
//  ShuZhiZhangSDK
//
//  Created by SkyGame on 2018/7/25.
//  Copyright © 2018年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeyChainSave : NSObject


+(NSDictionary *)getUserInfo;
+(void)setUserInfo:(NSDictionary *)dict;
@end
