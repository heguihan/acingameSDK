//
//  BPBackPaySecretViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-27.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPForgotPasswordViewController.h"

@interface BPBackPaySecretViewController : BPForgotPasswordViewController

@end
