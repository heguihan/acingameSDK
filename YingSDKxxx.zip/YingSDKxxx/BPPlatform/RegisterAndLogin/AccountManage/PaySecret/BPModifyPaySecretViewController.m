//
//  BPModifyPaySecretViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-27.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPModifyPaySecretViewController.h"
#import "BPModifySecretViewController.h"
#import "BPLoginPublic.h"
#import "BPRegisterAndLoginRequest.h"

@interface BPModifyPaySecretViewController ()
@property (nonatomic,retain) BPModifySecretViewController *passwordViewController;
@property (nonatomic,retain) UIScrollView *scrollView;
@property (nonatomic,retain) BPRegisterAndLoginRequest *paySecretRequest;
@end

@implementation BPModifyPaySecretViewController
@synthesize passwordViewController;
@synthesize scrollView;
@synthesize paySecretRequest;


-(void) dealloc
{
    [passwordViewController release];       passwordViewController = nil;
    [scrollView release];                   scrollView = nil;
    [paySecretRequest release];             paySecretRequest = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        paySecretRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        self.phoneRequest = paySecretRequest;
    }
    return self;
}

- (void)viewDidLoad
{
//    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
    UIImageView * back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
    back.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
    back.userInteractionEnabled = YES;
    [self.view addSubview:back];
    [back release];
//    self.title = [BPLanguage getStringForKey:@"BPModifyPaySecret" InTable:@"BPMultiLanguage"];
    [BPUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPModifyPaySecret" InTable:@"BPMultiLanguage"] ViewController:self];
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV)];
    scrollView.backgroundColor = [UIColor clearColor];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.delegate = self;
    scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 315);
    [self.view addSubview:scrollView];
    [self showPhoneNumEnterToView:scrollView];
    [self showVerifyCodeToView:scrollView];
    UITextField *VerifyCode = (UITextField *)[self.view viewWithTag:1001];
    CGRect frame = VerifyCode.frame;
    frame.origin.y -= 20;
    VerifyCode.frame = frame;
    
    //提示
    UILabel *label = [[UILabel alloc] init];
    label.text = [BPLanguage getStringForKey:@"BPPhonePrompt2" InTable:@"BPMultiLanguage"];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    label.font = [UIFont systemFontOfSize:12];
    if(SCREEN_IS_LANDSCAPE)
    {
        label.frame = CGRectMake((SCREEN_WIDTH - 300)/2+10, 120, 200, 15);
    }
    else
    {
        label.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 120, 200, 15);
    }
    [scrollView addSubview:label];
    [label release];
    
    //3个密码
    NSArray *array = [NSArray arrayWithObjects:@"BPOldPassword",@"BPNewPassword",@"BPConfirmNewPassword", nil];
    for (int i=0;i<3;i++)
    {
        //密码
        BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
        passwordField.placeholder = [BPLanguage getStringForKey:[array objectAtIndex:i] InTable:@"BPMultiLanguage"];
        [BPLoginPublic setTextFieldProperty:passwordField withDelegate:self];
        [scrollView addSubview:passwordField];
        if(i == 2)
        {
            passwordField.returnKeyType = UIReturnKeyGo;
        }
        else
        {
            passwordField.returnKeyType = UIReturnKeyNext;
        }
        passwordField.secureTextEntry= YES;
        passwordField.tag = 11000+i;
        
        if(SCREEN_IS_LANDSCAPE)
        {
            passwordField.frame = CGRectMake((SCREEN_WIDTH - 300)/2, 150+55*i, 300, 40);
        }
        else
        {
            passwordField.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 150+55*i, 290, 40);
        }
        [passwordField release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}

-(void) requestVerifyCode
{
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
    [paySecretRequest RequestPhoneVerifyCodeInModifyPaySecret:phoneNumber.text];
}

-(BOOL) checkAccountAndPassword
{
    UITextField * oldPassword = (UITextField *)[self.view viewWithTag:11000];
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11001];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11002];
    [self hideAllKeyBoard];
    
    NSString *regularExpression = @"^[A-z0-9_-]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:oldPassword.text] == NO)
    {
        [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        return NO;
    }
    else if(![BPLoginPublic checkTwoPasswordValid:passwordField.text ConfirmPassword:verifypassword.text])
    {
        return NO;
    }
    return YES;
}

- (void)rightButtonItemAction
{
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self.view viewWithTag:1001];
    
    UITextField * oldPassword = (UITextField *)[self.view viewWithTag:11000];
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11001];
    
    if([self checkAccountAndPassword])
    {
        [paySecretRequest ModifyPaySecretWithPhone:phoneNumber.text VerifyCode:VerifyCode.text OldPassword:oldPassword.text NewPassword:passwordField.text];
        [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    }
}

#pragma mark ------UITextField delegate-----------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    [super textField:textField shouldChangeCharactersInRange:range replacementString:string];
    //限制输入的长度
    if (textField.text.length >= 18&&![string isEqualToString:@""])
        return NO; // return NO to not change text
    return YES;
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * userField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11001];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11002];
    
    if(textField == userField)
    {
        [userField resignFirstResponder];
        [passwordField becomeFirstResponder];
    }
    else if(textField == passwordField)
    {
        if(scrollView.contentOffset.y<=40)
        {
            scrollView.contentOffset = CGPointMake(0, 40);
        }
        [passwordField resignFirstResponder];
        [verifypassword becomeFirstResponder];
    }
    else if(textField == verifypassword)
    {
        [self hideAllKeyBoard];
        [self rightButtonItemAction];
    }
    return YES;
}


-(void) hideAllKeyBoard
{
    [super hideAllKeyBoard];
    for(int i=0;i<3;i++)
    {
        UITextField * textField = (UITextField *)[self.view viewWithTag:11000+i];
        [textField resignFirstResponder];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
//    [passwordViewController hideAllKeyBoard];
}

#pragma mark ----request delegate------
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=========%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    //获取手机验证码
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"RequestPhoneVerifyCode"])
    {
        NSString *descode = [BPUtility decodeBase64:[request responseString]];
        NSDictionary *dic = [descode JSONValue];
        if(![[dic objectForKey:@"msg"] isEqualToString:@"done"])
        {
            NSString *str = [NSString stringWithFormat:@"%@\n%@",[BPLanguage getStringForKey:@"BPGetVerifyCodeError" InTable:@"BPMultiLanguage"],[dic objectForKey:@"msg"]];
            [BPCustomPromptBox showWithTitle:str AndDisappearSecond:2];
            [super stopCountDown];
        }
    }
    //修改支付密码
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"modifyPaySecret"])
    {
        NSString *descode = [BPUtility decodeBase64:[request responseString]];
        NSDictionary *dic = [descode JSONValue];
        if([[dic objectForKey:@"info"] isEqualToString:@"done"])
        {
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPModifyPaySecretSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            [super leftButtonItemAction];
        }
        else
        {
//            NSString *str = [NSString stringWithFormat:@"%@\n%@",[BPLanguage getStringForKey:@"BPModifyPaySecretFail" InTable:@"BPMultiLanguage"],[dic objectForKey:@"msg"]];
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPModifyPaySecretFail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        }
    }
}
@end
