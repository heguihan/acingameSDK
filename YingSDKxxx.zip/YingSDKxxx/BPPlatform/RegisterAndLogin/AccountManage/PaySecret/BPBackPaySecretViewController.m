//
//  BPBackPaySecretViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-27.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPBackPaySecretViewController.h"
#import "BPLoginPublic.h"
#import "BPRegisterAndLoginRequest.h"

@interface BPBackPaySecretViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *bpRequest;
@end

@implementation BPBackPaySecretViewController
@synthesize bpRequest;

-(void) dealloc
{
    [bpRequest release];        bpRequest = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
//    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
    UIImageView * back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
    back.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
    back.userInteractionEnabled = YES;
    [self.view addSubview:back];
    [back release];
    
//    [super viewDidLoad];
	// Do any additional setup after loading the view.
//    self.title = [BPLanguage getStringForKey:@"BPBackSecret" InTable:@"BPMultiLanguage"];
    [BPUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPBackSecret" InTable:@"BPMultiLanguage"] ViewController:self];
    bpRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    
    //找回方式
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_inputButton_bg.png"] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_inputButton_bg.png"] forState:UIControlStateHighlighted];
    button.tag = 200;
    [button addTarget:self action:@selector(clickBackType) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
    typeLabel.text = [BPLanguage getStringForKey:@"BPForgetBackType" InTable:@"BPMultiLanguage"];
    [self setLabelProperty:typeLabel];
    [button addSubview:typeLabel];
    [typeLabel release];
    
    UILabel *typeLabel2 = [[UILabel alloc] init];
    typeLabel2.text = [BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"];
    typeLabel2.textAlignment = NSTextAlignmentRight;
    typeLabel2.font = [UIFont systemFontOfSize:14];
    typeLabel2.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    typeLabel2.backgroundColor = [UIColor clearColor];
    typeLabel2.tag  = 201;
    [button addSubview:typeLabel2];
    [typeLabel2 release];
    
    UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_icon_list.png"]];
    [button addSubview:imgView];
    [imgView release];
    
    //手机／邮箱
    BPCustomTextField *phoneField = [[BPCustomTextField alloc] init];
//    phoneField.placeholder = [BPLanguage getStringForKey:@"BPForgetEnter" InTable:@"BPMultiLanguage"];
    [BPLoginPublic setTextFieldProperty:phoneField withDelegate:self];
//    phoneField.PlaceholderOffset_x = 245;
//    phoneField.TextOffset_x = 15;
    phoneField.textAlignment = NSTextAlignmentRight;
    phoneField.returnKeyType = UIReturnKeyNext;
    phoneField.tag = 300;
    phoneField.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:phoneField];
    [phoneField release];
    
    UILabel *phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
    phoneLabel.text = [BPLanguage getStringForKey:@"BPForgetPhone" InTable:@"BPMultiLanguage"];
    [self setLabelProperty:phoneLabel];
    phoneLabel.tag = 301;
    [phoneField addSubview:phoneLabel];
    [phoneLabel release];
    
    
    
    if(SCREEN_IS_LANDSCAPE)
    {
        button.frame = CGRectMake((SCREEN_WIDTH-300)/2, 25, 300, 40);
        typeLabel2.frame = CGRectMake(button.frame.size.width - 100, 0, 70, 40);
        imgView.frame = CGRectMake(button.frame.size.width - 20, 14, 6, 12);
        phoneField.frame = CGRectMake((SCREEN_WIDTH-300)/2, 80, 300, 40);
    }
    else
    {
        button.frame = CGRectMake((SCREEN_WIDTH-290)/2, 25, 290, 40);
        typeLabel2.frame = CGRectMake(button.frame.size.width - 100, 0, 70, 40);
        imgView.frame = CGRectMake(button.frame.size.width - 20, 14, 6, 12);
        phoneField.frame = CGRectMake((SCREEN_WIDTH-290)/2, 80, 290, 40);
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//完成
- (void)rightButtonItemAction
{
    [self hideAllKeyBoard];

    BPCustomTextField *phoneText = (BPCustomTextField *)[self.view viewWithTag:300];
    
    if(backType == 0)
    {
        if([BPUtility isMobileNumber:phoneText.text])
        {
            [self.bpRequest BackPaySecretWithNum:phoneText.text Type:1];
            [BPQLoadingView showDefaultLoadingViewWithView:self.view];
            return;
        }
        ////手机号无效
        [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPInvalidPhonePrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
    }
    else if(backType == 1)
    {
        if([BPUtility isValidateEmail:phoneText.text])
        {
            [self.bpRequest BackPaySecretWithNum:phoneText.text Type:2];
            [BPQLoadingView showDefaultLoadingViewWithView:self.view];
            return;
        }
        //邮箱无效
        [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPInvalidEmailPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
    }
}

-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=========%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"backPaySecret"])
    {
        NSString *descode = [BPUtility decodeBase64:[request responseString]];
        NSDictionary *dic = [descode JSONValue];
        if([[dic objectForKey:@"msg"] isEqualToString:@"done"])
        {
            if([[userInfo objectForKey:@"type"] intValue]==1)
            {
                [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPaySecrectPhoneBackSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            }
            else
            {
                [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPaySecrectEmailBackSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            }
        }
        else
        {
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPasswordBackFail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        }
    }
}
@end
