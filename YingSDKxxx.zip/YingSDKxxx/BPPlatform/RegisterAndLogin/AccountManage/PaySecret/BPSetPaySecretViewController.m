//
//  BPSetPaySecretViewController.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-26.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import "BPSetPaySecretViewController.h"
#import "BPLoginPublic.h"
#import "BPRegisterAndLoginRequest.h"

@interface BPSetPaySecretViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *paySecretRequest;
@end

@implementation BPSetPaySecretViewController
@synthesize paySecretRequest;

-(void) dealloc
{
    [paySecretRequest release];     paySecretRequest = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPPaySecret" InTable:@"BPMultiLanguage"];;
        [BPUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPPaySecret" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BPSDKResource.bundle/BP_login_background.png"]];
        
        paySecretRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        
        [BPUtility customNavigationButton:self isleftButton:YES NormalImage:@"BPSDKResource.bundle/BP_nav_back.png" HighLightedImage:@"BPSDKResource.bundle/BP_nav_back_sel.png"];
        [BPUtility customNavigationButton:self isleftButton:NO NormalImage:@"BPSDKResource.bundle/BP_finish.png" HighLightedImage:@"BPSDKResource.bundle/BP_finish_sel.png"];
    }
    return self;
}

-(void) rightButtonItemAction
{
    [self hideAllKeyBoard];
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11001];
    if([BPLoginPublic checkTwoPasswordValid:passwordField.text ConfirmPassword:verifypassword.text])
    {
        [paySecretRequest setPaySecret:passwordField.text];
        [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    }
}

-(void) cancelRequest
{
    [paySecretRequest cancelAllRequest];
}
//返回
-(void) leftButtonItemAction
{
    [self.navigationController popViewControllerAnimated:YES];
    [self cancelRequest];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self showThings];
}

-(void) showThings
{
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
    passwordField.placeholder = [BPLanguage getStringForKey:@"BPInputPaySecret" InTable:@"BPMultiLanguage"];
    [BPLoginPublic setTextFieldProperty:passwordField withDelegate:self];
    [self.view addSubview:passwordField];
    passwordField.returnKeyType = UIReturnKeyNext;
    passwordField.secureTextEntry= YES;
    passwordField.tag = 11000;
    [passwordField release];
    
    UILabel *passwordPrompt = [[UILabel alloc] init];
    passwordPrompt.text = [BPLanguage getStringForKey:@"BPRegistPasswordLabel" InTable:@"BPMultiLanguage"];
    passwordPrompt.textAlignment = NSTextAlignmentLeft;
    passwordPrompt.font = [UIFont systemFontOfSize:10];
    passwordPrompt.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    passwordPrompt.backgroundColor = [UIColor clearColor];
    [self.view addSubview:passwordPrompt];
    [passwordPrompt release];
    
    
    BPCustomTextField *conPasswordField = [[BPCustomTextField alloc] init];
    conPasswordField.placeholder = [BPLanguage getStringForKey:@"BPConfirmPaySecret" InTable:@"BPMultiLanguage"];
    [BPLoginPublic setTextFieldProperty:conPasswordField withDelegate:self];
    [self.view addSubview:conPasswordField];
    conPasswordField.returnKeyType = UIReturnKeyNext;
    conPasswordField.secureTextEntry= YES;
    conPasswordField.tag = 11001;
    [conPasswordField release];
    if(SCREEN_IS_LANDSCAPE)
    {
        passwordField.frame = CGRectMake((SCREEN_WIDTH - 300)/2, 20, 300, 40);
        conPasswordField.frame = CGRectMake((SCREEN_WIDTH - 300)/2, 90, 300, 40);
        passwordPrompt.frame = CGRectMake((SCREEN_WIDTH - 300)/2 + 10, 70, 270, 10);
    }
    else
    {
        passwordField.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 20, 290, 40);
        conPasswordField.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 90, 290, 40);
        passwordPrompt.frame = CGRectMake((SCREEN_WIDTH - 290)/2 + 10, 70, 260, 10);
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
#pragma mark -------keyboard event-------
-(void) hideAllKeyBoard
{
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11001];
    [passwordField resignFirstResponder];
    [verifypassword resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (textField.text.length >= 18&&![string isEqualToString:@""])
        return NO; // return NO to not change text
    return YES;
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11001];
    
    if(textField == passwordField)
    {
        [passwordField resignFirstResponder];
        [verifypassword becomeFirstResponder];
    }
    else if(textField == verifypassword)
    {
        [self hideAllKeyBoard];
        [self rightButtonItemAction];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [BPUtility ViewScrollUp:textField WillScrollView:self.view];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [BPUtility ViewScrollDown: self.view];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}

#pragma mark -------request delegate-----
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=========%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPSetPaySecret"])
    {
        NSString *descode = [BPUtility decodeBase64:[request responseString]];
        NSDictionary *dic = [descode JSONValue];
        if([[dic objectForKey:@"info"] isEqualToString:@"done"])
        {
            [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPaySerectSetSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            [self leftButtonItemAction];
        }
        else
        {
           [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPaySerectSetFail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2]; 
        }
    }
}
@end
