//
//  BPSetPaySecretViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-26.
//  Copyright (c) 2013年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"

@interface BPSetPaySecretViewController : BPBaseViewController

@end
