//
//  BPModifySecretViewController.m
//  BigPlayerSDK
//

#import "BPModifySecretViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "BPLoginPublic.h"
#import "BPCustomNoticeBox.h"

@interface BPModifySecretViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *ModifySecretRequest;
@end

@implementation BPModifySecretViewController
@synthesize ModifySecretRequest;


-(void) dealloc
{
    [ModifySecretRequest release];          ModifySecretRequest = nil;
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPModifySecret" InTable:@"BPMultiLanguage"];;
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPModifySecret" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
        
        ModifySecretRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_cancel.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_cancel_sel.png"];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:NO NormalImage:@"ShuZhiZhang.bundle/BP_finish.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_finish_sel.png"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self showThings];
}



-(void) showThings
{
    NSArray *array = [NSArray arrayWithObjects:@"BPNewPassword",@"BPConfirmNewPassword", nil];
    NSArray *arrayPrompt = [NSArray arrayWithObjects:@"BPNewPasswordPrompt",@"BPConfirmNewPasswordPrompt", nil];
    for (int i=0;i<2;i++)
    {
        //密码
        BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];
        NSString *str = [BPLanguage getStringForKey:[arrayPrompt objectAtIndex:i] InTable:@"BPMultiLanguage"];
        passwordField.placeholder = str;
        [BPLoginPublic setTextFieldProperty:passwordField withDelegate:self];
        passwordField.textAlignment = NSTextAlignmentRight;
        [self.view addSubview:passwordField];
        if(i == 2)
        {
            passwordField.returnKeyType = UIReturnKeyGo;
        }
        else
        {
            passwordField.returnKeyType = UIReturnKeyNext;
        }
        passwordField.secureTextEntry= YES;
        passwordField.tag = 11000+i;
        
        if(SCREEN_IS_LANDSCAPE)
        {
            passwordField.frame = CGRectMake((SCREEN_WIDTH - 360)/2, 20+55*i, 360, 40);
        }
        else
        {
            passwordField.frame = CGRectMake((SCREEN_WIDTH - 290)/2, 20+55*i, 290, 40);
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:14] forKey:NSFontAttributeName];
        CGSize size = [str sizeWithAttributes:dict];
        passwordField.PlaceholderOffset_x = passwordField.frame.size.width - size.width - 13;
        passwordField.TextOffset_x = 15;
        [passwordField release];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 80, 40)];
        titleLabel.font = [UIFont systemFontOfSize:14.0f];
        titleLabel.textColor=[UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.backgroundColor = [UIColor clearColor];
        [passwordField addSubview:titleLabel];
        titleLabel.text = [BPLanguage getStringForKey:[array objectAtIndex:i] InTable:@"BPMultiLanguage"];
        [titleLabel release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -----events------
-(void) cancelRequest
{
    [ModifySecretRequest cancelAllRequest];
}
//返回
-(void) leftButtonItemAction
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}

-(void) hideAllKeyBoard
{
    for(int i=0;i<2;i++)
    {
        UITextField * textField = (UITextField *)[self.view viewWithTag:11000+i];
        [textField resignFirstResponder];
    }
}

-(BOOL) checkAccountAndPassword
{
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11001];
    [self hideAllKeyBoard];

    if(![BPLoginPublic checkTwoPasswordValid:passwordField.text ConfirmPassword:verifypassword.text])
    {
        return NO;
    }
    return YES;
}

- (void)rightButtonItemAction
{
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    
    if([self checkAccountAndPassword])
    {
        [ModifySecretRequest requestModifySecret:nil NewSecret:[BPDESEncryption desEncodeWithText:passwordField.text]];
        [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    }
}
#pragma mark -------keyboard event-------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (textField.text.length >= 18&&![string isEqualToString:@""])
        return NO; // return NO to not change text
    return YES;
}

//点击return按钮
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * passwordField = (UITextField *)[self.view viewWithTag:11000];
    UITextField * verifypassword = (UITextField *)[self.view viewWithTag:11001];
    
    if(textField == passwordField)
    {
        [passwordField resignFirstResponder];
        [verifypassword becomeFirstResponder];
    }
    else if(textField == verifypassword)
    {
        [self hideAllKeyBoard];
        [self rightButtonItemAction];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollUp:textField WillScrollView:self.view];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [ShuZhiZhangUtility ViewScrollDown: self.view];
//    if(textField.tag == 11000)
//    {
//        ////////NSLog(@"%@",textField.text);
//    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}

#pragma mark -----request delegate-----
/*****************************
 1：修改密码成功；
 0：账号密码不正确；
 -1：修改密码失败；
 -10：username或者oldPassword或者newPassword不能为空；
 -20：检测数据失败；
 -30：账号不存在；
 -35：账号已冻结；
 *****************************/
-(void) showRegisterErrorTishi:(int) response
{

    if(response == -30)
    {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountNotExistPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        

        
    }
    else if(response == -35)
    {
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountFreezePrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        

    }
    else if(response == -12)
    {
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordNoChange" InTable:@"BPMultiLanguage"] duration:2.0];

    }
    else
    {
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPModitySecretError" InTable:@"BPMultiLanguage"] duration:2.0];
        

    }
}

-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    ////////NSLog(@"---%@=====密码修改动====%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPModifySecret"])
    {
        int response = [[request responseString] intValue];
        //密码修改成功
        if(response >0)
        {
            ////////NSLog(@"-=====密码修====%@",userInfo);
            //将新密码保存到数据库
            BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
           [userInfoTable UpdateDataToTable:[NSString stringWithFormat:@"update %@ set password = '%@' where uid = '%@'",BPUserInfoTableName,[userInfo objectForKey:@"password"],[ShuZhiZhangUserPreferences CurrentUserID]]];
           [userInfoTable release];
            
            [ShuZhiZhangUtility saveAccountAndPasswordToKeyChain:nil AndPassword:[userInfo objectForKey:@"password"]];
            
            [[NSUserDefaults standardUserDefaults ] setObject:[userInfo objectForKey:@"password"] forKey:@"BPUserPasswor_now"];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPSecretModifySuccess" InTable:@"BPMultiLanguage"] duration:2.0];

           [self leftButtonItemAction];
        }
        else
        {
            [self showRegisterErrorTishi:response];
        }
    }
}
@end
