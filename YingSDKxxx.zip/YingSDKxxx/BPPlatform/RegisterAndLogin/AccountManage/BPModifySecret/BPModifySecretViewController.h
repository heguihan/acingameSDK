//
//  BPModifySecretViewController.h
//  BigPlayerSDK
//
//
#import "BPBaseViewController.h"

@interface BPModifySecretViewController : BPBaseViewController <UITextFieldDelegate>

@end
