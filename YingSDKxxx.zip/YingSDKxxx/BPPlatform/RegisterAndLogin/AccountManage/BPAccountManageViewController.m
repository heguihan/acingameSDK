//
//  AccountManageViewController.m
//  BigPlayerSDK
//
//

#import "BPAccountManageViewController.h"
//#import "BPSecretSecurityViewController.h"
//#import "BPAccountBindViewController.h"
#import "BPModifySecretViewController.h"
#import "BPModifyAccountViewController.h"
#import "BPBindPhoneViewController.h"
#import "BPBindEmailViewController.h"
#import "BPPersonalInfoViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "ShuEnter.h"
#import "BPWebViewBaseViewController.h"


@interface BPAccountManageViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *bpRequest;
@property (nonatomic,retain) UIScrollView *infoScroller;
@end


@implementation BPAccountManageViewController
@synthesize bpRequest;
@synthesize userInfoDic;
@synthesize infoScroller;

-(void) dealloc
{
    [self cancelRequest];
    [bpRequest release];            bpRequest = nil;
    [userInfoDic release];          userInfoDic = nil;
    [infoScroller release];                 infoScroller = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPAccountManage" InTable:@"BPMultiLanguage"] ViewController:self];
        [ShuZhiZhangUtility customNavigationButtonWithTitle:self isleftButton:YES Title:[BPLanguage getStringForKey:@"BPBackToGame" InTable:@"BPMultiLanguage"]];
    }
    return self;
}

-(void) cancelRequest
{
    [bpRequest cancelAllRequest];
}
- (BOOL)prefersStatusBarHidden
{
    return YES;//隐藏为YES，显示为NO
}
-(void) leftButtonItemAction
{
//    [self.navigationController popViewControllerAnimated:YES];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];

    [self cancelRequest];
    [self dismissModalViewControllerAnimated:YES];
    [ShuZhiZhangUtility postPlatformExitNotification];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    if(SCREEN_IS_LANDSCAPE)
    {
        [self showTableViewWithFrame:CGRectMake((SCREEN_WIDTH-380)/2, 10, 380, 330)];
    }
    else
    {
        [self showTableViewWithFrame:CGRectMake((SCREEN_WIDTH-310)/2-4, 10, 310+8, SCREEN_HEIGHT_NAV)];
    }
    
    infoScroller = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT_NAV)];
    infoScroller.contentSize = CGSizeMake(0, 370);
    [self.view addSubview:infoScroller];
    bpRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    [bpRequest requestUserInfomation];
    
    self.bpTableView.showsVerticalScrollIndicator = NO;
    [self.bpTableView removeFromSuperview];
    infoScroller.bounces = YES;
    [infoScroller addSubview:self.bpTableView];
    
    UIButton *logoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_BP_btn_logout.png"] forState:UIControlStateNormal];
    [logoutButton setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/logoutbtn.png"] forState:UIControlStateHighlighted];
    [logoutButton setTitle:[BPLanguage getStringForKey:@"BPLogout" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    logoutButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [logoutButton addTarget:self action:@selector(clickLogoutButton) forControlEvents:UIControlEventTouchUpInside];
    logoutButton.frame = CGRectMake((SCREEN_WIDTH-290)/2, 310, 290, 40);
    if(SCREEN_IS_LANDSCAPE)
    {
        logoutButton.frame = CGRectMake((SCREEN_WIDTH-360)/2, 310, 360, 40);
    }
    [infoScroller addSubview:logoutButton];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -----logout----注销----
-(void) clickLogoutButton
{
    [self addChoieView];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        [self cancelRequest];
        [ShuEnter BPLogout];
        [self dismissModalViewControllerAnimated:YES];
        
    }
}


- (void)addChoieView{
    
    UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH, SCREEN_HEIGHT)];
    [bg setBackgroundColor:[UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:0.5]];
    [self.navigationController.view addSubview:bg];
    bg.tag = 20000;
    [bg release];
    
    UIImageView *imageBg = [[UIImageView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH-300.0)/2.0,(SCREEN_HEIGHT-250.0)/2.0, 300.0, 250.0)];
    [imageBg setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_logout_alert.png"]];
    //[imageBg setBackgroundColor:[UIColor whiteColor]];
    [imageBg setUserInteractionEnabled:YES];
    [bg addSubview:imageBg];
    [imageBg release];
    
    UILabel *title_lab = [[UILabel alloc] initWithFrame:CGRectMake(0.0,15.0,300.0,17.0)];
    [title_lab setBackgroundColor:[UIColor clearColor]];
    [title_lab setTextAlignment:NSTextAlignmentCenter];
    [title_lab setText:@"提示"];
    [title_lab setTextColor:[UIColor blackColor]];
    [title_lab setFont:[UIFont systemFontOfSize:16.0f]];
    [imageBg addSubview:title_lab];
    [title_lab release];
    
    UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(0.0,32.0,300.0,77.0)];
    [content setBackgroundColor:[UIColor clearColor]];
    [content setText:@"主银，去看看人家的活动再走嘛"];
    [content setFont:[UIFont systemFontOfSize:14.0f]];
    [content setTextAlignment:NSTextAlignmentCenter];
    [imageBg addSubview:content];
    [content release];
    
    
    NSArray *title = @[@"查看",@"注销",@"关闭"];
    
    for (int i = 0; i<3; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_logout_alertbtn.png"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_logout_alertbtn_sel.png"] forState:UIControlStateHighlighted];
        [btn setTitle:[title objectAtIndex:i]  forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithRed:13/255.0 green:98/255.0 blue:254/255.0 alpha:1] forState:UIControlStateNormal];
        [btn setFrame:CGRectMake(0.0,114.0+45*i,300.0,45.0)];
        btn.tag = 2015+i;
        [btn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [imageBg addSubview:btn];
        
    }
    
    
}

// 注消按钮
- (void)BtnAction:(id)sender
{
    UIView *view = [self.navigationController.view viewWithTag:20000];
    UIButton *btn = (UIButton *)sender;

    switch (btn.tag-2015) {
        case 0:{
            //查看
            [view removeFromSuperview];
            NSString *str = [NSString stringWithFormat:@"%@?game_id=%@&channel_id=%@&action=system&operation=sdkActivity&uid=%@&token=%@&macAddress=%@&version=%@&deviceType=%d&idfa=%@",GLOBAL_BASE_API_URL,[ShuZhiZhangUserPreferences CurrentGameId],[ShuZhiZhangUserPreferences CurrentChannelId],[ShuZhiZhangUserPreferences CurrentUserID],[ShuZhiZhangUserPreferences getCurrentToken],[ShuZhiZhangUtility macaddress],[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"],1,[ShuZhiZhangUtility getIDFA]];
            
            BPWebViewBaseViewController *viewController = [[BPWebViewBaseViewController alloc] initWithUrl:str AndTitle:[BPLanguage getStringForKey:@"BPForum" InTable:@"BPMultiLanguage"]];
            [viewController showWebViewActionButtons];
            [self.navigationController pushViewController:viewController animated:YES];
            [viewController release];

        }
            break;
        case 1:{
            //注销
            [self cancelRequest];
            [ShuEnter BPLogout];
            [view removeFromSuperview];
            [self dismissModalViewControllerAnimated:YES];
        }
            break;
        case 2:{
            //关闭
            [view removeFromSuperview];
        }
            break;
        default:
            break;
    }
}


#pragma mark -------UITableView delegate-----

-(void) addViewToTableViewCell:(NSIndexPath *)indexPath AndCell:(UITableViewCell *)cell
{
    for(UIView *view in cell.contentView.subviews)
    {
        [view removeFromSuperview];
    }
    int w = 290;
    int offset_x = 0;
    if(SCREEN_IS_LANDSCAPE)
    {
        w=360;
    }
    else if(BP_Show_IOS7)
    {
        w = 310;
        offset_x = 10;
    }
    int index = indexPath.section+indexPath.row;
    if(indexPath.section>0)
    {
        index ++;
    }
    NSMutableArray *userInfoTitle = [NSMutableArray arrayWithObjects:@"BPAccount_2",@"BPModifySecret",@"BPMyInfo",@"BPBindPhone",@"BPBindEmail", nil];
    
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(47+offset_x, 10, 90, 20)];
    typeLabel.tag = 21000;
    typeLabel.textAlignment = NSTextAlignmentLeft;
    typeLabel.backgroundColor = [UIColor clearColor];
    typeLabel.text = [BPLanguage getStringForKey:[userInfoTitle objectAtIndex:index] InTable:@"BPMultiLanguage"];
    typeLabel.font = [UIFont boldSystemFontOfSize:16];
    typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [cell.contentView addSubview:typeLabel];
    if(indexPath.section == 1 &&indexPath.row==1 && [[ShuZhiZhangUserPreferences CurrentAccountType] intValue] > 0)
    {
        typeLabel.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    }
    [typeLabel release];
    
    if(indexPath.section == 1)
    {
        //头像
        UIImageView *HeadImageView = [[UIImageView alloc] init];
        HeadImageView.contentMode = UIViewContentModeScaleToFill;
        // 圆角
        HeadImageView.layer.masksToBounds = YES;
        HeadImageView.layer.cornerRadius = 6.0;
        HeadImageView.layer.borderWidth = 1.0;
        HeadImageView.layer.borderColor = [[UIColor grayColor] CGColor];
        HeadImageView.tag = 19000;
        [cell.contentView addSubview:HeadImageView];

        NSString * headPath = [BPFilePathManager getCachePathWithFileName:@"UserHead" AndURLStr:[userInfoDic objectForKey:@"image"]];
        if(![[NSFileManager defaultManager] fileExistsAtPath:headPath])
        {
            NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"downloadHead",@"RequestTag",headPath,@"savePath", nil];
            [bpRequest downloadFileWithUrl:[userInfoDic objectForKey:@"image"] UserInfo:userInfo ProgressView:nil];
            HeadImageView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_user_default_icon.png"];
        }
        else
        {
            HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
        }
        HeadImageView.frame = CGRectMake(5+offset_x, 4, 32, 32);
        [HeadImageView release];
    }
    else
    {
        NSArray *imageArray = [NSArray arrayWithObjects:@"ShuZhiZhang.bundle/BP_icon_user.png",@"ShuZhiZhang.bundle/BP_icon_password.png",@"ShuZhiZhang.bundle/BP_icon_user.png",@"ShuZhiZhang.bundle/AccountPhone.png",@"ShuZhiZhang.bundle/BP_email.png", nil];
        UIImageView *passwordImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[imageArray objectAtIndex:index]]];
        [cell.contentView addSubview:passwordImage];
        passwordImage.frame = CGRectMake(0+offset_x, 0, 40, 40);
        [passwordImage release];
    }
    
    UILabel *resultLabel = [[UILabel alloc] initWithFrame:CGRectMake(w-225, 10, 200, 20)];
    resultLabel.tag = 21007;
    resultLabel.textAlignment = NSTextAlignmentRight;
    resultLabel.backgroundColor = [UIColor clearColor];
    resultLabel.font = [UIFont systemFontOfSize:14];
    resultLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [cell.contentView addSubview:resultLabel];
    if(index == 0)
    {
        resultLabel.text = [BPDESEncryption desDecodeWithText:[ShuZhiZhangUserPreferences CurrentAccount]];
    }
    if(index == 2)
    {
        resultLabel.text = [ShuZhiZhangUserPreferences CurrentNickname];
    }
    else if(index == 3)
    {
        NSString *str = [userInfoDic objectForKey:@"phone"];
        if([userInfoDic objectForKey:@"phone"] != [NSNull null] && str.length>0)
        {
            str = [str stringByReplacingCharactersInRange:NSMakeRange(3, 4) withString:@"****"];
            resultLabel.text = str;
            resultLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        }
        else
        {
            resultLabel.text = @"立即绑定";
            resultLabel.textColor = [UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1];
        }
    }
    else if(index == 4)
    {
         NSString *str = [userInfoDic objectForKey:@"email"];
        if([userInfoDic objectForKey:@"email"] != [NSNull null] && str.length>0)
        {
            str = [NSString stringWithFormat:@"%@****%@",[str substringWithRange:NSMakeRange(0, 3)],[str substringWithRange:NSMakeRange(str.length-4, 4)]];
            resultLabel.text = str;
            resultLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        }
        else
        {
            NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"bindEmail_%@",[ShuZhiZhangUserPreferences CurrentUserID]]];
            if(str && str.length>0)
            {
                resultLabel.text = @"等待验证";
                resultLabel.textColor = [UIColor colorWithRed:230/255.0f green:169/255.0f blue:23/255.0f alpha:1];
            }
            else
            {
                resultLabel.text = @"立即绑定";
                resultLabel.textColor = [UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1];
            }
        }
    }
    [resultLabel release];
    
    UIImageView *moreView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_more.png"]];
    moreView.frame = CGRectMake(w- 10-8, 14, 8, 13);
    [cell.contentView addSubview:moreView];
    [moreView release];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==0)
        return 2;
    if(section==2)
        return 2;
    return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    [self addViewToTableViewCell:indexPath AndCell:cell];
    
    cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
    cell.selectedBackgroundView.backgroundColor = BPUITableViewCellSelectedColor;
    if(!BP_Show_IOS7)
    {
        cell.selectedBackgroundView.layer.masksToBounds = YES;
        cell.selectedBackgroundView.layer.cornerRadius = 8;
        cell.selectedBackgroundView.layer.borderWidth = 1;
        cell.selectedBackgroundView.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
    }

    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == 2 || section ==4)
    {
        return 25;
    }
    else
    {
        return 5;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //通行证
    if(indexPath.section == 0 && indexPath.row == 0)
    {
        BPModifyAccountViewController *viewControl = [[BPModifyAccountViewController alloc] init];
        viewControl.accountManager = self;
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewControl];
        UIImage *image2 = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_nav_head.png"];
        image2 = [image2 resizableImageWithCapInsets:UIEdgeInsetsMake(25,10,10,10)];
        [navController.navigationBar setBackgroundImage:image2 forBarMetrics:UIBarMetricsDefault];
        [navController.navigationBar customNavigationBar];
        if(BPDevice_is_ipad)
        {
            navController.modalPresentationStyle = UIModalPresentationFormSheet;
        }
        [self presentViewController:navController animated:YES completion:^{
            
        }];
        [navController release];
        [viewControl release];
    }
    //修改密码
    else if(indexPath.section == 0 && indexPath.row == 1)
    {
        
        BPModifySecretViewController *viewControl = [[BPModifySecretViewController alloc] init];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewControl];
        UIImage *image2 = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_nav_head.png"];
        image2 = [image2 resizableImageWithCapInsets:UIEdgeInsetsMake(25,10,10,10)];
        [navController.navigationBar setBackgroundImage:image2 forBarMetrics:UIBarMetricsDefault];
        [navController.navigationBar customNavigationBar];
        if(BPDevice_is_ipad)
        {
            navController.modalPresentationStyle = UIModalPresentationFormSheet;
        }
        [self presentViewController:navController animated:YES completion:^{
            
        }];
        [navController release];
        [viewControl release];
    }
    //我的资料
    if(indexPath.section == 1)
    {
        BPPersonalInfoViewController *viewControl = [[BPPersonalInfoViewController alloc] init];
        viewControl.accountManager = self;
        [self.navigationController pushViewController:viewControl animated:YES];
        [viewControl release];
    }
    //手机绑定
    else if(indexPath.section == 2 && indexPath.row == 0)
    {
        BPBindPhoneViewController *viewControl = [[BPBindPhoneViewController alloc] init];
        viewControl.accountManager = self;
//        [self.navigationController pushViewController:viewControl animated:YES];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewControl];
        UIImage *image2 = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_nav_head.png"];
        image2 = [image2 resizableImageWithCapInsets:UIEdgeInsetsMake(25,10,10,10)];
        [navController.navigationBar setBackgroundImage:image2 forBarMetrics:UIBarMetricsDefault];
        [navController.navigationBar customNavigationBar];
        if(BPDevice_is_ipad)
        {
            navController.modalPresentationStyle = UIModalPresentationFormSheet;
        }
        [self presentViewController:navController animated:YES completion:^{
            
        }];
        [navController release];
        [viewControl release];
    }
    //邮箱绑定
    else if(indexPath.section == 2 && indexPath.row == 1 )
    {
        BPBindEmailViewController *viewControl = [[BPBindEmailViewController alloc] init];
        viewControl.accountManager = self;
        viewControl.bindMail = [userInfoDic objectForKey:@"email"];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewControl];
        UIImage *image2 = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_nav_head.png"];
        image2 = [image2 resizableImageWithCapInsets:UIEdgeInsetsMake(25,10,10,10)];
        [navController.navigationBar setBackgroundImage:image2 forBarMetrics:UIBarMetricsDefault];
        [navController.navigationBar customNavigationBar];
        if(BPDevice_is_ipad)
        {
            navController.modalPresentationStyle = UIModalPresentationFormSheet;
        }
        
        [self presentViewController:navController animated:YES completion:^{
            
        }];
         
        [navController release];
        [viewControl release];
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}



- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(section == 2)
    {
        UIView* myView = [[[UIImageView alloc] init] autorelease];
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 80, 20)];
        titleLabel.font = [UIFont systemFontOfSize:12.0f];
        titleLabel.textColor=[UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.backgroundColor = [UIColor clearColor];
        [myView addSubview:titleLabel];
        titleLabel.text = @"帐户安全级别:";
        [titleLabel release];
        
        UILabel *titleLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(105, 0, 80, 20)];
        titleLabel2.font = [UIFont systemFontOfSize:12.0f];
        titleLabel2.textAlignment = NSTextAlignmentLeft;
        titleLabel2.backgroundColor = [UIColor clearColor];
        [myView addSubview:titleLabel2];
        [titleLabel2 release];
        
        UIImageView *securityImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_AccountMan_security_bg.png"]];
        securityImage.frame = CGRectMake(290-112, 5, 122, 12);
        if(SCREEN_IS_LANDSCAPE)
        {
            securityImage.frame = CGRectMake(360-112, 5, 122, 12);
        }
        [myView addSubview:securityImage];
        [securityImage release];
        NSString *phone = [userInfoDic objectForKey:@"phone"];
        //已设置过密码
        if(phone && (NSNull *)phone != [NSNull null] && phone.length>1)
        {
            hasAlreadyBindPhone = YES;
        }
        NSString *email = [userInfoDic objectForKey:@"email"];
        if(email && (NSNull *)email != [NSNull null] && email.length>1)
        {
            hasAlreadyBindEmail = YES;
        }
        if(hasAlreadyBindEmail && hasAlreadyBindPhone)
        {
            for(int i=0;i<3;i++)
            {
                UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(i*41, 0, 40, 12)];
                colorView.backgroundColor = [UIColor colorWithRed:23/255.0f green:230/255.0f blue:23/255.0f alpha:1];
                [securityImage addSubview: colorView];
                [colorView release];
            }
            titleLabel2.textColor=[UIColor colorWithRed:23/255.0f green:230/255.0f blue:23/255.0f alpha:1];
            titleLabel2.text = @"很强";
        }
        else if(!hasAlreadyBindEmail && !hasAlreadyBindPhone)
        {
            UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(0,0, 40, 12)];
            colorView.backgroundColor = [UIColor colorWithRed:230/255.0f green:23/255.0f blue:23/255.0f alpha:1];
            [securityImage addSubview: colorView];
            [colorView release];
            titleLabel2.textColor=[UIColor colorWithRed:230/255.0f green:23/255.0f blue:23/255.0f alpha:1];
            titleLabel2.text = @"非常低";
        }
        else
        {
            for(int i=0;i<2;i++)
            {
                UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(i*41, 0, 40, 12)];
                colorView.backgroundColor = [UIColor colorWithRed:230/255.0f green:169/255.0f blue:23/255.0f alpha:1];
                [securityImage addSubview: colorView];
                [colorView release];
            }
            titleLabel2.textColor=[UIColor colorWithRed:230/255.0f green:169/255.0f blue:23/255.0f alpha:1];
            titleLabel2.text = @"一般";
        }
        
        return myView;

    }
    return nil;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section;
{
    if(section == 2)
    {
        UIView* myView = [[[UIImageView alloc] init] autorelease];
        int w = 290;
        if(SCREEN_IS_LANDSCAPE)
        {
            w=360;
        }
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, w, 24)];
        titleLabel.font = [UIFont systemFontOfSize:12.0f];
        titleLabel.textColor=[UIColor colorWithRed:100/255.0f green:100/255.0f blue:100/255.0f alpha:1];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.backgroundColor = [UIColor clearColor];
        [myView addSubview:titleLabel];
        titleLabel.text = @"绑定手机或邮箱可以降低您帐号被盗的风险";
        [titleLabel release];
        return myView;
        
    }
    return nil;
}


-(void) downloadImageSuccessWithRequest:(ASIHTTPRequest *)request
{
    UITableViewCell *cell = [self.bpTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
    UIImageView *HeadImageView = (UIImageView *)[cell.contentView viewWithTag:19000];
    NSString * headPath = [BPFilePathManager getCachePathWithFileName:@"UserHead" AndURLStr:[userInfoDic objectForKey:@"image"]];
    HeadImageView.image = [UIImage imageWithContentsOfFile:headPath];
}
@end
