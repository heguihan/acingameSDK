//
//  BPSecretSecurityViewController.h
//  BigPlayerSDK
//
//

#import "BPBaseViewController.h"

@interface BPSecretSecurityViewController : BPBaseViewController

@end
