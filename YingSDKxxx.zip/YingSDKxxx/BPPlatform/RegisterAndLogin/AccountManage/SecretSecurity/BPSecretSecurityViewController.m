//
//  BPSecretSecurityViewController.m
//  BigPlayerSDK
//

//

#import "BPSecretSecurityViewController.h"
#import "BPBindEmailViewController.h"
#import "BPBindPhoneViewController.h"
#import "BPRegisterAndLoginRequest.h"

@interface BPSecretSecurityViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *secretSecurityRequest;
@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@end

@implementation BPSecretSecurityViewController
@synthesize secretSecurityRequest;
@synthesize userInfoDic;

-(void) dealloc
{
    [secretSecurityRequest release];    secretSecurityRequest = nil;
    [userInfoDic release];    userInfoDic = nil;
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPSecretSecurity" InTable:@"BPMultiLanguage"];
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPSecretSecurity" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_nav_back.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_nav_back_sel.png"];
        
        secretSecurityRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        
    }
    return self;
}

-(void) cancelRequest
{
    [secretSecurityRequest cancelAllRequest];
}
-(void) leftButtonItemAction
{
    [self.navigationController popViewControllerAnimated:YES];
    [self cancelRequest];
}

-(void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [secretSecurityRequest requestUserInfomation];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    UILabel *promptLabel = [[UILabel alloc] init];
    promptLabel.text = [BPLanguage getStringForKey:@"BPSecretSecurityPrompt" InTable:@"BPMultiLanguage"];
    promptLabel.font = [UIFont systemFontOfSize:12];
    promptLabel.backgroundColor = [UIColor clearColor];
    promptLabel.textAlignment = NSTextAlignmentLeft;
    promptLabel.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    [self.view addSubview:promptLabel];
    [promptLabel release];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        [self showTableViewWithFrame:CGRectMake((SCREEN_WIDTH - 320)/2, 10, 320, SCREEN_HEIGHT_NAV)];
        promptLabel.frame = CGRectMake((SCREEN_WIDTH - 280)/2, 110, 280, 12);
    }
    else
    {
        [self showTableViewWithFrame:CGRectMake((SCREEN_WIDTH - 300)/2, 10, 300, SCREEN_HEIGHT_NAV)];
        promptLabel.frame = CGRectMake((SCREEN_WIDTH - 240)/2, 110, 240, 12);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark ---UITableView delegate-----
-(void) addViewToTableViewCell:(NSIndexPath *)indexPath AndCell:(UITableViewCell *)cell
{
    for(UIView *view in cell.contentView.subviews)
    {
        [view removeFromSuperview];
    }

    NSMutableArray *userInfoTitle = [NSMutableArray arrayWithObjects:@"BPBindPhone",@"BPBindEmail", nil];
    
    UILabel *typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 90, 20)];
    typeLabel.tag = 21000;
    typeLabel.textAlignment = NSTextAlignmentLeft;
    typeLabel.backgroundColor = [UIColor clearColor];
    typeLabel.textColor = [UIColor blackColor];
    typeLabel.text = [BPLanguage getStringForKey:[userInfoTitle objectAtIndex:indexPath.row] InTable:@"BPMultiLanguage"];
    typeLabel.font = [UIFont systemFontOfSize:14];
    typeLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    [cell.contentView addSubview:typeLabel];
    [typeLabel release];
    
    if(userInfoDic)
    {
        NSString *str;
        if(indexPath.row == 0)
        {
            str = [userInfoDic objectForKey:@"phone"];
        }
        else
        {
            str = [userInfoDic objectForKey:@"email"];
        }
        if(str && (NSNull *)str != [NSNull null] && str.length >1)
        {
            UILabel *phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(130, 10, 160, 20)];
            phoneLabel.tag = 22000;
            phoneLabel.textAlignment = NSTextAlignmentRight;
            phoneLabel.backgroundColor = [UIColor clearColor];
            phoneLabel.textColor = [UIColor blackColor];
            phoneLabel.text = str;
            phoneLabel.font = [UIFont systemFontOfSize:14];
            phoneLabel.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
            [cell.contentView addSubview:phoneLabel];
            [phoneLabel release];
            if(!SCREEN_IS_LANDSCAPE)
            {
                phoneLabel.frame = CGRectMake(110, 10, 160, 20);
            }
        }
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    [self addViewToTableViewCell:indexPath AndCell:cell];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
        {
            BPBindPhoneViewController *viewControl = [[BPBindPhoneViewController alloc] init];
            [self.navigationController pushViewController:viewControl animated:YES];
            [viewControl release];
        }
            break;
        case 1:
        {
            BPBindEmailViewController *viewControl = [[BPBindEmailViewController alloc] init];
            [self.navigationController pushViewController:viewControl animated:YES];
            [viewControl release];
        }
            break;
        default:
            break;
    }
}

@end
