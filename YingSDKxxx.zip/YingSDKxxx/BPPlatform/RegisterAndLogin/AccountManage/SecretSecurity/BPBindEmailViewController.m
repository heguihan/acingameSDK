//
//  BindEmailViewController.m
//  BigPlayers
//
//  Created by John Cheng on 13-6-3.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPBindEmailViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "BPCustomPromptBox.h"
#import "BPLoginPublic.h"

@interface BPBindEmailViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *emailRequest;
@end

@implementation BPBindEmailViewController
@synthesize emailRequest;
@synthesize bindMail;
@synthesize accountManager;

-(void) dealloc
{
    [emailRequest release];         emailRequest = nil;
    [bindMail release];         bindMail = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = [BPLanguage getStringForKey:@"BPBindEmail" InTable:@"BPMultiLanguage"];;
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPBindEmail" InTable:@"BPMultiLanguage"] ViewController:self];
//        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
        
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_cancel.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_cancel_sel.png"];
//        [ShuZhiZhangUtility customNavigationButton:self isleftButton:NO NormalImage:@"ShuZhiZhang.bundle/BP_finish.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_finish_sel.png"];
    }
    return self;
}

-(void) cancelRequest
{
    [emailRequest cancelAllRequest];
}
-(void) leftButtonItemAction
{
//    [self.navigationController popViewControllerAnimated:YES];
    [self dismissModalViewControllerAnimated:YES];
    [self cancelRequest];
    [accountManager.bpTableView reloadData];
}

-(void) rightButtonItemAction
{
    [self hideAllKeyBoard];
    UITextField *emailText = (UITextField *)[self.view viewWithTag:1000];
    if(emailText.text.length<1)
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEnterEmail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPEnterEmail" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    else if(![self isValidateEmail:emailText.text])
    {
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEmailInvalid" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPEmailInvalid" InTable:@"BPMultiLanguage"] duration:2.0];
        
        
        
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    if([bindMail isEqualToString:emailText.text])
    {
      //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPModifyEmailFirst" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPModifyEmailFirst" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;;
    }
    [emailRequest RequestBindEmail:emailText.text];
    
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    
    if(!BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:40];
        else
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:120];
    }
    
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView * back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    back.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
    back.userInteractionEnabled = YES;
    [self.view addSubview:back];
    [back release];
	// Do any additional setup after loading the view.
    emailRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    
    BPCustomTextField *emailText = [[BPCustomTextField alloc] init];
    emailText.tag = 1000;
    NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"bindEmail_%@",[ShuZhiZhangUserPreferences CurrentUserID]]];
    if(!bindMail || bindMail.length<1)
    emailText.text = str;
    emailText.delegate = self;
    emailText.placeholder = [BPLanguage getStringForKey:@"BPEmailPrompt" InTable:@"BPMultiLanguage"]; //
    [emailText becomeFirstResponder];
    [BPLoginPublic setTextFieldProperty:emailText withDelegate:self];
    emailText.keyboardType = UIKeyboardTypeEmailAddress;
    emailText.PlaceholderOffset_x = 38;
    [self.view addSubview:emailText];
    [emailText release];
    
    UIImageView *emailImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_email.png"]];
    [emailText addSubview:emailImage];
    emailImage.frame = CGRectMake(0, 0, 40, 40);
    [emailImage release];
    
    // 邮箱绑定页面的 绑定按钮
    UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPBind" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    [getVerifyCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
    [getVerifyCode addTarget:self action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    UIImage *image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind.png"];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(10,15,10,15)];
    [getVerifyCode setBackgroundImage:image forState:UIControlStateNormal];
    image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind_sel.png"];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(10,15,10,15)];
    [getVerifyCode setBackgroundImage:image forState:UIControlStateHighlighted];
    getVerifyCode.tag = 1003;
    [self.view addSubview:getVerifyCode];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        getVerifyCode.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH - 360)/2-105, 30, 105, 40);
        emailText.frame = CGRectMake((SCREEN_WIDTH-360)/2, 30, 280, 40);
    }
    else
    {
        getVerifyCode.frame = CGRectMake((SCREEN_WIDTH-290)/2, 85, 290, 40);
        getVerifyCode.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        emailText.frame = CGRectMake((SCREEN_WIDTH-290)/2, 30, 290, 40);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) hideAllKeyBoard
{
    return;
    UITextField *emailText = (UITextField *)[self.view viewWithTag:1000];
    [emailText resignFirstResponder];
}

//验证email是否有效
-(BOOL) isValidateEmail:(NSString *)email {
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    
    return [emailTest evaluateWithObject:email];
    
}

#pragma mark ----------http request -------------
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=====邮箱绑定====%@",request.url,[request responseString]);
    [BPQLoadingView hideWithAnimated:NO];
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindEmail"])
    {
        //该邮箱已绑定过其他的帐户
        if([[request responseString] isEqualToString:@"-20"])
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPEmailAlreadyUsed" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPEmailAlreadyUsed" InTable:@"BPMultiLanguage"] duration:2.0];

            
           [ShuZhiZhangUtility setPromptPosition];
        }
        //成功
        else if([[request responseString] intValue]>=0)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPBindEmailSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPBindEmailSuccess" InTable:@"BPMultiLanguage"] duration:2.0];

            
            [ShuZhiZhangUtility setPromptPosition];
            [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"bindEmail"] forKey:[NSString stringWithFormat:@"bindEmail_%@",[ShuZhiZhangUserPreferences CurrentUserID]]];
            [[NSUserDefaults standardUserDefaults] synchronize];

            dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
            dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [self leftButtonItemAction];
            });
        }
        else
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPBindEmailFail" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPBindEmailFail" InTable:@"BPMultiLanguage"] duration:2.0];

            
            [ShuZhiZhangUtility setPromptPosition];
        }
    }
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindEmail"])
    {
      //  [BPCustomPromptBox showWithTitle:@"当前网络不可用，请检查你的网络状态" AndDisappearSecond:2];
        
           [BPCustomNoticeBox showCenterWithText:@"当前网络不可用，请检查你的网络状态" duration:2.0];
        
        
        [ShuZhiZhangUtility setPromptPosition];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self rightButtonItemAction];
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
}
@end
