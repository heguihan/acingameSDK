//
//  TPBindSmallViewTips.h
//  BigPlayerSDK
//
//  Created by SkyGame on 16/7/29.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPBindSmallView : UIView<UITextFieldDelegate,ASIHTTPRequestDelegate,HttpRequestBaseDelegate>
{
    int currentCountDown;
    NSTimer *countdownTimer;
}

@property (nonatomic,retain) BPRegisterAndLoginRequest *phoneRequest;
@property (nonatomic,retain) BPOperateTable *userInfoTable;

-(void)backButtonButtonItemAction; // 删除

+(TPBindSmallView*)getShareInstance;  // 单例模式


-(void) showBindSmallVies;  //显示按钮

@end
