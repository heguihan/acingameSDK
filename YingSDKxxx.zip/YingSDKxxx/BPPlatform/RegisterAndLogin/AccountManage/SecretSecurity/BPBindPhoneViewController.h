//
//  BindPhoneViewController.h
//  BigPlayers
//
//  Created by John Cheng on 13-6-1.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"
#import "BPRegisterAndLoginRequest.h"
#import "BPAccountManageViewController.h"

@interface BPBindPhoneViewController : BPBaseViewController <UITextFieldDelegate>
{
    int currentCountDown;
    NSTimer *countdownTimer;
}

@property (nonatomic,retain) BPRegisterAndLoginRequest *phoneRequest;
@property (nonatomic,assign) BPAccountManageViewController *accountManager;
//显示手机号
-(void) showPhoneNumEnterToView:(UIView *)view;
//显示验证码
-(void) showVerifyCodeToView:(UIView *)view;

-(void) hideAllKeyBoard;

-(void) stopCountDown;

-(void) requestDidFinished:(ASIHTTPRequest *)request;



@end
