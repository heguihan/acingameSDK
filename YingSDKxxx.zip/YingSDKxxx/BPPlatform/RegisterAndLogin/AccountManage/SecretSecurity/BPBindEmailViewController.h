//
//  BindEmailViewController.h
//  BigPlayers
//
//  Created by John Cheng on 13-6-3.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

#import "BPBaseViewController.h"
#import "BPAccountManageViewController.h"

@interface BPBindEmailViewController : BPBaseViewController <UITextFieldDelegate>

@property (nonatomic,retain) NSString *bindMail;
@property (nonatomic,assign) BPAccountManageViewController *accountManager;


@end
