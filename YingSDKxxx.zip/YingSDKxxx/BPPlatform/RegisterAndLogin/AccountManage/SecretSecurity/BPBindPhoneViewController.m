//
//  BindPhoneViewController.m
//  BigPlayers
//
//  Created by John Cheng on 13-6-1.
//  Copyright (c) 2016年 teamtop3. All rights reserved.
//

// 手机邮箱绑定




#import "BPBindPhoneViewController.h"
#import "BPLoginPublic.h"

@interface BPBindPhoneViewController ()

@end

@implementation BPBindPhoneViewController
@synthesize phoneRequest;
@synthesize accountManager;


-(void) dealloc
{
    [phoneRequest release];         phoneRequest = nil;
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_cancel.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_cancel_sel.png"];
    }
    return self;
}

-(void) cancelRequest
{
    [phoneRequest cancelAllRequest];
}

-(void) leftButtonItemAction
{

    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
    
    [self cancelRequest];
}

// 判断是不是标准手机号码

-(void) rightButtonItemAction
{
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self.view viewWithTag:1001];
    [self hideAllKeyBoard];
    if(VerifyCode.text.length<1 || phoneNumber.text.length<1)
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneOrVerifyCodeEmpty" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneOrVerifyCodeEmpty" InTable:@"BPMultiLanguage"] duration:2.0];

        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    else if(![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneInvalid" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneInvalid" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    [phoneRequest RequestBindPhoneNumber:phoneNumber.text VerifyCode:VerifyCode.text];
    
    
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    if(!BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
        [BPQLoadingView setLoadingViewPosition:-1 Position_Y:40];
        else
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:80];
    }
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
//    self.title = [BPLanguage getStringForKey:@"BPBindPhone" InTable:@"BPMultiLanguage"];
    [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPBindPhone" InTable:@"BPMultiLanguage"] ViewController:self];
    phoneRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    
 
    [self showPhoneNumEnterToView:self.view];
    [self showVerifyCodeToView:self.view];
    
    
}
//显示手机号
-(void) showPhoneNumEnterToView:(UIView *)view
{
    BPCustomTextField *phoneNumber = [[BPCustomTextField alloc] init];
    phoneNumber.tag = 1000;
    phoneNumber.delegate = self;
    [phoneNumber becomeFirstResponder];
    phoneNumber.placeholder = [BPLanguage getStringForKey:@"BPEnterPhone" InTable:@"BPMultiLanguage"];
    // 请输入手机号
    [BPLoginPublic setTextFieldProperty:phoneNumber withDelegate:self];
    phoneNumber.keyboardType = UIKeyboardTypeNumberPad;
    phoneNumber.PlaceholderOffset_x = 38;
    [view addSubview:phoneNumber];
    [phoneNumber release];
    
    UIImageView *phoneImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/AccountPhone"]];
    [phoneNumber addSubview:phoneImage];
    phoneImage.frame = CGRectMake(0, 0, 40, 40);
    [phoneImage release];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        phoneNumber.placeholder = [BPLanguage getStringForKey:@"BPEnterPhonePrompt" InTable:@"BPMultiLanguage"];   // 请输入手机号
        phoneNumber.frame = CGRectMake((SCREEN_WIDTH-360)/2, 15, 280, 40);
    }
    else
    {
        phoneNumber.frame = CGRectMake((SCREEN_WIDTH-290)/2, 20, 290, 40);
        
        UILabel *phoneTishi = [[UILabel alloc] initWithFrame:CGRectMake(20, 70, SCREEN_WIDTH-40, 15)];
        phoneTishi.text = [BPLanguage getStringForKey:@"BPEnterPhonePrompt" InTable:@"BPMultiLanguage"];   // 绑定手机号,使您的账号更安全
        phoneTishi.backgroundColor = [UIColor clearColor];
        phoneTishi.textAlignment = NSTextAlignmentLeft;
        phoneTishi.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
        phoneTishi.font = [UIFont systemFontOfSize:12];
        [self.view addSubview:phoneTishi];
        phoneTishi.frame = CGRectMake((SCREEN_WIDTH-270)/2, 66, 270, 15);
        [phoneTishi release];
    }
    
    
// 获取验证码按钮
    UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
    getVerifyCode.frame = CGRectMake((SCREEN_WIDTH-290)/2+300-115, 20, 105, 40);
    if(SCREEN_IS_LANDSCAPE)
    {
        getVerifyCode.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH - 360)/2-105, 15, 105, 40);
    }
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    [getVerifyCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
    [getVerifyCode addTarget:self action:@selector(getVerifyCodeAction) forControlEvents:UIControlEventTouchUpInside];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateHighlighted];
    getVerifyCode.tag = 1002;
    [self.view addSubview:getVerifyCode];
}

//显示验证码的输入框和 发送请求功能按钮
-(void) showVerifyCodeToView:(UIView *)view
{
    BPCustomTextField *VerifyCode = [[BPCustomTextField alloc] init];
    VerifyCode.tag = 1001;
    [BPLoginPublic setTextFieldProperty:VerifyCode withDelegate:self];
    VerifyCode.PlaceholderOffset_x = 38;
    VerifyCode.keyboardType = UIKeyboardTypeNumberPad;
    VerifyCode.placeholder = [BPLanguage getStringForKey:@"BPEnterVerifyCode" InTable:@"BPMultiLanguage"]; // 动态验证码
    [view addSubview:VerifyCode];
    [VerifyCode release];
    
    UIImageView *codeImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/AccountSecurity.png"]];
    [VerifyCode addSubview:codeImage];
    codeImage.frame = CGRectMake(0, 0, 40, 40);
    [codeImage release];
    
        
    if(SCREEN_IS_LANDSCAPE)
    {
        VerifyCode.frame = CGRectMake((SCREEN_WIDTH-360)/2, 70, 280, 40);
    }
    else
    {
        VerifyCode.frame = CGRectMake((SCREEN_WIDTH-290)/2, 96, 200, 40);
    }
    
    // 手机绑定的绑定按钮
    
    UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
    getVerifyCode.frame = CGRectMake((SCREEN_WIDTH-290)/2+300-115, 96, 105, 40);
    if(SCREEN_IS_LANDSCAPE)
    {
        getVerifyCode.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH - 360)/2-105, 70, 105, 40);
    }
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPBind" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    [getVerifyCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
    [getVerifyCode addTarget:self action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind_sel.png"] forState:UIControlStateHighlighted];
    getVerifyCode.tag = 1003;
    [self.view addSubview:getVerifyCode];
}

#pragma mark --------countdown------
//显示多少秒后获取验证码
-(void) showCountDownButton:(int)seconds
{
    UIButton *getVerifyCode = (UIButton *)[self.view viewWithTag:1002];
    [getVerifyCode setTitle:[NSString stringWithFormat:@"%d%@",seconds,[BPLanguage getStringForKey:@"BPReacquireVerifyCode" InTable:@"BPMultiLanguage"]] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg3.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg3.png"] forState:UIControlStateHighlighted];
}

// 提交请求
-(void) requestVerifyCode
{
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
   [phoneRequest RequestPhoneVerifyCode:phoneNumber.text];
    
}

//点击获取验证码
-(void) getVerifyCodeAction
{
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
    if(currentCountDown==0 && [ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
        if(phoneNumber.text.length<1)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] duration:2.0];

            
            [ShuZhiZhangUtility setPromptPosition];
            return;
        }
        currentCountDown = 60;
        [self requestVerifyCode]; // 提交请求
        [self showCountDownButton:currentCountDown];
        
        if(countdownTimer==nil)
        {
            countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(VerifyCountDown) userInfo:nil repeats:YES];
        }
 }
}

//停止倒计时
-(void) stopCountDown
{
    [countdownTimer invalidate];
    countdownTimer = nil;
    currentCountDown = 0;
    
    UIButton *getVerifyCode = (UIButton *)[self.view viewWithTag:1002];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
    
}

// 定时器方法
-(void) VerifyCountDown
{
    currentCountDown--;
    UIButton *getVerifyCode = (UIButton *)[self.view viewWithTag:1002];
    if(currentCountDown==0)
    {
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
        [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
        [countdownTimer invalidate];
        countdownTimer = nil;
        return;
    }
    [self showCountDownButton:currentCountDown]; //显示多少秒后获取验证码
}




#pragma mark ----------http request -------------
-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=====手机绑定====%@",request.url,[request responseString]);
    NSDictionary *userInfo = request.userInfo;
    [BPQLoadingView hideWithAnimated:NO];
    //获取手机验证码
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"RequestPhoneVerifyCode"])
    {
        //该手机已绑定过其他帐户
        if([[request responseString] intValue] == -20)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneAlreadyUsed" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
              [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneAlreadyUsed" InTable:@"BPMultiLanguage"] duration:2.0];
            
            
            [ShuZhiZhangUtility setPromptPosition]; // 邮箱号占位
            [self stopCountDown];
        }
        //获取验证码失败
        else if([[request responseString] intValue] <= 0)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPGetVerifyCodeError" InTable:@"BPMultiLanguage"] AndDisappearSecond:2]; // 获取验证码
            
              [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPGetVerifyCodeError" InTable:@"BPMultiLanguage"] duration:2.0];
            
            
            [ShuZhiZhangUtility setPromptPosition];
            [self stopCountDown];
        }
    }
    //手机号绑定
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindPhoneNumber"])
    {
        //手机绑定成功
        if([[request responseString] intValue] == 1)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneBindSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
              [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneBindSuccess" InTable:@"BPMultiLanguage"] duration:2.0];
            
            
            [ShuZhiZhangUtility setPromptPosition];
            
            BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
            [userInfoTable UpdateDataToTable:[NSString stringWithFormat:@"update %@ set phone = %@ where userId = %@",BPUserInfoTableName,[userInfo objectForKey:@"phoneNumber"],[ShuZhiZhangUserPreferences CurrentUserID]]];
            [userInfoTable release];
            
            [accountManager.userInfoDic setObject:[userInfo objectForKey:@"phoneNumber"] forKey:@"phone"];
            [accountManager.bpTableView reloadData];

            dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
            dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [self leftButtonItemAction];
            });
        }
        //验证码已过期或不存在
        else if([[request responseString] intValue] == -20)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPVerifyCodeNotExist" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPVerifyCodeNotExist" InTable:@"BPMultiLanguage"] duration:2.0];

            
            [ShuZhiZhangUtility setPromptPosition];
        }
        //手机号跟验证码不匹配
        else if([[request responseString] intValue] == -30)
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneAndVerifyNotMatch" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
             [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneAndVerifyNotMatch" InTable:@"BPMultiLanguage"] duration:2.0];
            [ShuZhiZhangUtility setPromptPosition];
        }
        //绑定失败
        else
        {
           // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneBindError" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
             [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneBindError" InTable:@"BPMultiLanguage"] duration:2.0];
            
            
            [ShuZhiZhangUtility setPromptPosition];
        }
    }
}



-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindPhoneNumber"])
    {
        // [BPCustomPromptBox showWithTitle:@"当前网络不可用，请检查你的网络状态" AndDisappearSecond:2];
        
        
        [BPCustomNoticeBox showCenterWithText:@"当前网络不可用，请检查你的网络状态" duration:2.0];
        
        
        [ShuZhiZhangUtility setPromptPosition];
    }
}

#pragma mark -----textField delegate-----
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
//    if (range.location >= 8  &&
    if(textField.tag == 1000 && currentCountDown <= 0)
    {
        UIButton *getVerifyCode = (UIButton *)[self.view viewWithTag:1002];
        NSMutableString *phoneStr = (NSMutableString *)textField.text;
        if ([string isEqualToString:@""])
        {
            phoneStr = (NSMutableString *)[phoneStr substringToIndex:phoneStr.length-1];
        }
        else
        {
            phoneStr = (NSMutableString *)[phoneStr stringByAppendingString:string];
        }
        
        if([ShuZhiZhangUtility isMobileNumber:phoneStr])
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
        }
        else
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateNormal];
        }
    }

    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

-(void) hideAllKeyBoard
{
    return;
    UITextField *phoneNumber = (UITextField *)[self.view viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self.view viewWithTag:1001];
    
    [phoneNumber resignFirstResponder];
    [VerifyCode resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
   
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
