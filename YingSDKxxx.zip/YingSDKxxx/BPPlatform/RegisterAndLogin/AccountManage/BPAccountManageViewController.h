//
//  AccountManageViewController.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-25.
//  Copyright (c) 2016年 John FAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BPBaseViewController.h"

@interface BPAccountManageViewController : BPBaseViewController
{
    BOOL PaySecretAlreadySet;
    BOOL hasAlreadyBindPhone;
    BOOL hasAlreadyBindEmail;
}
@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@end
