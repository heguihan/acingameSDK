//
//  BPModifyAccountViewController.m
//  BigPlayerSDK
//
//

#import "BPModifyAccountViewController.h"
#import "BPBindEmailViewController.h"
#import "BPLoginPublic.h"
#import "BPKeychainItemWrapper.h"

@interface BPModifyAccountViewController ()
@property (nonatomic,retain) BPRegisterAndLoginRequest *modifyAccountRequest;
@end

@implementation BPModifyAccountViewController
@synthesize modifyAccountRequest;
@synthesize accountManager;

-(void) dealloc
{
    [modifyAccountRequest release];         modifyAccountRequest = nil;
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [ShuZhiZhangUtility customNavigationTitle:[BPLanguage getStringForKey:@"BPModifyAccount" InTable:@"BPMultiLanguage"] ViewController:self];
        [ShuZhiZhangUtility customNavigationButton:self isleftButton:YES NormalImage:@"ShuZhiZhang.bundle/BP_cancel.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_cancel_sel.png"];
        //        [ShuZhiZhangUtility customNavigationButton:self isleftButton:NO NormalImage:@"ShuZhiZhang.bundle/BP_finish.png" HighLightedImage:@"ShuZhiZhang.bundle/BP_finish_sel.png"];
    }
    return self;
}

-(void) cancelRequest
{
    [modifyAccountRequest cancelAllRequest];
}
-(void) leftButtonItemAction
{
    //    [self.navigationController popViewControllerAnimated:YES];
    [self dismissModalViewControllerAnimated:YES];
    [self cancelRequest];
    [accountManager.bpTableView reloadData];
}

-(void) rightButtonItemAction
{
    UITextField *emailText = (UITextField *)[self.view viewWithTag:1000];
    NSString *regularExpression = @"^[A-z0-9_@.-]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:emailText.text] == NO)
    {
       //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    else if([[BPDESEncryption desDecodeWithText:[ShuZhiZhangUserPreferences CurrentAccount]] isEqualToString:emailText.text])
    {
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccountSame" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
          [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountSame" InTable:@"BPMultiLanguage"] duration:2.0];
        
        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    [modifyAccountRequest RequestModifyAccount:emailText.text];
    [BPQLoadingView showDefaultLoadingViewWithView:self.view];
    if(!BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:40];
        else
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:120];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView * back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    back.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT_NAV);
    back.userInteractionEnabled = YES;
    [self.view addSubview:back];
    [back release];
	// Do any additional setup after loading the view.
    modifyAccountRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
    
    BPCustomTextField *emailText = [[BPCustomTextField alloc] init];
    emailText.tag = 1000;
    emailText.text = [BPDESEncryption desDecodeWithText:[ShuZhiZhangUserPreferences CurrentAccount]];
    emailText.delegate = self;
    emailText.placeholder = [BPLanguage getStringForKey:@"BPPleaseEnterAccount" InTable:@"BPMultiLanguage"]; //
    [emailText becomeFirstResponder];
    [BPLoginPublic setTextFieldProperty:emailText withDelegate:self];
    emailText.PlaceholderOffset_x = 38;
    [self.view addSubview:emailText];
    [emailText release];
    
    UIImageView *emailImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_user.png"]];
    [emailText addSubview:emailImage];
    emailImage.frame = CGRectMake(0, 0, 40, 40);
    [emailImage release];
    
    UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPModify" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
    [getVerifyCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
    [getVerifyCode addTarget:self action:@selector(rightButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    UIImage *image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind.png"];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(10,15,10,15)];
    [getVerifyCode setBackgroundImage:image forState:UIControlStateNormal];
    image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind_sel.png"];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(10,15,10,15)];
    [getVerifyCode setBackgroundImage:image forState:UIControlStateHighlighted];
    getVerifyCode.tag = 1003;
    [self.view addSubview:getVerifyCode];
    
    
    UILabel *accoutPrompt = [[UILabel alloc] init];
    accoutPrompt.text = [BPLanguage getStringForKey:@"BPRegistAccount" InTable:@"BPMultiLanguage"];
    accoutPrompt.textAlignment = NSTextAlignmentLeft;
    accoutPrompt.font = [UIFont systemFontOfSize:12];
    accoutPrompt.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
    accoutPrompt.backgroundColor = [UIColor clearColor];
    [self.view addSubview:accoutPrompt];
    [accoutPrompt release];
    
    if(SCREEN_IS_LANDSCAPE)
    {
        getVerifyCode.frame = CGRectMake(SCREEN_WIDTH - (SCREEN_WIDTH - 360)/2-105, 30, 105, 40);
        emailText.frame = CGRectMake((SCREEN_WIDTH-360)/2, 30, 280, 40);
        accoutPrompt.frame = CGRectMake((SCREEN_WIDTH-360)/2+5, 80, 280, 14);
    }
    else
    {
        getVerifyCode.frame = CGRectMake((SCREEN_WIDTH-290)/2, 105, 290, 40);
        getVerifyCode.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        emailText.frame = CGRectMake((SCREEN_WIDTH-290)/2, 30, 290, 40);
        accoutPrompt.frame = CGRectMake((SCREEN_WIDTH-290)/2+5, 80, 290, 14);
    }
}


#pragma mark ----------http request -------------
-(void) modifyErrorTishi:(int) response
{
    //    UILabel * remindLabel = (UILabel *)[self.view viewWithTag:510];
    if(response == -50)
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccountAlreadyExit" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountAlreadyExit" InTable:@"BPMultiLanguage"] duration:2.0];

        
    }
    else
    {
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPAccontModifyError" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccontModifyError" InTable:@"BPMultiLanguage"] duration:2.0];
        

    }
}


-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    BPLog(@"---%@=========%@",request.url,[request responseString]);
    [BPQLoadingView hideWithAnimated:NO];
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"modifyAccount"])
    {
        //成功
        if([[request responseString] intValue]==1)
        {
          //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPModifyAccountSuccess" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPModifyAccountSuccess" InTable:@"BPMultiLanguage"] duration:2.0];
            

            
            [ShuZhiZhangUtility setPromptPosition];
            
            BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
            [userInfoTable UpdateDataToTable:[NSString stringWithFormat:@"update %@ set username = '%@' where uid = %@",BPUserInfoTableName,[BPDESEncryption desEncodeWithText:[userInfo objectForKey:@"newAccount"]],[ShuZhiZhangUserPreferences CurrentUserID]]];
            [userInfoTable release];
            [ShuZhiZhangUserPreferences setCurrentAccount:[BPDESEncryption desEncodeWithText:[userInfo objectForKey:@"newAccount"]]];
            
            [ShuZhiZhangUtility saveAccountAndPasswordToKeyChain:[BPDESEncryption desEncodeWithText:[userInfo objectForKey:@"newAccount"]] AndPassword:nil];
            

            dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1.5*NSEC_PER_SEC);
            dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [self leftButtonItemAction];
            });
        }
        else
        {
            [self modifyErrorTishi:[[request responseString] intValue]];
           [ShuZhiZhangUtility setPromptPosition];
        }
    }
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BindEmail"])
    {
        [BPCustomPromptBox showWithTitle:@"当前网络不可用，请检查你的网络状态" AndDisappearSecond:2];
        [ShuZhiZhangUtility setPromptPosition];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self rightButtonItemAction];
    [textField resignFirstResponder];
    return YES;
}

@end
