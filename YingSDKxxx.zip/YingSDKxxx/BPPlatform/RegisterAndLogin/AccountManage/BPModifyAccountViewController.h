//
//  BPModifyAccountViewController.h
//  BigPlayerSDK

#import "BPBaseViewController.h"
#import "BPAccountManageViewController.h"
#import "BPRegisterAndLoginRequest.h"

@interface BPModifyAccountViewController : BPBaseViewController
@property (nonatomic,assign) BPAccountManageViewController *accountManager;
@end
