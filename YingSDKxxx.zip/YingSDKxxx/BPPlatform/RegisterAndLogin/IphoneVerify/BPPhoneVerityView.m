//
//  IphoneVerityView.m
//  BigPlayerSDK
//
//  Created by John Cheng on 15/3/11.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPPhoneVerityView.h"
#import "BPLoginPublic.h"
@implementation BPPhoneVerityView
@synthesize bindResultBlock;

-(void) dealloc
{
    [bindResultBlock release];      bindResultBlock = nil;
    [phoneRequest release];         phoneRequest = nil;
    [super dealloc];
}

-(void) showBackImage
{
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_background.png"]];
    
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - 300)/2, (REAL_SCREEN_HEIGHT - 185)/2-65, 300, 185);
    backImageView.userInteractionEnabled = YES;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
    backImageView.layer.masksToBounds = YES;
    backImageView.layer.cornerRadius = 5;
    
    [backImageView release];
    
    backImageView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    [UIView animateWithDuration:0.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 1.1, 1.1);
                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.1
                                          animations:^{
                                              backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 1.0, 1.0);
                                          }
                                          completion:^(BOOL finished) {}];
                     }];
}

- (id)init
{
    self = [super init];
    if (self) {
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.6;
        [self addSubview:background];
        [background release];
        
        phoneRequest = [[BPRegisterAndLoginRequest alloc] initWithDelegate:self];
        [self showBackImage];
        
        UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 40, 300, 1)];
        line.backgroundColor = [UIColor colorWithRed:208/255.0f green:208/255.0f blue:208/255.0f alpha:0.5];
        line.layer.shadowOffset = CGSizeMake(0, 2);
        line.layer.shadowOpacity = 0.60;
        [backImageView addSubview:line];
        [line release];
        
        UIButton * closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        closeButton.frame = CGRectMake(0, 0, 44, 50);
        [closeButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_cancel.png"] forState:UIControlStateNormal];
        [closeButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_cancel_sel.png"] forState:UIControlStateHighlighted];
        [closeButton addTarget:self action:@selector(clickCloseButton) forControlEvents:UIControlEventTouchUpInside];
        [backImageView addSubview:closeButton];
        
        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 300, 44)];
        title.text = @"手机验证";
        title.backgroundColor = [UIColor clearColor];
        title.textAlignment = NSTextAlignmentCenter;
//        phoneTishi.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
        title.font = [UIFont systemFontOfSize:14];
        [backImageView addSubview:title];
        [title release];
        
        
        
        BPCustomTextField *phoneNumber = [[BPCustomTextField alloc] init];
        phoneNumber.tag = 1000;
        phoneNumber.delegate = self;
        [phoneNumber becomeFirstResponder];
        phoneNumber.placeholder = [BPLanguage getStringForKey:@"BPEnterPhone" InTable:@"BPMultiLanguage"];   // 请输入手机号
        [BPLoginPublic setTextFieldProperty:phoneNumber withDelegate:self];
        phoneNumber.keyboardType = UIKeyboardTypeNumberPad;
        phoneNumber.PlaceholderOffset_x = 38;
        [backImageView addSubview:phoneNumber];
        [phoneNumber release];
        
        UIImageView *phoneImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/AccountPhone"]];
        [phoneNumber addSubview:phoneImage];
        phoneImage.frame = CGRectMake(0, 0, 40, 40);
        [phoneImage release];
        
        phoneNumber.frame = CGRectMake(10, 55, 200, 40);
        
//        UILabel *phoneTishi = [[UILabel alloc] initWithFrame:CGRectMake(20, 70, SCREEN_WIDTH-40, 15)];
//        phoneTishi.text = [BPLanguage getStringForKey:@"BPEnterPhonePrompt" InTable:@"BPMultiLanguage"];
//        phoneTishi.backgroundColor = [UIColor clearColor];
//        phoneTishi.textAlignment = NSTextAlignmentLeft;
//        phoneTishi.textColor = [UIColor colorWithRed:150/255.0f green:150/255.0f blue:150/255.0f alpha:1];
//        phoneTishi.font = [UIFont systemFontOfSize:12];
//        [backImageView addSubview:phoneTishi];
//        phoneTishi.frame = CGRectMake((SCREEN_WIDTH-270)/2, 66, 270, 15);
//        [phoneTishi release];
        
        UIButton *getVerifyCode = [UIButton buttonWithType:UIButtonTypeCustom];
        getVerifyCode.frame = CGRectMake(10+280-115, 55, 105, 40);
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
        [getVerifyCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        getVerifyCode.titleLabel.font = [UIFont systemFontOfSize:14];
        [getVerifyCode addTarget:self action:@selector(getVerifyCode) forControlEvents:UIControlEventTouchUpInside];
        [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateNormal];
        [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateHighlighted];
        getVerifyCode.tag = 1002;
        [backImageView addSubview:getVerifyCode];
        
        
        BPCustomTextField *VerifyCode = [[BPCustomTextField alloc] init];
        VerifyCode.tag = 1001;
        [BPLoginPublic setTextFieldProperty:VerifyCode withDelegate:self];
        VerifyCode.PlaceholderOffset_x = 38;
        VerifyCode.keyboardType = UIKeyboardTypeNumberPad;
        VerifyCode.placeholder = [BPLanguage getStringForKey:@"BPEnterVerifyCode" InTable:@"BPMultiLanguage"];// 动态验证码
        [backImageView addSubview:VerifyCode];
        [VerifyCode release];
        
        UIImageView *codeImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/AccountSecurity.png"]];
        [VerifyCode addSubview:codeImage];
        codeImage.frame = CGRectMake(0, 0, 40, 40);
        [codeImage release];
        
        VerifyCode.frame = CGRectMake(10, 106, 200, 40);
        
        UIButton *bind = [UIButton buttonWithType:UIButtonTypeCustom];
        bind.frame = CGRectMake(10+280-115, 106, 105, 40);
        [bind setTitle:[BPLanguage getStringForKey:@"BPBind" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
        [bind setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        bind.titleLabel.font = [UIFont systemFontOfSize:14];
        [bind addTarget:self action:@selector(clickBind) forControlEvents:UIControlEventTouchUpInside];
        [bind setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind.png"] forState:UIControlStateNormal];
        [bind setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_btn_bind_sel.png"] forState:UIControlStateHighlighted];
        bind.tag = 1003;
        [backImageView addSubview:bind];
    }
    return self;
}
-(void) clickCloseButton
{
//    NSDictionary *postInfo = [NSDictionary dictionaryWithObjectsAndKeys:@"userCancel", @"PhoneNumberBindResult", nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:BPBindPhoneNumberResult object:postInfo];
    bindResultBlock(@"userCancel");
    [self dimissVerifyPage];
}

-(void) dimissVerifyPage
{
    UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
    [phoneRequest cancelAllRequest];
    [UIView animateWithDuration:.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                     }];
}

-(void) clickBind
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    UITextField *VerifyCode = (UITextField *)[self viewWithTag:1001];
    if(VerifyCode.text.length<1 || phoneNumber.text.length<1)
    {
       // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneOrVerifyCodeEmpty" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneOrVerifyCodeEmpty" InTable:@"BPMultiLanguage"] duration:2.0];

        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    else if(![ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
       //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneInvalid" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneInvalid" InTable:@"BPMultiLanguage"] duration:2.0];

        [ShuZhiZhangUtility setPromptPosition];
        return;
    }
    [phoneRequest BindPhoneNumber_ForGift:phoneNumber.text VerifyCode:VerifyCode.text];
    [BPQLoadingView showDefaultLoadingViewWithView:self];
    if(!BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:40];
        else
            [BPQLoadingView setLoadingViewPosition:-1 Position_Y:80];
    }
}


#pragma mark --------countdown------
//显示多少秒后获取验证码
-(void) showCountDownButton:(int)seconds
{
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    [getVerifyCode setTitle:[NSString stringWithFormat:@"%d%@",seconds,[BPLanguage getStringForKey:@"BPReacquireVerifyCode" InTable:@"BPMultiLanguage"]] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg3.png"] forState:UIControlStateNormal];
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg3.png"] forState:UIControlStateHighlighted];
}

-(void) requestVerifyCode
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    [phoneRequest phoneVerifyCode_ForGift:phoneNumber.text];
}

//点击获取验证码
-(void) getVerifyCode
{
    UITextField *phoneNumber = (UITextField *)[self viewWithTag:1000];
    if(currentCountDown==0 && [ShuZhiZhangUtility isMobileNumber:phoneNumber.text])
    {
        if(phoneNumber.text.length<1)
        {
          //  [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
            
            [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPhoneEmpty" InTable:@"BPMultiLanguage"] duration:2.0];
            

            [ShuZhiZhangUtility setPromptPosition];
            return;
        }
        currentCountDown = 90;
        [self requestVerifyCode];
        [self showCountDownButton:currentCountDown];
        
        if(countdownTimer==nil)
        {
            countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(VerifyCountDown) userInfo:nil repeats:YES];
        }
    }
}

-(void) stopCountDown
{
    [countdownTimer invalidate];
    countdownTimer = nil;
    currentCountDown = 0;
    
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
    [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
}

-(void) VerifyCountDown
{
    currentCountDown--;
    UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
    if(currentCountDown==0)
    {
        [getVerifyCode setTitle:[BPLanguage getStringForKey:@"BPGetVerifyCode" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal]; // 获取验证码
        [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
        [countdownTimer invalidate];
        countdownTimer = nil;
        return;
    }
    [self showCountDownButton:currentCountDown];
}


#pragma mark -----textField delegate-----
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    //    if (range.location >= 8  &&
    if(textField.tag == 1000 && currentCountDown <= 0)
    {
        UIButton *getVerifyCode = (UIButton *)[self viewWithTag:1002];
        NSMutableString *phoneStr = (NSMutableString *)textField.text;
        if ([string isEqualToString:@""])
        {
            phoneStr = (NSMutableString *)[phoneStr substringToIndex:phoneStr.length-1];
        }
        else
        {
            phoneStr = (NSMutableString *)[phoneStr stringByAppendingString:string];
        }
        
        if([ShuZhiZhangUtility isMobileNumber:phoneStr])
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg2.png"] forState:UIControlStateNormal];
        }
        else
        {
            [getVerifyCode setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_VerifyCode_bg1.png"] forState:UIControlStateNormal];
        }
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}


@end
