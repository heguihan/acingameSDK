//
//  IphoneVerityView.h
//  BigPlayerSDK
//
//  Created by John Cheng on 15/3/11.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPPhoneVerityView : UIView <UITextFieldDelegate>
{
    BPRegisterAndLoginRequest *phoneRequest;
    int currentCountDown;
    NSTimer *countdownTimer;
}
@property (nonatomic,strong) void(^bindResultBlock)(NSString *result);
@end
