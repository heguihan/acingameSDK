 //
//  BPRegisterAndLoginRequest.m
//  BigPlayerSDK
//
//

#import "BPRegisterAndLoginRequest.h"
#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPOperateTable.h"
#import "BPBindPhoneView.h"
#import "BPLoginView.h"


@interface BPRegisterAndLoginRequest ()
{
    
 BPOperateTable *userInfoTable;
    
}

@end

@implementation BPRegisterAndLoginRequest
- (instancetype)init
{
    self = [super init];
    if (self) {
        
        userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];

        
    }
    return self;
}
static BPRegisterAndLoginRequest *BPPlatformShared = nil;
+(BPRegisterAndLoginRequest *) BPSharedRequest
{
    @synchronized(BPPlatformShared)
    {
        if(BPPlatformShared == nil)
        {
            BPPlatformShared =[[BPRegisterAndLoginRequest alloc] init];
        }
        
        return BPPlatformShared;
    }
}



#pragma mark --------Announcements公告，更新等----

//检测游戏是否有新版本
-(void) RequestcheckGameUpdate
{
  

}


//获取游戏信息
-(void) RequestGameInfoWithLast:(NSString *)last
{
  


}


/********************************************************************************  登录模块  ********************************************************************************/



/************************
 //帐户登陆
 //account: 帐号
 //password: 密码
 *************************/
//hghyyyyy登录1
-(void) requestLoginWithAccount:(NSString *)account Password:(NSString *)password
{

    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];

    [dict setObject:channelId forKey:@"channelID"];
    [dict setObject:account forKey:@"userID"];
    [dict setObject:@"2"forKey:@"type"];
    [dict setObject:dateStr forKey:@"ts"];
    [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    ////////NSLog(@"账号密码登录");
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"login",appid,sortStr,sign];
    
    ////////NSLog(@"账号登录dict = %@,urlStr = %@",dict,urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            ////////NSLog(@"登录dict = %@",data);
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                ////////NSLog(@"登录成功");
//                [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
                [BPShowLoginPrompt showWithName:account];
                NSString *userID = data[@"userID"];
                [ShuZhiZhangUserPreferences setCurrentUserID:userID];    // 存储当前userID
                
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
//                [userInfo setObject:account forKey:@"userID"];
                [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
                [userInfo setObject:password forKey:@"password"];
                    
                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
                [BPShowLoginPrompt showWithName:account];
                [BPLoginPublic userDidLoginAction:userInfo];
                
                // 更新
                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
                [userInfoTable UpdateDataToTable:sqlStr];
                
                
            }else{
                
//                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                
                [self gotoLoginViewController];

            }
        });
    } failure:^(NSError *error) {
        
    }];
    
    
}

// 手机号用户
-(void)requestLoginWithPhoneNumber:(NSString *)account Password:(NSString *)password{

    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];

    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    if ([ShuZhiZhangUtility isMobileNumber:account])
    {
        [dict setObject:channelId forKey:@"channelID"];
        [dict setObject:@"1"forKey:@"type"];
        [dict setObject:dateStr forKey:@"ts"];
        [dict setObject:account forKey:@"phoneNumber"];
        [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    }
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"login",appid,sortStr,sign];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            ////////NSLog(@"账号登录dict = %@,urlStr = %@",data,urlStr);
            
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                ////////NSLog(@"手机登录成功");
              
//                [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
                [BPShowLoginPrompt showWithName:account];
                [ShuZhiZhangUserPreferences setCurrentUserID:account];    // 存储当前userID
                
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
                [userInfo setObject:account forKey:@"userID"];
                [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
                [userInfo setObject:password forKey:@"password"];
                [userInfo setObject:account forKey:@"phoneNumber"];
                [BPShowLoginPrompt showWithName:account];
                [BPLoginPublic userDidLoginAction:userInfo];
                // 更新
                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
                [userInfoTable UpdateDataToTable:sqlStr];
                [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"loginway"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
            }else{
                [self gotoLoginViewController];
            }
        });
    } failure:^(NSError *error) {
        
        
    }];
}

//hghyyyyy调用比较多的网络库
-(void) requestLoginWithVistor:(NSString *)userID token:(NSString *)token{

    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?type=3",GLOBAL_LOGIN_API_URL,@"login",appid];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSString * signStr = [NSString stringWithFormat:@"channelID=%@&token=%@&ts=%@&type=3&userID=%@&key=%@",channelId,token,dateStr,userID,appsecret];
    ////////NSLog(@"hghhhhhhhhhhhhhhhsign=%@",signStr);
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    urlStr = [NSString stringWithFormat:@"%@&channelID=%@&userID=%@&token=%@&ts=%@&sign=%@",urlStr,channelId,userID,token,dateStr,sign];
    ////////NSLog(@"hghtest=============游客登录======urlStr=%@",urlStr);
    
   [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        ////////NSLog(@"游客自动登录回包dict = %@,urlStr = %@",data,urlStr);
        [ShuZhiZhangUserPreferences setCurrentUserID:[data objectForKey:@"userID"]];
        if (data.count==0) {
            [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
            return ;
        }
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
        if ([[data objectForKey:@"ret"] intValue]==0) {
            
            [userInfo setObject:[[data objectForKey:@"token"] substringToIndex:8] forKey:@"password"];
            [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
            [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            // 更新
            NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],userID];
            [userInfoTable UpdateDataToTable:sqlStr];
            
            [BPLoginPublic userDidLoginAction:userInfo];
            [BPShowLoginPrompt showWithName:[NSString stringWithFormat:@"用户%@",  [data objectForKey:@"userID"]]];

            
        }else{
            [self gotoLoginViewController];
        }
    });
    
} failure:^(NSError *error) {
    
    
    
}];

}


-(void) gotoLoginViewController
{
    [BPQLoadingView hideWithAnimated:NO];
    UIViewController *currentViewControl_t = [ShuZhiZhangUtility getCurrentViewController];
    if(!currentViewControl_t)
    {

        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self gotoLoginViewController];
        });
        return;
    }
    
    BPLoginView *loginView = [[BPLoginView alloc] init];
    
    [currentViewControl_t.view addSubview:loginView];
    
    [loginView release];
    return;
}
















/************************
 // 微信登录
 // weiChatDic: 新浪用户信息字典
 *************************/
-(void) requestLoginWithWeChat:(NSString *)userID NickName:(NSString *)nickname
{


    
    
    
}



/************************
 // qq帐户登陆
 // openId: qq帐户唯一标识
 // nickName： 昵称
 *************************/
-(void) requestLoginWithQQAccount:(NSString *)openId NickName:(NSString *)nickName
{




}




/********************************************************************************  注册模块  ********************************************************************************/




#pragma mark ------register------
/************************
 // 用户名注册账号
 //account: 帐号
 //password: 密码
 *************************/

// 用户名注册账号v
-(void) requestRegisterWithAccount:(NSString *)account Password:(NSString *)password registerType:(NSString *)registerType{

    
    
    
}

#pragma mark ------register------
/************************
  手机号注册
  account: 帐号
  password: 密码
  SecurityCode 验证码
 *************************/

//获取手机验证码
-(void) RequestPhoneVerifyCodeForRegister:(NSString *)phoneNumber
{

    
    
    
}


// 手机号注册
-(void) requestRegisterWithAccount:(NSString *)account Password:(NSString *)password SecurityCode:(NSString *)securityCode registerType:(NSString *)registerType

{

    
    
    
    
}






/* 
 * 游客模式
 *
 * 一秒注册，快速进入
 */
-(void) oneSecondRegiste
{
    NSString *urlStr = [self BPUrlJoininTogetherwithAction:@"register" appid:@"999" type:@"3" ];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    urlStr = [NSString stringWithFormat:@"%@&ts=%@",urlStr,dateStr];
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
      
        
        ////////NSLog(@"游客登录回包dict = %@,urlStr = %@",data,urlStr);
        
        
    } failure:^(NSError *error) {
        
    }];
    
}



#pragma mark ------logout-----
/************************
 //注销帐户
 *************************/
-(void) requestLogout
{
   



}



/***************************************************************************手机号绑定****************************************************************/

//获取手机验证码 ----
-(void) RequestPhoneVerifyCode:(NSString *)phoneNumber
{
   
    
    
    
}



//请求手机号绑定
-(void) RequestBindPhoneNumber:(NSString *)phoneNumber VerifyCode:(NSString *)verityCode
{
   


}



-(NSString *)BPUrlJoininTogetherwithAction:(NSString *)action appid:(NSString *)appid type:(NSString *)type{

    NSString *urlString = [NSString stringWithFormat:@"%@%@/%@?type=%@",GLOBAL_LOGIN_API_URL,action,appid,type];
    
    return urlString;

}









#pragma mark------------------------------------------------------------------- 分割线 -----------------------------------------------------------








//请求邮箱绑定
-(void) RequestBindEmail:(NSString *)email
{
   

}


// 选择注册方法
-(void)selectRegisterMethodActionMode{
    
  
    
    
    
}






//一秒注册，获取用户的帐户
-(void) GetUserAccountWhenOneSecondRegister
{
   }


//第三方登录
-(void)thirdAutoLogin:(NSString *)uid
{
   

}


//用户修改账号(通行证)
-(void) RequestModifyAccount:(NSString *)account
{
    

}


#pragma mark -------forget password----
/************************
 //通过邮箱或手机找回密码
 //account: 帐号
 //num: 邮箱号／手机号
 //Type:是通过邮箱还是手机 0--手机， 1----邮箱
 *************************/
-(void) backPasswordByPhoneOrMailNum:(NSString *)num Type:(int)type
{
    

}


#pragma mark -------Personal Info------
//获取用户信息
-(void) requestUserInfomation
{
    






}


/************************
 //上传用户信息
 //filePath: 头像路径
 //userDic: 用户信息字典
 *************************/
-(void) uploadImageAndUserInfo:(NSString *)filePath UserInfo:(NSMutableDictionary *)userDic
{
   



}



    
    


#pragma --------------------------mark -- 注册邮箱验证码----------
    
-(void) RequetEmailForRegister:(NSString *)email
{

  


}
  
    



#pragma mark ------modify secret-----
//修改密码
-(void) requestModifySecret:(NSString *)oldSecret NewSecret:(NSString *)newSecret
{
   


}

#pragma mark - 广告
//获取登录时的广告
- (void)getLoginAd{
    
  
    
    
}






#pragma mark ---为游戏领取礼包设定的，手机号验证模块
//获取手机验证码
-(void) phoneVerifyCode_ForGift:(NSString *)phoneNumber
{
   

}

//请求手机号绑定
-(void) BindPhoneNumber_ForGift:(NSString *)phoneNumber VerifyCode:(NSString *)verityCode
{
   

}




-(void) requestUserInfo:(NSString *)userID phoneNumber:(NSString *)phoneNumber {
    
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];

    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
   
        [dict setObject:channelId forKey:@"channelID"];
        [dict setObject:@"2"forKey:@"type"];
        [dict setObject:dateStr forKey:@"ts"];
        [dict setObject:userID forKey:@"userID"];
        [dict setObject:phoneNumber forKey:@"phoneNumber"];


    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];

    
    NSString *urlStr = [NSString stringWithFormat:@"http://192.168.1.35/www/index.php?__msgID=userInfo&__appID=%@",appid];
    
    urlStr = [NSString stringWithFormat:@"%@&%@&sign=%@",urlStr,sortStr,sign];
    
    ////////NSLog(@"获取用户信息urlStr = %@",urlStr);

    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        
            ////////NSLog(@"获取用户信息= %@,urlStr = %@",data,urlStr);
        
                       
            
    } failure:^(NSError *error) {
        
        
        
    }];
    
}







@end
