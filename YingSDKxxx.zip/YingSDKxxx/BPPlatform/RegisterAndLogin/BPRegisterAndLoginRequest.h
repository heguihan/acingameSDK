//
//  BPRegisterAndLoginRequest.h
//  BigPlayerSDK
//
//

#import "BPHttpRequestBase.h" //没有用到

#define ExperienceInfoTableName @"experienceInfo"

@interface BPRegisterAndLoginRequest : NSObject

+(BPRegisterAndLoginRequest *) BPSharedRequest;

#pragma mark ------ login-----
//帐户登陆
-(void) requestLoginWithAccount:(NSString *)account Password:(NSString *)password;

// 手机号用户
-(void)requestLoginWithPhoneNumber:(NSString *)account Password:(NSString *)password;

// 游客账号
-(void) requestLoginWithVistor:(NSString *)userID token:(NSString *)token;


//微信帐户登陆
-(void) requestLoginWithWeChat:(NSString *)userID NickName:(NSString *)nickname;

 //qq帐户登陆
-(void) requestLoginWithQQAccount:(NSString *)openId NickName:(NSString *)nickName;





#pragma mark ------register------
/************************
 //注册帐户
 //account: 帐号
 //password: 密码
 // securityCode 注册
 *************************/

// 账户名注册
-(void) requestRegisterWithAccount:(NSString *)account Password:(NSString *)password registerType:(NSString *)registerType;

// 手机号注册
-(void) RequestPhoneVerifyCodeForRegister:(NSString *)phoneNumber;   // 注册手机验证码

-(void) requestRegisterWithAccount:(NSString *)account Password:(NSString *)password SecurityCode:(NSString *)securityCode registerType:(NSString *)registerType;


//游客模式，快速进入
-(void) oneSecondRegiste;


//获取手机验证码
-(void) RequestPhoneVerifyCode:(NSString *)phoneNumber;

//请求手机号绑定
-(void) RequestBindPhoneNumber:(NSString *)phoneNumber VerifyCode:(NSString *)verityCode;








































// 注册选择
-(void)selectRegisterMethodActionMode;
-(void) RequetEmailForRegister:(NSString *)email;        // 注册邮箱的验证码




//一秒注册，获取用户的帐户
-(void) GetUserAccountWhenOneSecondRegister;


//用户修改账号(通行证)
-(void) RequestModifyAccount:(NSString *)account;
#pragma mark ---------logout------
/************************
 //注销帐户
 *************************/
-(void) requestLogout;

#pragma mark -------forget password----
/************************
 //通过邮箱或手机找回密码
 //account: 帐号
 //num: 邮箱号／手机号
 //Type:是通过邮箱还是手机 0--手机， 1----邮箱
 *************************/

-(void) backPasswordByPhoneOrMailNum:(NSString *)num Type:(int)type;




#pragma mark ------modify secret-----
//修改密码
-(void) requestModifySecret:(NSString *)oldSecret NewSecret:(NSString *)newSecret;


//获取手机验证码
-(void) phoneVerifyCode_ForGift:(NSString *)phoneNumber;
//请求手机号绑定
-(void) BindPhoneNumber_ForGift:(NSString *)phoneNumber VerifyCode:(NSString *)verityCode;




/*
    请求用户信息
 */
-(void) requestUserInfo:(NSString *)userID phoneNumber:(NSString *)phoneNumber ;









@end
