//
//  BPAccountExceptionViewController.m
//  BigPlayerSDK
//
//

#import "BPAccountExceptionViewController.h"

@interface BPAccountExceptionViewController ()

@end

@implementation BPAccountExceptionViewController
@synthesize loginView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void) leftButtonItemAction
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSURL *requestURL =[ [ request URL ] retain ];
    if([[requestURL absoluteString] rangeOfString:@"result=1"].location != NSNotFound)
    {
        NSString *result =[[requestURL absoluteString] substringFromIndex:([[requestURL absoluteString] rangeOfString:@"key="].location + 4)];
        
        NSMutableDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:[ShuZhiZhangUtility decodeBase64:result] options:NSJSONReadingMutableContainers error:nil];
            UITextField * userField = (UITextField * )[loginView viewWithTag:9101];
        UITextField * passwordField = (UITextField * )[loginView viewWithTag:9102];
        userField.text = [BPDESEncryption desDecodeWithText:[resultDic objectForKey:@"uname"]];
        passwordField.text = [BPDESEncryption desDecodeWithText:[resultDic objectForKey:@"pwd"]];
        
        [self leftButtonItemAction];
    }
    [requestURL release ];
    
    return YES;
}
@end
