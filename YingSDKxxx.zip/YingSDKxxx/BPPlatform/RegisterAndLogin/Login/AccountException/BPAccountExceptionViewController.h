//
//  BPAccountExceptionViewController.h
//  BigPlayerSDK
//
//

#import "BPWebViewBaseViewController.h"

@interface BPAccountExceptionViewController : BPWebViewBaseViewController
{
    UIView *loginView;
}
@property (nonatomic,assign) UIView *loginView;
@end
