//
//  BigPlayerSDKBase+LoginAndOut.h
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-18.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase.h"
#import "BPLoginPublic.h"
#import "BPShowADForIDFAView.h"

@interface BigPlayerSDKBase (LoginAndOut)

//检测是否可以自动登陆
-(void) autoLoginFromDatabase;

//传用户名，密码，类型进行登陆，主要用于被其他应用呼起时的登陆
-(void) loginWithUserName:(NSString *)userName AndPassword:(NSString *)password Type:(int)type;

//注销用户
-(void) BPLogout;

//用应用那边的帐户进行登陆
-(void) AutoLoginWithAppAccount;





@end
