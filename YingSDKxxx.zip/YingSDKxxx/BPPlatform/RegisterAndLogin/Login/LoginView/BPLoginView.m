//
//  BPLoginView.m
//  BigPlayerSDK
//
//

#import "BPLoginView.h"
#import "BPWebViewBaseViewController.h"
#import "BPAccountExceptionViewController.h"
#import "BPRegisterSelectView.h"
#import "BPNotificationName.h"
#import "HJManagedImageV.h"
#import "BPPublicHandle.h"
#import "BPOneSecondRegisterView.h"
#import "BPCustomLoginView.h"


#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "BPVistorTipsView.h"
#import "BPPhoneLoginView.h"
#import "BPCustomLoginView.h"
#import "BPBindPhoneView.h"
#import "KeyChainSave.h"
#import "HGHUUID.h"
#import "HTTPRequest.h"
#import "Tracking.h"
@implementation BPLoginView
@synthesize loginRequest;
@synthesize userInfoDic;
@synthesize userInfoTable;

@synthesize accountDropDownList;
@synthesize sinaInfoDic;

@synthesize QQInfoDic;

@synthesize AdImageDic;


//@synthesize registerRequest;




-(void) dealloc
{
   
    [loginRequest release];             loginRequest = nil;
    [userInfoDic release];              userInfoDic = nil;
    [userInfoTable release];            userInfoTable = nil;
    [accountDropDownList release];      accountDropDownList = nil;
    [sinaInfoDic release]; sinaInfoDic = nil;
    [QQInfoDic release];   QQInfoDic = Nil;
    [AdImageDic release];  AdImageDic = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        self.tag = 9999;
        self.AdImageDic = [[[NSMutableDictionary alloc] initWithCapacity:10] autorelease];
        userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
        [self showLoginViews];


        self.multipleTouchEnabled = YES;
        
        
        BPCustomLoginView *view = [[BPCustomLoginView alloc]init];
        view.loginViw = self;    // 传递自身对象
        
    }
    return self;
}


// 显示注册页面
-(void) showLoginViews
{
    
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/new_BP_background.png"]];
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2.0,(REAL_SCREEN_HEIGHT - BPBackImageHeight)/2.0, BPBackImageWidth, BPBackImageHeight);
    backImageView.userInteractionEnabled = YES;
    backImageView.layer.masksToBounds = YES;
    backImageView.contentMode = UIViewContentModeScaleToFill;
    backImageView.layer.cornerRadius = 5;
    ////////NSLog(@"汉字xxxxx=界面出来了");
    [self addSubview:backImageView];
    

// 左上角小X按钮
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_close.png"] forState:UIControlStateHighlighted];
    leftButton.frame = CGRectMake(BPBackImageWidth-30, 5, 45, 45);
    [leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 20, 20)];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
//    [backImageView addSubview:leftButton];
    
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-100)/2, 0, 100, 40)];
    lab.text = @"登录";
    lab.textColor = [UIColor whiteColor];
    lab.font = [UIFont fontWithName:@"Helvetica-Bold" size:35];
    lab.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:lab];

    UILabel *choselable1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 75, BPBackImageWidth, 40)];
    choselable1.backgroundColor = [UIColor clearColor];
    choselable1.font = [UIFont systemFontOfSize:15];
    choselable1.textColor = [UIColor orangeColor];
    choselable1.textColor = [UIColor blackColor];
    choselable1.text = @"请选择登录方式";
    choselable1.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:choselable1];
    
    
    //游客登陆
    UIButton *autoLogin_button = [UIButton buttonWithType:UIButtonTypeCustom];
    autoLogin_button.frame =CGRectMake((BPBackImageWidth-240)/2, 115, 60, 60);
    [autoLogin_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/new_BPYingsdk_vistorLogin.png"] forState:UIControlStateNormal];
    autoLogin_button.layer.cornerRadius = 30;
    [autoLogin_button setExclusiveTouch:YES];   //  避免多点触控

    [autoLogin_button addTarget:self action:@selector(clickAutoLoginButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:autoLogin_button];
    
    
    // 注册
    UIButton *register_button = [UIButton buttonWithType:UIButtonTypeCustom];
    register_button.frame =CGRectMake((BPBackImageWidth-60)/2, 115, 60, 60);
    [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/new_BPYingsdk_yingLogin.png"] forState:UIControlStateNormal];
    register_button.layer.cornerRadius = 30;
    [autoLogin_button setExclusiveTouch:YES];
    [register_button addTarget:self action:@selector(clickRegisterButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:register_button];

    // 手机
    UIButton *phone_button = [UIButton buttonWithType:UIButtonTypeCustom];
    phone_button.frame =CGRectMake((BPBackImageWidth+120)/2, 115, 60, 60);
    [phone_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/new_BPYingsdk_phoneLogin.png"] forState:UIControlStateNormal];
    phone_button.layer.cornerRadius = 30;
    [phone_button setExclusiveTouch:YES];
    [phone_button addTarget:self action:@selector(clickPhoneRegisterButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:phone_button];
    
    
    NSArray *arr = @[@"快速游戏",@"账号登录",@"手机登录"];
    for (int i = 0 ; i < 3 ; i++) {
        
        UILabel *vistorLable = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-240+180*i)/2, 160, 60, 60)];
        vistorLable.backgroundColor = [UIColor clearColor];
        vistorLable.font = [UIFont systemFontOfSize:12];
        vistorLable.textColor = [UIColor blackColor];
        vistorLable.text = arr[i];
        vistorLable.textAlignment = NSTextAlignmentCenter;
        [backImageView addSubview:vistorLable];
    }
    
    
    
  //hghaaa登录界面
    
    UILabel *choselable = [[UILabel alloc]initWithFrame:CGRectMake(0, 200, BPBackImageWidth, 40)];
    choselable.backgroundColor = [UIColor clearColor];
    choselable.font = [UIFont systemFontOfSize:12];
    choselable.textColor = [UIColor colorWithRed:116/255.0 green:116/255.0 blue:116/255.0 alpha:1];
    choselable.text = @"—————— 或通过以下方式登录 ——————";
    choselable.textAlignment = NSTextAlignmentCenter;
//    [backImageView addSubview:choselable];

    
//    
//    if([BigPlayerSDKBase getSharedBPPlatform].BPShouldShowQQSinaFLag)
//    {

        //QQ登陆
        UIButton * QQLogin = [UIButton buttonWithType:UIButtonTypeCustom];
        //[QQLogin setTitle:[BPLanguage getStringForKey:@"BPLogin" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
        QQLogin.titleLabel.font = [UIFont boldSystemFontOfSize:16.0f];
        [QQLogin setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [QQLogin setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_qq.png"] forState:UIControlStateNormal];
        [QQLogin setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_qq.png"] forState:UIControlStateHighlighted];
        QQLogin.layer.cornerRadius = 5;
        QQLogin.layer.masksToBounds = YES;
        [QQLogin addTarget:self action:@selector(QQLogin) forControlEvents:UIControlEventTouchUpInside];
//        [backImageView addSubview:QQLogin];
        QQLogin.frame = CGRectMake((BPBackImageWidth-260)/2, 245, 120, 35);

    //微信登录
        UIButton * wechatLogin = [UIButton buttonWithType:UIButtonTypeCustom];
               //[wechatLogin setTitle:[BPLanguage getStringForKey:@"BPLogin" InTable:@"BPMultiLanguage"] forState:UIControlStateNormal];
        wechatLogin.titleLabel.font = [UIFont boldSystemFontOfSize:16.0f];
        [wechatLogin setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [wechatLogin setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_weichat.png"] forState:UIControlStateNormal];
        [wechatLogin setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_weichat.png"] forState:UIControlStateHighlighted];
        wechatLogin.layer.cornerRadius = 5;
        wechatLogin.layer.masksToBounds = YES;
        [wechatLogin addTarget:self action:@selector(wechatLogin) forControlEvents:UIControlEventTouchUpInside];
      //  if ([WXApi isWXAppInstalled]) {
    
        wechatLogin.frame = CGRectMake((BPBackImageWidth-260)/2+140, 245, 120, 35);
//            [backImageView addSubview:wechatLogin];

//        }else{
//        
//            QQLogin.frame = CGRectMake((BPBackImageWidth-150)/2, 245, 150, 35);
//        
//        }
   //  }

    
  //  [self getLastLoginUserFromDatabase];
}




#pragma mark ------userInfo table update----------
//自动登陆，或是显示上次登陆的帐户密码
-(void) getLastLoginUserFromDatabase
{
    NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where time=(select max(tokenCreateTime) from %@)",BPUserInfoTableName,BPUserInfoTableName];
    NSMutableDictionary *dic = [[userInfoTable queryForDataWithSql:sqlStr] objectAtIndex:0];
    
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
   //
    if(dic)
    {
        if ([[dic objectForKey:@"userType"] isEqualToString:@"0"]) {
            userField.text = [BPDESEncryption desDecodeWithText: [dic objectForKey:@"username"]];
            passwordField.text = [BPDESEncryption desDecodeWithText: [dic objectForKey:@"password"]];
        }else{
            userField.text = @"";
            passwordField.text = @"";
        } 
    }
    else
    {
        NSDictionary *dic = [ShuZhiZhangUtility getAccountAndPasswordFromKeyChain];

        if(dic && dic.allKeys.count>0)
        {
            userField.text = [BPDESEncryption desDecodeWithText: [dic objectForKey:@"BPAccount"]];
            passwordField.text = [BPDESEncryption desDecodeWithText: [dic objectForKey:@"BPPassword"]];
        }
    }
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
  
    if(accountDropDownList.frame.size.height>10)
    {
    }
    [accountDropDownList hideDropDownList];
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    

    
}


#pragma mark -------------BP login and register------------
//hghyyy登录和注册入口
// 账号注册
-(void)clickRegisterButton{

    BPCustomLoginView *loginviesw =  [[BPCustomLoginView alloc]init];
    [self addSubview:loginviesw];
    [loginviesw release];
    
    
}

-(void)clickPhoneRegisterButton{

    BPPhoneLoginView *registerViesw =  [[BPPhoneLoginView alloc]init];
    [self addSubview:registerViesw];
    [registerViesw release];
}

//点击一秒注册
//hghcccc游客登录

-(void) clickAutoLoginButton
{

//    NSDictionary *dictUser = [KeyChainSave getUserInfo];
//    ////////NSLog(@"vistorUserinfo=%@",dictUser);
//    if (dictUser == nil) {
//        [self addSubview: [[BPVistorTipsView alloc] init]];      // 提示手机注册
//        return;
//    }else{
        NSString *uuid = [HGHUUID getUUID];
        NSLog(@"uuid");
        [self requestLoginWithAccount:uuid];
        [self removeFromSuperview];
        return;
//    }
    

}

-(void)requestLoginWithAccount:(NSString *)device{
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    [dict setObject:channelId forKey:@"channelID"];
    [dict setObject:device forKey:@"deviceID"];
    [dict setObject:@"3"forKey:@"type"];
    [dict setObject:dateStr forKey:@"ts"];
//    [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    ////////NSLog(@"账号密码登录");
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"register",appid,sortStr,sign];
    
    ////////NSLog(@"账号登录dict = %@,urlStr = %@",dict,urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
        /*
         登录dict = {
         accountType = 3;
         msg = "Success.";
         phoneNumber = "";
         ret = 0;
         timestamp = 1564391454;
         token = "eyJpZGVudGlmaWVyIjoiMzYwMGY3YzVhMjg2ZDczOTU2OGYyODhmNGVjZDJjNGQiLCJleHBpcmUiOjE1NjQzOTg2NTQsIm5vbmNlU3RyIjoiSzBMa2ExT3VhWFU2Y29peUdxWHgwVmZKUGlCTno0WkEiLCJ0b2tlbiI6IjZlMDEyNzVhMWFiZTQyMzNlODgxNjFhMTA1ZTUxNDZkNTdjYjgyMThlYWE0MDNmNGQ0OTBjNmQ4N2FjYjZjMTMifQ==";
         tokenCreateTime = 1564391454;
         userID = y10000053;
         yingID = 0286347a404923d19def6d3b1c7f2c2a;
         }
         
         */
            NSString *phoneNO = [NSString stringWithFormat:@"%@",data[@"phoneNumber"]];
            if ([data[@"phoneNumber"] isEqualToString:@""]||data[@"phoneNumber"]==NULL) {
                [[BPBindPhoneView ShareInstance] showBindPhoneTipsThings:@"亲爱的玩家,您正在使用非正式账号登录,建议尽快绑定手机账号,防止游戏记录丢失." type:1];
            }
            
            
            ////////NSLog(@"登录dict = %@",data);
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                [self removeFromSuperview];
                ////////NSLog(@"登录成功");
                BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
                [view removeFromSuperview];
                [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
                
//                [ShuZhiZhangUserPreferences setCurrentUserID:account];    // 存储当前userID
//
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
//                [userInfo setObject:account forKey:@"userID"] ;
                [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
//                [userInfo setObject:password forKey:@"password"];
//                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
                [BPLoginPublic userDidLoginAction:userInfo];
                [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_login_cb"];
                [Tracking setLoginWithAccountID:[userInfo objectForKey:@"userID"]];
                [BPShowLoginPrompt showWithName:[userInfo objectForKey:@"userID"]];
//                [[NSUserDefaults standardUserDefaults] setObject:account forKey:@"acingameAccount"];
//                [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"acingamePassword"];
                [[NSUserDefaults standardUserDefaults] setObject:userInfo[@"id"] forKey:@"reportID"];
                [[NSUserDefaults standardUserDefaults] synchronize];
//
//                [HGHUserTypeSave saveUserTypeWithUsername:account password:password field:@"hghuserlogintype"];
//                [BPShowLoginPrompt showWithName:account];
//
//                // 更新
//                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
//                [userInfoTable UpdateDataToTable:sqlStr];
//
                
            }else{
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePassword"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingameAccount"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhonePassword"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhone"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"loginway"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
            }
        });
    } failure:^(NSError *error) {
        ////////NSLog(@"s失败");
        
    }];
    
}


///*
// * 游客模式
// *
// * 一秒注册，快速进入
// */
//-(void) oneSecondRegiste
//{
//    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
//    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
//    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
//
//    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?type=3",GLOBAL_LOGIN_API_URL,@"register",appid];
//    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
//    NSString * signStr = [NSString stringWithFormat:@"channelID=%@&ts=%@&type=3&key=%@",channelId,dateStr,appsecret];
//    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
//    urlStr = [NSString stringWithFormat:@"%@&channelID=%@&ts=%@&sign=%@",urlStr,channelId,dateStr,sign];
//
//    ////////NSLog(@"hghtest33333333333333333333url=%@",urlStr);
//    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
//
//        dispatch_async(dispatch_get_main_queue(), ^{
//
//            ////////NSLog(@"游客注册dict = %@,urlStr = %@",data,urlStr);
//            if (data.count==0) {
//                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
//                return ;
//            }
//          NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
//            if ([[data objectForKey:@"ret"] intValue]==0) {
//
//               [self registCompleteAndExit];
//                [userInfo setObject:[[data objectForKey:@"token"] substringToIndex:8] forKey:@"password"];
//                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
//                [BPLoginPublic userDidLoginAction:userInfo];
//                [BPShowLoginPrompt showWithName:[NSString stringWithFormat:@"用户%@", [data objectForKey:@"userID"]]];
//                ////////NSLog(@"qqqqqqqqqqqqqqqqqqqqqqqqqqqqqxx");
//                [ShuZhiZhangUserPreferences setCurrentUserID:[data objectForKey:@"userID"]];
//                [[BPBindPhoneView ShareInstance] showBindPhoneTipsThings:@"亲爱的玩家,您正在使用非正式账号登录,建议尽快绑定手机账号,防止游戏记录丢失."  type:1];
//
//            }else{
//
//                [BPCustomNoticeBox showCenterWithText:@"注册失败" duration:2.0];
//            }
//        });
//
//    } failure:^(NSError *error) {
//
//    }];
//
//}

//游客登录成功并自动关闭界面
-(void) registCompleteAndExit
{
    [self removeFromSuperview];
    //发送注册成功消息
    ////////NSLog(@"post444444444444");
//    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:[ShuZhiZhangUserPreferences getCurrentToken],@"token",@"BPLoginSuccess", @"result",nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
    [BPShowLoginPrompt showWithName:@""];
    
}


// 账号登录
-(void)loginCommon{
    
    BPCustomLoginView *custonView = [[BPCustomLoginView alloc]init];
    [self addSubview:custonView];
    custonView.loginViw  = self;
    [custonView release];
    
}





#pragma mark --------request delegate---------
-(void) loginErrorTishi:(int) response
{
    //    UILabel * remindLabel = (UILabel *)[self.view viewWithTag:510];
    if(response == 0)
    {
        //        remindLabel.text = @"密码错误！";
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordErrorPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        
        
    }
    else if(response ==-30)
    {
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccountNotExistPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
    }
    else if (response == -35)
    {
        
        BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:@"冻结提示" message:@"由于你违反了相关的协议，你的账号已被冻结"  delegate:self cancelButtonTitle:@"申诉" otherButtonTitles:@"确认",nil];
        alert.tag = 2015;
        [alert show];
        [alert release];
    }
    else if (response == -12)
    {
        BPCustomAlertView *alert = [[BPCustomAlertView alloc] initWithTitle:@"冻结提示" message:@"由于你违反了的相关协议，你的设备已被冻结"  delegate:self cancelButtonTitle:@"申诉" otherButtonTitles:nil];
        alert.tag = 2015;
        [alert show];
        [alert release];
    }
    else
    {
        
           [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPLoginFailPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
    }
}

#pragma mark - UIAlertView Delegate Method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        
        
    }else{
        //申诉
        NSString *stringURL = [NSString stringWithFormat:@"http://files.iwangyou.com/html/appeal/index.html?mac=%@",[ShuZhiZhangUtility macaddress]];
        NSURL *url = [NSURL URLWithString:stringURL];
        [[UIApplication sharedApplication] openURL:url];
    }
    
    
}




-(void) clickCancelButton
{
    [self leftButtonItemAction];
    
}

//返回
-(void) leftButtonItemAction
{
    HJManagedImageV *adImageLeft = (HJManagedImageV*)[self viewWithTag:2015];
    HJManagedImageV *adImageRight = (HJManagedImageV*)[self viewWithTag:2015];
    
    [adImageLeft setHidden:YES];
    [adImageRight setHidden:YES];
    
    UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
   //  [loginRequest cancelAllRequest];
    [UIView animateWithDuration:.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                         //[ShuZhiZhangUtility postPlatformExitNotification];
                     }];
    
    
}






-(void) dimissLoginPage:(NSString *)name
{
    UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
    [loginRequest cancelAllRequest];
    [UIView animateWithDuration:.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                         [BPShowLoginPrompt showWithName:name];
                     }];
}



-(void)playSoundRemoveFromSuperview:(NSNotification *)notify{

//       UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
        [UIView animateWithDuration:0.05
                         animations:^{
//                             backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.05, 0.05);
                         }
                         completion:^(BOOL finished) {
                             [self removeFromSuperview];
                        [UIView animateWithDuration:1.0 animations:^{
                            
                        } completion:^(BOOL finished) {
                            
                            [BPLoginPublic postThirdLoginSuccessNotification];
                            
                        }];
                }];
    
 

}





@end
