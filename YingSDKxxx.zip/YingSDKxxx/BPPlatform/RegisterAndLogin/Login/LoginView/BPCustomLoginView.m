//
//  CustomLoginView.m
//  BigPlayerSDK
//
//  Created by teamtop on 15/12/1.
//  Copyright © 2015年 John Cheng. All rights reserved.
//

#import "BPCustomLoginView.h"
#import "BPLoginView.h"
#import "BPWebViewBaseViewController.h"
#import "BPAccountExceptionViewController.h"
#import "BPRegisterSelectView.h"
#import "BPNotificationName.h"
#import "HJManagedImageV.h"
#import "BPPublicHandle.h"
#import "BPCustomNoticeBox.h"
#import "HGHUserTypeSave.h"
#import "DropListVC.h"
#import "BPBindPhoneView.h"
#import "HTTPRequest.h"
#import "Tracking.h"
@interface BPCustomLoginView ()<DropDownListDelegate,UITextFieldDelegate,DropListVCDelegate>
@property(nonatomic,strong)BPCustomTextField *userTF;
@property(nonatomic,strong)BPCustomTextField *pwdTF;

@end

@implementation BPCustomLoginView

@synthesize loginRequest;
@synthesize userInfoDic;
@synthesize userInfoTable;
@synthesize AccountArray;
@synthesize accountDropDownList;
@synthesize sinaInfoDic;
@synthesize QQInfoDic;

@synthesize AdImageDic;

@synthesize adClickBlock;
- (void)dealloc
{
    [AccountArray release];
    AccountArray = nil;
   
    [super dealloc];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
       
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor blackColor];
        background.alpha = 0.3;
        [self addSubview:background];
        [background release];
        
        self.AdImageDic = [[[NSMutableDictionary alloc] initWithCapacity:10] autorelease];
        
        userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
        NSString *sqlStr = [NSString stringWithFormat:@"select * from %@",BPUserInfoTableName];
        self.AccountArray = [userInfoTable queryForDataWithSql:sqlStr];
        
        
        
        for(int i = 0;i<AccountArray.count;i++)
        {
            NSDictionary *dic = [AccountArray objectAtIndex:i];
            if([[dic objectForKey:@"accountType"] intValue]!= 2)
            {
                [AccountArray removeObjectAtIndex:i];
                i--;
            }
        }
        ////////NSLog(@"普通账号AccountArray = %@",AccountArray);
        [ShuZhiZhangUtility sortArrayWithKey:@"tokenCreateTime" SortArray:AccountArray isAscending:NO];
        [self createLoginSubViews];
        
        //添加广告
    }
    return self;
}

-(void)createLoginSubViews
{
    
    self.alpha = 0.0;
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.alpha = 1.0;
                     }
                     completion:^(BOOL finished) {
                         
                }];
    
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2.0,(REAL_SCREEN_HEIGHT - BPBackImageHeight)/2.0, BPBackImageWidth, BPBackImageHeight);
    backImageView.userInteractionEnabled = YES;
    [self addSubview:backImageView];
    backImageView.tag = 13100;
    [backImageView release];
    
    
    
    UIImageView * headLogView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BPYingsdk_logo.png"]];
    headLogView.frame = CGRectMake((BPBackImageWidth-100)/2,10, 100, 60);
    headLogView.userInteractionEnabled = YES;
    headLogView.layer.masksToBounds = YES;
    headLogView.contentMode = UIViewContentModeScaleToFill;
    headLogView.layer.cornerRadius = 5;
//    [backImageView addSubview:headLogView];
    
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake((BPBackImageWidth-100)/2, 0, 100, 40)];
    lab.text = @"登录";
    lab.textColor = [UIColor whiteColor];
    lab.font = [UIFont fontWithName:@"Helvetica-Bold" size:35];
    lab.textAlignment = NSTextAlignmentCenter;
    [backImageView addSubview:lab];
    
    
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(15, 10, 25, 25);
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateNormal];
    [leftButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/goback.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(clickCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:leftButton];

    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake((BPBackImageWidth-250)/2, 100, 250,100)];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.scrollEnabled = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.tag = 999888;
    scrollView.contentOffset = CGPointMake(0, 0);
    scrollView.contentSize  =CGSizeMake(250, 150);
    [backImageView addSubview:scrollView];
    
    
#pragma  登录
    BPCustomTextField *userField = [[BPCustomTextField alloc] init];
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"acingameAccount"]) {
        userField.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"acingameAccount"];
    }else{
        userField.placeholder = @"请输入您的账号";
        //    [BPLoginPublic setTextFieldProperty:userField withDelegate:self];

    }
    userField.tag = 10000;
    self.userTF = userField;
    userField.PlaceholderOffset_x = 40;
    userField.PlaceholderOffset_y = 2;
    userField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    userField.layer.borderWidth =1.0;
    userField.layer.cornerRadius =5.0;
    userField.font = [UIFont systemFontOfSize:14];
    userField.backgroundColor = [UIColor whiteColor];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    userField.textAlignment = NSTextAlignmentLeft;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    userField.delegate = self;
    [scrollView addSubview:userField];
    userField.returnKeyType = UIReturnKeyNext;
    userField.tag = 9101;
    [userField release];
    
    
    UIImageView *userImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_user.png"]];
    userImage.layer.cornerRadius = 5;
    userImage.layer.masksToBounds = YES;
    userImage.frame = CGRectMake(0, 0, 40, 40);
    [userField addSubview:userImage];
    [userImage release];

    
    
    //帐户切换
    if(AccountArray && AccountArray.count>1)
    {
    // 历史号码切换按钮
        UIButton *moreAccount = [UIButton buttonWithType:UIButtonTypeCustom];
        [moreAccount addTarget:self action:@selector(clickMoreAccount) forControlEvents:UIControlEventTouchUpInside];
        moreAccount.tag = 11008;
        [moreAccount setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/ListAccount.png"] forState:UIControlStateNormal];
        moreAccount.frame = CGRectMake(BPBackImageWidth-90, 0, 40, 40);
        [userField addSubview:moreAccount];
    }
    
 
    //密码
    BPCustomTextField *passwordField = [[BPCustomTextField alloc] init];

    
    
    self.pwdTF = passwordField;
    passwordField.tag = 10001;
    passwordField.layer.borderWidth =1.0;
    passwordField.layer.cornerRadius =5.0;
    passwordField.font = [UIFont systemFontOfSize:14];
    passwordField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    passwordField.delegate= self;
    passwordField.textAlignment = NSTextAlignmentLeft;
    passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePassword"]) {
        passwordField.text = [[NSUserDefaults standardUserDefaults]objectForKey:@"acingamePassword"];
    }else{
        passwordField.placeholder = @"请输入您的密码";
    }
    passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    passwordField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    
    passwordField.PlaceholderOffset_x = 40;
    passwordField.PlaceholderOffset_y = 2;
    passwordField.layer.borderColor = [UIColor colorWithRed:174/255.0f green:166/255.0f blue:149/255.0f alpha:1].CGColor;
    passwordField.layer.borderWidth = 1.0;
    passwordField.returnKeyType = UIReturnKeyGo;
    passwordField.secureTextEntry= YES;
    passwordField.tag = 9102;
    [scrollView addSubview:passwordField];
    [passwordField release];
    
    UIImageView *passwordImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_icon_password.png"]];
    passwordImage.layer.cornerRadius=8;
    passwordImage.layer.masksToBounds = YES;
    passwordImage.frame = CGRectMake(0, 0, 40, 40);
    [passwordField addSubview:passwordImage];
    [passwordImage release];
    
    
#pragma mark -- 立即登录
    UIButton * Common_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [Common_button setTitle:@"立即登录" forState:UIControlStateNormal];
    Common_button.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
    [Common_button setTitleColor:[UIColor colorWithRed: 98/255.0 green:18/255.0 blue:131/255.0 alpha:1]forState:UIControlStateNormal];
//    [Common_button setBackgroundColor:[UIColor colorWithRed: 160/255.0 green:175/255.0 blue:250/255.0 alpha:1]];
    [Common_button setBackgroundColor:[UIColor whiteColor]];
    Common_button.layer.cornerRadius = 5;
    [Common_button setExclusiveTouch:YES];  //  防止多点触控
    [Common_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_finish_regist.png"] forState:UIControlStateNormal];
    [Common_button addTarget:self action:@selector(loginCommon) forControlEvents:UIControlEventTouchUpInside];
    Common_button.frame = CGRectMake((BPBackImageWidth - 250)/2.0, 210, 250, 40);
    [backImageView addSubview:Common_button];

    //重设密码
    UIButton * re_password_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [re_password_button setTitle:@"找回密码" forState:UIControlStateNormal];
    [re_password_button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    re_password_button.backgroundColor = [UIColor clearColor];
    [re_password_button setExclusiveTouch:YES];

    re_password_button.titleLabel.font = [UIFont systemFontOfSize:14.0f];
    [re_password_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [re_password_button addTarget:self action:@selector(resetPassword) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:re_password_button];
    
    //注册
    UIButton * register_button = [UIButton buttonWithType:UIButtonTypeCustom];
    [register_button setTitle:@"注册账号" forState:UIControlStateNormal];
    register_button.backgroundColor = [UIColor clearColor];
    [register_button setExclusiveTouch:YES];

    register_button.titleLabel.font = [UIFont systemFontOfSize:14.0f];
    [register_button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [register_button addTarget:self action:@selector(registerButton) forControlEvents:UIControlEventTouchUpInside];
    [backImageView addSubview:register_button];

    
    // 账户密码坐标
    userField.frame = CGRectMake(0, 0, 250, 40);
    passwordField.frame = CGRectMake(0, 50, 250, 40);
    register_button.frame = CGRectMake(BPBackImageWidth-100, 265, 80, 25);
    re_password_button.frame = CGRectMake(20, 265, 80, 25);
    
    if(AccountArray && AccountArray.count>1)
    {
        int w = 250;
        int y = 140;
        accountDropDownList = [[BPLoginAccountListView alloc] initWithFrame:CGRectMake((BPBackImageWidth-w)/2, y, w, 150) AndArray:AccountArray];
        accountDropDownList.delegate = self;
        [backImageView addSubview:accountDropDownList];
    }
//    [self getLastLoginUserFromDatabase];
}






#pragma mark ------userInfo table update----------
//自动登陆，或是显示上次登陆的帐户密码
-(void) getLastLoginUserFromDatabase
{
    NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where tokenCreateTime=(select max(tokenCreateTime) from %@)",BPUserInfoTableName,BPUserInfoTableName];
    
    NSMutableDictionary *dic = [[userInfoTable queryForDataWithSql:sqlStr] objectAtIndex:0];
    
    BPLog(@"上次登陆的账号信息dic = %@", dic );
    
//    [NSUserDefaults standardUserDefaults] setObject:[dic objectForKey:<#(nonnull id)#>] forKey:<#(nonnull NSString *)#>
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
    if(dic && [[dic objectForKey:@"accountType"] intValue] == 2)
    {
            userField.text =  [dic objectForKey:@"userID"];
            passwordField.text =  [dic objectForKey:@"password"];
            
        
            
    } else{
            userField.text = @"";
            passwordField.text = @"";
    }
}


#pragma mark ----drop list delegate-----
//-(void) didClickAtIndex:(NSIndexPath *)indexPath
-(void) didClickAtIndex:(NSIndexPath *)indexPath withTableView:(UITableView *)tableView
{
    NSDictionary *dic = [AccountArray objectAtIndex:indexPath.row];
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
    userField.text =  [dic objectForKey:@"userID"];
    passwordField.text =  [dic objectForKey:@"password"];
    
    //    [self showMoreButtonAnimation];
}

//显示点击帐号历史的动画
-(void) showMoreButtonAnimation
{
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UIButton *moreAccount = (UIButton *)[userField viewWithTag:11008];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.2];
    if(accountDropDownList.frame.size.height < 10)
    {
        moreAccount.transform = CGAffineTransformMakeRotation(M_PI * 90.0f / 180.0f);
    }
    else
    {
        moreAccount.transform = CGAffineTransformIdentity;
    }
    [UIView commitAnimations];
}

//点击查看历史账号
-(void) clickMoreAccount
{
    [self showMoreButtonAnimation];
    [accountDropDownList showOrHideDropDownList];
}


-(void) DidDeleteCell:(NSArray *)currentArray
{
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
    if(currentArray && currentArray.count>0)
    {
        NSDictionary *dic = [currentArray objectAtIndex:0];
        userField.text = [dic objectForKey:@"userID"];
        passwordField.text =[dic objectForKey:@"password"];
    }
    else
    {
        userField.text = @"";
        passwordField.text =@"";
        UIButton *moreAccount = (UIButton *)[userField viewWithTag:11008];
        moreAccount.hidden = YES;
        UIButton *register_button = (UIButton *)[self viewWithTag:9105];
        [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_Common_but.png"] forState:UIControlStateNormal];
        [register_button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_login_Common_but_sel.png"] forState:UIControlStateHighlighted];
        [register_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
}

#pragma mark -------------BP login and register------------

-(void)loginCommon{
    
//    [self getLastLoginUserFromDatabase];
//
//    return;
//    
    [self hideAllKeyBoard];

    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
    
    if (userField.text.length == 0  || passwordField.text.length == 0) {
    
        [BPCustomNoticeBox showCenterWithText:@"输入不能为空,请正确输入" duration:2.0];
        return;
    
    }
    if (userField.text.length <5) {
        
      [BPCustomNoticeBox showCenterWithText:@"账号名不正确" duration:2.0];
        return;
    }
    
    if (passwordField.text.length <6) {
        
        [BPCustomNoticeBox showCenterWithText:@"密码不正确" duration:2.0];
        return;
    }
    
    NSString *regularExpression = @"^[A-z0-9_@.]{5,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    
    NSString *pwdExpression = @"^[A-z0-9_@.]{6,18}$";
    NSPredicate *pwdtestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pwdExpression];
    if ([regextestmobile evaluateWithObject:userField.text] == NO)
    {
        
          [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPAccoutInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return;
    }
    if ([pwdtestmobile evaluateWithObject:passwordField.text] == NO)
    {
        
          [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return;
    }
    
// 登陆验证
    NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where userID ='%@'",BPUserInfoTableName,userField.text];
    
    NSMutableDictionary *dic = [[userInfoTable queryForDataWithSql:sqlStr] objectAtIndex:0];
    [BPQLoadingView showDefaultLoadingViewWithView:self]; // 加载动画
    
    if(BPDevice_is_ipad)
    {
        if(SCREEN_IS_LANDSCAPE)
        {
            [BPQLoadingView setLoadingViewPosition:(1024-80)/2 Position_Y:(768-80)/2];
        }
        else
        {
            [BPQLoadingView setLoadingViewPosition:(768-80)/2 Position_Y:(1024-80)/2];
        }
    }

//    if (dic && dic.allKeys > 0 && [[dic objectForKey:@"accountType"] intValue]==3) {
//        
//        [self requestLoginWithAccount:userField.text passWord:nil token:[dic objectForKey:@"token"]];
//
//        return;
//    }
//    [[NSUserDefaults standardUserDefaults] setObject:userField.text forKey:@"acingameAccount"];
//    [[NSUserDefaults standardUserDefaults] setObject:passwordField.text forKey:@"acingamePassword"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
    [self requestLoginWithAccount:userField.text passWord:passwordField.text token:nil];
    
}

// 登录
-(void)requestLoginWithAccount:(NSString *)account passWord:(NSString *)password token:(NSString *)token{
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    [dict setObject:channelId forKey:@"channelID"];
    [dict setObject:account forKey:@"userID"];
    [dict setObject:@"2"forKey:@"type"];
    [dict setObject:dateStr forKey:@"ts"];
    [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    ////////NSLog(@"账号密码登录");
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"login",appid,sortStr,sign];
    
    ////////NSLog(@"账号登录dict = %@,urlStr = %@",dict,urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{

         [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
        }
        
        ////////NSLog(@"登录dict = %@",data);
        if ([[data objectForKey:@"ret"] intValue]==0) {
            
            NSString *phoneNO = [NSString stringWithFormat:@"%@",data[@"phoneNumber"]];
            if ([phoneNO isEqualToString:@""]||phoneNO==NULL) {
                ////////NSLog(@"没有绑定");
                [[BPBindPhoneView ShareInstance] showBindPhoneTipsThings:@"亲爱的玩家,您正在使用非正式账号登录,建议尽快绑定手机账号,防止游戏记录丢失." type:2];
            }
            
            [self removeFromSuperview];
            ////////NSLog(@"登录成功");
            BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
            [view removeFromSuperview];
            [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
            [BPShowLoginPrompt showWithName:account];
            NSString *userID = data[@"userID"];
            [ShuZhiZhangUserPreferences setCurrentUserID:userID];    // 存储当前userID
            
            NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
//            [userInfo setObject:account forKey:@"userID"] ;
            [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
            [userInfo setObject:password forKey:@"password"];
//            [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
            [BPLoginPublic userDidLoginAction:userInfo];
            [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_login_cb"];
            [[NSUserDefaults standardUserDefaults] setObject:account forKey:@"acingameAccount"];
            [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"acingamePassword"];
            [[NSUserDefaults standardUserDefaults] setObject:@"2" forKey:@"loginway"];
            [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [HGHUserTypeSave saveUserTypeWithUsername:account password:password field:@"hghuserlogintype"];
            [BPShowLoginPrompt showWithName:account];
//            [HTTPRequest requestLogin:[NSString stringWithFormat:@"%@",userInfo[@"userID"]]];
            [Tracking setLoginWithAccountID:[userInfo objectForKey:@"userID"]];
            // 更新
            NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
            [userInfoTable UpdateDataToTable:sqlStr];
            
            
        }else{
            
            [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
            [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePassword"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingameAccount"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhonePassword"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhone"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"loginway"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
        }
    });
    } failure:^(NSError *error) {
        ////////NSLog(@"s失败");
        
    }];
    
}





#pragma mark -----------------忘记密码页面------------------
//忘记密码
- (void)resetPassword
{
    BPForgotPasswordView *forgotPassword = [[BPForgotPasswordView alloc] init];
    [self addSubview:forgotPassword];
    [forgotPassword release];
}

-(void)registerButton{

    BPRegisterView *selectView = [[BPRegisterView alloc]init];
    [self addSubview:selectView];
    [selectView release];


}


//账号异常
-(void) AccountException_Modify
{
    NSString *accountModifyUrl = [[NSUserDefaults standardUserDefaults] objectForKey:@"BP_AccountException_ModifyURL"];
    BPAccountExceptionViewController *viewController = [[BPAccountExceptionViewController alloc] initWithUrl:accountModifyUrl AndTitle:@"账号转换"];
    viewController.loginView = self;
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
    UIImage *image2 = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_nav_head.png"];
    image2 = [image2 resizableImageWithCapInsets:UIEdgeInsetsMake(25,10,10,10)];
    [navController.navigationBar setBackgroundImage:image2 forBarMetrics:UIBarMetricsDefault];
    [navController.navigationBar customNavigationBar];
    if(BPDevice_is_ipad)
    {
        navController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    [[ShuZhiZhangUtility getCurrentViewController] presentModalViewController:navController animated:YES];
    [navController release];
    [viewController release];
}
#pragma mark -------keyboard event-------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //限制输入的长度
    if (range.location >= 18&&![string isEqualToString:@""])
        return NO; // return NO to not change text
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    UITextField * userField = (UITextField * )[self viewWithTag:9101];
    UITextField * passwordField = (UITextField * )[self viewWithTag:9102];
    
    if(textField == userField)
    {
        [userField resignFirstResponder];
        [passwordField becomeFirstResponder];
    }
    else if(textField == passwordField)
    {
        [self loginCommon];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
//    ////////NSLog(@"test_tag=%d",textField.tag);
    UITextField * passwordField = (UITextField * )[self viewWithTag:9102];

    if(SCREEN_IS_LANDSCAPE){
    
        if (textField == passwordField ) {
            
        UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
        
        [UIView animateWithDuration:0.3 animations:^{
            
            scroll.contentOffset = CGPointMake(0, 50);
            
        }];
        scroll.scrollEnabled = YES;
    }
   
  }
    if (textField.tag==9101) {
        NSArray *arr = [[NSUserDefaults standardUserDefaults] objectForKey:@"hghuserlogintype"];
        ////////NSLog(@"arr_get=%@",arr);
        NSMutableArray *resultArr = (NSMutableArray *)[[arr reverseObjectEnumerator] allObjects];
        NSMutableArray *userArr = [NSMutableArray array];
        for (NSDictionary *dictxx in resultArr) {
            [userArr addObject:dictxx[@"userNamehgh"]];
        }
        DropListVC *list = [DropListVC dropListView];
        list.orginView = textField;
        list.dropDelegate = self;
        list.datas = [userArr copy];
        
//        list.datas = @[@"aaaaaaaaa",@"bbbbbbbbb",@"cccccccc",@"ddddddddd"];
        UIViewController *cvc = [ShuZhiZhangUtility getCurrentViewController];
//        [list showDropListWithViewController:cvc];
    }
    
}

#pragma mark - DropListVCDelegate
- (void)dropListView:(DropListVC *)dropListVC selectedResult:(NSString *)result selectedIndex:(NSInteger)index{
    ////////NSLog(@"%@,index=%ld",result,(long)index);
    NSArray *arr = [[NSUserDefaults standardUserDefaults] objectForKey:@"hghuserlogintype"];
    ////////NSLog(@"arr_get=%@",arr);
    NSMutableArray *resultArr = (NSMutableArray *)[[arr reverseObjectEnumerator] allObjects];
    self.userTF.text = result;
    self.pwdTF.text = resultArr[index][@"pwdhgh"];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    UIScrollView *scroll = (UIScrollView *)[self viewWithTag:999888];
    [UIView animateWithDuration:0.3 animations:^{
        
        scroll.contentOffset = CGPointMake(0, 0);
        
    }];
    scroll.scrollEnabled = NO;

//     [BPLoginPublic ViewScrollDown_little: self];
}

// 隐藏键盘
-(void) hideAllKeyBoard
{
    UITextField * userField = (UITextField *)[self viewWithTag:9101];
    UITextField * passwordField = (UITextField *)[self viewWithTag:9102];
    [userField resignFirstResponder];
    [passwordField resignFirstResponder];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self hideAllKeyBoard];
    if(accountDropDownList.frame.size.height>10)
    {
        [self showMoreButtonAnimation];
    }
    [accountDropDownList hideDropDownList];
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
}


#pragma mark - UIAlertView Delegate Method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        
        
    }else{
        //申诉
        NSString *stringURL = [NSString stringWithFormat:@"http://files.iwangyou.com/html/appeal/index.html?mac=%@",[ShuZhiZhangUtility macaddress]];
        NSURL *url = [NSURL URLWithString:stringURL];
        [[UIApplication sharedApplication] openURL:url];
    }
    
    
}


-(void) clickCancelButton
{
    [self leftButtonItemAction];
    
}

//返回
-(void) leftButtonItemAction
{
    [UIView animateWithDuration:0
                     animations:^{
                         self.alpha = 0.0;

                     }
                     completion:^(BOOL finished) {
                      
                         [self removeFromSuperview];
                        
    }];
}

-(void) dimissLoginPage:(NSString *)name
{
    UIImageView *backImageView = (UIImageView *)[self viewWithTag:13100];
    [UIView animateWithDuration:.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                         [BPShowLoginPrompt showWithName:name];
                     }];
}





@end
