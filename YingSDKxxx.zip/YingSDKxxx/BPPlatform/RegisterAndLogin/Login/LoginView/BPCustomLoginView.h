//
//  CustomLoginView.h
//  BigPlayerSDK
//
//  Created by teamtop on 15/12/1.
//  Copyright © 2015年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BPRegisterAndLoginRequest.h"
#import "BPOperateTable.h"
#import "BPPublicRequest.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPCustomTextField.h"
#import "BPLoginAccountListView.h"
#import "BPRegisterView.h"
#import "BPForgotPasswordView.h"
#import "BPCustomLoginView.h"
#import "BPLoginView.h"
#import "BPPhoneLoginView.h"



@interface BPCustomLoginView : UIView

@property (nonatomic,retain) BPRegisterAndLoginRequest *loginRequest;
@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@property (nonatomic,retain) BPOperateTable *userInfoTable;
@property (nonatomic,retain) NSMutableArray *AccountArray;

@property (nonatomic,retain) BPLoginAccountListView *accountDropDownList;

//@property (nonatomic , retain) BPShareInterface *share;

@property (nonatomic,retain) NSMutableDictionary * sinaInfoDic;

@property (nonatomic,retain) NSMutableDictionary * QQInfoDic;

@property (nonatomic,retain) NSMutableDictionary *AdImageDic;

@property (nonatomic,strong) void (^adClickBlock)(NSDictionary *dic, int index);

@property(nonatomic,strong) BPLoginView *loginViw;


-(void)requestLoginWithAccount:(NSString *)account passWord:(NSString *)password token:(NSString *)token;


@end
