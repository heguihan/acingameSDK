//
//  BPLoginView.h
//  BigPlayerSDK
//
//

#import <UIKit/UIKit.h>
#import "BPRegisterAndLoginRequest.h"
#import "BPOperateTable.h"
#import "BPPublicRequest.h"
#import "BPShowLoginPrompt.h"
#import "BPLoginPublic.h"
#import "BPCustomTextField.h"
#import "BPLoginAccountListView.h"         
#import "BPRegisterView.h"
#import "BPForgotPasswordView.h"

@interface BPLoginView : UIView<UITextFieldDelegate,DropDownListDelegate>



@property (nonatomic,retain) BPRegisterAndLoginRequest *loginRequest;

@property (nonatomic,retain) NSMutableDictionary *userInfoDic;
@property (nonatomic,retain) BPOperateTable *userInfoTable;

@property (nonatomic,retain) BPLoginAccountListView *accountDropDownList;

//@property (nonatomic , retain) BPShareInterface *share;

@property (nonatomic,retain) NSMutableDictionary * sinaInfoDic;

@property (nonatomic,retain) NSMutableDictionary * QQInfoDic;

@property (nonatomic,retain) NSMutableDictionary *AdImageDic;



@property(nonatomic,retain) BPLoginView *loginview;

// 切换注册的种类页面

//@property (nonatomic,retain) BPRegisterAndLoginRequest *registerRequest;



//返回
-(void) leftButtonItemAction;


@end
