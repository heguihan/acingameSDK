//
//  BPLoginPublic.h
//  BigPlayerSDK


#import <Foundation/Foundation.h>


@interface BPLoginPublic : NSObject

//创建账单信息表
+(void) createPaymentInfoTable;

//将登陆的玩家账单保持到本地数据库
+(void) savePaymentInfoToDatabase:(NSMutableDictionary *)dic;


//将登陆的玩家信息保持到本地数据库
+(void) saveUserInfoToDatabase:(NSMutableDictionary *)dic;

//发送登陆成功的消息
+(void) postLoginSuccessNotification:(NSMutableDictionary *)dic;
//发送登陆失败的消息
+(void) postLoginFailNotification:(NSString *)error;
//发送注销成功的消息
+(void) postLogoutSuccessNotification;
//发送注销失败的消息
+(void) postLogoutFailNotification:(NSString *)error;

//发送第三方登陆成功的消息
+(void) postThirdLoginSuccessNotification;
//第三方登陆成功后
+(void) ThirdUserDidLoginAction:(NSMutableDictionary *)dic;


//发送ShuZhiZhangSDK第三方登陆成功的消息
+(void) postThirdLoginSuccessNotificationOfOpenId:(NSDictionary *)dict loginType:(NSString *)loginType;

//创建用户信息表
+(void) createUserInfoTable;


//登陆成功后
+(void) userDidLoginAction:(NSMutableDictionary *)dic;
//登录成功之后上报DM
+(void) userDidLoginOrRegister:(NSDictionary *)dic ename:(NSString *)ename;
//设置输入框的一些属性
+(void) setTextFieldProperty:(UITextField *)userField withDelegate:(id)delegate;

//判断两个密码是否有效
+(BOOL) checkTwoPasswordValid:(NSString *)password ConfirmPassword:(NSString *)password2;

//缩放
+ (CGAffineTransform)transformForOrientation;
//显示小屏界面的背景和动画
+(void) showBackImageAndAnimation:(UIView *)superView;

//视图上移
+(void) ViewScrollUp_little:(UIView *) textField WillScrollView:(UIView *)scrollView;
//视图下移
+(void) ViewScrollDown_little:(UIView *)willScrollView;



// 提示
+(void) loginErrorTishi:(int) response;




@end
