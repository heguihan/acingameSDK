 //
//  BigPlayerSDKBase+LoginAndOut.m
//  BigPlayerSDK
//
//  Created by John Cheng on 13-6-18.
//  Copyright (c) 2015年 John FAN. All rights reserved.
//

#import "BigPlayerSDKBase+LoginAndOut.h"
#import "BPShowLoginPrompt.h"
#import "BPRegisterAndLoginRequest.h"
#import "BigPlayerSDKBase+BPCheckUpdate.h"
#import "BPButtonBoard.h"
#import "BPLoginView.h"
#import "BPCustomLoginView.h"
#import "HTTPRequest.h"
#import "Tracking.h"

@implementation BigPlayerSDKBase (LoginAndOut)

//自动登录
-(BOOL) AutoLoginWithDic:(NSMutableDictionary *)dic
{
    //帐户
    if( [[dic objectForKey:@"accountType"] intValue]==2)
    {
        [[BPRegisterAndLoginRequest BPSharedRequest] requestLoginWithAccount:[dic objectForKey:@"userID"] Password:[dic objectForKey:@"password"]];
        return YES;
    
    } // 手机号用户
    else if ([[dic objectForKey:@"accountType"] intValue]== 1){
        
        [[BPRegisterAndLoginRequest BPSharedRequest] requestLoginWithPhoneNumber:[dic objectForKey:@"phoneNumber"] Password:[dic objectForKey:@"password"]];
    }// 游客账户
    else if ([[dic objectForKey:@"accountType"] intValue]== 3){
        
        [[BPRegisterAndLoginRequest BPSharedRequest] requestLoginWithVistor:[dic objectForKey:@"userID"] token:[dic objectForKey:@"token"]];
    }
    //微信
    else if([[dic objectForKey:@"accountType"] intValue]==7)
    {
//        [[BPRegisterAndLoginRequest  BPSharedRequest]  requestLoginWithWeChat:[BPDESEncryption desEncodeWithText:[dic objectForKey:@"sinaweibo"]] NickName:[dic objectForKey:@"nickname"]];
        [self gotoLoginViewController];

        return YES;
    }
    //QQ
    else if([[dic objectForKey:@"accountType"] intValue]==6)
    {
//         [[BPRegisterAndLoginRequest  BPSharedRequest]  requestLoginWithQQAccount:[BPDESEncryption desEncodeWithText:[dic objectForKey:@"qqAccount"]] NickName:[dic objectForKey:@"nickname"]];
        
        [self gotoLoginViewController];
        return YES;
    }
    
    return NO;
}


-(void) gotoLoginViewController
{
    [BPQLoadingView hideWithAnimated:NO];
    UIViewController *currentViewControl_t = [ShuZhiZhangUtility getCurrentViewController];
    if(!currentViewControl_t)
    {

        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self gotoLoginViewController];
        });
        
        return;
    }
    
    BPLoginView *loginView = [[BPLoginView alloc] init];
    NSLog(@"%s, currentview==%@,AddLoginView",__func__,currentViewControl_t);
    [currentViewControl_t.view addSubview:loginView];
    
    [loginView release];
    return;
}



//用应用那边的帐户进行登陆
-(void) AutoLoginWithAppAccount
{
    NSString *account = [[NSUserDefaults standardUserDefaults] objectForKey:@"AccountFormYingSDKApp"];
    NSString *password =[[NSUserDefaults standardUserDefaults] objectForKey:@"PasswordFormYingSDKApp"];
    int type =[[[NSUserDefaults standardUserDefaults] objectForKey:@"TypeFormYingSDKApp"] intValue];
    //帐户
    switch (type) {
        //账户登录
        case 0:
            [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithAccount:account Password:password];
            break;
        // 微信登录
        case 1:
            [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithWeChat:account NickName:password];
            break;
        //QQ 登录
        case 3:
            [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithQQAccount:account NickName:password];
            break;
        default:
            [self gotoLoginViewController];
            break;
    }
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"AccountFormYingSDKApp"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"PasswordFormYingSDKApp"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"TypeFormYingSDKApp"];
}

//检测是否可以自动登陆
-(void) autoLoginFromDatabase
{
    NSLog(@"%s",__func__);
    if(SCREEN_IS_LANDSCAPE){
        
        [BPQLoadingView setLoadingViewPosition:([UIScreen mainScreen].bounds.size.height - 80)/2 Position_Y:([UIScreen mainScreen].bounds.size.width - 80)/2];
    }
    else{
        
        [BPQLoadingView setLoadingViewPosition:([UIScreen mainScreen].bounds.size.width - 80)/2 Position_Y:([UIScreen mainScreen].bounds.size.height - 80)/2];
    }
   
        BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
        NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where tokenCreateTime=(select max(tokenCreateTime) from %@)",BPUserInfoTableName,BPUserInfoTableName];
        NSMutableDictionary *dic = [[userInfoTable queryForDataWithSql:sqlStr] objectAtIndex:0];
        
        BPLog(@"&&&&&自动登陆%@&&&&&&&&&",dic);
        int nowTime =[[NSDate date] timeIntervalSince1970];
        //自动登陆
        NSString *loginway = [[NSUserDefaults standardUserDefaults] objectForKey:@"loginway"];
        ////////NSLog(@"loginway=%@",loginway);
        if ([loginway isEqualToString:@"2"]&&[[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePassword"]&&[[NSUserDefaults standardUserDefaults] objectForKey:@"acingameAccount"]){
            ////////NSLog(@"账号自动登录");
            NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePassword"];
            NSString *userName =[[NSUserDefaults standardUserDefaults] objectForKey:@"acingameAccount"];
            ////////NSLog(@"username=%@, password=%@",userName,password);
            [self requestLoginWithAccount:userName passWord:password token:nil];
        }else if ([loginway isEqualToString:@"phone"]&&[[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePhonePassword"]&&[[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePhone"]){
            ////////NSLog(@"手机自动登录");
            NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePhonePassword"];
            NSString *userName =[[NSUserDefaults standardUserDefaults] objectForKey:@"acingamePhone"];
            ////////NSLog(@"username=%@, password=%@",userName,password);
            [self phonerequestLoginWithAccount:userName passWord:password];
        }else{
            if(dic && nowTime - [[dic objectForKey:@"tokenCreateTime"] intValue]<2*24*3600 )
            {
                ////////NSLog(@"自动登录====== 11111111");
                [self AutoLoginWithDic:dic];
                
            }else{
                ////////NSLog(@"自动登录====== 22222222222");
                
                [self gotoLoginViewController];
                
            }
        }
    
        [userInfoTable release];

}
// 登录
-(void)phonerequestLoginWithAccount:(NSString *)account passWord:(NSString *)password{
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    //  [dict setObject:[dic objectForKey:@"accountType"] forKey:@"type"];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    
    
    if ([ShuZhiZhangUtility isMobileNumber:account])
    {
        [dict setObject:@"1"forKey:@"type"];
        [dict setObject:dateStr forKey:@"ts"];
        [dict setObject:channelId forKey:@"channelID"];
        [dict setObject:account forKey:@"phoneNumber"];
        [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    }
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"login",appid,sortStr,sign];
    
    ////////NSLog(@"账号登录dict = %@,urlStr = %@",dict,urlStr);
    
    
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            ////////NSLog(@"账号登录dict = %@,urlStr = %@",data,urlStr);
            
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                ////////NSLog(@"登录成功");
                BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
                [view removeFromSuperview];
                [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
                [BPShowLoginPrompt showWithName:account];
                NSString *userID = data[@"userID"];
                [ShuZhiZhangUserPreferences setCurrentUserID:userID];    // 存储当前userID
                
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
                [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
                [userInfo setObject:password forKey:@"password"];
                [userInfo setObject:account forKey:@"phoneNumber"];
                [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                [BPShowLoginPrompt showWithName:account];
                [BPLoginPublic userDidLoginAction:userInfo];
                [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_login_cb"];
//                [HTTPRequest requestLogin:[NSString stringWithFormat:@"%@",userInfo[@"userID"]]];
//                []
                [Tracking setLoginWithAccountID:[userInfo objectForKey:@"userID"]];
                // 更新
                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
                
            }else{
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [self gotoLoginViewController];
                
            }
        });
    } failure:^(NSError *error) {
        
    }];
    
}

///**************************************//

-(void)requestLoginWithAccount:(NSString *)account passWord:(NSString *)password token:(NSString *)token{
    
    
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    NSString  *channelId = [ShuZhiZhangUserPreferences CurrentChannelId];
    [dict setObject:channelId forKey:@"channelID"];
    [dict setObject:account forKey:@"userID"];
    [dict setObject:@"2"forKey:@"type"];
    [dict setObject:dateStr forKey:@"ts"];
    [dict setObject:[ShuZhiZhangUtility md5String:password] forKey:@"pwd"];
    ////////NSLog(@"账号密码登录");
    
    NSString *sortStr = [ShuZhiZhangUtility sortHttpString:dict];
    NSString * signStr = [NSString stringWithFormat:@"%@&key=%@",sortStr,appsecret];
    NSString *sign = [ShuZhiZhangUtility md5String:signStr];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@",GLOBAL_LOGIN_API_URL,@"login",appid,sortStr,sign];
    
    ////////NSLog(@"账号登录dict = %@,urlStr = %@",dict,urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [BPQLoadingView hideWithAnimated:NO];
            if (data.count==0) {
                [BPCustomNoticeBox showCenterWithText:@"数据错误" duration:2.0];
                return ;
            }
            
            ////////NSLog(@"登录dict = %@",data);
            if ([[data objectForKey:@"ret"] intValue]==0) {
                
                //                [self removeFromSuperview];
                ////////NSLog(@"登录成功");
                BPLoginView *view = [(BPLoginView *)[ShuZhiZhangUtility getCurrentViewController].view viewWithTag:9999];
                [view removeFromSuperview];
                [BPCustomNoticeBox showCenterWithText:@"登录成功" duration:2.0];
                [BPShowLoginPrompt showWithName:account];
                NSString *userID = data[@"userID"];
                [ShuZhiZhangUserPreferences setCurrentUserID:userID];    // 存储当前userID
                
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:data];
                [userInfo setObject:account forKey:@"userID"] ;
                [userInfo setObject:[ShuZhiZhangUserPreferences CurrentAppId] forKey:@"appID"];
                [userInfo setObject:password forKey:@"password"];
                [userInfo setObject:[NSNull null] forKey:@"phoneNumber"];
                [[NSUserDefaults standardUserDefaults] setObject:[userInfo objectForKey:@"id"] forKey:@"reportID"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [BPLoginPublic userDidLoginAction:userInfo];
                [BPLoginPublic userDidLoginOrRegister:userInfo ename:@"sdk_login_cb"];
                [BPShowLoginPrompt showWithName:account];
                
                // 更新
                NSString *sqlStr = [NSString stringWithFormat:@"update %@ set token = '%@',tokenCreateTime= '%@' where userID = '%@'",BPUserInfoTableName,[data objectForKey:@"token"],[data objectForKey:@"tokenCreateTime" ],account];
                //                [userInfoTable UpdateDataToTable:sqlStr];
                
                
            }else{
                
                [BPLoginPublic loginErrorTishi:[[data objectForKey:@"ret"] intValue]];
                [self gotoLoginViewController];
                
            }
        });
    } failure:^(NSError *error) {
        ////////NSLog(@"s失败");
        
    }];
    
}


//传用户名，密码，类型进行登陆，主要用于被其他应用呼起时的登陆
-(void) loginWithUserName:(NSString *)userName AndPassword:(NSString *)password Type:(int)type
{
    //帐户
    if(type == 0)
    {
        [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithAccount:userName Password:password];
        return;
    }
    //微信
    else if(type == 1)
    {
        [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithWeChat:userName NickName:password];
        return;
    }
    //QQ
    else if(type==2)
    {
        [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLoginWithQQAccount:userName NickName:password];
        return;
    }
  
}

//注销用户
-(void) BPLogout
{
    if([[ShuZhiZhangUserPreferences CurrentUserID] intValue]<0)
    {
        return;
    }
    //隐藏功能球
    [BPButtonBoard hideDefaultButtonBoardAndClose];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"AccountFormYingSDKApp"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"PasswordFormYingSDKApp"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"TypeFormYingSDKApp"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePassword"];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingameAccount"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhonePassword"];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"acingamePhone"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"loginway"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [(BPRegisterAndLoginRequest *)self.BPBaseRequest requestLogout];
    
//    [self gotoLoginViewController];
    
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    [userInfoTable UpdateDataToTable:[NSString stringWithFormat:@"update %@ set logoutFlag = 1 where uid = %@",BPUserInfoTableName,[ShuZhiZhangUserPreferences CurrentUserID]]];
    NSString *str = [NSString stringWithFormat:@"select * from %@ where uid = %@",BPUserInfoTableName,[ShuZhiZhangUserPreferences CurrentUserID]];
    //注销的是新浪登陆时，删除本地保存的新浪帐号
    NSDictionary *dic = [[userInfoTable queryForDataWithSql:str] objectAtIndex:0];
    if([[dic objectForKey:@"userType"] intValue] == 1)
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"SinaWeiboAuthData"];
    }
    [userInfoTable release];
    [ShuZhiZhangUserPreferences clearUserInfo];
    [BPLoginPublic postLogoutSuccessNotification];
    
    
}



-(void) loginSuccess:(int)flag userInfoDic:(NSMutableDictionary *)dic
{
    [dic setObject:[NSNumber numberWithInt:flag] forKey:@"userType"];

    if(flag == 0)
    {
        [BPShowLoginPrompt showWithName:[dic objectForKey:@"nickname"]];
    }
    else if(flag == 1)
    {
        [dic setObject:@" " forKey:@"password"];
        [BPShowLoginPrompt showWithName:[dic objectForKey:@"nickname"]];
    }
    else if(flag == 2)
    {
        [dic setObject:@" " forKey:@"password"];
        [BPShowLoginPrompt showWithName:[dic objectForKey:@"nickname"]];
    }
    else if(flag == 3)
    {
        [dic setObject:@" " forKey:@"password"];
        [BPShowLoginPrompt showWithName:[dic objectForKey:@"nickname"]];
    }
    [BPLoginPublic userDidLoginAction:dic];
}


-(void) requestDidFinished:(ASIHTTPRequest *)request
{
    
    NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [BPQLoadingView hideWithAnimated:NO];
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        
        int response = [[dic objectForKey:@"result"] intValue];
        //登陆成功
        if(response >0)
        {
            [dic setObject:[userInfo objectForKey:@"password"] forKey:@"password"];
            [self loginSuccess:0 userInfoDic:dic];
        }
        else
        {
            [self gotoLoginViewController];
        }
    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"SinaWeiboLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [BPQLoadingView hideWithAnimated:NO];
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        
        int response = [[dic objectForKey:@"result"] intValue];        //登陆成功
        if(response >0)
        {
            [self loginSuccess:1 userInfoDic:dic];
        }
        else
        {
            [self gotoLoginViewController];
        }
    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"qqAccountLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [BPQLoadingView hideWithAnimated:NO];
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        
        int response = [[dic objectForKey:@"result"] intValue];
        //登陆成功
        if(response >0)
        {
            [self loginSuccess:3 userInfoDic:dic];
        }
        else
        {
            [self gotoLoginViewController];
        }
    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"TCWeiboLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [BPQLoadingView hideWithAnimated:NO];
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        
        int response = [[dic objectForKey:@"result"] intValue];
        //登陆成功
        if(response >0)
        {
            [self loginSuccess:2 userInfoDic:dic];
        }
        else
        {
            [self gotoLoginViewController];
        }

    }
    else if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPLogout"])
    {
        //注销成功
//        if([[request responseString] intValue] >0)
//        {
//            [self gotoLoginViewController];
//            
//            BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
//            [userInfoTable UpdateDataToTable:[NSString stringWithFormat:@"update %@ set logoutFlag = 1 where uid = %@",BPUserInfoTableName,[ShuZhiZhangUserPreferences CurrentUserID]]];
//            [userInfoTable release];
//            
//            [BPLoginPublic postLogoutSuccessNotification];
//            
//            [ShuZhiZhangUserPreferences clearUserInfo];
//        }
    }
    else if ([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"thirdAutoLogin"]){
        
        
        NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:[request responseData] options:NSJSONReadingMutableContainers error:nil];
        
        int response = [[dic objectForKey:@"result"] intValue];        //注册成功
        if(response >0)
        {
            [dic setObject:@"0" forKey:@"userType"];
            [dic setObject:@"" forKey:@"password"];
            [self loginSuccess:0 userInfoDic:dic];
            [BPLoginPublic saveUserInfoToDatabase:dic];
            ////////NSLog(@"thirdAutoLogin success");
        }
        else
        {
            ////////NSLog(@"thirdAutoLogin---%@",request.responseString);
        }
        
    }
     else
    {
        [self checkGameVersionUpdataDidFinished:request];
    }
}

-(void) requestDidFailed:(ASIHTTPRequest *)request
{
     NSDictionary *userInfo = request.userInfo;
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"BPLogin"])
    {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
       // [BPCustomPromptBox showWithTitle:@"登陆失败，请检查你的网络状态" AndDisappearSecond:2];
        [BPCustomNoticeBox showCenterWithText:@"登陆失败，请检查你的网络状态" duration:2.0];
    }
}

@end
