//
//  BPLoginPublic.m
//  BigPlayerSDK
//
//

#import "BPLoginPublic.h"
#import "BPOperateTable.h"
#import "BPPublicRequest.h"
//#import "BPApplePay.h"
#import "DatabaseDAO.h"
#import "BPPublicHandle.h"
#import "ShuZhiZhangIAPPurchaseClass.h"
#import "HGHDeviceReport.h"

@implementation BPLoginPublic

//创建账单信息表
+(void) createPaymentInfoTable
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    
    BOOL result= [userInfoTable CreateTableToDataBase:BPPaymentInfoTableName SQLString:@"platformOrderID text primary key ,cpOrderID text, userID text,transactionReceipt text, jsonDataString text,OrderStatus text"];
    if (result) {
        ////////NSLog(@"创建账单表成功");
        
    }else{
        ////////NSLog(@"创建账单表失败");
        
    }
    
    [userInfoTable release];
    
}


//将登陆的玩家账单保持到本地数据库
+(void) savePaymentInfoToDatabase:(NSMutableDictionary *)dic{
    
    [self createPaymentInfoTable];
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    NSString *sqlStr = [NSString stringWithFormat:@"insert into %@ (platformOrderID, cpOrderID, userID, transactionReceipt, jsonDataString, OrderStatus) values ( :platformOrderID, :cpOrderID, :userID,:transactionReceipt,  :jsonDataString, :OrderStatus)",BPPaymentInfoTableName];
    [userInfoTable insertDataToTable:sqlStr withParameterDictionary:dic];
    [userInfoTable release];
}



//创建用户信息数据库
+(void) createUserInfoTable
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    
     BOOL result= [userInfoTable CreateTableToDataBase:BPUserInfoTableName SQLString:@"userID text primary key,password text , yingID text, accountType text, phoneNumber text, token text,tokenCreateTime text"];
    if (result) {
        ////////NSLog(@"创建用户表成功");
        
    }else{
        ////////NSLog(@"创建用户表失败");
        
    }
    [userInfoTable release];
}

//将登陆的玩家信息保持到本地数据库
+(void) saveUserInfoToDatabase:(NSMutableDictionary *)dic
{
   // [self createUserInfoTable];
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    
    NSString *sqlStr = [NSString stringWithFormat:@"insert into %@ (userID, password, yingID, accountType, phoneNumber, token, tokenCreateTime) values (:userID, :password, :yingID, :accountType, :phoneNumber, :token,:tokenCreateTime)",BPUserInfoTableName];
   
    //普通登录时，才保存到keyChain里。
    if([dic.allKeys containsObject:@"userType"] && [dic objectForKey:@"userType"] != [NSNull null] && [[dic objectForKey:@"userType"] intValue] == 0)
    {
        [ShuZhiZhangUtility saveAccountAndPasswordToKeyChain:[dic objectForKey:@"username"] AndPassword:[dic objectForKey:@"password"]];
    }
    
    [[NSUserDefaults standardUserDefaults ] setObject:[dic objectForKey:@"csPhone"] forKey:@"csPhoneNumberOnLine"];
    
    
    [userInfoTable insertDataToTable:sqlStr withParameterDictionary:dic];
    [userInfoTable release];
    
    [ShuZhiZhangUserPreferences setUserInfoWithDic:dic];
    [ShuZhiZhangUserPreferences setServicePhoneAndOtherInfo:dic];
    
    // 创建用户文件夹
    NSString * userFolder = [NSString stringWithFormat:@"user_%@",[ShuZhiZhangUserPreferences CurrentUserID]];
    [BPFilePathManager createUserFolderWithName:userFolder];
    
    [ShuZhiZhangUserPreferences setCurrentUserID:[dic objectForKey:@"userID"]];

    // 数据库DAO初始化（用户）
    [DatabaseDAO getSharedDatabaseDAO];
    [DatabaseDAO changeDatabaseDAO];

    [[BPPublicHandle sharedPublicHandle] getOffLineMessage];
}

//发送登陆成功的消息
+(void) postLoginSuccessNotification:(NSMutableDictionary *)dic
{
    //////NSLog(@"post3333333");
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:dic];
    [userInfo setObject:@"BPLoginSuccess" forKey:@"result"];
    [userInfo setObject:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelID"];
    [ShuEnter SharedYingApplePayPlatform].loginBackBlock(userInfo);
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"BPLoginResult" object:nil userInfo:userInfo];
    
    
}

+(void) userDidLoginOrRegister:(NSDictionary *)dic ename:(NSString *)ename
{
    [HGHDeviceReport HGHreportDeviceInfo:dic ename:ename];
}


//发送第三方登陆成功的消息
+(void) postThirdLoginSuccessNotification
{
     NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObject:@"BPLoginSuccess"forKey: @"result"];
    [userInfo setObject:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelID"];

    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
    
}


//发送ShuZhiZhangSDK第三方登陆成功的消息
+(void) postThirdLoginSuccessNotificationOfOpenId:(NSDictionary *)dict loginType:(NSString *)loginType
{
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:dict];
    [userInfo setObject:@"BPLoginSuccess" forKey:@"result"];
    [userInfo setObject:loginType forKey:@"LoginType"];
    [userInfo setObject:[ShuZhiZhangUserPreferences CurrentChannelId] forKey:@"channelID"];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
    
}



//发送登陆失败的消息
+(void) postLoginFailNotification:(NSString *)error
{
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"BPLoginFail",@"result",error,@"error",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
}

//发送注销成功的消息
+(void) postLogoutSuccessNotification
{
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"BPLogoutSuccess",@"result",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
}

//发送注销失败的消息
+(void) postLogoutFailNotification:(NSString *)error
{
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"BPLogoutFail",@"result",error, @"error",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:BPLoginResultNotification object:nil userInfo:userInfo];
}

//登陆成功后
+(void) userDidLoginAction:(NSMutableDictionary *)dic
{
    [self saveUserInfoToDatabase:dic];
    ////////NSLog(@"dic=%@",dic);
    ////////NSLog(@"hghtest==============登录成功之后");
    [dic removeObjectForKey:@"password"];
    [dic removeObjectForKey:@"phoneNumber"];
    [dic removeObjectForKey:@"accountType"];
    
//    [[NSUserDefaults standardUserDefaults] setObject:dic[@"userID"] forKey:@"reportID"];
//    [[NSUserDefaults standardUserDefaults] synchronize];

    [self postLoginSuccessNotification:dic];  // 通知到游戏客户端

   //  [ShuZhiZhangIAPPurchaseClass  verifyReceiptFromCompanyServerWhenAccident];   // 补单
}

//第三方登陆成功后
+(void) ThirdUserDidLoginAction:(NSMutableDictionary *)dic
{
    [self saveUserInfoToDatabase:dic];
    
   // [ShuZhiZhangIAPPurchaseClass  verifyReceiptFromCompanyServerWhenAccident];   // 补单
}


//设置输入框的一些属性
+(void) setTextFieldProperty:(UITextField *)userField withDelegate:(id)delegate
{
    userField.delegate = delegate;
   
    userField.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
//    userField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    userField.layer.borderWidth =1.0;
    userField.layer.cornerRadius =5.0;
    userField.font = [UIFont systemFontOfSize:14];
    userField.textColor = [UIColor colorWithRed:30/255.0f green:30/255.0f blue:30/255.0f alpha:1];
    
    userField.textAlignment = NSTextAlignmentLeft;
    userField.keyboardType = UIKeyboardTypeASCIICapable;
    
    userField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //是否纠错
    userField.autocorrectionType = UITextAutocorrectionTypeNo;
    //首字母是否大写
    userField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    userField.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
    
}




//判断两个密码是否有效
+(BOOL) checkTwoPasswordValid:(NSString *)password ConfirmPassword:(NSString *)password2
{
    NSString *regularExpression = @"^[A-z0-9_@.-]{6,18}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    if ([regextestmobile evaluateWithObject:password] == NO)
    {
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
        [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPPasswordInvalidPrompt" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    if (!([password isEqualToString:password2])) {
        //        remindLabel.text = @"密码不一致";
        // [BPCustomPromptBox showWithTitle:[BPLanguage getStringForKey:@"BPTwoPasswordInconsistent" InTable:@"BPMultiLanguage"] AndDisappearSecond:2];
        
         [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPTwoPasswordInconsistent" InTable:@"BPMultiLanguage"] duration:2.0];
        return NO;
    }
    return YES;
}

#pragma mark ------UIText delegate----
//视图上移
+(void) ViewScrollUp_little:(UIView *) textField WillScrollView:(UIView *)scrollView
{
    if(BPDevice_is_ipad)
    {
        return;
    }
    int keyboardHeight;
    int screenHeight;
    CGPoint point = [textField convertPoint:CGPointMake(0, 0) toView:scrollView];
    int viewHeight = textField.frame.size.height;
    if(SCREEN_IS_LANDSCAPE)
    {
        keyboardHeight=180.0f; //220.0f; //
        screenHeight = [[UIScreen mainScreen] bounds].size.width;
        if (screenHeight - keyboardHeight <= point.y + viewHeight)
        {
            if(viewHeight>80)
            {
                viewHeight = 80;
            }
            //CGFloat y = point.y - (self.view.frame.size.height - keyboardHeight - textField.frame.size.height);
            CGFloat y = keyboardHeight - (screenHeight-point.y) + viewHeight;
            [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
            [UIView setAnimationDuration:0.30f];
            CGPoint point = scrollView.center;
            point = scrollView.center;
            if(y<0)
            {
                y=0;
            }
            point.y -= y;
            scrollView.center = point;
            [UIView commitAnimations];
        }
    }
    else
    {
        keyboardHeight= 250.0f;
        screenHeight = [[UIScreen mainScreen] bounds].size.height;
        if (screenHeight - keyboardHeight <= point.y + viewHeight)
        {
            //CGFloat y = point.y - (self.view.frame.size.height - keyboardHeight - textField.frame.size.height);
            CGFloat y = keyboardHeight - (screenHeight-point.y)+ viewHeight;
            [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
            [UIView setAnimationDuration:0.30f];
            CGPoint point = scrollView.center;
            point.y -= y;
            scrollView.center = point;
            [UIView commitAnimations];
        }
    }
}
//视图下移
+(void) ViewScrollDown_little:(UIView *)willScrollView
{
    if(BPDevice_is_ipad)
    {
        return;
    }
    [UIView beginAnimations:@"srcollView" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.275f];
    //self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    willScrollView.center = CGPointMake(REAL_SCREEN_WIDTH/2, REAL_SCREEN_HEIGHT/2);//self.view.frame.size.height/2+22);
    [UIView commitAnimations];
}

//缩放
+ (CGAffineTransform)transformForOrientation {
    return CGAffineTransformIdentity;
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (orientation == UIInterfaceOrientationLandscapeLeft) {
        return CGAffineTransformMakeRotation(M_PI*1.5);
    } else if (orientation == UIInterfaceOrientationLandscapeRight) {
        return CGAffineTransformMakeRotation(M_PI/2);
    } else if (orientation == UIInterfaceOrientationPortraitUpsideDown) {
        return CGAffineTransformMakeRotation(-M_PI);
    } else {
        return CGAffineTransformIdentity;
    }
}
//显示小屏界面的背景和动画
+(void) showBackImageAndAnimation:(UIView *)superView
{
    UIImageView * backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/gobackground.png"]];
    backImageView.contentMode = UIViewContentModeScaleToFill;
    backImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2, (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2, BPBackImageWidth, BPBackImageHeight);
    
    backImageView.userInteractionEnabled = YES;
    [superView addSubview:backImageView];
    backImageView.tag = 13100;
    [backImageView release];
    
    HJManagedImageV *adImageLeft = (HJManagedImageV*)[superView viewWithTag:2015];
    HJManagedImageV *adImageRight = (HJManagedImageV*)[superView viewWithTag:2015];
    
    backImageView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    [UIView animateWithDuration:0.2
                     animations:^{
                         backImageView.transform = CGAffineTransformScale([self transformForOrientation], 1.1, 1.1);
                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.1
                                          animations:^{
                                              backImageView.transform = CGAffineTransformScale([self transformForOrientation], 1.0, 1.0);
                                          }
                                          completion:^(BOOL finished) {
                                              
                                              [UIView animateWithDuration:0.3
                                                               animations:^{
                                                                   
                                                                   if (SCREEN_IS_LANDSCAPE) {
                                                                       
                                                                       [adImageLeft setFrame:CGRectMake((REAL_SCREEN_WIDTH - BPBackImageWidth)/2-80.0, (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2+10, 75.0,BPBackImageHeight-10)];
                                                                       
                                                                       CGRect rect = adImageRight.frame;
                                                                       rect.origin.y = (REAL_SCREEN_HEIGHT - BPBackImageHeight)/2+10;
                                                                       [adImageRight setFrame:rect];
                                                                       
                                                                       
                                                                   }else{
                                                                       
                                                                       CGRect rect = adImageRight.frame;
                                                                       rect.origin.x = (REAL_SCREEN_WIDTH - BPBackImageWidth)/2;
                                                                       [adImageRight setFrame:rect];
                                                                   }

                                                                   
                                                               }
                                                               completion:^(BOOL finished) {
                                                                   
                                                                   
                                                               }];
                                          }];
                     }];
}

// 提示
+(void) loginErrorTishi:(int) response
{
   
    
    if (response == 100)
    {
        [BPCustomNoticeBox showCenterWithText:@"验证码错误" duration:2.0];
        
    }else if (response == 102)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"验证码错误" duration:2.0];
    }
    else if (response == 109)
    {
        [BPCustomNoticeBox showCenterWithText:@"手机号已经被使用" duration:2.0];
        
    }
    else if (response == 110)
    {
        [BPCustomNoticeBox showCenterWithText:@"手机号非法 " duration:2.0];
    }
    else if (response == 111)
    {
        [BPCustomNoticeBox showCenterWithText:@"用户名或者密码错误" duration:2.0];
        
    }
    else if (response == 112)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"登录已过期" duration:2.0];
    }
    
    else if (response == 113)
    {
        [BPCustomNoticeBox showCenterWithText:@"帐号已注册" duration:2.0];
        
    }
    else if (response == 114)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"手机号不存在" duration:2.0];
    }
    else if (response == 115)
    {
        [BPCustomNoticeBox showCenterWithText:@"发送验证码失败,未知错误" duration:2.0];
    }
    else if (response == 116)
    {
        [BPCustomNoticeBox showCenterWithText:@"操作频繁,请稍后" duration:2.0];
        
    }
    else if (response == 117)
    {
        [BPCustomNoticeBox showCenterWithText:@"账号无效" duration:2.0];
    }
    else if (response == 118)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"签名错误" duration:2.0];
    }
    else if (response == 119)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"第三方账号验证失败" duration:2.0];
    }
    else if (response == 120)
    {
        
        [BPCustomNoticeBox showCenterWithText:@"账号不存在" duration:2.0];
    }
    else
    {
        [BPCustomNoticeBox showCenterWithText:[NSString stringWithFormat:@"操作失败(%d)",response] duration:2.0];
    }
}



@end
