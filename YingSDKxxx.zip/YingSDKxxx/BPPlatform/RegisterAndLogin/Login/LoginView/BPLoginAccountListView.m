//
//  BPLoginAccountListView.m
//  BigPlayerSDK
//

#import "BPLoginAccountListView.h"

@implementation BPLoginAccountListView

- (id)initWithFrame:(CGRect)frame AndArray:(NSArray *)array
{
    self = [super initWithFrame:frame AndArray:array];
    if (self) {
        // Initialization code
        UIView *bakcgroundView = [self viewWithTag:4100];
        bakcgroundView.backgroundColor = [UIColor colorWithRed:250/255.0f green:249/255.0f blue:246/255.0f alpha:1];
        bakcgroundView.alpha = 1;
        
        UIImageView *arrowImage = (UIImageView *)[self viewWithTag:4101];
        [arrowImage removeFromSuperview];
        
        self.listTableView.layer.borderColor = [UIColor colorWithRed:187/255.0f green:187/255.0f blue:187/255.0f alpha:1].CGColor;
        self.listTableView.layer.borderWidth = 1;
    }
    return self;
}

//删除后重新布局
-(void) resetSizeAfterDelete
{
    CGRect frame = self.frame;
    frame.size.height = [self getViewHeiht:dataArray];
    self.frame = frame;
    frame = self.listTableView.frame;
    frame.size.height = [self getViewHeiht:dataArray] - 3;
    self.listTableView.frame = frame;
    UIView *bakcgroundView = [self viewWithTag:4100];
    bakcgroundView.frame = frame;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        
        UIImageView *lineImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/fengexian.png"]];
        lineImage.frame = CGRectMake(5, 40-1, self.frame.size.width-10, 2);
        [cell.contentView addSubview:lineImage];
        lineImage.tag = 4102;
        [lineImage release];

        
        //设置点击高亮
//        cell.textLabel.highlightedTextColor = [UIColor colorWithRed:215/255.0f green:126/255.0f blue:0 alpha:1];
        
        cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
        cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:230/255.0f green:228/255.0f blue:224/255.0f alpha:1];
        
        UILabel *optionsLab = [[UILabel alloc]initWithFrame:CGRectMake(15.0, 0.0,150.0, 40.0)];
        [optionsLab setBackgroundColor:[UIColor clearColor]];
        [optionsLab setTextAlignment:NSTextAlignmentLeft];
        [optionsLab setFont:[UIFont systemFontOfSize:14.0f]];
        [optionsLab setTextColor:[UIColor blackColor]];
        [cell.contentView addSubview:optionsLab];
        optionsLab.tag = 4103;
        [optionsLab release];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(self.frame.size.width - 40, 0, 40, 40);
        [button setBackgroundImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/delAccount.png"] forState:UIControlStateNormal];
        [cell.contentView addSubview:button];
        [button addTarget:self action:@selector(clickDeleteButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    UILabel *optionsLab =  (UILabel *)[cell viewWithTag:4103];
    NSDictionary *dic = [dataArray objectAtIndex:indexPath.row];
    
    if ([[dic objectForKey:@"accountType"] intValue]== 2) {
        
        optionsLab.text =  [dic objectForKey:@"userID"];
        
    }
    return cell;
}

//点击删除历史账号
-(void) clickDeleteButton:(UIButton *)sender
{
    UITableViewCell * cell = (UITableViewCell *)[[sender superview] superview];
    
    if(BP_Show_IOS7)
    {
        cell = (UITableViewCell *)[[[sender superview] superview] superview]; // 真机
        
//      cell = (UITableViewCell *)[[sender superview] superview];  // 模拟器
        
        
    }
    if (BP_IS_OS_8_OR_LATER) {
        
    cell = (UITableViewCell *)[[sender superview] superview]; // 模拟器

    }
    
        
    NSIndexPath * path = [self.listTableView indexPathForCell:cell];
    NSDictionary *dic = [dataArray objectAtIndex:path.row];
    
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    NSString *sqlStr = [NSString stringWithFormat:@"delete from %@ where uid =%@",BPUserInfoTableName,[dic objectForKey:@"uid"]];
    [userInfoTable UpdateDataToTable:sqlStr];
    [userInfoTable release];
    
    [dataArray removeObjectAtIndex:path.row];
    
    NSArray *array = [NSArray arrayWithObject:path];
    
    
    
    [self.listTableView deleteRowsAtIndexPaths:array withRowAnimation:UITableViewRowAnimationFade];
    
    [self.listTableView reloadData];
    
    [self resetSizeAfterDelete]; //重新布局
    
    if(dataArray.count<1)
    {
        [self hideDropDownList]; //隐藏下拉历史账号页面
    }
}


@end
