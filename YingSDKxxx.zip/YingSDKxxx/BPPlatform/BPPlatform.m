//
//  BPPlatform.m
//  BPPlatform
//
//  Created by John Cheng on 13-7-5.
//  Copyright (c) 2016年 John Cheng. All rights reserved.
//

#import "BPPlatform.h"

@implementation BPPlatform

@end
