//
//  ShuZhiZhangOrderInfo.h
//  BigPlayerSDK
//
//

#import <Foundation/Foundation.h>

#import  <UIKit/UIKit.h>

@interface ShuZhiZhangOrderInfo : NSObject

/*
 *   ShuZhiZhangSDK 支付Info
 */
@property (nonatomic, retain) NSString *cpOrderID;  //CP生成的订单ID
@property (nonatomic, retain) NSString *userID;     //用户账号
@property (nonatomic, retain) NSString *yingID;     //SDK平台用户ID
@property (nonatomic, retain) NSString *extension;     ////扩展信息。在支付成功后，会回传给游戏服务器的支付回调地址
@property (nonatomic, retain) NSString *money;         //支付总额。单位是元; 注意微信 分
@property (nonatomic, retain) NSString *gameCallbackUrl;  //游戏服务器回调地址
@property (nonatomic, retain) NSString *productID;  //苹果支付时，在itunesconnect后台申请的道具id
@property (nonatomic, retain) NSString *productName; // 产品名称
@property (nonatomic, assign) int productCount;  //购买的商品数量
@property (nonatomic, retain) NSString *serverID;     //服区ID
@property (nonatomic, retain) NSString *serverName;     //服区名
@property (nonatomic, retain) NSString *roleID;     //角色ID
@property (nonatomic, retain) NSString *roleNick;     //角色昵称
@property (nonatomic, retain) NSString *cpProductID;     //cp的productID




@end
