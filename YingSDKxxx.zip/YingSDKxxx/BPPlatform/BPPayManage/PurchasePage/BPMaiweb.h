//
//  BPMaiweb.h
//  ShuZhiZhangSDK
//
//  Created by SkyGame on 2018/6/27.
//  Copyright © 2018年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShuZhiZhangOrderInfo.h"

@interface BPMaiweb : NSObject

-(void)BPMaiurl:(NSString *)url andparms:(ShuZhiZhangOrderInfo *)orderInfo;

@end
