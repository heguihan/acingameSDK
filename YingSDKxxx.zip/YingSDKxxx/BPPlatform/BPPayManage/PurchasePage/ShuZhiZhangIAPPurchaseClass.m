//
//  ShuZhiZhangIAPPurchaseClass.m
//  BigPlayerSDK
//
//  Created by teamtop on 16/1/5.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import "ShuZhiZhangIAPPurchaseClass.h"
#import <StoreKit/StoreKit.h>
#import "ASIHTTPRequest.h"
#import "ShuZhiZhangOrderInfo.h"
#import "MBProgressHUD.h"
#import "BPLoginPublic.h"
#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "ProgressHUD.h"
#import "HTTPRequest.h"
#import "Tracking.h"
@interface ShuZhiZhangIAPPurchaseClass ()<SKProductsRequestDelegate,SKPaymentTransactionObserver,MBProgressHUDDelegate,ASIHTTPRequestDelegate,HttpRequestBaseDelegate>
{
    NSString* BPyInAppIdentifier;
    ShuZhiZhangOrderInfo *orderInfoPlist;
    
    UIActivityIndicatorView* spinner;
    NSArray *products;    // 商品Array
    NSArray *orderInfoArray;
    
    MBProgressHUD *hud;
    
    ASINetworkQueue *RequestQueue;
    
    id<HttpRequestBaseDelegate> delegate;
    
    SKPaymentTransaction *transactionList;
    
    SKProduct *skProduct;
    BOOL result;

    NSArray *productArray;
}

@end

@implementation ShuZhiZhangIAPPurchaseClass


-(void)dealloc
{
     [orderInfoPlist release];
     [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
     [super dealloc];
 
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    }
    return self;
}


+(ShuZhiZhangIAPPurchaseClass *)SharedBPApplePayPlatform{
    
    static ShuZhiZhangIAPPurchaseClass *applePayClass = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        applePayClass = [[ShuZhiZhangIAPPurchaseClass alloc]init];;
        
    });
    return applePayClass;
}


-(void)showBPProgressHUD
{
    
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows lastObject];
    }
     hud = [[MBProgressHUD alloc]initWithView:window.rootViewController.view];
     hud.center = window.center;
     [window.rootViewController.view addSubview:hud];
     hud.color = [UIColor blackColor];
     hud.delegate = self;
     hud.removeFromSuperViewOnHide = YES;
     hud.labelText = @"正在请求数据,请稍候";
     [hud show:YES];
}



//请求数据
-(void)ApplePurchaseWithProductInfo:(ShuZhiZhangOrderInfo *)orderInfo
{
      [self payToNotifyYingSDKServer:orderInfo]; // 下单
      BPyInAppIdentifier = orderInfo.productID;
    ////////NSLog(@"beginssssss=%@",BPyInAppIdentifier);
    
}

//判断是否可以应用内支付
- (BOOL) canInAppPayment
{
    //你应该根据是否想让越狱的ｉＯＳ设备允许内支付
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Cydia.app"]){
        ////////NSLog(@"越狱版设备!");
        return NO;
        [hud hide:YES];
    }
    if ([SKPaymentQueue canMakePayments]) {
        return YES;
    } else {
        return NO;
        
    }
}

#pragma mark -SKProductsRequestDelegate 获取appstroe产品信息
-(void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    
    NSArray *gameProduct = response.products;
    if (gameProduct.count == 0) {
        NSLog(@"无法获取产品信息,购买失败");
//         [BPCustomNoticeBox showCenterWithText:@"无法获取产品信息,购买失败" duration:2.0];
         [hud hide:YES];
        return;
    }
    NSLog(@"拉起支付");
    for (SKProduct *product in gameProduct) {
        
        ////////NSLog(@"产品标题 %@ ", product.localizedTitle);
        ////////NSLog(@"产品描述信息: %@ ", product.localizedDescription);
        ////////NSLog(@"价格: %@" , product.price);
        ////////NSLog(@"Product id: %@ ", product.productIdentifier);
        
        SKMutablePayment *Mpayment = [SKMutablePayment paymentWithProduct:product];
        int price = [product.price intValue];
    
        [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",price] forKey:@"IAPMoney"];


         [[SKPaymentQueue defaultQueue] addPayment:Mpayment];  //请求已经生效
//           [hud  hide:YES afterDelay:2.0];
//        }
    }
}
// 支付前 服务器下单
- (void)payToNotifyYingSDKServer:(ShuZhiZhangOrderInfo *)orderInfo
{
    
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    // 平台数据
    NSDictionary *platformDic =@{
                                 @"subject" :orderInfo.productName,
                                 @"body":orderInfo.extension,
                                 };
    NSError *parseError = nil;
    NSString *userID = [ShuZhiZhangUserPreferences CurrentUserID];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:platformDic options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString *payPlatformDataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *dateStr = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    /***************************/
    
    /***************************/

    // 3.设置请求体
    NSDictionary *jsonDict = @{
                               @"cpOrderID" : orderInfo.cpOrderID,
                               @"extension" :orderInfo.extension,
                               @"gameCallbackUrl": orderInfo.gameCallbackUrl,
                               @"userID" : userID,
                               @"yingID":[ShuZhiZhangUserPreferences CurrentYingID],
                               @"serverID":orderInfo.serverID,
                               @"serverName":orderInfo.serverName,
                               @"roleID":orderInfo.roleID,
                               @"roleName":orderInfo.roleNick,
                               @"money":orderInfo.money,
                               @"productID" :orderInfo.productID,
                               @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId],
                               @"ts":dateStr,
                               @"payPlatformData": payPlatformDataStr
                        };
    NSString *productHgh = orderInfo.productID;
    NSString *payStr = [self getHttpSing:[NSMutableDictionary dictionaryWithDictionary:jsonDict]];
    NSString * payString = [NSString stringWithFormat:@"%@&key=%@",payStr,appsecret];
    
    ////////NSLog(@"before md5 : %@",payString);
    [HTTPRequest requestGetorder:userID andOrderId:orderInfo.cpOrderID currencytype:@"apple" currencyamount:[NSString stringWithFormat:@"%@",orderInfo.money]];
    
    
    [Tracking setDD:orderInfo.cpOrderID hbType:@"CNY" hbAmount:[orderInfo.money floatValue]];
    NSString *str_sign = [ShuZhiZhangUtility md5String:payString];  //md5
    
   NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@?%@&sign=%@&signType=rsa",GLOBAL_Pay_API_URL,appid,@"appstore",payStr,str_sign ];
    
//    NSLog(@"下单url = %@",urlStr);
    
    [ShuZhiZhangHttpsNetworkHelper postWithUrlString:urlStr parameters:nil success:^(NSDictionary *data) {
//        NSLog(@"SDK server下单返回 data= %@",data);
        
        if (data && [[data objectForKey:@"ret"] intValue] == 0) {
                ////////NSLog(@"iap支付下单OK");
             result = YES;
            // 苹果支付
            ////////NSLog(@"oooo=%@",productHgh);
            ////////NSLog(@"bp=%@",BPyInAppIdentifier);
            self.hghOrderInfoPlist = orderInfo;
            self.yingOrderID = data[@"orderID"];
            NSLog(@"productID=%@",productHgh);
            NSArray *array = @[productHgh];
            ////////NSLog(@"array=%@",array);
            if ( [SKPaymentQueue canMakePayments]) {
                NSSet *set = [NSSet setWithArray:array];
                SKProductsRequest * appStoreRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:set];
                appStoreRequest.delegate = self;
                [appStoreRequest start];
                ////////NSLog(@"允许应用内支付,请求的productID: %@",set);
            }else{
                ////////NSLog(@"不允许应用内支付");
                [BPCustomNoticeBox showCenterWithText:[BPLanguage getStringForKey:@"BPApplePayDeviceNotice" InTable:@"BPMultiLanguage"] duration:2.0];
                [hud hide:YES];
            }
            }else{
              result = NO;
              [hud hide:YES];
        }
    } failure:^(NSError *error) {
        
    }];
    
}



// transaction 交易成功服务器
// Read the Receipt Data 获取
//observer在用户成功购买后提供相应的product
- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    
    ////////NSLog(@"-----支付完成-----苹果订单号=%@------------",transaction.transactionIdentifier);
    
    [[NSUserDefaults standardUserDefaults] setObject:transaction.transactionIdentifier forKey:@"transactionIdentifier"];
    
    NSString * productIdentifier = transaction.payment.productIdentifier;
   // if ([productIdentifier length]>0) {
        // 向自己的服务器验证购买凭证
        [self verifyReceiptFromCompanyServer:transaction];   //这个方法是内支付最重要的方法
   // }
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    [hud hide:YES];
    
}

- (void)request:(SKRequest *)request didFailWithError:(NSError *)error
{
    //处理错误
    [hud hide:YES ];
    [request cancel];
    request = nil;
}

// 交易失败,通知IAP进行UI刷新
- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    
    [hud hide:YES];
    if(transaction.error.code != SKErrorPaymentCancelled) {
        ////////NSLog(@"购买失败");
//        [BPCustomNoticeBox showCenterWithText:@"支付请求失效" duration:2];
    } else {
//        [BPCustomNoticeBox showCenterWithText:@"支付请求已取消" duration:2.0];
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"UserCancel",@"result", nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:BPPayResultNotification object:nil userInfo:userInfo];
   }
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}


// 二次验证的过程
//向服务器请求求验证
// Send the Receipt Data to the App Store
#pragma amrk --- 注意iOS9的session请求

- (void)verifyReceiptFromCompanyServer:(SKPaymentTransaction *)transaction
{
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[[NSBundle mainBundle] appStoreReceiptURL]];//苹果推荐
    NSString *money = [[NSUserDefaults standardUserDefaults] objectForKey:@"IAPMoney"];
    
    if (!urlRequest) { /* ... error ... */
        return;
    }
    //////NSLog(@"kaishiyanz");
    [Tracking setRyzf:self.hghOrderInfoPlist.cpOrderID ryzfType:@"apple" hbType:@"CNY" hbAmount:[money floatValue]];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionTask *task = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString *base64String = [ASIHTTPRequest base64forData:data];
      //  ////////NSLog(@"base64String = %@",base64String);
        /*  渠道参数 */
        NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
        NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
        ////////NSLog(@"yanzheng=%@",self.hghOrderInfoPlist.cpOrderID);
        NSDictionary *jsonDict = @{
                                   @"cpOrderID" : self.yingOrderID,
                                   @"transactionReceipt":base64String,
                                   @"platformOrderID":transaction.transactionIdentifier,
                                   @"money":money
                                };
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:jsonDict];
        NSString *payStr = [self getHttpSing:dict]; // 签名算法字符串
        NSString *payString = [NSString stringWithFormat:@"%@&key=%@",payStr,appsecret];
        NSString *str_sign = [ShuZhiZhangUtility md5String:payString];  //md5 签名
     //   ////////NSLog(@"算出的签名字符串 = %@",str_sign);
        [dict setObject:str_sign forKey:@"sign"];
        
    // 下一步 网络而请求SDK server
        NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@",GLOBAL_Pay_callback_URL,appid,@"appstore"];
        [ShuZhiZhangHttpsNetworkHelper  postWithUrlString:urlStr parameters:jsonDict success:^(NSDictionary *data) {
            if (data &&[[data objectForKey:@"ret"]intValue] == 0) {
                
                [self deletePaymentInfoFromSqliteTableWithOrderId:transaction.transactionIdentifier];
            }else{
                [hud  hide:YES afterDelay:2.0];
            }
        } failure:^(NSError *error) {
            
            [hud  hide:YES afterDelay:2.0];
           
         }];
        
        // 数据库存储
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *string = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        [dict setObject:string forKey:@"jsonDataString"];
        [dict setObject:@"1" forKey:@"OrderStatus"];
        [dict setObject:[ShuZhiZhangUserPreferences CurrentUserID] forKey:@"userID"];
        
        [BPLoginPublic savePaymentInfoToDatabase:dict];   // 存储订单信
        }];
    [task resume];
    
    
    
    
}

// 删除数据库中 已经验证成功的订单
-(void)deletePaymentInfoFromSqliteTableWithOrderId:(NSString *)orderId{
    
        BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
        NSString *sqlStr = [NSString stringWithFormat:@"delete from %@ where platformOrderID =%@",BPPaymentInfoTableName,orderId];
        [userInfoTable UpdateDataToTable:sqlStr];
    
}





#pragma mark - 购买商品
- (void)buyProduct:(SKProduct *)product
{
    // 1.创建票据
    SKPayment *payment = [SKPayment paymentWithProduct:product];
    
    // 2.将票据加入到交易队列中
    [[SKPaymentQueue defaultQueue] addPayment:payment];
    
}


- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSDictionary *userInfo = request.userInfo;
    //出错处理
    [hud hide:YES];
//    [BPCustomNoticeBox showCenterWithText:@"当前网络不可用，请检查你的网络状态" duration:2.0];
    if([[userInfo objectForKey:@"RequestTag"] isEqualToString:@"IapReceiptVerify"]){
        
//       [ShuZhiZhangIAPPurchaseClass verifyReceiptFromCompanyServerWhenAccident];    // 支付验证网络第二次
    }
}


#pragma mark-SKPayment TransactionObserver支付结果
//----监听购买结果
//然后当用户输入正确的appStore帐号密码后进入（再次说明 如果是测试 必须是你注册的测试账号 不能使用真实的AppleID ）
//方法在新交易被创建或更新时都会被调用
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    
    [ProgressHUD dismiss];
    for (SKPaymentTransaction *transaction in transactions) {
        
  
        switch (transaction.transactionState) {
            case SKPaymentTransactionStatePurchased: //交易完成
                
                ////////NSLog(@"交易完成transactionIdentifier= %@", transaction.transactionIdentifier);
                
                [self completeTransaction:transaction];
                
                NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"BPPaySuccess",@"result", nil];
                [[NSNotificationCenter defaultCenter] postNotificationName:BPPayResultNotification object:nil userInfo:userInfo];
                
                break;
            case SKPaymentTransactionStateFailed://交易失败
                [self failedTransaction:transaction];
                
                ////////NSLog(@"交易失败");
                NSMutableDictionary *userInfo1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"BPPayFailed",@"result", nil];
                [[NSNotificationCenter defaultCenter] postNotificationName:BPPayResultNotification object:nil userInfo:userInfo1];
                
                break;
            case SKPaymentTransactionStateRestored://已经购买过该商品
                
                [self restoreTransaction:transaction];
                
                break;
            case SKPaymentTransactionStatePurchasing: //商品添加进列表
                break;
                
            default:
                break;
        }
    }
}





- (void)paymentQueue:(SKPaymentQueue *)queue removedTransactions:(NSArray *)transactions
{
    [hud hide:YES];
}

- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error
{
       [hud hide:YES];
}

-(void)restoreTransaction: (SKPaymentTransaction *)transaction
{
    // 对于已经购买的产品,恢复其处理逻辑
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
}



- (NSString *)getHttpSing:(NSMutableDictionary *)dic
{
    NSString *str = nil;
    NSMutableArray *parameters_array = [NSMutableArray arrayWithArray:[dic allKeys]];
    [parameters_array sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2];
        //return [obj2 compare:obj1];//降序
    } ];
    for (int i = 0; i<parameters_array.count; i++) {
        NSString *key = [parameters_array objectAtIndex: i];
        NSString * value = [dic objectForKey:key];
        value = [self encodeString:value];
        if (i==0) {
            
            str = [NSString stringWithFormat:@"%@=%@",key,value] ;
            
        }else{
            
            str = [NSString stringWithFormat:@"%@&%@=%@",str,key,value];
        }
        
    }
    
    return str;
}

-(NSString*)encodeString:(NSString*)unencodedString{
    
    NSString *encodedString=nil;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0f) {
        
        encodedString = (NSString *)
        CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                  (CFStringRef)unencodedString,
                                                                  NULL,
                                                                  (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                  kCFStringEncodingUTF8));
    }
    
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"%20" withString:@"+"];
    return encodedString;
}



// 登录时二次验证
+ (void)verifyReceiptFromCompanyServerWhenAccident
{
    BPOperateTable *userInfoTable = [[BPOperateTable alloc] initWithDatabaseTypeIsGlobal:YES];
    NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where userID = %@",BPPaymentInfoTableName,[ShuZhiZhangUserPreferences CurrentUserID]];
    NSArray *OrderArr = [userInfoTable queryForDataWithSql:sqlStr];
    ////////NSLog(@"查询账单数据 orderArr= %lu",(unsigned long)OrderArr.count);
    if (!OrderArr.count || OrderArr.count ==0) {
        ////////NSLog(@"木有未验证的账单");
        return;
    }
    
    for(int i = 0;i<OrderArr.count;i++)
    {
        NSDictionary *dic = [OrderArr objectAtIndex:i];
       
            NSData *jsonData = [[dic objectForKey:@"jsonDataString"] dataUsingEncoding:NSUTF8StringEncoding];
            NSError *err;
            NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                        options:NSJSONReadingMutableContainers
                                                                          error:&err];
            [[ShuZhiZhangIAPPurchaseClass SharedBPApplePayPlatform ] verifyReceiptFromCompanyServerWhenLogin:dict];
    }
}

// 断网漏单时二次验证
- (void)verifyReceiptFromCompanyServerWhenLogin:(NSMutableDictionary *)orderInfoDic
{
    /*  渠道参数 */
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    // 3.设置请求体
    // 网络而请求SDK server
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/%@",GLOBAL_Pay_callback_URL,appid,@"appstore"];
    [ShuZhiZhangHttpsNetworkHelper  postWithUrlString:urlStr parameters:orderInfoDic success:^(NSDictionary *data) {
        
        ////////NSLog(@"二次验证返回data = %@",data);
        
        if ([[data objectForKey:@"ret"] intValue] == 0) {
            
            [self deletePaymentInfoFromSqliteTableWithOrderId:[orderInfoDic objectForKey:@"platformOrderID"]];
            
        }
    
    } failure:^(NSError *error) {
        
        
    
    }];
}





@end
