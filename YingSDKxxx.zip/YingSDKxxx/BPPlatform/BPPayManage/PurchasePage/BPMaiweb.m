//
//  BPMaiweb.m
//  ShuZhiZhangSDK
//
//  Created by SkyGame on 2018/6/27.
//  Copyright © 2018年 John Cheng. All rights reserved.
//

#import "BPMaiweb.h"
#import "BPMaiWebview.h"

@implementation BPMaiweb

-(void)BPMaiurl:(NSString *)url andparms:(ShuZhiZhangOrderInfo *)orderInfo
{
    ////////NSLog(@"进来了");
    
    /*
     *   渠道参数
     */
    NSString  *appid = [ShuZhiZhangUserPreferences CurrentAppId];
    NSString  *appsecret = [ShuZhiZhangUserPreferences CurrentAppSecret];
    
    // 平台数据
    NSDictionary *platformDic =@{
                                 @"subject":orderInfo.productName,
                                 @"body":orderInfo.productID
                                 };
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:platformDic options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString *payPlatformDataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
//    NSData *jsonDatahot = [NSJSONSerialization dataWithJSONObject:@{@"ReYun":deviceInfo} options:NSJSONWritingPrettyPrinted error:&parseError];
//    NSString *payPlatformDataStrhot = [[NSString alloc] initWithData:jsonDatahot encoding:NSUTF8StringEncoding];
    // 3.设置请求体
    NSDictionary *jsonDict = @{
                               @"cpOrderID" : orderInfo.cpOrderID,
                               @"extension" :orderInfo.extension,
                               @"gameCallbackUrl": orderInfo.gameCallbackUrl,
                               @"userID" : orderInfo.userID,
                               @"yingID":[ShuZhiZhangUserPreferences CurrentYingID],
                               @"serverID":orderInfo.serverID,
                               @"serverName":orderInfo.serverName,
                               @"roleID":orderInfo.roleID,
                               @"roleName":orderInfo.roleNick,
                               @"money":orderInfo.money,
                               @"productID" :orderInfo.cpProductID,
                               @"channelID":[ShuZhiZhangUserPreferences CurrentChannelId],
                               @"ts":[NSString stringWithFormat:@"%d",(int)[[NSDate date] timeIntervalSince1970]],
                               @"payPlatformData": payPlatformDataStr
                               };
    
    NSString *payStr = [self getHttpSing:[NSMutableDictionary dictionaryWithDictionary:jsonDict]];
    NSString * payString = [NSString stringWithFormat:@"%@&key=%@",payStr,appsecret];
    //  ////////NSLog(@"BeforeMD5 Str = %@",payString);
    
    NSString *str_sign = [ShuZhiZhangUtility md5String:payString];  //md5
    // ////////NSLog(@"str_sign = %@",str_sign);

    NSString *urlStr = [NSString stringWithFormat:@"%@?%@&sign=%@&signType=rsa",url,payStr,str_sign ];
    
    ////////NSLog(@"urlStr222 = %@",urlStr);
    ////////NSLog(@"the end");
    BPMaiWebview *maiwebview = [[BPMaiWebview alloc]init];
    [maiwebview showPurchaseMethodChooseView:urlStr];
    
    
}

-(NSString*)encodeString:(NSString*)unencodedString{
    
    // CharactersToBeEscaped = @":/?&=;+!@#$()~',*";
    // CharactersToLeaveUnescaped = @"[].";
    NSString *encodedString=nil;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0f) {
        encodedString = (NSString *)
        CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                  (CFStringRef)unencodedString,
                                                                  NULL,
                                                                  (CFStringRef)@"!*'(); :@&=+$,/?%#[]",
                                                                  kCFStringEncodingUTF8));
    }
    
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"%20" withString:@"+"];
    
    return encodedString;
}

- (NSString *)getHttpSing:(NSMutableDictionary *)dic
{
    
    NSString *str = nil;
    
    NSMutableArray *parameters_array = [NSMutableArray arrayWithArray:[dic allKeys]];
    
    [parameters_array sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2]; // 升序
        //return [obj2 compare:obj1];//降序
    } ];
    
    for (int i = 0; i<parameters_array.count; i++) {
        
        
        NSString *key = [parameters_array objectAtIndex: i];
        NSString * value = [dic objectForKey:key];
        value = [self encodeString:value];
        
        if (i==0) {
            
            str = [NSString stringWithFormat:@"%@=%@",key,value] ;
            
        }else{
            
            str = [NSString stringWithFormat:@"%@&%@=%@",str,key,value];
        }
        
    }
    
    return str;
}



@end
