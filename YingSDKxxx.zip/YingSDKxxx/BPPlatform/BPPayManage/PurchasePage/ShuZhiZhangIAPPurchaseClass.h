//
//  ShuZhiZhangIAPPurchaseClass.h
//  BigPlayerSDK
//
//  Created by teamtop on 16/1/5.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "ShuZhiZhangOrderInfo.h"


@interface ShuZhiZhangIAPPurchaseClass : NSObject


@property(nonatomic,assign) int receiptValid;

@property(nonatomic,retain) NSMutableDictionary *orderInfoDic;

@property(nonatomic,retain) NSString *signString;

@property(nonatomic, strong)ShuZhiZhangOrderInfo *hghOrderInfoPlist;
@property(nonatomic, strong) NSString *yingOrderID;



+(ShuZhiZhangIAPPurchaseClass *)SharedBPApplePayPlatform;

-(void)ApplePurchaseWithProductInfo:(ShuZhiZhangOrderInfo *)orderInfo;


+ (void)verifyReceiptFromCompanyServerWhenAccident;


@end
