//
//  ShuZhiZhangOrderInfo.m
//  BigPlayerSDK
//
//

#import "ShuZhiZhangOrderInfo.h"

@implementation ShuZhiZhangOrderInfo



@synthesize cpOrderID;  //CP生成的订单ID
@synthesize userID;     //用户ID
@synthesize extension;     ////扩展信息。在支付成功后，会回传给游戏服务器的支付回调地址
@synthesize money;         //支付总额。单位是元; 注意微信 分
@synthesize gameCallbackUrl;  //游戏服务器回调地址
@synthesize productID;  //苹果支付时，在itunesconnect后台申请的道具id
@synthesize productCount;  //购买的商品数量
@synthesize productName; // 产品名称
@synthesize serverID; // 产品名称
@synthesize yingID;    //ShuZhiZhangSDK平台用户唯一ID
@synthesize serverName;
@synthesize roleNick;
@synthesize roleID;

-(void) dealloc
{
    [serverID release];       serverID = nil;
    [yingID release];   yingID =nil;
    [userID release];          userID = nil;
    [cpOrderID release];      cpOrderID = nil;
    [extension release];          extension = nil;
    [money release];      money = nil;
    [productName release];          productName = nil;
    [gameCallbackUrl release];      gameCallbackUrl = nil;
    [productID release];      productID = nil;
    [roleID release];    roleID = nil;
    [serverName release]; serverName=nil;
    [roleNick release]; roleNick = nil;
    [super dealloc];
}


@end
