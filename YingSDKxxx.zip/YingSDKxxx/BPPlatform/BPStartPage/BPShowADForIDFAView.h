//
//  BPShowADForIDFAView.h
//  BigPlayerSDK
//
//  Created by John Cheng on 14/11/18.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPShowADForIDFAView : UIView

@end
