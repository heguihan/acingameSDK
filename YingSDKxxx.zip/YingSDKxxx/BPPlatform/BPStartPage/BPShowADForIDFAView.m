//
//  BPShowADForIDFAView.m
//  BigPlayerSDK
//
//  Created by John Cheng on 14/11/18.
//  Copyright (c) 2015年 John Cheng. All rights reserved.
//

#import "BPShowADForIDFAView.h"
#import "BPLoginPublic.h"


@implementation BPShowADForIDFAView


#pragma 登陆弹出小的自定义UIView初始化 第一页面

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.frame = CGRectMake(0, 0, REAL_SCREEN_WIDTH, REAL_SCREEN_HEIGHT);
        
        UIView *background = [[UIView alloc] initWithFrame:self.frame];
        background.backgroundColor = [UIColor greenColor];
        background.alpha = 0.6;
        [self addSubview:background];
        [background release];
        
        int width = 300;
        UIImageView *ADImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_IDFA_AD_iphone.jpg"]];
        if(BPDevice_is_ipad)
        {
            width = 540;
            ADImageView.image = [UIImage imageNamed:@"ShuZhiZhang.bundle/BP_IDFA_AD_ipad.jpg"];
        }
        ADImageView.frame = CGRectMake((REAL_SCREEN_WIDTH - width)/2, (REAL_SCREEN_HEIGHT - width)/2, width, width);
        ADImageView.tag = 1420;
        [self addSubview:ADImageView];
        ADImageView.userInteractionEnabled = YES;
//        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickAD)];
//        [ADImageView addGestureRecognizer:tap];
//        [tap release];
        [ADImageView release];
         
        UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        closeButton.frame = CGRectMake(0, 0, 49, 46);
        [closeButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_IDFA_AD_close.png"] forState:UIControlStateNormal];
        [closeButton setImage:[UIImage imageNamed:@"ShuZhiZhang.bundle/BP_IDFA_AD_close_sel.png"] forState:UIControlStateHighlighted];
        [closeButton addTarget:self action:@selector(clickCloseButton) forControlEvents:UIControlEventTouchUpInside];
        [ADImageView addSubview:closeButton];
        
        [ShuZhiZhangUtility macaddress];
    }
    return self;
}


#pragma mark --- 点击小 X 号按钮,关闭登陆小弹窗
-(void) clickCloseButton
{
    UIImageView *ADImageView = (UIImageView *)[self viewWithTag:1420];
    [UIView animateWithDuration:.2
                     animations:^{
                         ADImageView.transform = CGAffineTransformScale([BPLoginPublic transformForOrientation], 0.1, 0.1);
                     }
                     completion:^(BOOL finished) {
                         [self removeFromSuperview];
                     }];
}
//点击广告
-(void) clickAD
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/us/app/xuan-yuan-zheng-ba/id734127715?mt=8"]];
}



@end
