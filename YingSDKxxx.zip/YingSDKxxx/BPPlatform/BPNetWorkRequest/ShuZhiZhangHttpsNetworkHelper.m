//
//  ShuZhiZhangHttpsNetworkHelper.m
//  BigPlayerSDK
//
//  Created by SkyGame on 16/10/21.
//  Copyright © 2016年 John Cheng. All rights reserved.
//

#import "ShuZhiZhangHttpsNetworkHelper.h"
#import "RSA.h"
@implementation ShuZhiZhangHttpsNetworkHelper
//定义一个变量
static ShuZhiZhangHttpsNetworkHelper *helper = nil;


//实例化对象
+ (instancetype)LWQ_shareHelper
{
    @synchronized(self) {
        if (!helper) {
            helper = [[ShuZhiZhangHttpsNetworkHelper alloc] init];
        }
        return helper;
    }
}

//get请求
+ (void)getWithUrlString:(NSString *)url parameters:(id)parameters success:(SuccessBlock)successBlock failure:(FailureBlock)failureBlock
{
    [self LWQ_shareHelper];
    NSMutableString *mutableUrl = [[NSMutableString alloc] initWithString:url];
    if ([parameters allKeys]) {
        [mutableUrl appendString:@"?"];
        for (id key in parameters) {
            NSString *value = [[parameters objectForKey:key] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
            [mutableUrl appendString:[NSString stringWithFormat:@"%@=%@&", key, value]];
        }
    }
    NSString *urlEnCode = [[mutableUrl substringToIndex:mutableUrl.length - 1] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlEnCode]];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:helper delegateQueue:queue];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            failureBlock(error);
        } else {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            successBlock(dic);
        }
    }];
    [dataTask resume];
}

//post请求
+ (void)postWithUrlString:(NSString *)url parameters:(id)parameters success:(SuccessBlock)successBlock failure:(FailureBlock)failureBlock
{
    
    [self LWQ_shareHelper];
    //////NSLog(@"urlStxxxxr=%@",url);
    NSArray *urlArr = [url componentsSeparatedByString:@"?"];
    NSURL *nsurl = [NSURL URLWithString:urlArr[0]];
    NSString *postStrAll = @"";
    if (urlArr.count<2) {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:0];
        NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        postStrAll= dataStr;
    }else{
        postStrAll =[url componentsSeparatedByString:@"?"][1];
    }
    //////NSLog(@"hghceshiyanzheng=%@",postStrAll);
    NSString *paramstr = [self getRsaParamStr:postStrAll];
    //////NSLog(@"paramstr=%@",paramstr);
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:nsurl];
    //设置请求方式
    request.HTTPMethod = @"POST";
    ////    NSString *publicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCpl3QVq4zLvq7zwQo5z1hMRBqS0p5JCrYfIb8K833AQ5ghNaQQaOzuGrLg7r4NWl7sL0AUrFSg8VytJfxIUUGFAug6Ngk+ZZLfS3ql3XXCNGKAz91lcNF5MjIHh/x3P32YHfegFGd6Pg1xq7c2ft62+zkMb6VR26RI9yQd6AU/JQIDAQAB";
    //    NSString *postStr = [ShuZhiZhangHttpsNetworkHelper LWQ_parseParams:parameters];
    //    //////NSLog(@"postStr=%@",postStr);
    //    NSString *rsaStr = [RSA encryptString:postNewStr publicKey:publicKey];
        //NSLog(@"rsaStrxxx=%@",paramstr);
    request.HTTPBody = [paramstr dataUsingEncoding:NSUTF8StringEncoding];
    
    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:helper delegateQueue:queue];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //NSLog(@"data=%@",data);
        NSDictionary *resultDict = [self getresponseRsaDict:data];
        if (!data || data == nil) {
            
            return ;
        }
        if (error) {
            
            failureBlock(error);
            //////NSLog(@"requestError = %@",error);
            
        } else {
            
            if (resultDict) {
                
                successBlock(resultDict);
            }
        }
    }];
    [dataTask resume];
}

+(NSDictionary *)getresponseRsaDict:(NSData *)responseData
{
    NSString *publicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCpl3QVq4zLvq7zwQo5z1hMRBqS0p5JCrYfIb8K833AQ5ghNaQQaOzuGrLg7r4NWl7sL0AUrFSg8VytJfxIUUGFAug6Ngk+ZZLfS3ql3XXCNGKAz91lcNF5MjIHh/x3P32YHfegFGd6Pg1xq7c2ft62+zkMb6VR26RI9yQd6AU/JQIDAQAB";
    NSString *dataStr = [[NSString alloc]initWithData:responseData encoding:NSUTF8StringEncoding];
    NSArray *arr = [dataStr componentsSeparatedByString:@","];
    //NSLog(@"arr=%@",arr);
    NSMutableString *mutableResult = @"";
    for (NSString *subStr in arr) {
        NSString *subRsaStr = [RSA decryptString:subStr publicKey:publicKey];
        //NSLog(@"subStr=%@",subRsaStr);
        mutableResult = [mutableResult stringByAppendingString:subRsaStr];
    }
    //NSLog(@"mutaResultStr=%@",mutableResult);
    NSDictionary *resultDict = [self dictionaryWithJsonString:mutableResult];
    return resultDict;
}

+(NSString *)getRsaParamStr:(NSString *)paramstr
{
    NSMutableArray *mutabArr = [NSMutableArray array];
    for (int i=0; i<paramstr.length; i+=30) {
        NSInteger len =(paramstr.length-i)>30?30:paramstr.length-i;
        NSRange range ={i,len};
        [mutabArr addObject:[paramstr substringWithRange:range]];
    }
    NSString *publicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCpl3QVq4zLvq7zwQo5z1hMRBqS0p5JCrYfIb8K833AQ5ghNaQQaOzuGrLg7r4NWl7sL0AUrFSg8VytJfxIUUGFAug6Ngk+ZZLfS3ql3XXCNGKAz91lcNF5MjIHh/x3P32YHfegFGd6Pg1xq7c2ft62+zkMb6VR26RI9yQd6AU/JQIDAQAB";
    //NSLog(@"mutabArr=%@",mutabArr);
    NSMutableString *mutabSTr = @"";
    for (NSString *str in mutabArr) {
        NSString *rsaStr = [RSA encryptString:str publicKey:publicKey];
        if (rsaStr==nil||[rsaStr isEqualToString:@""]) {
            rsaStr=@"";
        }
        mutabSTr = [mutabSTr stringByAppendingString:rsaStr];
        mutabSTr = [mutabSTr stringByAppendingString:@","];
    }
    
    mutabSTr = [mutabSTr  substringToIndex:mutabSTr.length-1];
    return [mutabSTr copy];
    
}

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    //////NSLog(@"json jiexi dic=%@",dic);
    //    if(err) {
    //        //////NSLog(@"json解析失败：%@",err);
    //        return nil;
    //    }
    return dic;
}

////把NSDictionary解析成post格式的NSString字符串
//+ (NSString *)LWQ_parseParams:(NSDictionary *)params
//{
////    NSString *keyValueFormat;
////    NSMutableString *result = [NSMutableString new];
////    NSMutableArray *array = [NSMutableArray new];
////    //实例化一个key枚举器用来存放dictionary的key
////    NSEnumerator *keyEnum = [params keyEnumerator];
////    id key;
////    while (key = [keyEnum nextObject]) {
////        keyValueFormat = [NSString stringWithFormat:@"%@=%@&", key, [params valueForKey:key]];
////        [result appendString:keyValueFormat];
////        [array addObject:keyValueFormat];
////    }
////
////    //////NSLog(@"result = %@",result);
//    if ( !params) {
//
//        return nil;
//    }
//
//    NSString *resultStr;
//
//    for (NSString *key in params) {
//
//       resultStr = [NSString stringWithFormat:@"%@=%@&", key, [params valueForKey:key]];
//
//        [resultStr stringByAppendingString:resultStr];
//    }
//
//    //////NSLog(@"resultStr = %@",resultStr);
//
//    return resultStr;
//}


// 服务器下单
+ (NSString *)parseParams:(NSDictionary *)params
{
    
    NSString *str = nil;
    NSMutableArray *parameters_array = [NSMutableArray arrayWithArray:[params allKeys]];
    
    for (int i = 0; i<parameters_array.count; i++) {
        
        
        NSString *key = [parameters_array objectAtIndex: i];
        NSString * value = [params objectForKey:key];
        value = [self encodeString:value];
        
        if (i==0) {
            
            str = [NSString stringWithFormat:@"%@=%@",key,value] ;
            
        }else{
            
            str = [NSString stringWithFormat:@"%@&%@=%@",str,key,value];
        }
        
    }
    
    return str;
}

+(NSString*)encodeString:(NSString*)unencodedString{
    
    NSString *encodedString=nil;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0f) {
        
        encodedString = (NSString *)
        CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                  (CFStringRef)unencodedString,
                                                                  NULL,
                                                                  (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                  kCFStringEncodingUTF8));
    }
    
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"%20" withString:@"+"];
    return encodedString;
}



#pragma mark - NSURLSessionDelegate 代理方法

//主要就是处理HTTPS请求的
- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler
{
    NSURLProtectionSpace *protectionSpace = challenge.protectionSpace;
    if ([protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        SecTrustRef serverTrust = protectionSpace.serverTrust;
        completionHandler(NSURLSessionAuthChallengeUseCredential, [NSURLCredential credentialForTrust:serverTrust]);
    } else {
        completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
    }
}
@end
