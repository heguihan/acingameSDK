//
//  YingSDKxxx.h
//  YingSDKxxx
//
//  Created by Lucas on 2019/8/29.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YingSDKxxx : NSObject

@end
