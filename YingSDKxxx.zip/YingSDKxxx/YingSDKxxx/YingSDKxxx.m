//
//  YingSDKxxx.m
//  YingSDKxxx
//
//  Created by Lucas on 2019/8/29.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import "YingSDKxxx.h"

@implementation YingSDKxxx

@end
