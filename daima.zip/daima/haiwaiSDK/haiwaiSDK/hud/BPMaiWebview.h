//
//  BPMaiWebview.h
//  YingSDK
//
//  Created by SkyGame on 2018/6/27.
//  Copyright © 2018年 John Cheng. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BPMaiWebview : UIView

+(BPMaiWebview *)shareInstance;
-(void) showProtol:(NSString *)protolStr;

@end
