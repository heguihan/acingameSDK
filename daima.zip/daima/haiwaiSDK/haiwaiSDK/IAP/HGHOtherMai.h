//
//  HGHOtherMai.h
//  haiwaiSDK
//
//  Created by Lucas on 2019/7/25.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HGHOrderInfo.h"
NS_ASSUME_NONNULL_BEGIN

@interface HGHOtherMai : NSObject
+(void)requestWithorderInfo:(HGHOrderInfo *)orderInfo;
@end

NS_ASSUME_NONNULL_END
