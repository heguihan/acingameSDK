//
//  HGHTranslation.h
//  haiwaiSDK
//
//  Created by Lucas on 2019/5/23.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HGHTranslation : NSObject
@property(nonatomic,assign)int registNum;
@property(nonatomic,assign)NSInteger forgotNum;
+(instancetype)shareinstance;

@end

NS_ASSUME_NONNULL_END
