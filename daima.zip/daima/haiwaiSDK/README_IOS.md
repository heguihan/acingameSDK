

如果U8接入完成了， 直接导入SDK和 plugin， info.plist的参数是海外召唤师的参数， 可以直接使用
