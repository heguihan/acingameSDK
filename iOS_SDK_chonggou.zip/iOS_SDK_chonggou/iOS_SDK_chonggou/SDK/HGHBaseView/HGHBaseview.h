//
//  HGHBaseview.h
//  iOS_SDK_chonggou
//
//  Created by Lucas on 2019/11/25.
//  Copyright © 2019 Lucas. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HGHBaseview : UIView
@property(nonatomic,assign)CGFloat baseX;
@property(nonatomic,assign)CGFloat baseY;
@property(nonatomic,assign)CGFloat baseWidth;
@property(nonatomic,assign)CGFloat baseHeight;
//@property(nonatomic,assign)CGPoint baseCenter;

@end

NS_ASSUME_NONNULL_END
